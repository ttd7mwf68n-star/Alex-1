"""
AlexERP — Business Management System — Mobile & Web Server (PWA)
Zero external web framework dependencies (uses Python built-in http.server).
Runs seamlessly on Android (Termux / Pydroid 3), iOS (Pythonista), or PC over Wi-Fi.
"""

from __future__ import annotations

import json
import os
import socket
import ssl
import sys
import threading
import secrets
import time
import urllib.parse
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# Ensure alexerp package is importable
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from alexerp.config import APP_NAME, APP_VERSION, DATABASE_DIR
from alexerp.core.helpers import allocate_discount
from alexerp.database.db import Database
from alexerp.database.transaction import TransactionError
from alexerp.database.backup import BackupManager, BackupValidationError
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.auth_service import AuthService, AuthenticationError
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService
from alexerp.services.security_admin_service import SecurityAdminService, SecurityAdminError
from alexerp.services.session_service import SessionService
from alexerp.services.dashboard_service import DashboardService
from alexerp.services.product_service import ProductService
from alexerp.services.customer_service import CustomerService
from alexerp.services.supplier_service import SupplierService
from alexerp.services.sales_service import SalesService, SalesError
from alexerp.services.sales_order_service import SalesOrderService, SalesOrderError
from alexerp.services.sales_delivery_service import SalesDeliveryService
from alexerp.services.purchase_service import PurchaseService, PurchaseError
from alexerp.services.receipt_service import ReceiptService
from alexerp.services.payment_service import PaymentService, PaymentError
from alexerp.services.trial_balance_service import TrialBalanceService
from alexerp.services.balance_sheet_service import BalanceSheetService
from alexerp.services.general_ledger_service import GeneralLedgerService
from alexerp.ai.tools import ToolBox

TEMPLATE_PATH = Path(__file__).resolve().parent / "templates" / "index.html"
SESSION_TTL_SECONDS = 8 * 60 * 60
MAX_JSON_BODY_BYTES = 1_000_000
def _issue_session(user, ip_address: str = "", device: str = "") -> str:
    return SessionService().create(user, ip_address=ip_address, device=device)


def _lookup_session(token: str):
    return SessionService().validate(token)


def _rows_to_list(rows) -> list[dict]:
    if not rows:
        return []
    return [dict(r) for r in rows]




def _rows_for_user(rows, user: dict) -> list[dict]:
    result = []
    for row in rows or []:
        item = dict(row)
        if item.get("company_id") is None or int(item["company_id"]) != int(user["company_id"]):
            continue
        if item.get("branch_id") is not None and int(item["branch_id"]) != int(user["branch_id"]):
            continue
        result.append(item)
    return result

def _get_default_accounts(company_id: int = 1) -> dict:
    conn = Database.connect()
    rows = conn.execute(
        "SELECT id, account_code FROM chart_of_accounts WHERE company_id=?",
        (company_id,),
    ).fetchall()
    mapping = {r["account_code"]: r["id"] for r in rows}
    return {
        "cash": mapping.get("1101", 2),
        "bank": mapping.get("1102", 3),
        "ar": mapping.get("1201", 4),
        "inv": mapping.get("1301", 5),
        "ap": mapping.get("2101", 7),
        "tax": mapping.get("2201", 8),
        "sales": mapping.get("4101", 12),
        "cogs": mapping.get("5101", 14),
        "adj": mapping.get("5201", 15),
    }


class SecureHTTPServer(ThreadingHTTPServer):
    """Threaded server that stays quiet about failed/aborted TLS handshakes."""

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (ssl.SSLError, ConnectionError, TimeoutError, socket.timeout)):
            return  # port scans, plain-HTTP clients hitting the HTTPS port, dropped phones
        super().handle_error(request, client_address)


class MobileERPHandler(BaseHTTPRequestHandler):
    tls_enabled = False   # set per server by build_server()
    timeout = 30          # seconds a client may stall on a read (slow-client protection)

    API_PERMISSIONS = {
        ("GET", "/api/dashboard"): "dashboard.view",
        ("GET", "/api/products"): "products.view",
        ("GET", "/api/customers"): "customers.view",
        ("GET", "/api/suppliers"): "suppliers.view",
        ("GET", "/api/receipts"): "receipts.view",
        ("GET", "/api/payments"): "payments.view",
        ("GET", "/api/sales"): "sales.view",
        ("GET", "/api/sales/orders"): "sales.view",
        ("GET", "/api/sales/orders/deliveries"): "sales.view",
        ("GET", "/api/purchases"): "purchases.view",
        ("GET", "/api/reports/trial_balance"): "reports.view",
        ("GET", "/api/reports/balance_sheet"): "reports.view",
        ("GET", "/api/reports/ledger"): "reports.view",
        ("GET", "/api/accounts"): "accounts.view",
        ("POST", "/api/products/create"): "products.create",
        ("POST", "/api/customers/create"): "customers.create",
        ("POST", "/api/suppliers/create"): "suppliers.create",
        ("POST", "/api/sales/create"): "sales.create",
        ("POST", "/api/sales/quotations/create"): "sales.create",
        ("POST", "/api/sales/quotations/send"): "sales.create",
        ("POST", "/api/sales/orders/confirm"): "sales.confirm",
        ("POST", "/api/sales/orders/invoice"): "sales.invoice_from_order",
        ("POST", "/api/sales/orders/cancel"): "sales.cancel",
        ("POST", "/api/sales/orders/deliver"): "sales.delivery.post",
        ("POST", "/api/purchases/create"): "purchases.create",
        ("POST", "/api/receipts/create"): "receipts.create",
        ("POST", "/api/receipts/cancel"): "receipts.cancel",
        ("POST", "/api/payments/create"): "payments.create",
        ("POST", "/api/payments/cancel"): "payments.cancel",
        ("POST", "/api/ai/ask"): "ai.use",
        ("GET", "/api/security/roles"): "security.roles.manage",
        ("GET", "/api/security/permissions"): "security.roles.manage",
        ("GET", "/api/security/users"): "security.users.manage",
        ("GET", "/api/security/audit"): "security.audit.view",
        ("GET", "/api/backups"): "backup.view",
        ("POST", "/api/backups/create"): "backup.manage",
        ("POST", "/api/backups/verify"): "backup.view",
        ("POST", "/api/backups/restore"): "backup.manage",
        ("POST", "/api/backups/delete"): "backup.manage",
        ("GET", "/api/security/branches"): "security.users.manage",
        ("POST", "/api/security/roles/create"): "security.roles.manage",
        ("POST", "/api/security/roles/update"): "security.roles.manage",
        ("POST", "/api/security/users/create"): "security.users.manage",
        ("POST", "/api/security/users/update"): "security.users.manage",
    }

    def setup(self):
        if self.tls_enabled:
            # The TLS handshake runs here, in the per-connection thread, so one stalled
            # client can never block the accept loop for everybody else.
            self.request.settimeout(10)
            self.request.do_handshake()
            self.request.settimeout(None)
        super().setup()

    def end_headers(self):
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        if self.tls_enabled:
            self.send_header("Strict-Transport-Security", "max-age=31536000")
        super().end_headers()

    def log_message(self, format, *args):
        # Quiet clean logging
        sys.stdout.write(f"[MobileERP] {self.address_string()} - {format % args}\n")

    def _send_json(self, data, status: int = 200):
        body = json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html: str, status: int = 200):
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid Content-Length.") from exc
        if length < 0:
            raise ValueError("Invalid Content-Length.")
        if length > MAX_JSON_BODY_BYTES:
            raise ValueError("Request body is too large.")
        if length == 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8")
        data = json.loads(raw) if raw else {}
        if not isinstance(data, dict):
            raise ValueError("JSON request body must be an object.")
        return data

    def _authorize_api(self, path: str) -> bool:
        if not path.startswith("/api/") or path == "/api/login":
            return True
        scheme, separator, token = self.headers.get("Authorization", "").partition(" ")
        user = _lookup_session(token.strip()) if separator and scheme.lower() == "bearer" else None
        if user is None:
            self._send_json({"ok": False, "error": "Authentication required."}, 401)
            return False
        self.current_user = user
        # Logout is an authenticated session operation, not a business permission.
        if self.command == "POST" and path == "/api/logout":
            return True
        permission = self.API_PERMISSIONS.get((self.command, path))
        if permission is None:
            self._send_json({"ok": False, "error": "Endpoint is not authorized."}, 403)
            return False
        if not PermissionService().has_permission(int(user["id"]), permission):
            self._send_json({"ok": False, "error": "Insufficient permissions."}, 403)
            return False
        return True

    def do_OPTIONS(self):
        # This same-origin application deliberately does not allow cross-origin API access.
        self.send_response(204)
        self.end_headers()

    def _assert_record_scope(self, table: str, record_id: int) -> None:
        if table not in {"customers", "suppliers", "products", "warehouses"}:
            raise ValueError("Invalid record type.")
        columns = {
            column["name"]
            for column in Database.connect().execute(f"PRAGMA table_info({table})").fetchall()
        }
        branch_column = ", branch_id" if "branch_id" in columns else ""
        row = Database.connect().execute(
            f"SELECT company_id{branch_column} FROM {table} WHERE id=?", (int(record_id),)
        ).fetchone()
        if row is None or int(row["company_id"] or 0) != int(self.current_user["company_id"]):
            raise ValueError("Record does not belong to the signed-in company.")
        if ("branch_id" in row.keys() and row["branch_id"] is not None
                and int(row["branch_id"]) != int(self.current_user["branch_id"])):
            raise ValueError("Record does not belong to the signed-in branch.")

    def _assert_financial_document_scope(self, table: str, record_id: int) -> None:
        if table not in {"receipts", "payments"}:
            raise ValueError("Invalid financial document type.")
        row = Database.connect().execute(
            f"SELECT company_id, branch_id FROM {table} WHERE id=?", (int(record_id),)
        ).fetchone()
        if (row is None or int(row["company_id"] or 0) != int(self.current_user["company_id"])
                or int(row["branch_id"] or 0) != int(self.current_user["branch_id"])):
            raise ValueError("Financial document does not belong to the signed-in company and branch.")

    def _default_warehouse_id(self) -> int:
        row = Database.connect().execute(
            "SELECT id FROM warehouses WHERE company_id=? AND branch_id=? AND is_active=1 ORDER BY id LIMIT 1",
            (self.current_user["company_id"], self.current_user["branch_id"]),
        ).fetchone()
        if row is None:
            raise ValueError("No active warehouse is configured for the signed-in branch.")
        return int(row["id"])

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)

        if not self._authorize_api(path):
            return

        try:
            if path == "/" or path == "/index.html":
                html = TEMPLATE_PATH.read_text(encoding="utf-8")
                return self._send_html(html)

            if path == "/manifest.json":
                manifest = {
                    "name": APP_NAME,
                    "short_name": "AlexERP",
                    "start_url": "/",
                    "display": "standalone",
                    "background_color": "#0F1A2E",
                    "theme_color": "#0F1A2E",
                    "description": "نظام إدارة المبيعات والمخزون والحسابات للهاتف",
                }
                return self._send_json(manifest)

            if path == "/api/dashboard":
                dash = DashboardService()
                company_id = self.current_user["company_id"]
                branch_id = self.current_user["branch_id"]
                return self._send_json({
                    "ok": True,
                    "summary": dash.summary(company_id, branch_id),
                    "trend": dash.sales_trend(7, company_id, branch_id),
                    "top_products": dash.top_products(5, 30, company_id, branch_id),
                    "low_stock": dash.low_stock_items(10, company_id, branch_id),
                    "top_debtors": dash.top_debtors(5, company_id, branch_id),
                })

            if path == "/api/products":
                q = qs.get("q", [""])[0].strip()
                ps = ProductService()
                rows = ps.search(q) if q else ps.list()
                return self._send_json({"ok": True, "items": _rows_for_user(rows, self.current_user)})

            if path == "/api/customers":
                cs = CustomerService()
                return self._send_json({"ok": True, "items": _rows_for_user(cs.get_all(), self.current_user)})

            if path == "/api/suppliers":
                ss = SupplierService()
                return self._send_json({"ok": True, "items": _rows_for_user(ss.get_all(), self.current_user)})

            if path == "/api/receipts":
                rows = Database.connect().execute(
                    "SELECT r.*, c.name AS customer_name FROM receipts r "
                    "LEFT JOIN customers c ON c.id=r.customer_id "
                    "WHERE r.company_id=? AND r.branch_id=? ORDER BY r.id DESC LIMIT 100",
                    (self.current_user["company_id"], self.current_user["branch_id"]),
                ).fetchall()
                return self._send_json({"ok": True, "items": _rows_to_list(rows)})

            if path == "/api/payments":
                rows = Database.connect().execute(
                    "SELECT p.*, s.name AS supplier_name FROM payments p "
                    "LEFT JOIN suppliers s ON s.id=p.supplier_id "
                    "WHERE p.company_id=? AND p.branch_id=? ORDER BY p.id DESC LIMIT 100",
                    (self.current_user["company_id"], self.current_user["branch_id"]),
                ).fetchall()
                return self._send_json({"ok": True, "items": _rows_to_list(rows)})

            if path == "/api/sales":
                sales = SalesService()
                return self._send_json({"ok": True, "items": _rows_for_user(sales.list(), self.current_user)})

            if path == "/api/sales/orders":
                orders = SalesOrderService().list_for_company(
                    int(self.current_user["company_id"]),
                    qs.get("q", [None])[0],
                    int(self.current_user["branch_id"]),
                )
                return self._send_json({"ok": True, "items": _rows_to_list(orders)})

            if path == "/api/sales/orders/deliveries":
                order_id = int(qs.get("order_id", [0])[0])
                delivery_service = SalesDeliveryService()
                order = Database.connect().execute(
                    "SELECT id FROM sales_orders WHERE id=? AND company_id=? AND branch_id=?",
                    (order_id, int(self.current_user["company_id"]), int(self.current_user["branch_id"])),
                ).fetchone()
                if order is None:
                    raise ValueError("أمر البيع غير موجود ضمن الفرع الحالي")
                return self._send_json({
                    "ok": True,
                    "invoices": _rows_to_list(delivery_service.list_invoices_for_order(order_id, int(self.current_user["company_id"]))),
                    "deliveries": _rows_to_list(delivery_service.list_for_order(order_id, int(self.current_user["company_id"]))),
                })

            if path == "/api/purchases":
                purchases = PurchaseService()
                return self._send_json({"ok": True, "items": _rows_for_user(purchases.list(), self.current_user)})

            if path == "/api/reports/trial_balance":
                d_from = qs.get("from", ["2000-01-01"])[0]
                d_to = qs.get("to", [date.today().isoformat()])[0]
                tb = TrialBalanceService().get_report(self.current_user["company_id"], d_from, d_to)
                return self._send_json({"ok": True, "report": tb})

            if path == "/api/reports/balance_sheet":
                d_to = qs.get("to", [date.today().isoformat()])[0]
                bs = BalanceSheetService().get_report(self.current_user["company_id"], d_to)
                return self._send_json({"ok": True, "report": bs})

            if path == "/api/security/roles":
                return self._send_json({"ok": True, "items": SecurityAdminService().list_roles(
                    self.current_user["company_id"], actor_id=self.current_user["id"]
                )})

            if path == "/api/security/permissions":
                return self._send_json({"ok": True, "items": SecurityAdminService().list_permissions()})

            if path == "/api/security/users":
                return self._send_json({"ok": True, "items": SecurityAdminService().list_users(
                    self.current_user["company_id"], actor_id=self.current_user["id"]
                )})

            if path == "/api/backups":
                manager = BackupManager()
                items = []
                for backup in manager.list_backups()[:100]:
                    stat = backup.stat()
                    items.append({
                        "name": backup.name,
                        "size_bytes": stat.st_size,
                        "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
                    })
                can_manage = PermissionService().has_permission(int(self.current_user["id"]), "backup.manage")
                from alexerp.config import AUTO_BACKUP_ENABLED, AUTO_BACKUP_HOUR, AUTO_BACKUP_MINUTE
                state_path = manager.backup_dir / ".daily_backup_state.json"
                try:
                    daily_state = json.loads(state_path.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    daily_state = {}
                schedule = {"enabled": bool(AUTO_BACKUP_ENABLED),
                            "schedule_local": f"{AUTO_BACKUP_HOUR:02d}:{AUTO_BACKUP_MINUTE:02d}",
                            "last_success": daily_state.get("last_success"),
                            "last_error": daily_state.get("last_error"),
                            "runs_while_app_open": True}
                return self._send_json({"ok": True, "items": items, "can_manage": can_manage, "schedule": schedule})

            if path == "/api/security/audit":
                limit = int(qs.get("limit", [100])[0])
                offset = int(qs.get("offset", [0])[0])
                events = AuditService().list_events(
                    company_id=int(self.current_user["company_id"]), limit=limit, offset=offset,
                    module=qs.get("module", [None])[0], action=qs.get("action", [None])[0],
                    entity_type=qs.get("entity_type", [None])[0],
                    user_id=int(qs["user_id"][0]) if qs.get("user_id") else None,
                    date_from=qs.get("from", [None])[0], date_to=qs.get("to", [None])[0],
                )
                return self._send_json({"ok": True, "items": events})

            if path == "/api/security/branches":
                rows = Database.connect().execute(
                    "SELECT id,code,name FROM branches WHERE company_id=? AND is_active=1 ORDER BY name",
                    (self.current_user["company_id"],),
                ).fetchall()
                return self._send_json({"ok": True, "items": _rows_to_list(rows)})

            if path == "/api/accounts":
                conn = Database.connect()
                rows = conn.execute(
                    "SELECT id, account_code, account_name FROM chart_of_accounts WHERE company_id=? ORDER BY account_code",
                    (self.current_user["company_id"],),
                ).fetchall()
                return self._send_json({"ok": True, "items": _rows_to_list(rows)})

            if path == "/api/reports/ledger":
                raw_account_id = qs.get("account_id", [""])[0]
                if not raw_account_id.isdigit() or int(raw_account_id) <= 0:
                    return self._send_json({"ok": False, "error": "A valid account_id is required."}, 400)
                acc_id = int(raw_account_id)
                d_from = qs.get("from", [f"{date.today().year}-01-01"])[0]
                d_to = qs.get("to", [date.today().isoformat()])[0]
                account = Database.connect().execute(
                    "SELECT id FROM chart_of_accounts WHERE id=? AND company_id=? "
                    "AND COALESCE(is_active,1)=1 AND COALESCE(allow_posting,1)=1",
                    (acc_id, self.current_user["company_id"]),
                ).fetchone()
                if account is None:
                    return self._send_json({"ok": False, "error": "Account not found."}, 404)
                report = GeneralLedgerService().get_report(self.current_user["company_id"], acc_id, d_from, d_to)
                return self._send_json({"ok": True, "report": report})

            return self._send_json({"ok": False, "error": "Not found"}, 404)
        except SecurityAdminError as exc:
            return self._send_json({"ok": False, "error": str(exc)}, 400)
        except Exception as exc:
            return self._send_json({"ok": False, "error": str(exc)}, 500)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if not self._authorize_api(path):
            return

        try:
            payload = self._read_json()

            if path == "/api/login":
                username = str(payload.get("username", "")).strip()
                password = str(payload.get("password", "")).strip()
                user = AuthService().login(username, password)
                public_user = {
                    "id": int(user["id"]),
                    "username": user["username"],
                    "full_name": user["full_name"],
                    "role_id": int(user["role_id"] or 0),
                    "company_id": int(user["company_id"]),
                    "branch_id": int(user["branch_id"]),
                }
                return self._send_json({
                    "ok": True,
                    "token": _issue_session(public_user, self.client_address[0], self.headers.get("User-Agent", "")),
                    "user": public_user,
                })

            if path == "/api/logout":
                scheme, _, raw_token = self.headers.get("Authorization", "").partition(" ")
                revoked = SessionService().revoke(raw_token.strip() if scheme.lower() == "bearer" else "",
                                                   user_id=int(self.current_user["id"]))
                return self._send_json({"ok": bool(revoked)})

            if path.startswith("/api/backups/"):
                manager = BackupManager()
                if path == "/api/backups/create":
                    backup = manager.create_backup()
                    info = manager.verify_backup(backup)
                    AuditService.record(user_id=int(self.current_user["id"]), company_id=int(self.current_user["company_id"]),
                                        branch_id=int(self.current_user["branch_id"]), module="backup", action="create",
                                        entity_type="backup", description="إنشاء نسخة احتياطية",
                                        after={"name": backup.name, "table_count": info["table_count"]},
                                        ip_address=self.client_address[0])
                    return self._send_json({"ok": True, "name": backup.name, "verification": info}, 201)
                name = str(payload.get("name", ""))
                if not name or Path(name).name != name or not name.startswith("alex_erp_") or not name.endswith(".db"):
                    return self._send_json({"ok": False, "error": "Invalid backup name."}, 400)
                backup = manager.backup_dir / name
                if backup not in manager.list_backups():
                    return self._send_json({"ok": False, "error": "Backup not found."}, 404)
                if path == "/api/backups/verify":
                    info = manager.verify_backup(backup)
                    return self._send_json({"ok": True, "name": name, "verification": info})
                if path == "/api/backups/restore":
                    if payload.get("confirm") is not True:
                        return self._send_json({"ok": False, "error": "Explicit restore confirmation is required."}, 400)
                    AuditService.record(user_id=int(self.current_user["id"]), company_id=int(self.current_user["company_id"]),
                                        branch_id=int(self.current_user["branch_id"]), module="backup", action="restore_attempt",
                                        entity_type="backup", description="طلب استعادة نسخة احتياطية",
                                        after={"requested_backup": name}, ip_address=self.client_address[0])
                    safety = manager.restore_backup(backup)
                    return self._send_json({"ok": True, "safety_backup": safety.name, "restored": name})
                if path == "/api/backups/delete":
                    if payload.get("confirm") is not True:
                        return self._send_json({"ok": False, "error": "Explicit delete confirmation is required."}, 400)
                    manager.delete_backup(backup)
                    AuditService.record(user_id=int(self.current_user["id"]), company_id=int(self.current_user["company_id"]),
                                        branch_id=int(self.current_user["branch_id"]), module="backup", action="delete",
                                        entity_type="backup", description="حذف نسخة احتياطية",
                                        before={"name": name}, ip_address=self.client_address[0])
                    return self._send_json({"ok": True})

            if path == "/api/security/roles/create":
                role_id = SecurityAdminService().create_role(
                    int(self.current_user["company_id"]), payload.get("code", ""), payload.get("name", ""),
                    payload.get("description", ""), payload.get("permissions", []),
                    actor_id=int(self.current_user["id"]),
                )
                return self._send_json({"ok": True, "id": role_id}, 201)

            if path == "/api/security/roles/update":
                SecurityAdminService().update_role(
                    int(self.current_user["company_id"]), int(payload.get("role_id", 0)), payload.get("name", ""),
                    payload.get("description", ""), payload.get("permissions", []),
                    bool(payload.get("is_active", True)), actor_id=int(self.current_user["id"]),
                )
                return self._send_json({"ok": True})

            if path == "/api/security/users/create":
                user_id = SecurityAdminService().create_user(
                    company_id=int(self.current_user["company_id"]),
                    branch_id=int(payload.get("branch_id", 0)),
                    username=payload.get("username", ""), full_name=payload.get("full_name", ""),
                    password=payload.get("password", ""), role_id=int(payload.get("role_id", 0)),
                    email=payload.get("email", ""), phone=payload.get("phone", ""),
                    actor_id=int(self.current_user["id"]),
                )
                return self._send_json({"ok": True, "id": user_id}, 201)

            if path == "/api/security/users/update":
                SecurityAdminService().update_user(
                    actor_id=int(self.current_user["id"]), company_id=int(self.current_user["company_id"]),
                    user_id=int(payload.get("user_id", 0)), full_name=payload.get("full_name", ""),
                    role_id=int(payload.get("role_id", 0)), branch_id=int(payload.get("branch_id", 0)),
                    is_active=bool(payload.get("is_active", True)), email=payload.get("email", ""),
                    phone=payload.get("phone", ""),
                )
                return self._send_json({"ok": True})

            if path == "/api/products/create":
                ps = ProductService()
                pid = ps.create(
                    company_id=self.current_user["company_id"],
                    branch_id=self.current_user["branch_id"],
                    name=payload.get("name", ""),
                    code=payload.get("code") or None,
                    barcode=payload.get("barcode") or None,
                    purchase_price=float(payload.get("purchase_price") or 0),
                    sale_price=float(payload.get("sale_price") or 0),
                    minimum_stock=float(payload.get("minimum_stock") or 0),
                )
                return self._send_json({"ok": True, "id": pid})

            if path == "/api/customers/create":
                cs = CustomerService()
                code = payload.get("code") or f"C-{int(date.today().strftime('%y%m%d'))}-{os.urandom(2).hex().upper()}"
                cid = cs.create_customer(
                    company_id=self.current_user["company_id"],
                    code=code,
                    name=payload.get("name", "").strip(),
                    phone=payload.get("phone", "").strip(),
                    address=payload.get("address", "").strip(),
                )
                return self._send_json({"ok": True, "id": cid})

            if path == "/api/suppliers/create":
                ss = SupplierService()
                code = payload.get("code") or f"S-{int(date.today().strftime('%y%m%d'))}-{os.urandom(2).hex().upper()}"
                sid = ss.create_supplier(
                    company_id=self.current_user["company_id"],
                    code=code,
                    name=payload.get("name", "").strip(),
                    phone=payload.get("phone", "").strip(),
                    address=payload.get("address", "").strip(),
                )
                return self._send_json({"ok": True, "id": sid})

            if path == "/api/sales/quotations/create":
                customer_id = int(payload["customer_id"])
                self._assert_record_scope("customers", customer_id)
                raw_items = payload.get("items", [])
                if not raw_items:
                    raise ValueError("يجب إضافة صنف واحد على الأقل")
                items = []
                for item in raw_items:
                    product_id = int(item["product_id"])
                    warehouse_id = int(item.get("warehouse_id") or self._default_warehouse_id())
                    self._assert_record_scope("products", product_id)
                    self._assert_record_scope("warehouses", warehouse_id)
                    qty = float(item["quantity"])
                    price = float(item["unit_price"])
                    discount = float(item.get("discount") or 0)
                    tax = float(item.get("tax") or 0)
                    items.append({
                        "product_id": product_id, "warehouse_id": warehouse_id,
                        "quantity": qty, "unit_price": price, "discount": discount,
                        "tax": tax, "total": round(qty * price - discount + tax, 2),
                    })
                number = payload.get("quotation_number") or f"Q-{date.today():%Y%m%d}-{os.urandom(2).hex().upper()}"
                quote_id = SalesOrderService().create_quotation(
                    company_id=int(self.current_user["company_id"]),
                    branch_id=int(self.current_user["branch_id"]), customer_id=customer_id,
                    quotation_number=number,
                    document_date=payload.get("document_date") or date.today().isoformat(),
                    expiry_date=payload.get("expiry_date"), items=items,
                    notes=payload.get("notes", "عرض سعر من تطبيق الهاتف"),
                    created_by=int(self.current_user["id"]),
                )
                return self._send_json({"ok": True, "id": quote_id, "quotation_number": number})

            if path == "/api/sales/quotations/send":
                quote_id = int(payload["quotation_id"])
                row = Database.connect().execute(
                    "SELECT company_id,branch_id FROM sales_orders WHERE id=?", (quote_id,)
                ).fetchone()
                if row is None or int(row["company_id"]) != int(self.current_user["company_id"]) or int(row["branch_id"]) != int(self.current_user["branch_id"]):
                    raise ValueError("عرض السعر غير موجود ضمن الفرع الحالي")
                sent = SalesOrderService().send_quotation(quote_id, int(self.current_user["id"]))
                if sent is False:
                    raise ValueError("انتهت صلاحية عرض السعر وتم تحديث حالته إلى منتهي")
                return self._send_json({"ok": True})

            if path == "/api/sales/orders/confirm":
                order_id = int(payload["order_id"])
                row = Database.connect().execute(
                    "SELECT company_id,branch_id FROM sales_orders WHERE id=?", (order_id,)
                ).fetchone()
                if row is None or int(row["company_id"]) != int(self.current_user["company_id"]) or int(row["branch_id"]) != int(self.current_user["branch_id"]):
                    raise ValueError("أمر البيع غير موجود ضمن الفرع الحالي")
                number = SalesOrderService().confirm_order(
                    order_id, int(self.current_user["id"]), payload.get("order_number")
                )
                if number is False:
                    raise ValueError("انتهت صلاحية عرض السعر وتم تحديث حالته إلى منتهي")
                return self._send_json({"ok": True, "order_number": number})

            if path == "/api/sales/orders/invoice":
                order_id = int(payload["order_id"])
                row = Database.connect().execute(
                    "SELECT company_id,branch_id FROM sales_orders WHERE id=?", (order_id,)
                ).fetchone()
                if row is None or int(row["company_id"]) != int(self.current_user["company_id"]) or int(row["branch_id"]) != int(self.current_user["branch_id"]):
                    raise ValueError("أمر البيع غير موجود ضمن الفرع الحالي")
                accs = _get_default_accounts(int(self.current_user["company_id"]))
                accounts = {"receivable_account": accs["ar"], "sales_account": accs["sales"],
                            "inventory_account": accs["inv"], "cogs_account": accs["cogs"],
                            "tax_account": accs["tax"]}
                invoice_number = payload.get("invoice_number") or f"INV-SO-{date.today():%Y%m%d}-{os.urandom(2).hex().upper()}"
                raw_quantities = payload.get("quantities")
                quantities = {int(k): float(v) for k, v in raw_quantities.items()} if isinstance(raw_quantities, dict) else None
                invoice_id = SalesOrderService().create_invoice_from_order(
                    order_id, invoice_number, payload.get("invoice_date") or date.today().isoformat(),
                    int(self.current_user["id"]), quantities=quantities,
                    notes=payload.get("notes", ""), invoice_accounts=accounts,
                )
                return self._send_json({"ok": True, "invoice_id": invoice_id, "invoice_number": invoice_number})

            if path == "/api/sales/orders/deliver":
                order_id = int(payload["order_id"])
                invoice_id = int(payload["invoice_id"])
                scope = Database.connect().execute(
                    "SELECT id FROM sales_orders WHERE id=? AND company_id=? AND branch_id=?",
                    (order_id, int(self.current_user["company_id"]), int(self.current_user["branch_id"])),
                ).fetchone()
                if scope is None:
                    raise ValueError("أمر البيع غير موجود ضمن الفرع الحالي")
                number = payload.get("delivery_number") or f"DN-{date.today():%Y%m%d}-{os.urandom(2).hex().upper()}"
                quantities = payload.get("quantities")
                if not isinstance(quantities, dict):
                    raise ValueError("يجب إرسال كميات التسليم حسب بنود الفاتورة")
                delivery_id = SalesDeliveryService().create_and_post(
                    order_id=order_id, invoice_id=invoice_id, delivery_number=number,
                    delivery_date=payload.get("delivery_date") or date.today().isoformat(),
                    quantities={int(k): float(v) for k, v in quantities.items()},
                    created_by=int(self.current_user["id"]), notes=payload.get("notes", ""),
                )
                return self._send_json({"ok": True, "delivery_id": delivery_id, "delivery_number": number})

            if path == "/api/sales/orders/cancel":
                order_id = int(payload["order_id"])
                row = Database.connect().execute(
                    "SELECT company_id,branch_id FROM sales_orders WHERE id=?", (order_id,)
                ).fetchone()
                if row is None or int(row["company_id"]) != int(self.current_user["company_id"]) or int(row["branch_id"]) != int(self.current_user["branch_id"]):
                    raise ValueError("أمر البيع غير موجود ضمن الفرع الحالي")
                SalesOrderService().cancel_order(order_id, int(self.current_user["id"]))
                return self._send_json({"ok": True})

            if path == "/api/sales/create":
                accs = _get_default_accounts(self.current_user["company_id"])
                customer_id = int(payload["customer_id"])
                self._assert_record_scope("customers", customer_id)
                items = payload.get("items", [])
                if not items:
                    raise ValueError("يجب إضافة صنف واحد على الأقل")
                for item in items:
                    self._assert_record_scope("products", int(item["product_id"]))
                    self._assert_record_scope("warehouses", int(item.get("warehouse_id") or self._default_warehouse_id()))
                subtotal = round(sum(round(float(i["quantity"]) * float(i["unit_price"]), 2) for i in items), 2)
                discount = round(float(payload.get("discount") or 0), 2)
                tax = round(float(payload.get("tax") or 0), 2)
                allocations = allocate_discount(
                    [round(float(i["quantity"]) * float(i["unit_price"]), 2) for i in items],
                    discount,
                )
                total = round(subtotal - discount + tax, 2)
                paid = round(float(payload.get("paid_amount") or 0), 2)
                remaining = round(total - paid, 2)

                norm_items = []
                for idx, (it, line_discount) in enumerate(zip(items, allocations)):
                    quantity = float(it["quantity"])
                    unit_price = float(it["unit_price"])
                    line_base = round(quantity * unit_price, 2)
                    line_tax = tax if idx == 0 else 0
                    norm_items.append({
                        "product_id": int(it["product_id"]),
                        "warehouse_id": int(it.get("warehouse_id") or self._default_warehouse_id()),
                        "quantity": quantity,
                        "unit_price": unit_price,
                        "discount": line_discount,
                        "tax": line_tax,
                        "total": round(line_base - line_discount + line_tax, 2),
                    })

                inv_num = payload.get("invoice_number") or f"INV-{date.today().strftime('%Y%m%d')}-{os.urandom(2).hex().upper()}"
                inv_id = SalesService().create_invoice(
                    company_id=self.current_user["company_id"],
                    branch_id=self.current_user["branch_id"],
                    customer_id=customer_id,
                    invoice_number=inv_num,
                    invoice_date=payload.get("invoice_date") or date.today().isoformat(),
                    items=norm_items,
                    subtotal=subtotal,
                    discount=discount,
                    tax=tax,
                    total=total,
                    paid_amount=paid,
                    remaining_amount=remaining,
                    notes=payload.get("notes", "فاتورة من تطبيق الهاتف"),
                    created_by=self.current_user["id"],
                    receivable_account=accs["ar"],
                    sales_account=accs["sales"],
                    inventory_account=accs["inv"],
                    cogs_account=accs["cogs"],
                    tax_account=accs["tax"] if tax > 0 else None,
                    cash_account=accs["cash"] if paid > 0 else None,
                )
                return self._send_json({"ok": True, "id": inv_id, "invoice_number": inv_num})

            if path == "/api/purchases/create":
                accs = _get_default_accounts(self.current_user["company_id"])
                supplier_id = int(payload["supplier_id"])
                self._assert_record_scope("suppliers", supplier_id)
                items = payload.get("items", [])
                if not items:
                    raise ValueError("يجب إضافة صنف واحد على الأقل")
                for item in items:
                    self._assert_record_scope("products", int(item["product_id"]))
                    self._assert_record_scope("warehouses", int(item.get("warehouse_id") or self._default_warehouse_id()))
                subtotal = round(sum(round(float(i["quantity"]) * float(i["unit_cost"]), 2) for i in items), 2)
                discount = round(float(payload.get("discount") or 0), 2)
                tax = round(float(payload.get("tax") or 0), 2)
                allocations = allocate_discount(
                    [round(float(i["quantity"]) * float(i["unit_cost"]), 2) for i in items],
                    discount,
                )
                total = round(subtotal - discount + tax, 2)
                paid = round(float(payload.get("paid_amount") or 0), 2)
                remaining = round(total - paid, 2)

                norm_items = []
                for idx, (it, line_discount) in enumerate(zip(items, allocations)):
                    quantity = float(it["quantity"])
                    gross_cost = float(it["unit_cost"])
                    line_base = round(quantity * gross_cost, 2)
                    line_tax = tax if idx == 0 else 0
                    net_unit_cost = (line_base - line_discount) / quantity
                    norm_items.append({
                        "product_id": int(it["product_id"]),
                        "warehouse_id": int(it.get("warehouse_id") or self._default_warehouse_id()),
                        "quantity": quantity,
                        "unit_cost": net_unit_cost,
                        "discount": line_discount,
                        "tax": line_tax,
                        "total": round(line_base - line_discount + line_tax, 2),
                    })

                inv_num = payload.get("invoice_number") or f"PUR-{date.today().strftime('%Y%m%d')}-{os.urandom(2).hex().upper()}"
                inv_id = PurchaseService().create_invoice(
                    company_id=self.current_user["company_id"],
                    branch_id=self.current_user["branch_id"],
                    supplier_id=supplier_id,
                    invoice_number=inv_num,
                    supplier_invoice_number=payload.get("supplier_invoice_number") or inv_num,
                    invoice_date=payload.get("invoice_date") or date.today().isoformat(),
                    items=norm_items,
                    subtotal=subtotal,
                    discount=discount,
                    tax=tax,
                    total=total,
                    paid_amount=paid,
                    remaining_amount=remaining,
                    notes=payload.get("notes", "فاتورة مشتريات من الهاتف"),
                    created_by=self.current_user["id"],
                    supplier_account=accs["ap"],
                    inventory_account=accs["inv"],
                    tax_account=accs["tax"] if tax > 0 else None,
                    cash_account=accs["cash"] if paid > 0 else None,
                )
                return self._send_json({"ok": True, "id": inv_id, "invoice_number": inv_num})

            if path == "/api/receipts/create":
                accs = _get_default_accounts(self.current_user["company_id"])
                customer_id = int(payload["customer_id"])
                self._assert_record_scope("customers", customer_id)
                rc_num = payload.get("receipt_number") or f"REC-{date.today().strftime('%Y%m%d')}-{os.urandom(2).hex().upper()}"
                rc_id = ReceiptService().create_receipt(
                    company_id=self.current_user["company_id"],
                    branch_id=self.current_user["branch_id"],
                    receipt_number=rc_num,
                    receipt_date=payload.get("receipt_date") or date.today().isoformat(),
                    customer_id=customer_id,
                    cash_account=accs["cash"],
                    receivable_account=accs["ar"],
                    amount=float(payload["amount"]),
                    created_by=self.current_user["id"],
                )
                return self._send_json({"ok": True, "id": rc_id, "receipt_number": rc_num})

            if path == "/api/payments/create":
                supplier_id = int(payload["supplier_id"])
                self._assert_record_scope("suppliers", supplier_id)
                accs = _get_default_accounts(self.current_user["company_id"])
                payment_number = payload.get("payment_number") or f"PAY-{date.today():%Y%m%d}-{os.urandom(2).hex().upper()}"
                payment_id = PaymentService().create_payment(
                    company_id=self.current_user["company_id"],
                    branch_id=self.current_user["branch_id"],
                    payment_number=payment_number,
                    payment_date=payload.get("payment_date") or date.today().isoformat(),
                    supplier_id=supplier_id,
                    cash_account=accs["cash"],
                    payable_account=accs["ap"],
                    amount=payload.get("amount"),
                    created_by=self.current_user["id"],
                    notes=str(payload.get("notes") or ""),
                )
                return self._send_json({"ok": True, "id": payment_id, "payment_number": payment_number})

            if path == "/api/payments/cancel":
                payment_id = int(payload["payment_id"])
                self._assert_financial_document_scope("payments", payment_id)
                PaymentService().cancel_payment(payment_id, created_by=self.current_user["id"])
                return self._send_json({"ok": True})

            if path == "/api/receipts/cancel":
                receipt_id = int(payload["receipt_id"])
                self._assert_financial_document_scope("receipts", receipt_id)
                ReceiptService().cancel_receipt(receipt_id, created_by=self.current_user["id"])
                return self._send_json({"ok": True})

            if path == "/api/ai/ask":
                question = str(payload.get("question", "")).strip()
                tb = ToolBox({
                    "id": self.current_user["id"],
                    "company_id": self.current_user["company_id"],
                    "branch_id": self.current_user["branch_id"],
                })
                answer = _smart_local_assistant(question, tb)
                return self._send_json({"ok": True, "answer": answer})

            return self._send_json({"ok": False, "error": "Unknown endpoint"}, 404)
        except (AuthenticationError, SalesError, SalesOrderError, PurchaseError, PaymentError, TransactionError, ValueError) as exc:
            return self._send_json({"ok": False, "error": str(exc)}, 400)
        except SecurityAdminError as exc:
            return self._send_json({"ok": False, "error": str(exc)}, 400)
        except Exception as exc:
            return self._send_json({"ok": False, "error": str(exc)}, 500)


def _smart_local_assistant(q: str, tb: ToolBox) -> str:
    """Built-in smart Arabic financial & inventory assistant (works offline too)."""
    q_low = q.lower()
    summary = tb.get_dashboard_summary()

    if any(k in q_low for k in ["نواقص", "مخزون", "قرب", "نفاد", "كمية"]):
        low = tb.get_low_stock(10)
        if not low:
            return "✅ ممتاز! لا توجد أصناف وصلت إلى حد إعادة الطلب حالياً."
        lines = [
            f"• {item['name']} (المتاح: {item['quantity']} / الحد الأدنى: {item['minimum_stock']})"
            for item in low
        ]
        return "⚠️ الأصناف التي تحتاج إعادة طلب:\n" + "\n".join(lines)

    if any(k in q_low for k in ["مبيعات", "ارباح", "أرباح", "دخل", "ايراد", "إيراد"]):
        top = tb.get_top_products(3, 30)
        top_txt = "\n".join(
            f"• {product['name']}: {product['revenue']:.2f} ج.م"
            for product in top
        ) or "لا توجد مبيعات مسجلة بعد."
        return (
            "📊 ملخص المبيعات:\n"
            f"- مبيعات اليوم: {summary['sales_today']:.2f}\n"
            f"- مبيعات الشهر: {summary['sales_month']:.2f}\n"
            f"- قيمة المخزون الحالي: {summary['stock_value']:.2f}\n\n"
            "🏆 الأكثر مبيعاً (آخر 30 يوم):\n"
            f"{top_txt}"
        )

    if any(k in q_low for k in ["عملاء", "ديون", "مديونية", "مستحقات", "فلوس"]):
        debtors = tb.get_top_debtors(5)
        debtor_text = "\n".join(
            f"• {debtor['name']}: {debtor['current_balance']:.2f}"
            for debtor in debtors
        ) or "لا توجد مديونيات مستحقة."
        return (
            f"💰 إجمالي مستحقات العملاء: {summary['receivables']:.2f}\n\n"
            f"أعلى العملاء مديونية:\n{debtor_text}"
        )

    return (
        f"مرحباً بك في المساعد الذكي لـ {APP_NAME} 👋\n\n"
        "📌 نظرة سريعة على وضع النشاط الآن:\n"
        f"• عدد الأصناف النشطة: {summary['products']} (نواقص: {summary['low_stock']})\n"
        f"• مبيعات اليوم: {summary['sales_today']:.2f} | مبيعات الشهر: {summary['sales_month']:.2f}\n"
        f"• مشتريات الشهر: {summary['purchases_month']:.2f}\n"
        f"• مستحقات العملاء: {summary['receivables']:.2f} | مستحقات الموردين: {summary['payables']:.2f}\n\n"
        "💡 اسألني عن: (النواقص، المبيعات، ديون العملاء، الأكثر مبيعاً)."
    )

def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def build_server(host: str, port: int, tls_context: ssl.SSLContext | None = None) -> ThreadingHTTPServer:
    """Create the server; with a TLS context every connection must speak HTTPS."""
    handler = type("MobileERPHandlerBound", (MobileERPHandler,),
                   {"tls_enabled": tls_context is not None})
    server = SecureHTTPServer((host, port), handler)
    if tls_context is not None:
        server.socket = tls_context.wrap_socket(
            server.socket, server_side=True, do_handshake_on_connect=False)
    return server


_daily_backup_scheduler = None

def run_server(host: str = "0.0.0.0", port: int = 8080):
    from mobile_web.tls_support import TLSConfigError, prepare_tls
    ip = get_local_ip()
    try:
        tls = prepare_tls(host, DATABASE_DIR / "tls", ip)
    except TLSConfigError as exc:
        print(f"[MobileERP] Refusing to start: {exc}", file=sys.stderr)
        raise SystemExit(2)
    create_database()
    seed_database()
    from alexerp.services.party_balance_service import PartyBalanceService
    PartyBalanceService().refresh_all()
    server = build_server(host, port, tls.context if tls else None)
    global _daily_backup_scheduler
    from alexerp.config import AUTO_BACKUP_ENABLED, AUTO_BACKUP_HOUR, AUTO_BACKUP_MINUTE, AUTO_BACKUP_CHECK_SECONDS, AUTO_BACKUP_KEEP
    if AUTO_BACKUP_ENABLED:
        from alexerp.database.backup_scheduler import DailyBackupScheduler
        _daily_backup_scheduler = DailyBackupScheduler(hour=AUTO_BACKUP_HOUR, minute=AUTO_BACKUP_MINUTE,
                                                       interval_seconds=AUTO_BACKUP_CHECK_SECONDS, keep_last=AUTO_BACKUP_KEEP)
        _daily_backup_scheduler.start()
    scheme = "https" if tls else "http"
    print("=" * 56)
    print(f"  {APP_NAME} v{APP_VERSION} — Mobile & Web Edition")
    print("=" * 56)
    print(f"  📱 افتح على نفس الهاتف:  {scheme}://127.0.0.1:{port}")
    if host not in ("127.0.0.1", "localhost", "::1"):
        print(f"  🌐 افتح من أي هاتف/تابلت على نفس الشبكة: {scheme}://{ip}:{port}")
    print("  🔐 لا توجد كلمة مرور افتراضية ثابتة؛ كلمة المرور الأولية تُعرض عند إنشاء حساب admin لأول مرة.")
    if tls:
        print("  🔒 الاتصال مشفّر (TLS 1.2+).")
        if tls.self_signed:
            print("  ⚠️ الشهادة موقّعة ذاتيًا: سيحذّرك المتصفح. تأكد أن البصمة التالية مطابقة قبل المتابعة:")
            print(f"     SHA-256: {tls.fingerprint}")
            print(f"     ملف الشهادة لتثبيته على الهاتف: {tls.cert_path}")
        else:
            print(f"     SHA-256: {tls.fingerprint}")
    else:
        print("  ⚠️ وضع HTTP غير مشفّر (loopback فقط، بطلب صريح من ALEXERP_ALLOW_INSECURE_HTTP=1).")
    print("=" * 56)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
    finally:
        if _daily_backup_scheduler:
            _daily_backup_scheduler.stop()
            _daily_backup_scheduler = None
        server.server_close()
        Database.close()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    run_server(host=os.environ.get("ALEXERP_HOST", "0.0.0.0"), port=port)
