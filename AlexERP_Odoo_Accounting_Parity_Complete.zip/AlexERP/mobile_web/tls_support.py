"""TLS (HTTPS) support for the mobile/web server.

Policy
------
* HTTPS is the default. Plain HTTP is refused unless BOTH are true:
  ``ALEXERP_ALLOW_INSECURE_HTTP=1`` and the server listens on loopback only.
* Production: point ``ALEXERP_TLS_CERT`` and ``ALEXERP_TLS_KEY`` at a real
  certificate (e.g. from Let's Encrypt or your company CA).
* Otherwise a self-signed certificate is generated once (ECDSA P-256, 365 days)
  and stored under ``<data dir>/tls``. It is regenerated automatically when it
  is close to expiry or when the machine's address is no longer in its SAN list.
  Browsers will warn about a self-signed certificate; compare the SHA-256
  fingerprint printed at startup, or install ``cert.pem`` as trusted on the phone.
* Minimum protocol is TLS 1.2.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import ipaddress
import json
import os
import re
import shutil
import socket
import ssl
import subprocess
from dataclasses import dataclass
from pathlib import Path

CERT_VALID_DAYS = 365
RENEW_BEFORE_DAYS = 30
ENV_CERT = "ALEXERP_TLS_CERT"
ENV_KEY = "ALEXERP_TLS_KEY"
ENV_EXTRA_NAMES = "ALEXERP_TLS_EXTRA_NAMES"
ENV_ALLOW_HTTP = "ALEXERP_ALLOW_INSECURE_HTTP"


class TLSConfigError(RuntimeError):
    """TLS cannot be set up as required; the server must not start insecurely."""


@dataclass
class TLSInfo:
    context: ssl.SSLContext
    cert_path: Path
    fingerprint: str
    self_signed: bool


# --------------------------------------------------------------------------
# policy helpers
# --------------------------------------------------------------------------
def is_loopback(host: str) -> bool:
    return host in ("localhost", "::1") or host.startswith("127.")


def insecure_http_requested() -> bool:
    return os.environ.get(ENV_ALLOW_HTTP, "").strip() == "1"


def _valid_dns(name: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?", name))


def _split_names(values) -> tuple[list[str], list[str]]:
    dns: list[str] = []
    ips: list[str] = []
    for value in values:
        value = value.strip()
        if not value:
            continue
        try:
            ips.append(str(ipaddress.ip_address(value)))
        except ValueError:
            if _valid_dns(value):
                dns.append(value)
    return dns, ips


def wanted_names(local_ip: str | None = None) -> tuple[list[str], list[str]]:
    """DNS names and IP addresses the self-signed certificate must cover."""
    candidates = ["localhost", "127.0.0.1", "::1"]
    try:
        candidates.append(socket.gethostname())
    except OSError:
        pass
    if local_ip:
        candidates.append(local_ip)
    candidates += os.environ.get(ENV_EXTRA_NAMES, "").split(",")
    dns, ips = _split_names(candidates)
    return sorted(set(dns)), sorted(set(ips))


# --------------------------------------------------------------------------
# certificate generation
# --------------------------------------------------------------------------
def _write_private(path: Path, data: bytes) -> None:
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)


def _generate_with_cryptography(dns, ips, cert_path: Path, key_path: Path, days: int) -> None:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "AlexERP Mobile (self-signed)")])
    now = _dt.datetime.now(_dt.timezone.utc)
    san = [x509.DNSName(d) for d in dns] + [x509.IPAddress(ipaddress.ip_address(i)) for i in ips]
    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - _dt.timedelta(minutes=5))
        .not_valid_after(now + _dt.timedelta(days=days))
        .add_extension(x509.SubjectAlternativeName(san), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False),
            critical=True)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
        .sign(key, hashes.SHA256())
    )
    _write_private(key_path, key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption()))
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))


def _generate_with_openssl(dns, ips, cert_path: Path, key_path: Path, days: int) -> None:
    exe = shutil.which("openssl")
    if exe is None:
        raise TLSConfigError(
            "Cannot create a self-signed certificate: install the 'cryptography' package "
            "(pip install cryptography) or OpenSSL, or provide ALEXERP_TLS_CERT/ALEXERP_TLS_KEY.")
    san = ",".join([f"DNS:{d}" for d in dns] + [f"IP:{i}" for i in ips])
    old_umask = os.umask(0o077)
    try:
        subprocess.run(
            [exe, "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1",
             "-nodes", "-keyout", str(key_path), "-out", str(cert_path), "-days", str(days),
             "-subj", "/CN=AlexERP Mobile (self-signed)",
             "-addext", f"subjectAltName={san}",
             "-addext", "basicConstraints=critical,CA:FALSE",
             "-addext", "keyUsage=critical,digitalSignature",
             "-addext", "extendedKeyUsage=serverAuth"],
            check=True, capture_output=True, timeout=60)
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as exc:
        raise TLSConfigError(f"OpenSSL could not create the certificate: {exc}") from exc
    finally:
        os.umask(old_umask)


def _generate(dns, ips, cert_path: Path, key_path: Path, days: int) -> None:
    try:
        import cryptography  # noqa: F401
    except ImportError:
        _generate_with_openssl(dns, ips, cert_path, key_path, days)
    else:
        _generate_with_cryptography(dns, ips, cert_path, key_path, days)


# --------------------------------------------------------------------------
# self-signed lifecycle
# --------------------------------------------------------------------------
def _needs_regeneration(tls_dir: Path, dns, ips, renew_days: int) -> bool:
    cert, key, meta = tls_dir / "cert.pem", tls_dir / "key.pem", tls_dir / "meta.json"
    if not (cert.is_file() and key.is_file() and meta.is_file()):
        return True
    try:
        info = json.loads(meta.read_text(encoding="utf-8"))
        have = set(info["sans"])
        not_after = _dt.datetime.fromisoformat(info["not_after"])
    except (ValueError, KeyError, TypeError, OSError):
        return True
    want = {f"DNS:{d}" for d in dns} | {f"IP:{i}" for i in ips}
    if not want <= have:
        return True
    return not_after - _dt.datetime.now(_dt.timezone.utc) < _dt.timedelta(days=renew_days)


def ensure_self_signed(tls_dir: Path, dns, ips, days: int = CERT_VALID_DAYS,
                       renew_days: int = RENEW_BEFORE_DAYS) -> tuple[Path, Path]:
    """Return (cert, key) paths, creating or renewing the self-signed pair if needed."""
    tls_dir = Path(tls_dir)
    tls_dir.mkdir(parents=True, exist_ok=True)
    cert, key, meta = tls_dir / "cert.pem", tls_dir / "key.pem", tls_dir / "meta.json"
    if _needs_regeneration(tls_dir, dns, ips, renew_days):
        # keep the old SANs so an address that was valid before stays valid
        try:
            old = json.loads(meta.read_text(encoding="utf-8"))["sans"]
        except (ValueError, KeyError, TypeError, OSError):
            old = []
        old_dns, old_ips = _split_names([s.split(":", 1)[1] for s in old if ":" in s])
        all_dns, all_ips = sorted(set(dns) | set(old_dns)), sorted(set(ips) | set(old_ips))
        tmp_cert, tmp_key = tls_dir / "cert.pem.tmp", tls_dir / "key.pem.tmp"
        for tmp in (tmp_cert, tmp_key):
            tmp.unlink(missing_ok=True)
        _generate(all_dns, all_ips, tmp_cert, tmp_key, days)
        os.replace(tmp_key, key)
        os.replace(tmp_cert, cert)
        not_after = _dt.datetime.now(_dt.timezone.utc) + _dt.timedelta(days=days)
        meta.write_text(json.dumps({
            "sans": [f"DNS:{d}" for d in all_dns] + [f"IP:{i}" for i in all_ips],
            "not_after": not_after.isoformat(),
        }), encoding="utf-8")
    return cert, key


# --------------------------------------------------------------------------
# context + fingerprint
# --------------------------------------------------------------------------
def fingerprint_sha256(cert_path: Path) -> str:
    der = ssl.PEM_cert_to_DER_cert(Path(cert_path).read_text(encoding="ascii"))
    digest = hashlib.sha256(der).hexdigest().upper()
    return ":".join(digest[i:i + 2] for i in range(0, len(digest), 2))


def build_ssl_context(cert_path: Path, key_path: Path) -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    try:
        ctx.load_cert_chain(str(cert_path), str(key_path))
    except (ssl.SSLError, OSError) as exc:
        raise TLSConfigError(f"Cannot load the TLS certificate/key: {exc}") from exc
    return ctx


def prepare_tls(host: str, tls_dir: Path, local_ip: str | None = None) -> TLSInfo | None:
    """Decide how the server is secured. Returns None only for allowed loopback HTTP."""
    cert_env = os.environ.get(ENV_CERT, "").strip()
    key_env = os.environ.get(ENV_KEY, "").strip()

    if insecure_http_requested():
        if not is_loopback(host):
            raise TLSConfigError(
                f"{ENV_ALLOW_HTTP}=1 is only honoured when the server listens on loopback "
                "(127.0.0.1); refusing to serve plain HTTP on a network interface.")
        return None

    if bool(cert_env) != bool(key_env):
        raise TLSConfigError(f"Set both {ENV_CERT} and {ENV_KEY}, or neither.")
    if cert_env:
        cert_path, key_path, self_signed = Path(cert_env), Path(key_env), False
        for p in (cert_path, key_path):
            if not p.is_file():
                raise TLSConfigError(f"TLS file not found: {p}")
    else:
        dns, ips = wanted_names(local_ip)
        cert_path, key_path = ensure_self_signed(Path(tls_dir), dns, ips)
        self_signed = True

    return TLSInfo(
        context=build_ssl_context(cert_path, key_path),
        cert_path=cert_path,
        fingerprint=fingerprint_sha256(cert_path),
        self_signed=self_signed,
    )
