# TODO

- [x] توسيع اختبارات الانحدار لدورات الشراء والإلغاء والتحويل والمرتجعات وفشل القيود.
- [x] تصحيح المصادقة في API الهاتف، وإضافة جلسات Bearer محدودة العمر، وإزالة CORS المفتوح، وحدّ حجم JSON.
- [x] إزالة كلمة مرور البداية الثابتة؛ كلمة مرور admin الجديدة عشوائية وتظهر في سجل التشغيل، ويمكن تحديدها بمتغير البيئة `ALEXERP_INITIAL_ADMIN_PASSWORD`.
- [x] إصلاح اختيار عناصر الفواتير وتوزيع الخصومات، وحساب فرق الجرد والتحقق من نطاق المخزون.
- [x] تشغيل التحليل النحوي واختبارات الانحدار؛ النتيجة في آخر مراجعة: 16/16 ناجحة.
- [x] مزامنة `current_balance` للعملاء والموردين من الفواتير والتسويات والمرتجعات والإلغاءات؛ تمت إضافة تخصيص الإيصالات/المدفوعات على مستوى الفاتورة في المرحلة 10.
- [x] فحص انتماء العميل/المورد/الحساب/الفرع/المنتج/المستودع للشركة في طبقة الخدمات (بيع، شراء، إيصال، مرتجع) ومركزيًا في `AccountingService.create_entry`.
- [x] إضافة فحوصات الشركة/الفرع والمستودع/المنتج قبل التحويل والتسوية والجرد، وتشديد استعلامات المخزون الأساسية. باقٍ: مراجعة شاملة لكل استعلامات `WHERE id=?` في المستودعات.
- [x] تقييد `CustomerService/SupplierService.update_balance` لمنع تعديل الرصيد يدويًا؛ الرصيد مشتق من المستندات المرحلة.
- [x] المرحلة 2: مراجعة نطاق الشركة/الفرع في قراءات وتعديلات أرصدة المخزون داخل `InventoryService` و`StockService`، مع اختبارات تمنع استخدام مخزن شركة أخرى.
- [ ] اختبار التحديث والترحيل على نسخة احتياطية من قاعدة بيانات فعلية، والتحقق من خطة الاستعادة.
- [ ] مراجعة الأرصدة الوراثية للمستودعات قبل ترحيل مستندات المخزون للمنتجات المتأثرة.
- [x] المرحلة 3: تقييد إلغاء إيصالات العملاء ومدفوعات الموردين بهوية المستخدم النشط والشركة المالكة للمستند، وإضافة اختبار منع الإلغاء عبر الشركات.
- [ ] استكمال مراجعة جميع استعلامات `WHERE id=?` في بقية المستودعات والخدمات (تمت معالجة مسارات إلغاء الإيصالات والمدفوعات فقط في المرحلة 3).
- [ ] اختبار تدفق الواجهة الرسومية من البداية إلى النهاية ومعاينة شاشتي المبيعات والمشتريات على جهاز المستخدم.
- [x] تشفير اتصال الهاتف بـHTTPS (TLS 1.2+) افتراضيًا، مع رفض HTTP خارج loopback. باقٍ: اختبار تثبيت الشهادة على هاتف فعلي (تغيّر عنوان الجهاز عبر DHCP يعيد إصدار الشهادة فتتغير البصمة).

ملاحظة: لم يُشغّل التطبيق بواجهة رسومية في بيئة التطوير، ولم تُرحّل قاعدة بيانات فعلية. احتفظ بنسخة احتياطية قابلة للاستعادة قبل أي تشغيل على بيانات العمل.

## Enterprise Finalization — Phase 6
- [x] Add company-scoped accounting periods.
- [x] Prevent overlapping periods within a company.
- [x] Enforce open-period checks centrally for journal posting.
- [x] Require `accounting.periods.manage` for period creation and closing.
- [x] Audit period creation and closing.
- [x] Block closing when journals are unbalanced, empty, or unposted.
- [x] Add graphical accounting-period management screen (Fiscal Management page).
- [x] Implement transactional year-end closing journal and retained-earnings transfer (Phase 7).
- [ ] Review year-end accounting policy with a qualified accountant and design a separate opening-balance workflow only after reports support fiscal-year boundaries.


## Enterprise Finalization — Phase 7
- [x] Add company-scoped, duplicate-safe fiscal-year closing records.
- [x] Require dedicated `accounting.fiscal_year.close` permission.
- [x] Verify complete, gap-free accounting-period coverage before closing.
- [x] Reject unposted, empty, or unbalanced journals.
- [x] Close revenue and expense balances to retained earnings through a balanced journal.
- [x] Close remaining open periods atomically and record an audit event.
- [x] Add fiscal-year closing UI and retained-earnings account selection (Fiscal Management page).
- [ ] Add fiscal-year-aware reporting before implementing independent opening-balance journals.

## Enterprise Finalization — Phase 9: Financial Reports
- [x] Add company-scoped period profit-and-loss repository/service with Decimal-based totals.
- [x] Exclude unposted journals and cross-company journal/account combinations from the income statement.
- [x] Add income-statement tab to the financial reports screen.
- [x] Add CSV and XLSX export with UTF-8 BOM, RTL worksheet, formatting, filters, and frozen headers.
- [x] Add Arabic-capable PDF export pipeline (requires the declared Arabic shaping dependencies and an Arabic font at runtime).
- [x] Add regression tests for P&L period boundaries, unposted entries, company isolation, invalid dates, and CSV/XLSX exports.
- [x] Add company-scoped invoice-level receipt/payment allocation with Decimal amounts, active/reversed allocation history, and atomic invoice balance updates (Phase 10).
- [x] Reverse invoice allocations and restore open balances when a receipt/payment is cancelled; prevent invoice cancellation while active allocations remain (Phase 10).
- [x] Add customer/supplier aging reports with 0, 1-30, 31-60, 61-90, and over-90 day buckets based on invoice date (Phase 10).
- [x] Add customer/supplier aging tabs to the financial reports screen (Phase 10).
- [ ] Run desktop UI and PDF Arabic rendering on a Windows workstation with all requirements installed.
- [ ] Add fiscal-year comparative statements and validate report presentation with an accountant.


## Enterprise Finalization — Phase 10: Receivables, Payables & Aging
- [x] Add receipt-to-sales-invoice and payment-to-purchase-invoice allocation tables and indexes.
- [x] Enforce company, party, posting status, document date, receipt/payment available balance, and invoice remaining balance.
- [x] Keep party balances correct by subtracting only unapplied receipt/payment amounts after invoice allocations.
- [x] Reverse allocations atomically when receipts/payments are cancelled; block cancellation of invoices with active allocations.
- [x] Add customer and supplier aging services and reports tabs, scoped by company and optional branch.
- [x] Add automated tests for allocation, balance reconciliation, aging buckets, cancellation reversal, and cross-company rejection.
- [x] Add a dedicated graphical allocation workflow for selecting a receipt/payment and distributing it across invoices (Phase 11).
- [x] Add due dates/payment terms to invoice schemas and base aging on due dates (Phase 12).
- [ ] Validate aging and allocations against a migrated production database and accountant-approved samples.

## Enterprise Finalization — Phase 11: Settlement Operations UI
- [x] Add desktop navigation entry for the settlement workspace, gated by receipt/payment/report view permissions.
- [x] Add company-scoped receipt selection and invoice allocation workflow using the Phase 10 domain service.
- [x] Add company-scoped supplier-payment selection and purchase-invoice allocation workflow using the Phase 10 domain service.
- [x] Show available document balance and allocation history, including reversed allocation records.
- [x] Add a consolidated customer/supplier aging dashboard with overdue totals and an explicit invoice-date-basis warning.
- [x] Add static regression checks for navigation, permission checks, company-scoped queries, and domain-service delegation.
- [x] Add full party account statements and contract due-date/payment-term fields (Phase 12).
- [ ] Run the desktop workflow visually on Windows with CustomTkinter installed and test with role-restricted user accounts.


## Enterprise Finalization — Phase 12: Party Statements & Contractual Due Dates
- [x] Add backward-compatible customer/supplier default payment terms and invoice-level terms snapshots.
- [x] Add invoice due-date fields and populate them from party defaults during sales/purchase invoice creation.
- [x] Preserve existing invoice dates and leave legacy due dates NULL; aging falls back to invoice date for legacy records.
- [x] Rebase customer/supplier aging buckets on due date rather than invoice date.
- [x] Add company-scoped customer and supplier document statements with opening/closing balances, running debit/credit, receipts/payments, and returns.
- [x] Add audited payment-terms maintenance with a dedicated permission.
- [x] Add statement and payment-terms tab to the settlements workspace.
- [ ] Validate statement balances against the general ledger for all legacy return/cancellation scenarios and migrated production data.
- [ ] Visually test the desktop page on Windows with CustomTkinter installed.


## Enterprise Finalization — Phase 13: Business Intelligence
- [x] Add company- and optional branch-scoped executive KPIs for posted sales, purchases, gross profit, receipts, payments, and open invoice balances.
- [x] Add equal-length previous-period comparison with safe handling when the previous period is zero.
- [x] Add monthly sales/purchases/gross-profit series with zero-filled months.
- [x] Add company/branch-scoped top-customer and top-product rankings.
- [x] Add a dedicated desktop Business Intelligence page with period selection, KPI cards, monthly chart, comparisons, and rankings.
- [x] Scope the existing home dashboard queries to the signed-in user's company and branch to prevent cross-company dashboard aggregation.
- [x] Add regression tests for KPI calculations, draft exclusion, date validation, period comparison, monthly gaps, rankings, and cross-company isolation.
- [x] Add posted-ledger expense and net-income analytics, scoped by company/branch and including period comparisons; gross profit remains based on sales lines and stored costs.
- [ ] Add a distinct operating-expense classification only after the chart of accounts can reliably distinguish operating expense from other EXPENSE accounts.
- [ ] Add inventory turnover only after validating average inventory valuation across all warehouses and stock movement types.
- [ ] Add cash-flow forecasting only after a documented forecast model and source-data acceptance criteria are approved.
- [ ] Visually test both dashboard pages on Windows with the supported CustomTkinter dependencies installed.

## Enterprise Finalization — Phase 14: Advanced Inventory Intelligence
- [x] Add read-only company/branch-scoped inventory KPIs using operational `product_stock` balances and average cost.
- [x] Surface unresolved legacy stock quantities separately; exclude them from valuation until assigned to a warehouse.
- [x] Add minimum/maximum-stock reorder suggestions with bounded result limits.
- [x] Add warehouse valuation and branch-aware stock aggregation.
- [x] Add non-moving stock analysis based on last `SALE` movement, not arbitrary stock activity.
- [x] Add date- and branch-scoped stock movement summaries.
- [x] Add an Inventory Intelligence desktop page and navigation entry gated by `reports.view`.
- [x] Add regression tests for valuation, reorder recommendations, warehouse and branch scoping, company isolation, legacy balances, non-moving stock, movement summaries, and input validation.
- [ ] Validate inventory valuation against physical counts and the inventory control account on a migrated company database.
- [ ] Implement inventory turnover only after agreeing and validating average inventory valuation and COGS/returns methodology across all movement types.
- [ ] Visually test the inventory intelligence page on Windows with CustomTkinter installed.

## Enterprise Finalization — Phase 15: Purchasing & Supply Chain Workflow
- [x] Add backward-compatible requisition, purchase-order, goods-receipt, and supplier-quotation schema with company/branch keys and indexes.
- [x] Add validated company/branch-scoped requisition and purchase-order creation, including exact requisition-to-order quantity matching.
- [x] Add partial/full goods receipt tracking and prevent over-receipt with atomic rollback.
- [x] Add received-quantity invoice payload generation for the existing purchase-invoice posting service, including PO reference and calculated totals.
- [x] Add supplier quotation capture and price/delivery comparison.
- [x] Add late-delivery tracking, supplier on-time performance, and posted-invoice purchase-price history.
- [x] Add safe cancellation for unreceived purchase orders and audit events for core workflow actions.
- [x] Add a desktop purchasing control-tower page for order status, late deliveries, and supplier performance; gate it with `purchases.view`.
- [x] Add regression tests for requisitions, order conversion, partial/full receipts, over-receipt rollback, quotation ranking, tenant scope, late deliveries, invoice payloads, cancellation, and input validation.
- [ ] Add full create/edit/approve forms for requisitions, purchase orders, supplier quotes, and goods receipts to the desktop UI.
- [ ] Integrate purchase-order conversion as a guided invoice-posting wizard and persist an explicit invoice-to-order-line allocation table (current payload uses a PO marker in invoice notes).
- [ ] Define whether physical stock is recognized at goods receipt or invoice posting; current implementation deliberately leaves stock/accounting recognition to existing purchase invoice posting to avoid double posting.
- [ ] Visually test the purchasing workspace on Windows with CustomTkinter installed and validate supplier performance against real delivery records.

## Phase 17 — Purchasing workflow UI (2026-11-17)
- [x] Add UI actions for requisition creation, purchase order creation, approval/rejection, and receiving.
- [x] Force newly created GUI purchase orders into pending approval.
- [x] Keep stock posting at purchase invoice posting to avoid duplicate receipt quantities.
- [ ] Multi-line requisition/order/receipt editor.
- [x] Supplier quote entry/comparison UI (Phase 18).
- [x] Purchase invoice matching wizard (Phase 18) and read-only variance review (Phase 20).
- [ ] Windows visual acceptance test with CustomTkinter installed.

## Phase 18 — Purchasing UI & matching hardening (2026-11-17)
- Added supplier quote capture and live quote comparison actions to the purchasing control tower.
- Added invoice-to-PO matching wizard with automatic line allocation by product/warehouse and remaining received/invoiced quantities.
- Hardened matching limits across repeated matches and ignore cancelled invoice links when calculating consumed quantities.
- Added regression coverage for invoice-line overmatching.
- Validation: 212 passed, 1 skipped (customtkinter unavailable), 409 warnings, 10 subtests; compileall passed.
- Remaining: Windows visual QA, price/tax variance workflow, quote award-to-PO conversion, multi-line editable order/receipt forms.

## Phase 19 — Purchasing commercial variance controls (2026-11-17)
- [x] Add company/branch-scoped audit report comparing matched purchase-order and posted-invoice line prices, discounts, taxes, and net totals prorated to matched quantities.
- [x] Add configurable non-negative tolerance and explicit `MATCHED` / `REVIEW_REQUIRED` exception status; report is read-only and never silently adjusts invoices.
- [x] Add regression tests for price/discount/tax variance calculations and tolerance validation.
- [x] Add a dedicated read-only desktop exception-review screen (Phase 20).
- [ ] Define accounting policy for allowable price/tax differences, landed costs, and credit-note resolution before automated blocking or posting.
- [ ] Convert awarded supplier quotes to multi-line purchase orders after quote schema captures warehouse, discounts, taxes, and validity/award metadata.
- [ ] Complete Windows visual acceptance tests with CustomTkinter installed.

## Phase 20 — Purchasing variance review
- [x] Add a dedicated read-only invoice variance review window to the purchasing workflow screen.
- [x] Display matched PO/invoice quantities, price, discount, tax and net variances, with review status.
- [x] Keep variance review informational only; no automatic invoice edits or journal postings.
- [x] Add UI wiring regression coverage and rerun the full test suite.
- [ ] Complete visual acceptance testing on Windows with CustomTkinter installed.
- [ ] Define business-approved variance authorization policy before adding approval/release actions.


## Phase 21 — Multi-line purchasing operations (2026-11-17)
- [x] Replace the single-line purchase-order entry form with a multi-line editor for products, warehouses, quantities, and unit costs.
- [x] Replace single-line goods receipt entry with a multi-line receipt editor that supports partial receipt across several order lines.
- [x] Add regression coverage for a multi-line approved order and a multi-line partial receipt.
- [x] Add UI wiring regression coverage for the multi-line order and receipt workflows.
- [ ] Perform visual acceptance testing on Windows with CustomTkinter installed.
- [ ] Complete end-to-end integration testing against real supplier invoices and accounting configuration.

## Phase 22 — Sales Delivery & Collection
- [x] Add company-scoped sales defaults for inventory policy and accounting accounts, with invoice-level account overrides.
- [x] Add reserved-stock fulfillment and delivery states; issue reserved quantities and recognize their COGS on delivery.
- [x] Record invoice-time payments as linked, allocated receipt documents without duplicating journal entries.
- [x] Include invoice-time receipts and posted sales returns in business-intelligence summaries and rankings.
- [x] Add regression coverage for reservations, delivery, invoice cancellation, receipt linkage, and return-adjusted reporting.
- [x] Pass the acting user explicitly through mobile security-list reads so service authorization works outside desktop context.
- [ ] Visually validate sales settings and delivery actions on Windows with CustomTkinter installed.

## Phase 23 — Customer receivables completion
- [x] Create and link a dedicated receivable subaccount for each customer, including existing customer records.
- [x] Enforce customer credit limits when posting sales invoices and debit notes, with explicit authorized override and audit event.
- [x] Add customer debit/credit notes linked to posted invoices, with balanced journals, statement/aging visibility, and cancellation reversals without inventory movements.
- [x] Preserve company-scope validation for explicitly supplied receivable accounts while posting to the customer's dedicated subaccount.
- [x] Add regression coverage for dedicated accounts, credit-limit enforcement, statement/aging updates, financial-note limits/cancellation, and inventory neutrality.
- [x] Verify startup backfill and balance refresh are idempotent in `bootstrap_database`.
- [x] Avoid database initialization when the desktop GUI dependency is unavailable; batch startup balance refreshes.
- [ ] Reconcile and reclassify legacy receivable journal balances through an accountant-reviewed, auditable migration; historical posted journal lines are not rewritten automatically.
- [ ] Visually test customer and settlement screens on Windows with CustomTkinter installed.

## Phase 24 — Application launcher and catalog
- [x] Add an application-launcher grid and category-based module catalog using the existing AlexERP color palette.
- [x] Show only modules the signed-in user is authorized to open, and route each card to its existing screen.
- [x] Open the launcher after login while preserving direct sidebar navigation.
- [x] Add navigation wiring regression coverage.
- [ ] Visually validate launcher and catalog layout on Windows at narrow and wide window sizes.

## Phase 25 — Accounting dashboard details
- [x] Add a company-scoped accounting overview for customer invoices, supplier bills, bank accounts, and cash boxes.
- [x] Show draft, open, and overdue invoice counts and outstanding balances with permission-checked shortcuts to sales and purchase entry.
- [x] Expand the chart of accounts view with account type, company currency, and company name.
- [x] Add journal-line details with company-safe account and invoice-party resolution; default to posted journal entries.
- [x] Show the signed-in user's name and add a persisted Arabic/English language preference in the top bar.
- [ ] Implement true Arabic/English localization across all pages; the language selector currently saves the preference but does not translate page content.
- [ ] Build bank-statement import and reconciliation data before enabling matching numbers or account reconciliation controls.
- [ ] Add balance-sheet comparison periods, account drill-down, and print preview to match the reference workflow.
- [ ] Add accounting dashboard comparison charts and validate the desktop layout visually on Windows.

## Phase 26 — مرتجعات مرتبطة بالتسليم
- [x] ربط رأس المرتجع بأمر البيع ومستند التسليم، وربط كل بند ببند التسليم/الفاتورة/الأمر المصدر.
- [x] منع تجاوز كمية بند التسليم أو إجمالي الكميات المسلّمة على الفاتورة، مع دعم الترحيل الجزئي والمتكرر.
- [x] تحديث رصيد المرتجع على بند التسليم داخل المعاملة نفسها مع حركة المخزون والقيد المحاسبي.
- [x] إتاحة الإجراء من مساحة أوامر البيع واختيار مستند تسليم معتمد فقط.
- [x] إضافة ترحيل مخطط إضافي متوافق واختبارات لعزل الشركة/الفرع والفشل الذري.
- [ ] التحقق بصريًا على Windows بدور مستخدم مقيد، ومراجعة الترحيل على نسخة احتياطية فعلية.
- [ ] توحيد تقارير المبيعات وصافي التسليم لعرض الإجمالي والمرتجع والصافي ومصالحتها مع دفتر الأستاذ.

## Phase 27 — أساس هندسة التطبيقات والوحدات
- [x] جعل `application` يميز التطبيق الظاهر عن الوحدة التقنية التي لا تحتاج شاشة.
- [x] توحيد اسم التطبيق ووصفه وأيقونته وترتيبه وقسمه وصنف الصفحة وصلاحيات دخوله في manifest.
- [x] إنشاء عناصر التنقل والكتالوج من بيانات manifests بدل قوائم مكررة في الواجهة.
- [x] فصل `depends` التقنية عن `integrates_with` الوظيفية وتوليد الرسمين من manifests.
- [x] توليد رسم AST للاستيرادات الفعلية وحواف نقاط دخول الصفحات واختبار عدم تقادمه.
- [x] إضافة كشف package التقنية الناقصة في التدقيق.
- [ ] تعريف ترحيل/ترقية/تراجع لكل وحدة قبل تفعيل تثبيت أو تعطيل الوحدات وقت التشغيل.

## Phase 28 — فصل نواة ترحيل القيود
- [x] نقل موفر القيود والعكس ومستودع دفتر القيود إلى `alexerp.accounting` مع واجهتي توافق للمسارين القديمين.
- [x] تحويل مستهلكي الخدمة الإنتاجيين إلى الاستيراد من واجهة Accounting Core.
- [x] إعلان الوحدة التقنية `accounting_core` واعتماد التطبيقات التي تستهلك كتابة الأستاذ أو مخططه عليها.
- [x] حصر المستهلكين وقراءات SQL المباشرة وحدود subledger/settlement في تقرير المرحلة الثانية.
- [x] اجتياز المجموعة الكاملة: 312 اختبارًا و18 subtests، وفحص `compileall` ورسم الاعتماديات ورسم الاستيرادات.
- [x] نقل قراءات الأستاذ العام والفترات من SQL المباشر إلى واجهات مملوكة للنواة المحاسبية.
- [ ] فصل تخصيص القبوض/المدفوعات وأرصدة الأطراف عن خدمة ترحيل القيود من دون ازدواج تحديث الرصيد.
- [ ] نقل التحصيل الفوري داخل البيع من SQL إلى واجهة تسوية متوافقة، مع ضمان عدم إنشاء قيد قبض إضافي.
- [ ] تصميم حدود الحزم التقنية لباقي المجالات وترحيلاتها قبل إضافة دورة تحميل للوحدات.

## Phase 29 — واجهات قراءة الأستاذ والفترات
- [x] نقل مستودعات تقارير الأستاذ إلى `alexerp.accounting` وإبقاء أسماء المستودعات القديمة كواجهات توافق.
- [x] إضافة `AccountingReadService` لقراءة القيود وبنودها وتقارير الأستاذ وملخصات الربح وفحوص الإقفال.
- [x] نقل ملكية `FiscalPeriodService` إلى `accounting_core` وتفويض التحقق من تاريخ الترحيل إليها.
- [x] تمرير الاتصال النشط لخدمات القراءة أثناء إقفال السنة للحفاظ على الفحص والتحديث في المعاملة نفسها.
- [x] تحويل BI وصفحات المحاسبة والفترات وإلغاء البيع وخدمة إقفال السنة إلى الواجهات المالكة.
- [x] إضافة اختبار حد يمنع SQL على القيود والفترات خارج accounting_core، واختبارات عزل الشركة والجاهزية.
- [x] اجتياز 315 اختبارًا و18 subtests؛ نجاح `compileall` وفحص خريطة manifests ورسم imports.
- [ ] توحيد واجهة إدارة دليل الحسابات، ثم فصل خدمات subledger والتسويات مع مالك واحد لكل رصيد.
