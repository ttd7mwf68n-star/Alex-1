"""Export the currently rendered financial report to CSV, XLSX or PDF."""
from __future__ import annotations

import csv
from pathlib import Path


def export_csv(path, title, date_from, date_to, columns, rows):
    with open(path, "w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow([title])
        writer.writerow(["From", date_from, "To", date_to])
        writer.writerow([])
        writer.writerow([column[1] for column in columns])
        for row in rows:
            writer.writerow([row.get(column[0], "") for column in columns])


def export_xlsx(path, title, date_from, date_to, columns, rows):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Financial Report"
    sheet.sheet_view.rightToLeft = True
    sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(1, len(columns)))
    sheet.cell(1, 1, title).font = Font(name="Arial", size=16, bold=True, color="FFFFFF")
    sheet.cell(1, 1).fill = PatternFill("solid", fgColor="17365D")
    sheet.cell(1, 1).alignment = Alignment(horizontal="right")
    sheet.cell(2, 1, f"من: {date_from}    إلى: {date_to}")
    sheet.cell(2, 1).font = Font(name="Arial", italic=True, color="666666")
    header_row = 4
    for index, column in enumerate(columns, start=1):
        cell = sheet.cell(header_row, index, column[1])
        cell.font = Font(name="Arial", bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="2874A6")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        sheet.column_dimensions[get_column_letter(index)].width = max(12, min(42, int(column[2] / 7)))
    for row_index, row in enumerate(rows, start=header_row + 1):
        for col_index, column in enumerate(columns, start=1):
            value = row.get(column[0], "")
            cell = sheet.cell(row_index, col_index, value)
            cell.alignment = Alignment(horizontal="right", vertical="center")
            if isinstance(value, (int, float)):
                cell.number_format = '#,##0.00;[Red](#,##0.00)'
    sheet.freeze_panes = "A5"
    sheet.auto_filter.ref = f"A{header_row}:{get_column_letter(max(1, len(columns)))}{header_row + len(rows)}"
    workbook.save(path)


def _shape_arabic(value):
    text = str(value if value is not None else "")
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
    except ImportError as exc:
        raise RuntimeError(
            "تصدير PDF العربي يحتاج تثبيت arabic-reshaper و python-bidi من requirements.txt."
        ) from exc
    return get_display(arabic_reshaper.reshape(text))


def _arabic_font_path():
    candidates = [
        Path("C:/Windows/Fonts/arial.ttf"),
        Path("C:/Windows/Fonts/ARIAL.TTF"),
        Path("/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf"),
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise RuntimeError("لم يتم العثور على خط يدعم العربية لإنشاء PDF.")


def export_pdf(path, title, date_from, date_to, columns, rows):
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_RIGHT
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    font_name = "AlexERPArabic"
    if font_name not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont(font_name, str(_arabic_font_path())))
    styles = getSampleStyleSheet()
    rtl = ParagraphStyle("AlexRTL", parent=styles["Normal"], fontName=font_name,
                         fontSize=8, leading=12, alignment=TA_RIGHT)
    title_style = ParagraphStyle("AlexTitle", parent=rtl, fontSize=15, leading=20)
    count = max(1, len(columns))
    data = [[Paragraph(_shape_arabic(title), title_style)] + [""] * (count - 1),
            [Paragraph(_shape_arabic(f"من {date_from} إلى {date_to}"), rtl)] + [""] * (count - 1),
            [""] * count]
    data.append([Paragraph(_shape_arabic(column[1]), rtl) for column in columns])
    for row in rows:
        data.append([Paragraph(_shape_arabic(row.get(column[0], "")), rtl) for column in columns])
    available_width = landscape(A4)[0] - 24 * mm
    weights = [max(1.0, float(column[2])) for column in columns]
    weight_total = sum(weights) or 1.0
    widths = [available_width * weight / weight_total for weight in weights]
    table = Table(data, colWidths=widths, repeatRows=4, hAlign="RIGHT")
    table.setStyle(TableStyle([
        ("SPAN", (0, 0), (-1, 0)), ("SPAN", (0, 1), (-1, 1)),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#17365D")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("BACKGROUND", (0, 3), (-1, 3), colors.HexColor("#2874A6")),
        ("TEXTCOLOR", (0, 3), (-1, 3), colors.white),
        ("GRID", (0, 3), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
        ("ROWBACKGROUNDS", (0, 4), (-1, -1), [colors.white, colors.HexColor("#F3F6FA")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    document = SimpleDocTemplate(str(path), pagesize=landscape(A4),
                                 rightMargin=12 * mm, leftMargin=12 * mm,
                                 topMargin=12 * mm, bottomMargin=12 * mm)
    document.build([table])
