"""Generate the actual internal Python import graph for Alex ERP.

Includes statically resolvable imports under ``alexerp`` (excluding tests) and
separate dynamic page-entrypoint edges resolved from application manifests.
Run from the repository root with:
    python -m alexerp.modules.generate_python_import_graph
    python -m alexerp.modules.generate_python_import_graph --check
"""
from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path


def _module_name(path: Path, package_root: Path) -> str:
    parts = list(path.relative_to(package_root.parent).with_suffix("").parts)
    if parts[-1] == "__init__":
        parts.pop()
    return ".".join(parts)


def _resolve_import_from(node: ast.ImportFrom, current_module: str, is_package: bool,
                         modules: set[str]) -> set[str]:
    if node.level:
        current_package = current_module if is_package else current_module.rpartition(".")[0]
        parts = current_package.split(".") if current_package else []
        remove = node.level - 1
        if remove:
            parts = parts[:-remove]
        if node.module:
            parts.extend(node.module.split("."))
        base = ".".join(parts)
    else:
        base = node.module or ""
    targets: set[str] = set()
    for alias in node.names:
        candidate = f"{base}.{alias.name}" if base and alias.name != "*" else base
        if candidate in modules:
            targets.add(candidate)
        elif base in modules:
            targets.add(base)
    if not node.names and base in modules:
        targets.add(base)
    return targets


def build_payload(project_root: str | Path | None = None) -> dict:
    root = Path(project_root) if project_root else Path(__file__).resolve().parents[2]
    package_root = root / "alexerp"
    files = sorted(
        path for path in package_root.rglob("*.py")
        if "tests" not in path.relative_to(package_root).parts and "__pycache__" not in path.parts
    )
    modules = {_module_name(path, package_root) for path in files}
    imports: dict[str, set[str]] = {module: set() for module in modules}
    for path in files:
        module = _module_name(path, package_root)
        is_package = path.name == "__init__.py"
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (OSError, SyntaxError) as exc:
            raise ValueError(f"Cannot parse {path.relative_to(root)}: {exc}") from exc
        for node in ast.walk(tree):
            targets: set[str] = set()
            if isinstance(node, ast.Import):
                targets.update(alias.name for alias in node.names if alias.name in modules)
            elif isinstance(node, ast.ImportFrom):
                targets.update(_resolve_import_from(node, module, is_package, modules))
            imports[module].update(target for target in targets if target != module)

    from alexerp.core.module_registry import ModuleRegistry
    manifests = ModuleRegistry(root / "alexerp" / "modules" / "manifests").load()
    dynamic_edges = []
    for manifest in sorted(manifests.values(), key=lambda item: item.id):
        if manifest.application and manifest.state == "available" and manifest.entrypoint:
            target = manifest.entrypoint.rsplit(".", 1)[0]
            dynamic_edges.append({
                "consumer": "alexerp.ui.main_window",
                "provider": target,
                "manifest": manifest.id,
                "kind": "manifest_entrypoint",
            })
    edge_count = sum(len(targets) for targets in imports.values())
    return {
        "schema_version": 1,
        "source": "AST of alexerp/**/*.py excluding tests, plus manifest entrypoints",
        "note": "Static import graph only; runtime calls and database/schema coupling are separate concerns.",
        "static_edge_count": edge_count,
        "static_imports": {module: sorted(imports[module]) for module in sorted(imports)},
        "dynamic_entrypoints": dynamic_edges,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="fail if the generated import graph is stale")
    args = parser.parse_args()
    destination = Path(__file__).resolve().parent / "python_import_graph.json"
    expected = json.dumps(build_payload(), ensure_ascii=False, indent=2) + "\n"
    if args.check:
        if not destination.is_file() or destination.read_text(encoding="utf-8") != expected:
            print("Python import graph is stale; run python -m alexerp.modules.generate_python_import_graph")
            return 1
        print("Python import graph matches current source imports.")
        return 0
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(expected, encoding="utf-8")
    temporary.replace(destination)
    print(f"Updated {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
