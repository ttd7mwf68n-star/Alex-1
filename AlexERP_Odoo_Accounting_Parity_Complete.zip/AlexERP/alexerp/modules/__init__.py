"""Application module metadata and registry for Alex ERP."""
