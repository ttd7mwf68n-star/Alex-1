"""Synchronize the documented dependency graph from module manifests.

Run from the repository root with:
    python -m alexerp.modules.sync_dependency_graph
    python -m alexerp.modules.sync_dependency_graph --check
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from alexerp.core.module_registry import ModuleRegistry


def expected_content() -> str:
    registry = ModuleRegistry()
    return json.dumps(registry.dependency_graph_payload(), ensure_ascii=False, indent=2) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="fail if the generated graph is stale")
    args = parser.parse_args()
    destination = Path(__file__).resolve().parent / "module_dependency_graph.json"
    expected = expected_content()
    if args.check:
        if not destination.is_file() or destination.read_text(encoding="utf-8") != expected:
            print(f"Dependency graph is stale; run {__package__}.sync_dependency_graph")
            return 1
        print("Dependency graph matches module manifests.")
        return 0
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(expected, encoding="utf-8")
    temporary.replace(destination)
    print(f"Updated {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
