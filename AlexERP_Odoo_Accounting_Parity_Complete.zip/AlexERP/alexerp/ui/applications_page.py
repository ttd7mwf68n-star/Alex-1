"""Application launcher and searchable catalog for the AlexERP modules."""
from __future__ import annotations

from collections.abc import Callable

import customtkinter as ctk

from alexerp.ui.components import Badge, Card, Page, entry, ghost_button, label
from alexerp.core.module_registry import ModuleRegistry
from alexerp.ui.theme import START, c, font


_TILE_TONES = ("primary", "success", "info", "warning", "danger")
_MAX_GRID_COLUMNS = 4


_MODULE_MANIFESTS = ModuleRegistry().load()


def _columns_for_width(width: int, max_columns: int = _MAX_GRID_COLUMNS) -> int:
    """Choose a comfortable number of app cards for the available width."""
    if max_columns <= 2:
        return max(1, max_columns)
    if width < 760:
        return min(2, max_columns)
    if width < 1080:
        return min(3, max_columns)
    return max_columns


def _module_info(module):
    key = module[0]
    manifest = _MODULE_MANIFESTS.get(key)
    if manifest is None or not manifest.application:
        raise ValueError(f"Navigable application has no application manifest: {key}")
    return (
        manifest.id,
        manifest.name,
        manifest.icon,
        manifest.category,
        manifest.description,
        manifest.state,
        manifest.version,
    )


def _module_state_label(state: str) -> tuple[str, str]:
    """Return an honest Arabic label/tone for the manifest lifecycle state."""
    return {
        "available": ("متاحة", "success"),
        "planned": ("مخططة", "warning"),
        "disabled": ("معطلة", "muted"),
    }.get(state, ("غير معروفة", "danger"))


def _open_module(navigate: Callable[[str], object] | None, key: str) -> None:
    if navigate is not None:
        navigate(key)


def _configure_grid(frame, columns: int) -> None:
    """Set consistent, equal-width columns and collapse unused grid tracks."""
    for column in range(_MAX_GRID_COLUMNS):
        active = column < columns
        frame.grid_columnconfigure(
            column,
            weight=1 if active else 0,
            uniform="alexerp-app-card" if active else "",
            minsize=0,
        )


class ApplicationsPage(Page):
    """Launcher's clean, icon-led grid of apps available to the signed-in user."""

    def __init__(self, parent, user=None, navigate=None, modules=()):
        super().__init__(
            parent,
            title="التطبيقات",
            subtitle="افتح تطبيقًا للانتقال مباشرةً إلى أعمالك",
            user=user,
            scroll=True,
        )
        self.navigate = navigate
        self.modules = [_module_info(module) for module in modules]
        ghost_button(
            self.actions,
            "كتالوج التطبيقات  ⟵",
            lambda: _open_module(self.navigate, "app_catalog"),
            width=160,
        ).pack(side=START, padx=4)
        self.search = entry(self.actions, placeholder="ابحث عن تطبيق...", width=220)
        self.search.pack(side=START, padx=6)
        self.search.bind("<KeyRelease>", lambda _event: self._render())

        self.apps_grid = ctk.CTkFrame(self.body, fg_color="transparent")
        self.apps_grid.pack(fill="both", expand=True, padx=8, pady=8)
        self._grid_columns = 4
        _configure_grid(self.apps_grid, self._grid_columns)
        self._render()

    def _render(self):
        for child in self.apps_grid.winfo_children():
            child.destroy()

        query = self.search.get().strip().casefold()
        modules = [
            item for item in self.modules
            if not query or query in " ".join(item).casefold()
        ]
        if not modules:
            label(self.apps_grid, "لا توجد تطبيقات مطابقة للبحث", tone="muted").grid(
                row=0, column=0, columnspan=self._grid_columns, pady=32
            )
            return

        for index, (key, name, glyph, section, description, _state, _version) in enumerate(modules):
            row, logical_column = divmod(index, self._grid_columns)
            column = self._grid_columns - 1 - logical_column if START == "right" else logical_column
            tone = _TILE_TONES[index % len(_TILE_TONES)]
            card = Card(self.apps_grid)
            card.grid(row=row, column=column, padx=8, pady=8, sticky="nsew")

            ctk.CTkLabel(
                card,
                text=glyph,
                width=58,
                height=58,
                corner_radius=16,
                fg_color=c(f"{tone}_soft"),
                text_color=c(tone),
                font=font(28),
            ).pack(pady=(18, 7))
            ctk.CTkButton(
                card,
                text=name,
                height=30,
                fg_color="transparent",
                hover_color=c("surface_hover"),
                text_color=c("text"),
                font=font(14, "bold"),
                command=lambda k=key: _open_module(self.navigate, k),
            ).pack(fill="x", padx=10)
            ctk.CTkLabel(
                card,
                text=f"{section} · {description}",
                text_color=c("muted"),
                font=font(11),
                wraplength=175,
                justify="center",
                height=38,
            ).pack(fill="x", padx=12, pady=(0, 15))


class AppCatalogPage(Page):
    """Searchable, category-based app catalog with a responsive card grid."""

    def __init__(self, parent, user=None, navigate=None, modules=()):
        super().__init__(
            parent,
            title="كتالوج التطبيقات",
            subtitle="تصفح تطبيقات النظام حسب مجال العمل",
            user=user,
        )
        self.navigate = navigate
        self.modules = [_module_info(module) for module in modules]
        self.active_category = "الكل"
        self.search = entry(self.actions, placeholder="ابحث بالاسم أو الوصف...", width=300)
        self.search.pack(side=START, padx=4)
        self.search.bind("<KeyRelease>", lambda _event: self._render_cards())

        content = ctk.CTkFrame(self.body, fg_color="transparent")
        content.pack(fill="both", expand=True)
        self.content = content
        self.categories_panel = Card(content, width=190)
        self.categories_panel.pack(side=START, fill="y", padx=(0, 12))
        self.categories_panel.pack_propagate(False)
        ctk.CTkLabel(
            self.categories_panel,
            text="مجالات العمل",
            font=font(14, "bold"),
            text_color=c("text"),
            anchor="e",
        ).pack(fill="x", padx=14, pady=(16, 8))
        self.category_buttons = {}
        categories = ["الكل"] + list(dict.fromkeys(item[3] for item in self.modules))
        for category in categories:
            count = len(self.modules) if category == "الكل" else sum(
                item[3] == category for item in self.modules
            )
            button = ctk.CTkButton(
                self.categories_panel,
                text=f"{category}   ·   {count}",
                anchor="e",
                height=36,
                corner_radius=8,
                fg_color="transparent",
                hover_color=c("surface_hover"),
                text_color=c("text"),
                font=font(12),
                command=lambda value=category: self._select_category(value),
            )
            button.pack(fill="x", padx=8, pady=2)
            self.category_buttons[category] = button

        self.cards_frame = ctk.CTkScrollableFrame(
            content,
            fg_color="transparent",
            scrollbar_button_color=c("border"),
            scrollbar_button_hover_color=c("muted"),
        )
        self.cards_frame.pack(side="left", fill="both", expand=True)
        self._grid_columns = 3
        self._layout_job = None
        _configure_grid(self.cards_frame, self._grid_columns)
        content.bind("<Configure>", self._queue_grid_update, add="+")
        self._render_cards()

    def _queue_grid_update(self, _event=None):
        if self._layout_job is not None:
            self.after_cancel(self._layout_job)
        self._layout_job = self.after_idle(self._sync_grid_columns)

    def _sync_grid_columns(self):
        self._layout_job = None
        available_width = (
            self.content.winfo_width() - self.categories_panel.winfo_width() - 16
        )
        columns = _columns_for_width(available_width)
        if columns != self._grid_columns:
            self._grid_columns = columns
            _configure_grid(self.cards_frame, columns)
            self._render_cards()

    def _select_category(self, category):
        self.active_category = category
        self._update_category_buttons()
        self._render_cards()

    def _update_category_buttons(self):
        for category, button in self.category_buttons.items():
            active = category == self.active_category
            button.configure(
                fg_color=c("primary_soft") if active else "transparent",
                text_color=c("primary") if active else c("text"),
                font=font(12, "bold" if active else "normal"),
            )

    def _render_cards(self):
        for child in self.cards_frame.winfo_children():
            child.destroy()
        self._update_category_buttons()

        query = self.search.get().strip().casefold()
        modules = [
            item for item in self.modules
            if (self.active_category == "الكل" or item[3] == self.active_category)
            and (not query or query in " ".join(item).casefold())
        ]
        if not modules:
            label(self.cards_frame, "لا توجد تطبيقات مطابقة", tone="muted").grid(
                row=0, column=0, columnspan=self._grid_columns, pady=32
            )
            return

        for index, (key, name, glyph, section, description, state, _version) in enumerate(modules):
            row, logical_column = divmod(index, self._grid_columns)
            column = self._grid_columns - 1 - logical_column if START == "right" else logical_column
            tone = _TILE_TONES[index % len(_TILE_TONES)]
            card = Card(self.cards_frame, height=164)
            card.grid(row=row, column=column, padx=7, pady=7, sticky="nsew")
            card.grid_propagate(False)

            head = ctk.CTkFrame(card, fg_color="transparent")
            head.pack(fill="x", padx=12, pady=(13, 5))
            ctk.CTkLabel(
                head,
                text=glyph,
                width=44,
                height=44,
                corner_radius=12,
                fg_color=c(f"{tone}_soft"),
                text_color=c(tone),
                font=font(21),
            ).pack(side=START)
            identity = ctk.CTkFrame(head, fg_color="transparent")
            identity.pack(side=START, fill="x", expand=True, padx=9)
            ctk.CTkLabel(
                identity,
                text=name,
                font=font(13, "bold"),
                text_color=c("text"),
                anchor="e",
            ).pack(fill="x")
            ctk.CTkLabel(
                identity,
                text=section,
                font=font(11),
                text_color=c("muted"),
                anchor="e",
            ).pack(fill="x", pady=(2, 0))
            ctk.CTkLabel(
                card,
                text=description,
                font=font(11),
                text_color=c("muted"),
                anchor="e",
                justify="right",
                wraplength=235,
                height=38,
            ).pack(fill="x", padx=14, pady=(2, 5))
            footer = ctk.CTkFrame(card, fg_color="transparent")
            footer.pack(fill="x", padx=12, pady=(0, 10))
            state_label, state_tone = _module_state_label(state)
            Badge(footer, state_label, state_tone).pack(side=START)
            ctk.CTkButton(
                footer,
                text="فتح التطبيق",
                width=104,
                height=30,
                corner_radius=8,
                fg_color=c("primary"),
                hover_color=c("primary_hover"),
                text_color="#FFFFFF",
                font=font(11, "bold"),
                command=lambda k=key: _open_module(self.navigate, k),
            ).pack(side="left")
