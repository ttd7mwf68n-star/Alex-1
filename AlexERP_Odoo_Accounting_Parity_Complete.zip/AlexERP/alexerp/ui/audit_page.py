"""Company-scoped audit log viewer for Desktop."""
from __future__ import annotations

import json
from tkinter import messagebox

import customtkinter as ctk

from alexerp.services.audit_service import AuditService
from alexerp.ui.components import Badge, DataTable, Page, Toolbar, combo, entry, primary_button
from alexerp.ui.theme import END, TEXT_ANCHOR, c, font, icon


class AuditPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="سجل العمليات",
                         subtitle="مراجعة حركات المستخدمين والمستندات داخل الشركة", user=user)
        self.company_id = int((user or {}).get("company_id") or 0)
        self._build_filters()
        self.summary = Badge(self.body, "", "info")
        self.summary.pack(anchor=TEXT_ANCHOR, pady=(0, 8))
        self.table_host = ctk.CTkFrame(self.body, fg_color="transparent")
        self.table_host.pack(fill="both", expand=True)
        self.load_events()

    def _build_filters(self):
        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        bar.caption("من")
        self.date_from = entry(bar.row, "YYYY-MM-DD", 120)
        bar.add(self.date_from)
        bar.caption("إلى")
        self.date_to = entry(bar.row, "YYYY-MM-DD", 120)
        bar.add(self.date_to)
        bar.caption("الوحدة")
        self.module = combo(bar.row, ["الكل", "security", "sales", "purchases", "inventory", "accounting", "receipts", "payments"], 150)
        self.module.set("الكل")
        bar.add(self.module)
        primary_button(bar.row, f"{icon('refresh')}  تحديث", self.load_events, width=110).pack(side=END, padx=4)

    def load_events(self):
        try:
            module = self.module.get().strip()
            events = AuditService().list_events(
                company_id=self.company_id, limit=300, offset=0,
                module=None if module in ("", "الكل") else module,
                date_from=self.date_from.get().strip() or None,
                date_to=self.date_to.get().strip() or None,
            )
            self.summary.set(f"عدد الأحداث المعروضة: {len(events)} · النطاق: آخر 300 حدث كحد أقصى")
            rows = []
            for event in events:
                actor = event.get("actor_name") or event.get("actor_username") or "النظام"
                details = event.get("description") or ""
                before = json.dumps(event.get("before"), ensure_ascii=False, default=str) if event.get("before") is not None else ""
                after = json.dumps(event.get("after"), ensure_ascii=False, default=str) if event.get("after") is not None else ""
                snapshot = (f"قبل: {before} | بعد: {after}").strip(" |")
                rows.append({"date": event.get("created_at") or "", "actor": actor,
                             "module": event.get("module") or "", "action": event.get("action") or "",
                             "entity": f"{event.get('entity_type') or ''} #{event.get('record_id') or ''}",
                             "description": details or snapshot[:700]})
            for child in self.table_host.winfo_children():
                child.destroy()
            table = DataTable(self.table_host, [
                ("date", "التوقيت", 145, "w"), ("actor", "المستخدم", 130, "w"),
                ("module", "الوحدة", 90, "w"), ("action", "العملية", 125, "w"),
                ("entity", "السجل", 120, "w"), ("description", "التفاصيل", 360, "w"),
            ], empty_text="لا توجد عمليات مسجلة للفلاتر المحددة")
            table.pack(fill="both", expand=True)
            table.set_rows(rows)
        except Exception as exc:
            messagebox.showerror("تعذر تحميل سجل العمليات", str(exc), parent=self.winfo_toplevel())
