"""
AlexERP — Business Management System
Main window: login -> application shell (collapsible sidebar + topbar + pages).
"""

from __future__ import annotations

import customtkinter as ctk
from importlib import import_module

from alexerp.config import (
    APP_NAME, APP_VERSION, DEFAULT_APPEARANCE, DEFAULT_COLOR_THEME,
    MIN_HEIGHT, MIN_WIDTH, WINDOW_SIZE,
)
from alexerp.ui.applications_page import ApplicationsPage, AppCatalogPage
from alexerp.ui.components import Page, icon_button
from alexerp.ui.login import LoginFrame
from alexerp.ui import preferences
from alexerp.core.context import set_current_user
from alexerp.core.module_registry import ModuleRegistry
from alexerp.services.permission_service import PermissionService
from alexerp.ui.theme import (
    BRAND_MARK, BRAND_NAME, BRAND_TAGLINE_EN, END, START, TEXT_ANCHOR, c, font, icon,
)


def _placeholder(title: str, subtitle: str = "هذه الشاشة قيد التطوير"):
    def factory(parent, user=None, navigate=None):
        page = Page(parent, title=title, subtitle=subtitle, user=user)
        ctk.CTkLabel(page.body, text="🚧", font=font(64)).pack(pady=(80, 8))
        ctk.CTkLabel(page.body, text="قريباً", font=font(18, "bold"),
                     text_color=c("muted")).pack()
        return page
    return factory


# Shell utilities are not business applications and remain owned by the shell.
_SHELL_NAVIGATION = [
    ("apps", "التطبيقات", "▦", ApplicationsPage, "الرئيسية"),
    ("app_catalog", "كتالوج التطبيقات", "🧩", AppCatalogPage, "الرئيسية"),
]
MODULE_MANIFESTS = ModuleRegistry().load()


def _resolve_entrypoint(entrypoint: str):
    module_name, attribute = entrypoint.rsplit(".", 1)
    module = import_module(module_name)
    page_factory = getattr(module, attribute, None)
    if not callable(page_factory):
        raise RuntimeError(f"Application entrypoint is not callable: {entrypoint}")
    return page_factory


def _build_navigation():
    applications = sorted(
        (
            module for module in MODULE_MANIFESTS.values()
            if module.application and module.state == "available"
        ),
        key=lambda module: (module.sequence, module.id),
    )
    navigation = list(_SHELL_NAVIGATION)
    for module in applications:
        if not module.entrypoint or not module.icon or not module.navigation_section:
            raise RuntimeError(f"Available application has incomplete navigation metadata: {module.id}")
        navigation.append((
            module.id,
            module.name,
            module.icon,
            _resolve_entrypoint(module.entrypoint),
            module.navigation_section,
        ))
    return navigation


NAVIGATION = _build_navigation()
TITLES = {key: label for key, label, *_ in NAVIGATION}
SECTIONS = {key: section for key, _l, _i, _f, section in NAVIGATION}
NAV_PERMISSIONS = {
    module.id: module.permissions
    for module in MODULE_MANIFESTS.values()
    if module.application and module.state == "available"
}

SIDEBAR_WIDTH = 248
SIDEBAR_COLLAPSED = 76
AUTO_COLLAPSE_BELOW = 1280


class MainWindow(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.prefs = preferences.load()
        ctk.set_appearance_mode(self.prefs.get("appearance") or DEFAULT_APPEARANCE)
        ctk.set_default_color_theme(DEFAULT_COLOR_THEME)

        self.title(APP_NAME)
        self.geometry(WINDOW_SIZE)
        self.minsize(MIN_WIDTH, MIN_HEIGHT)
        self.configure(fg_color=c("bg"))

        self.user = None
        self.current_page = None
        self.current_key = None
        self.nav_buttons: dict[str, ctk.CTkButton] = {}
        self.nav_labels: dict[str, str] = {}
        self.section_labels: list[ctk.CTkLabel] = []
        self.sidebar = None
        self.collapsed = bool(self.prefs.get("sidebar_collapsed"))
        self._auto_collapsed = False
        self._bind_shortcuts()
        self.bind("<Configure>", self._on_resize, add="+")
        self.show_login()

    # -------------------------------------------------

    def _clear(self):
        for child in self.winfo_children():
            if isinstance(child, ctk.CTkToplevel):
                continue
            child.destroy()
        self.current_page = None
        self.nav_buttons = {}
        self.section_labels = []
        self.sidebar = None

    def show_login(self):
        self._clear()
        set_current_user(None)
        self.user = None
        LoginFrame(self, on_success=self.on_login).pack(fill="both", expand=True)

    def on_login(self, user):
        set_current_user(user)
        self.user = user
        self._clear()
        self._build_sidebar()

        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(side=START, fill="both", expand=True)
        self._build_topbar(main)
        self.page_container = ctk.CTkFrame(main, fg_color="transparent")
        self.page_container.pack(fill="both", expand=True)

        allowed = [key for key, *_ in NAVIGATION if self._has_navigation_permission(key)]
        if allowed:
            self.navigate("apps" if "apps" in allowed else allowed[0])
        else:
            self.show_login()

    # -------------------------------------------------
    # Sidebar
    # -------------------------------------------------

    def _build_sidebar(self):
        sidebar = ctk.CTkFrame(self, width=SIDEBAR_WIDTH, corner_radius=0, fg_color=c("sidebar"))
        sidebar.pack(side=START, fill="y")
        sidebar.pack_propagate(False)
        self.sidebar = sidebar

        brand = ctk.CTkFrame(sidebar, fg_color="transparent")
        brand.pack(fill="x", padx=16, pady=(22, 14))
        self.brand_mark = ctk.CTkLabel(brand, text=BRAND_MARK, width=42, height=42, corner_radius=8,
                                       fg_color=c("info"), text_color="#FFFFFF",
                                       font=font(21, "bold"))
        self.brand_mark.pack(side=START)
        self.brand_names = ctk.CTkFrame(brand, fg_color="transparent")
        self.brand_names.pack(side=START, padx=12)
        ctk.CTkLabel(self.brand_names, text=BRAND_NAME, font=font(17, "bold"),
                     text_color="#FFFFFF", anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)
        ctk.CTkLabel(self.brand_names, text=BRAND_TAGLINE_EN, font=font(8, "bold"),
                     text_color=c("sidebar_muted"), anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)

        ctk.CTkFrame(sidebar, height=1, fg_color=c("sidebar_line")).pack(fill="x", padx=16, pady=(0, 6))

        self.profile = ctk.CTkFrame(sidebar, fg_color=c("sidebar_hover"), corner_radius=12)
        self.profile.pack(side="bottom", fill="x", padx=12, pady=14)
        name = self.user["full_name"] or self.user["username"]
        self.avatar = ctk.CTkLabel(self.profile, text=name[:1].upper(), width=36, height=36,
                                   corner_radius=18, fg_color=c("primary"), text_color="#FFFFFF",
                                   font=font(15, "bold"))
        self.avatar.pack(side=START, padx=8, pady=8)
        self.profile_texts = ctk.CTkFrame(self.profile, fg_color="transparent")
        self.profile_texts.pack(side=START)
        ctk.CTkLabel(self.profile_texts, text=name, font=font(13, "bold"),
                     text_color="#FFFFFF", anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)
        ctk.CTkLabel(self.profile_texts, text=f"v{APP_VERSION}", font=font(10),
                     text_color=c("sidebar_muted"), anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)
        self.logout_btn = ctk.CTkButton(self.profile, text=icon("logout"), width=34, height=34,
                                        corner_radius=10, fg_color="transparent",
                                        hover_color=c("danger"), text_color=c("sidebar_text"),
                                        font=font(15), command=self.show_login)
        self.logout_btn.pack(side=END, padx=8)
        self.nav_area = ctk.CTkScrollableFrame(sidebar, fg_color="transparent",
                                               scrollbar_button_color=c("sidebar_hover"),
                                               scrollbar_button_hover_color=c("sidebar_line"))
        self.nav_area.pack(fill="both", expand=True, padx=0)

        last_section = None
        for key, text, glyph, _factory, section in NAVIGATION:
            if not self._has_navigation_permission(key):
                continue
            if section != last_section:
                lbl = ctk.CTkLabel(self.nav_area, text=section, font=font(11, "bold"),
                                   text_color=c("sidebar_muted"), anchor=TEXT_ANCHOR)
                lbl.pack(fill="x", padx=18, pady=(12, 2))
                self.section_labels.append(lbl)
                last_section = section
            btn = ctk.CTkButton(
                self.nav_area, text="", anchor=TEXT_ANCHOR, height=42,
                corner_radius=10, font=font(14), fg_color="transparent",
                hover_color=c("sidebar_hover"), text_color=c("sidebar_text"),
                command=lambda k=key: self.navigate(k))
            btn.pack(fill="x", padx=10, pady=2)
            self.nav_buttons[key] = btn
            self.nav_labels[key] = (glyph, text)

        self._apply_sidebar_state()

    def _apply_sidebar_state(self):
        if self.sidebar is None:
            return
        collapsed = self.collapsed
        self.sidebar.configure(width=SIDEBAR_COLLAPSED if collapsed else SIDEBAR_WIDTH)
        if collapsed:
            self.brand_names.pack_forget()
            self.profile_texts.pack_forget()
            self.logout_btn.pack_forget()
            for lbl in self.section_labels:
                lbl.configure(text="·" * 3)
        else:
            if not self.brand_names.winfo_ismapped():
                self.brand_names.pack(side=START, padx=12)
            if not self.profile_texts.winfo_ismapped():
                self.profile_texts.pack(side=START)
                self.logout_btn.pack(side=END, padx=8)
            sections = []
            last = None
            for key, *_rest, section in NAVIGATION:
                if key in self.nav_buttons and section != last:
                    sections.append(section)
                    last = section
            for lbl, section in zip(self.section_labels, sections):
                lbl.configure(text=section)
        for key, btn in self.nav_buttons.items():
            glyph, text = self.nav_labels[key]
            btn.configure(text=glyph if collapsed else f"{text}   {glyph}" if START == "right" else f"{glyph}   {text}",
                          anchor="center" if collapsed else TEXT_ANCHOR,
                          font=font(17 if collapsed else 14))
        if hasattr(self, "collapse_btn"):
            self.collapse_btn.configure(text=icon("menu"))

    def toggle_sidebar(self, _event=None):
        self.collapsed = not self.collapsed
        self._auto_collapsed = False
        preferences.save(sidebar_collapsed=self.collapsed)
        self._apply_sidebar_state()

    def _on_resize(self, event):
        if event.widget is not self or self.sidebar is None:
            return
        narrow = event.width < AUTO_COLLAPSE_BELOW
        if narrow and not self.collapsed:
            self.collapsed, self._auto_collapsed = True, True
            self._apply_sidebar_state()
        elif not narrow and self._auto_collapsed:
            self.collapsed, self._auto_collapsed = False, False
            self._apply_sidebar_state()

    # -------------------------------------------------
    # Top bar
    # -------------------------------------------------

    def _build_topbar(self, parent):
        bar = ctk.CTkFrame(parent, height=54, corner_radius=0, fg_color=c("sidebar"),
                           border_width=0)
        bar.pack(fill="x")
        bar.pack_propagate(False)
        self.topbar = bar

        company = ""
        try:
            company = self.user["company_name"]  # optional column
        except (KeyError, IndexError, TypeError):
            company = ""
        chip = ctk.CTkFrame(bar, fg_color=c("sidebar_hover"), corner_radius=8, height=36)
        chip.pack(side=START, padx=8)
        name = self.user["full_name"] or self.user["username"]
        ctk.CTkLabel(chip, text=name[:1].upper(), width=26, height=26, corner_radius=6,
                     fg_color=c("info"), text_color="#FFFFFF",
                     font=font(12, "bold")).pack(side=START, padx=5, pady=5)
        identity = ctk.CTkFrame(chip, fg_color="transparent")
        identity.pack(side=START, padx=(4, 10) if START == "left" else (10, 4), pady=3)
        ctk.CTkLabel(identity, text=name, font=font(12, "bold"),
                     text_color="#FFFFFF", anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)
        if company:
            ctk.CTkLabel(identity, text=company, font=font(9),
                         text_color=c("sidebar_muted"), anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)

        self.language_menu = ctk.CTkOptionMenu(
            bar,
            values=["العربية", "English"],
            command=self._set_language,
            width=112,
            height=34,
            corner_radius=6,
            fg_color=c("sidebar_hover"),
            button_color=c("sidebar_hover"),
            button_hover_color=c("sidebar_active"),
            text_color="#FFFFFF",
            dropdown_fg_color=c("surface"),
            dropdown_hover_color=c("primary_soft"),
            dropdown_text_color=c("text"),
            font=font(11, "bold"),
            dropdown_font=font(11),
        )
        self.language_menu.set(
            "English" if self.prefs.get("language") == "en" else "العربية"
        )
        self.language_menu.pack(side=START, padx=6)

        self.theme_btn = icon_button(
            bar, self._theme_glyph(), self.toggle_theme,
            fg_color="transparent", hover_color=c("sidebar_hover"),
            text_color="#FFFFFF", border_width=0,
        )
        self.theme_btn.pack(side=START, padx=6)

        self.collapse_btn = icon_button(
            bar, icon("menu"), self.toggle_sidebar,
            fg_color="transparent", hover_color=c("sidebar_hover"),
            text_color="#FFFFFF", border_width=0,
        )
        self.collapse_btn.pack(side=START, padx=(0, 18) if START == "right" else (18, 0))

        crumbs = ctk.CTkFrame(bar, fg_color="transparent")
        crumbs.pack(side=START, padx=12)
        self.crumb_section = ctk.CTkLabel(crumbs, text="", font=font(12),
                                          text_color=c("sidebar_muted"))
        self.crumb_section.pack(side=START)
        ctk.CTkLabel(crumbs, text="  ‹  " if START == "right" else "  ›  ", font=font(12),
                     text_color=c("sidebar_muted")).pack(side=START)
        self.crumb = ctk.CTkLabel(crumbs, text="", font=font(14, "bold"), text_color="#FFFFFF")
        self.crumb.pack(side=START)

        hint = ctk.CTkLabel(bar, text="Ctrl+B القائمة   ·   Ctrl+F بحث   ·   F5 تحديث",
                            font=font(11), text_color=c("sidebar_text"))
        hint.pack(side=END, padx=10)
        ctk.CTkFrame(parent, height=1, fg_color=c("border"), corner_radius=0
                     ).pack(fill="x")

    def _set_language(self, language: str):
        language_code = "en" if language == "English" else "ar"
        self.prefs["language"] = language_code
        preferences.save(language=language_code)

    @staticmethod
    def _theme_glyph():
        return icon("sun") if ctk.get_appearance_mode() == "Dark" else icon("moon")

    # -------------------------------------------------
    # Keyboard shortcuts (forwarded to the active page when supported)
    # -------------------------------------------------

    def _bind_shortcuts(self):
        self.bind_all("<Control-b>", self.toggle_sidebar, add="+")
        self.bind_all("<Control-B>", self.toggle_sidebar, add="+")
        self.bind_all("<F5>", lambda _e: self._page_call("refresh", "load_report", "load_events",
                                                        "load_backups"), add="+")
        self.bind_all("<Control-f>", lambda _e: self._focus_search(), add="+")
        self.bind_all("<Control-F>", lambda _e: self._focus_search(), add="+")
        self.bind_all("<Control-n>", lambda _e: self._page_call("add"), add="+")
        self.bind_all("<Control-N>", lambda _e: self._page_call("add"), add="+")

    def _page_call(self, *names):
        page = self.current_page
        if page is None or self.focus_get() is None:
            return
        if self.focus_get().winfo_toplevel() is not self:
            return  # a dialog has focus
        for name in names:
            fn = getattr(page, name, None)
            if callable(fn):
                fn()
                return

    def _focus_search(self):
        search = getattr(self.current_page, "search", None)
        if search is not None and hasattr(search, "focus"):
            search.focus()

    # -------------------------------------------------

    def _has_navigation_permission(self, key: str) -> bool:
        if not self.user:
            return False
        if key in ("apps", "app_catalog"):
            return bool(self._accessible_modules())
        service = PermissionService()
        user_id = int(self.user["id"])
        permissions = NAV_PERMISSIONS.get(key, ())
        if not permissions:
            return False
        # A module lists alternative permissions sufficient to enter its page.
        # Individual write actions remain checked by their page and services.
        return any(service.has_permission(user_id, permission) for permission in permissions)

    def _accessible_modules(self):
        return [
            item for item in NAVIGATION
            if item[0] not in ("apps", "app_catalog")
            and self._has_navigation_permission(item[0])
        ]

    def navigate(self, key: str):
        if not self._has_navigation_permission(key):
            return
        factory = next(f for k, _l, _i, f, _s in NAVIGATION if k == key)
        if self.current_page is not None:
            self.current_page.destroy()
        self.current_key = key
        page_kwargs: dict[str, object] = {"user": self.user, "navigate": self.navigate}
        if key in ("apps", "app_catalog"):
            page_kwargs["modules"] = self._accessible_modules()
        self.current_page = factory(self.page_container, **page_kwargs)
        self.current_page.pack(fill="both", expand=True)

        for k, btn in self.nav_buttons.items():
            active = k == key
            btn.configure(fg_color=c("sidebar_active") if active else "transparent",
                          text_color="#FFFFFF" if active else c("sidebar_text"))
        self.crumb.configure(text=TITLES[key])
        self.crumb_section.configure(text=SECTIONS.get(key, ""))
        return self.current_page

    def toggle_theme(self):
        dark = ctk.get_appearance_mode() == "Dark"
        mode = "Light" if dark else "Dark"
        ctk.set_appearance_mode(mode)
        preferences.save(appearance=mode)
        self.theme_btn.configure(text=self._theme_glyph())
        self.navigate(self.current_key)  # redraw canvas-based widgets
