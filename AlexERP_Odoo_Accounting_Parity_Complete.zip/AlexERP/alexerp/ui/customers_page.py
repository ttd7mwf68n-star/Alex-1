"""Company-scoped customer records, credit limits, and receivable accounts."""
from __future__ import annotations

import sqlite3
from tkinter import messagebox

import customtkinter as ctk

from alexerp.services.customer_service import CustomerService
from alexerp.services.permission_service import PermissionService
from alexerp.ui.components import (
    Badge, DataTable, Dialog, Page, SearchBar, Toolbar, danger_button, entry,
    field, primary_button, subtle_button, toast,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR

COLUMNS = [
    ("code", "الكود", 100, "w"),
    ("name", "العميل", 210, "w"),
    ("phone", "الهاتف", 125, "w"),
    ("current_balance", "الرصيد", 115, "e"),
    ("credit_limit", "حد الائتمان", 115, "e"),
    ("ledger_account_code", "حساب الذمم", 130, "w"),
]


def _money(value) -> float:
    text = str(value or "").strip().replace(",", "")
    amount = float(text or 0)
    if amount < 0:
        raise ValueError("لا يمكن أن يكون حد الائتمان سالباً.")
    return amount


class CustomerDialog(Dialog):
    FIELDS = (
        ("code", "كود العميل *"), ("name", "اسم العميل *"),
        ("tax_number", "الرقم الضريبي"), ("phone", "الهاتف"),
        ("mobile", "الجوال"), ("email", "البريد الإلكتروني"),
        ("address", "العنوان"), ("city", "المدينة"),
        ("credit_limit", "حد الائتمان (0 بلا حد)"),
    )
    LAYOUT = (
        ("code", "name"), ("tax_number", "phone"), ("mobile", "email"),
        ("address",), ("city", "credit_limit"),
    )

    def __init__(self, parent, service: CustomerService, user, customer=None, on_saved=None):
        super().__init__(
            parent, "تعديل عميل" if customer else "عميل جديد", 640, 590,
            subtitle="يُنشأ حساب ذمم مستقل للعميل تلقائياً", glyph="👤",
        )
        self.service, self.user, self.customer, self.on_saved = (
            service, user or {}, customer, on_saved
        )
        self.inputs: dict[str, ctk.CTkEntry] = {}
        labels = dict(self.FIELDS)
        form = ctk.CTkFrame(self, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=22, pady=(14, 0))
        for row_index, keys in enumerate(self.LAYOUT):
            for index, key in enumerate(keys):
                frame, widget = field(
                    form, labels[key], lambda parent: entry(
                        parent, "0.00" if key == "credit_limit" else ""
                    ),
                    required=key in {"code", "name"},
                )
                col = (1 - index) if len(keys) == 2 and START == "right" else index
                frame.grid(
                    row=row_index, column=col, columnspan=2 if len(keys) == 1 else 1,
                    sticky="ew", padx=6, pady=5,
                )
                value = customer[key] if customer is not None else ""
                if key == "credit_limit" and customer is None:
                    value = "0"
                if value is not None:
                    widget.insert(0, str(value))
                self.inputs[key] = widget
        form.grid_columnconfigure(0, weight=1, uniform="customer")
        form.grid_columnconfigure(1, weight=1, uniform="customer")
        if customer is not None:
            Badge(
                self,
                f"الرصيد الحالي: {float(customer['current_balance'] or 0):,.2f}  |  "
                f"حساب الأستاذ: {customer['ledger_account_code'] or 'غير محدد'}",
                "info",
            ).pack(anchor=TEXT_ANCHOR, padx=28, pady=(0, 6))
        self.error.pack(fill="x", padx=28, pady=(4, 0))
        buttons = [("حفظ", self.save, "primary"), ("إلغاء", self.destroy, "ghost")]
        self.footer(buttons, width=150)
        self.after(150, lambda: self.inputs["code"].focus())

    def save(self):
        values = {key: widget.get().strip() for key, widget in self.inputs.items()}
        if not values["code"] or not values["name"]:
            self.error.configure(text="كود العميل واسمه مطلوبان.")
            return
        try:
            limit = _money(values.pop("credit_limit"))
            if self.customer is None:
                self.service.create_customer(
                    company_id=int(self.user.get("company_id") or 0),
                    credit_limit=limit,
                    actor_id=int(self.user.get("id") or 0),
                    **values,
                )
            else:
                self.service.update_customer(
                    int(self.customer["id"]),
                    credit_limit=limit,
                    account_id=self.customer["account_id"],
                    actor_id=int(self.user.get("id") or 0),
                    **values,
                )
        except (ValueError, PermissionError) as exc:
            self.error.configure(text=str(exc))
            return
        except sqlite3.IntegrityError:
            self.error.configure(text="كود العميل مستخدم من قبل.")
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, "تم حفظ بيانات العميل")
        self.destroy()


class CustomersPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        super().__init__(
            parent, title="العملاء",
            subtitle="إدارة حسابات العملاء وأرصدتهم وحدود الائتمان", user=user,
        )
        self.user = user or {}
        self.user_id = int(self.user.get("id") or 0)
        self.company_id = int(self.user.get("company_id") or 0)
        self.service = CustomerService()
        permissions = PermissionService()
        self.can_create = permissions.has_permission(self.user_id, "customers.create")
        self.can_update = permissions.has_permission(self.user_id, "customers.update")
        self.can_delete = permissions.has_permission(self.user_id, "customers.delete")
        if self.can_create:
            primary_button(self.actions, "عميل جديد", self.add, width=130).pack(
                side="left", padx=4
            )
        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        self.search = SearchBar(
            bar.row, "ابحث بكود العميل أو اسمه أو هاتفه...",
            on_search=self.refresh, width=370,
        )
        bar.add(self.search)
        self.count = Badge(bar.row, "", "info")
        bar.add(self.count, side=END, padx=8)
        self.table = DataTable(
            self.body, COLUMNS,
            on_double=self.edit if self.can_update else None,
            empty_text="لا توجد حسابات عملاء",
        )
        self.table.pack(fill="both", expand=True)
        foot = ctk.CTkFrame(self.body, fg_color="transparent")
        foot.pack(fill="x", pady=(10, 0))
        if self.can_update:
            subtle_button(foot, "تعديل بيانات العميل", self.edit).pack(side=START, padx=6)
        if self.can_delete:
            danger_button(foot, "حذف العميل", self.delete).pack(side=START, padx=6)
        self.refresh()

    def refresh(self):
        rows = [dict(row) for row in self.service.get_all(self.company_id)]
        keyword = self.search.get().strip().lower()
        if keyword:
            rows = [
                row for row in rows
                if keyword in " ".join(
                    str(row.get(key) or "")
                    for key in ("code", "name", "phone", "mobile")
                ).lower()
            ]
        self.table.set_rows(
            rows,
            {
                "current_balance": lambda value: f"{float(value or 0):,.2f}",
                "credit_limit": lambda value: (
                    "بلا حد" if not float(value or 0) else f"{float(value):,.2f}"
                ),
                "ledger_account_code": lambda value: value or "—",
            },
        )
        self.count.set(f"{len(rows)} عميل")

    def _selected(self, row=None):
        selected = row or self.table.selected
        if selected is None:
            messagebox.showinfo("العملاء", "اختر عميلاً من الجدول أولاً.")
        return selected

    def add(self):
        if self.can_create:
            CustomerDialog(self, self.service, self.user, on_saved=self.refresh)

    def edit(self, row=None):
        if not self.can_update:
            return
        customer = self._selected(row)
        if customer is not None:
            CustomerDialog(self, self.service, self.user, customer, self.refresh)

    def delete(self):
        if not self.can_delete:
            return
        customer = self._selected()
        if customer is None:
            return
        if not messagebox.askyesno(
            "حذف عميل", f"حذف العميل «{customer['name']}»؟",
            parent=self.winfo_toplevel(),
        ):
            return
        try:
            self.service.delete(int(customer["id"]), actor_id=self.user_id)
        except (ValueError, PermissionError, sqlite3.IntegrityError) as exc:
            messagebox.showerror("تعذر حذف العميل", str(exc), parent=self.winfo_toplevel())
            return
        toast(self, "تم حذف العميل", "warning")
        self.refresh()
