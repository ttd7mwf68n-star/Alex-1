"""Purchasing control tower: order tracking, late deliveries and supplier performance."""
from __future__ import annotations

import customtkinter as ctk

from alexerp.services.purchasing_workflow_service import PurchasingWorkflowService
from alexerp.services.approval_workflow_service import ApprovalWorkflowService
from alexerp.services.permission_service import PermissionService
from alexerp.ui.components import DataTable, Dialog, Page, SectionHeader, StatCard, ghost_button
from alexerp.ui.theme import START, c, font, icon
from alexerp.database.db import Database
from alexerp.core import context
from tkinter import messagebox
from datetime import date


class ApprovalWorkflowDialog(Dialog):
    NEW_LABEL = "＋ تدفق اعتماد جديد"

    def __init__(self, parent, company_id, actor_id, on_saved):
        super().__init__(parent, "إعداد تدفقات الاعتماد", 760, 720,
                         subtitle="حدود المبلغ غير متداخلة، والخطوات تنفذ بالتتابع حسب الدور", glyph="✓")
        self.company_id = company_id
        self.actor_id = actor_id
        self.on_saved = on_saved
        self.service = ApprovalWorkflowService()
        self.roles = self.service.list_roles(company_id, actor_id)
        if not self.roles:
            raise ValueError("أضف دورًا نشطًا قبل إعداد تدفق الاعتماد.")
        self.role_labels = {f"{role['id']} — {role['name']}": role for role in self.roles}
        self.workflows = self.service.list_workflows(company_id, actor_id)
        self.workflow_labels = {
            f"{item['id']} — {item['name']}": item for item in self.workflows
        }
        selector_frame = ctk.CTkFrame(self, fg_color="transparent")
        selector_frame.pack(fill="x", padx=24, pady=(14, 4))
        ctk.CTkLabel(selector_frame, text="التدفق", anchor="e").pack(fill="x")
        self.selector_values = [self.NEW_LABEL] + list(self.workflow_labels)
        self.selector = ctk.CTkComboBox(
            selector_frame, values=self.selector_values, width=600,
            command=lambda _value: self._load_selected(),
        )
        self.selector.set(self.NEW_LABEL)
        self.selector.pack(fill="x", pady=4)
        self.name = self._entry("اسم التدفق")
        self.minimum = self._entry("الحد الأدنى للمبلغ (شامل)")
        self.maximum = self._entry("الحد الأعلى للمبلغ (غير شامل، اتركه فارغًا بلا حد)")
        self.active = ctk.CTkCheckBox(self, text="تدفق نشط")
        self.active.select()
        self.active.pack(anchor="e", padx=24, pady=4)
        ctk.CTkLabel(self, text="خطوات الاعتماد بالترتيب:", anchor="e",
                     font=font(13, "bold")).pack(fill="x", padx=24, pady=(8, 2))
        self.steps_area = ctk.CTkScrollableFrame(self, fg_color="transparent", height=200)
        self.steps_area.pack(fill="both", expand=True, padx=20, pady=4)
        self.steps = []
        ctk.CTkButton(self, text="＋ إضافة خطوة", command=self._add_step).pack(
            anchor="e", padx=24, pady=4
        )
        self.error.pack(fill="x", padx=24, pady=(2, 0))
        self.footer([("حفظ التدفق", self.save, "primary"), ("إغلاق", self.destroy, "ghost")])
        self._add_step()

    def _entry(self, caption):
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.pack(fill="x", padx=24, pady=4)
        ctk.CTkLabel(frame, text=caption, anchor="e").pack(fill="x")
        control = ctk.CTkEntry(frame, width=600)
        control.pack(fill="x", pady=3)
        return control

    def _add_step(self, role_id=None):
        if len(self.steps) >= 10:
            self.error.configure(text="الحد الأقصى 10 خطوات.")
            return
        row = ctk.CTkFrame(self.steps_area, fg_color="transparent")
        row.pack(fill="x", pady=3)
        combo = ctk.CTkComboBox(row, values=list(self.role_labels), width=450)
        combo.set(next(
            (label for label, role in self.role_labels.items() if role["id"] == role_id),
            next(iter(self.role_labels)),
        ))
        combo.pack(side="right", padx=5)
        record = {"row": row, "role": combo}
        ctk.CTkButton(
            row, text="حذف", width=60, fg_color=c("danger"),
            command=lambda: self._remove_step(record),
        ).pack(side="right", padx=5)
        self.steps.append(record)

    def _remove_step(self, record):
        if len(self.steps) <= 1:
            self.error.configure(text="يجب وجود خطوة اعتماد واحدة على الأقل.")
            return
        self.steps.remove(record)
        record["row"].destroy()

    def _clear_steps(self):
        for step in self.steps:
            step["row"].destroy()
        self.steps.clear()

    def _set_entry(self, control, value):
        control.delete(0, "end")
        if value is not None:
            control.insert(0, str(value))

    def _load_selected(self):
        selected = self.workflow_labels.get(self.selector.get())
        self._set_entry(self.name, selected["name"] if selected else "")
        self._set_entry(self.minimum, selected["min_amount"] if selected else "0")
        self._set_entry(self.maximum, selected["max_amount"] if selected else "")
        if selected and selected["is_active"]:
            self.active.select()
        else:
            self.active.deselect()
        self._clear_steps()
        if selected:
            for step in selected["steps"]:
                self._add_step(step["role_id"])
        else:
            self._add_step()
        self.error.configure(text="")

    def save(self):
        selected = self.workflow_labels.get(self.selector.get())
        role_ids = [
            int(self.role_labels[step["role"].get()]["id"]) for step in self.steps
        ]
        try:
            self.service.save_workflow(
                self.company_id, self.actor_id, self.name.get().strip(),
                self.minimum.get().strip(), self.maximum.get().strip() or None,
                role_ids, bool(self.active.get()),
                int(selected["id"]) if selected else None,
            )
        except (ValueError, PermissionError, KeyError) as exc:
            self.error.configure(text=str(exc))
            return
        self.on_saved()
        self.destroy()


class PurchasingWorkflowPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        user = user or {}
        super().__init__(parent, title="إدارة التوريد", subtitle="متابعة أوامر الشراء والاستلامات وأداء الموردين",
                         user=user, scroll=True)
        self.company_id = int(user.get("company_id") or 0)
        self.branch_id = int(user["branch_id"]) if user.get("branch_id") else None
        self.actor_id = int(user.get("id") or 0)
        self.service = PurchasingWorkflowService()
        if PermissionService().has_permission_for_company(
            self.actor_id, self.company_id, "purchases.workflow.manage"
        ):
            ghost_button(
                self.actions, "إعدادات الاعتماد", self.manage_approval_workflows, width=135
            ).pack(side="left", padx=3)
        ghost_button(self.actions, "طلب شراء", self.new_requisition, width=105).pack(side="left", padx=3)
        ghost_button(self.actions, "أمر شراء", self.new_order, width=105).pack(side="left", padx=3)
        ghost_button(self.actions, "استلام", self.receive_order, width=90).pack(side="left", padx=3)
        ghost_button(self.actions, "اعتماد", self.approve_order, width=85).pack(side="left", padx=3)
        ghost_button(self.actions, "رفض", self.reject_order, width=75).pack(side="left", padx=3)
        ghost_button(self.actions, "عرض مورد", self.add_quote, width=100).pack(side="left", padx=3)
        ghost_button(self.actions, "مقارنة العروض", self.compare_quotes, width=115).pack(side="left", padx=3)
        ghost_button(self.actions, "مطابقة فاتورة", self.match_invoice, width=115).pack(side="left", padx=3)
        ghost_button(self.actions, "مراجعة الفروق", self.review_invoice_variances, width=115).pack(side="left", padx=3)
        ghost_button(self.actions, f"{icon('refresh')}  تحديث", self.refresh, width=100).pack(side="left", padx=3)
        cards = ctk.CTkFrame(self.body, fg_color="transparent")
        cards.pack(fill="x", pady=5)
        self.cards = {}
        for i, (key, title, tone) in enumerate([
            ("orders", "أوامر الشراء", "primary"), ("open", "مفتوحة / جزئية", "warning"),
            ("late", "توريدات متأخرة", "danger"), ("received", "مستلمة بالكامل", "success")]):
            card = StatCard(cards, "🛒", title, "—", tone)
            card.grid(row=0, column=i, padx=5, pady=5, sticky="nsew")
            self.cards[key] = card
            cards.grid_columnconfigure(i, weight=1, uniform="purchasing-kpi")
        section = ctk.CTkFrame(self.body, fg_color="transparent")
        section.pack(fill="both", expand=True, pady=8)
        SectionHeader(section, "متابعة أوامر الشراء", "الكميات المطلوبة والمستلمة ومواعيد التسليم", "🚚").pack(fill="x", padx=8, pady=5)
        self.orders = DataTable(section, [
            ("id", "ID", 45, "e"), ("order_number", "رقم الأمر", 120, "w"), ("supplier_name", "المورد", 190, "w"),
            ("order_date", "التاريخ", 100, "w"), ("expected_date", "التسليم المتوقع", 120, "w"),
            ("status", "حالة الاستلام", 130, "w"), ("approval_status", "الاعتماد", 110, "w"), ("ordered_quantity", "مطلوب", 90, "e"),
            ("received_quantity", "مستلم", 90, "e"), ("total_amount", "الإجمالي", 115, "e"),
            ("is_late", "متأخر؟", 75, "center")],
            empty_text="لا توجد أوامر شراء في النطاق الحالي")
        self.orders.pack(fill="both", expand=True, padx=4)
        section2 = ctk.CTkFrame(self.body, fg_color="transparent")
        section2.pack(fill="both", expand=True, pady=8)
        SectionHeader(section2, "مؤشرات أداء الموردين", "عدد الأوامر ونسبة التسليم في الموعد ومتوسط الانحراف عن الموعد", "🏅").pack(fill="x", padx=8, pady=5)
        self.suppliers = DataTable(section2, [
            ("supplier_name", "المورد", 220, "w"), ("order_count", "الأوامر", 90, "e"),
            ("completed_orders", "مكتملة", 90, "e"), ("on_time_rate", "التسليم في الموعد %", 150, "e"),
            ("avg_days_vs_expected", "متوسط فرق الأيام", 150, "e")],
            empty_text="لا توجد بيانات موردين")
        self.suppliers.pack(fill="both", expand=True, padx=4)
        ctk.CTkLabel(self.body,
            text="مهم: تسجيل إذن الاستلام يحدّث كميات أمر الشراء فقط. لا يضيف المخزون ولا ينشئ قيدًا محاسبيًا؛ يتم إثبات المخزون عند ترحيل فاتورة الشراء عبر دورة الفواتير الحالية لمنع ازدواج الكميات.",
            font=font(11), text_color=c("muted"), justify="right", wraplength=1100).pack(fill="x", padx=10, pady=12)
        self.refresh()

    def _lookup(self, sql, params=()):
        return [dict(r) for r in Database.connect().execute(sql, params).fetchall()]

    def _form(self, title, fields, submit):
        win = ctk.CTkToplevel(self)
        win.title(title); win.geometry("560x560"); win.transient(self.winfo_toplevel()); win.grab_set()
        body = ctk.CTkScrollableFrame(win); body.pack(fill="both", expand=True, padx=16, pady=16)
        widgets = {}
        for key, caption, values in fields:
            ctk.CTkLabel(body, text=caption, anchor="e").pack(fill="x", pady=(8, 2))
            if values is not None:
                w = ctk.CTkComboBox(body, values=values, width=480)
                if values: w.set(values[0])
            else:
                w = ctk.CTkEntry(body, width=480)
                if key in {"date", "expected"}:
                    w.insert(0, date.today().isoformat())
            w.pack(fill="x"); widgets[key] = w
        def save():
            try:
                submit({k: w.get().strip() for k,w in widgets.items()})
                win.destroy(); self.refresh()
                messagebox.showinfo("إدارة التوريد", "تم حفظ العملية بنجاح", parent=self)
            except Exception as exc:
                messagebox.showerror("تعذر الحفظ", str(exc), parent=win)
        ctk.CTkButton(body, text="حفظ", command=save).pack(pady=18)
        return win

    def _scope(self):
        return self.company_id, self.branch_id, int(context.current_user_id() or 0)

    def manage_approval_workflows(self):
        try:
            ApprovalWorkflowDialog(
                self, self.company_id, self.actor_id, self.refresh
            )
        except Exception as exc:
            messagebox.showerror("إعداد تدفقات الاعتماد", str(exc), parent=self)


    def _catalog(self):
        suppliers = self._lookup("SELECT id,name FROM suppliers WHERE company_id=? AND is_active=1 ORDER BY name", (self.company_id,))
        products = self._lookup("SELECT id,name FROM products WHERE company_id=? ORDER BY name", (self.company_id,))
        warehouses = self._lookup("SELECT id,name FROM warehouses WHERE company_id=? ORDER BY name", (self.company_id,))
        return suppliers, products, warehouses

    def _multi_line_editor(self, title, header_fields, products, warehouses, price_required, on_save, receipt_lines=False):
        """Reusable multi-line editor for requisitions, orders and goods receipts."""
        win = ctk.CTkToplevel(self)
        win.title(title); win.geometry("900x720"); win.transient(self.winfo_toplevel()); win.grab_set()
        body = ctk.CTkScrollableFrame(win); body.pack(fill="both", expand=True, padx=14, pady=14)
        header = {}
        for key, caption in header_fields:
            ctk.CTkLabel(body, text=caption, anchor="e").pack(fill="x", pady=(7, 2))
            widget = ctk.CTkEntry(body, width=650)
            if key in {"date", "expected"}: widget.insert(0, date.today().isoformat())
            widget.pack(fill="x"); header[key] = widget
        ctk.CTkLabel(body, text="بنود العملية", font=font(14, weight="bold"), anchor="e").pack(fill="x", pady=(16, 5))
        rows_frame = ctk.CTkFrame(body, fg_color="transparent"); rows_frame.pack(fill="x")
        pmap = {r['name']: int(r['id']) for r in products}
        wmap = {r['name']: int(r['id']) for r in warehouses}
        row_widgets = []

        def add_row(default=None):
            default = default or {}
            frame = ctk.CTkFrame(rows_frame); frame.pack(fill="x", pady=4)
            product = ctk.CTkComboBox(frame, values=list(pmap), width=190)
            warehouse = ctk.CTkComboBox(frame, values=list(wmap), width=160)
            if pmap: product.set(default.get("product_name", list(pmap)[0]))
            if wmap: warehouse.set(default.get("warehouse_name", list(wmap)[0]))
            product.pack(side="left", padx=3); warehouse.pack(side="left", padx=3)
            qty = ctk.CTkEntry(frame, width=90, placeholder_text="الكمية")
            qty.pack(side="left", padx=3)
            cost = None
            if price_required:
                cost = ctk.CTkEntry(frame, width=100, placeholder_text="سعر الوحدة")
                cost.pack(side="left", padx=3)
            remove = ctk.CTkButton(frame, text="حذف", width=55, fg_color=c("danger"), command=lambda: remove_row(record))
            record = {"frame": frame, "product": product, "warehouse": warehouse, "qty": qty, "cost": cost}
            remove.pack(side="left", padx=3)
            row_widgets.append(record)

        def remove_row(record):
            if len(row_widgets) <= 1:
                messagebox.showwarning(title, "يجب الاحتفاظ ببند واحد على الأقل", parent=win); return
            row_widgets.remove(record); record["frame"].destroy()

        ctk.CTkButton(body, text="+ إضافة بند", command=add_row).pack(anchor="e", pady=8)
        add_row()
        notes = ctk.CTkEntry(body, width=650, placeholder_text="ملاحظات")
        notes.pack(fill="x", pady=8)

        def save():
            try:
                values = {k: w.get().strip() for k, w in header.items()}
                items = []
                for row in row_widgets:
                    product_name, warehouse_name = row["product"].get(), row["warehouse"].get()
                    qty_text = row["qty"].get().strip()
                    if not qty_text and not product_name and not warehouse_name: continue
                    item = {"product_id": pmap[product_name], "warehouse_id": wmap[warehouse_name], "quantity": float(qty_text)}
                    if price_required: item["unit_cost"] = float(row["cost"].get().strip())
                    items.append(item)
                if not items: raise ValueError("أدخل بندًا واحدًا على الأقل")
                on_save(values, items, notes.get().strip())
                win.destroy(); self.refresh()
                messagebox.showinfo("إدارة التوريد", "تم حفظ العملية بنجاح", parent=self)
            except Exception as exc:
                messagebox.showerror("تعذر الحفظ", str(exc), parent=win)
        ctk.CTkButton(body, text="حفظ العملية", command=save).pack(pady=16)
        return win

    def new_requisition(self):
        _, products, warehouses = self._catalog()
        if not products or not warehouses:
            messagebox.showwarning("بيانات ناقصة", "أضف الأصناف والمخازن أولاً", parent=self); return
        def save(v, items, notes):
            company, branch, user = self._scope()
            self.service.create_requisition(company, branch, v['number'], v['date'], user, items, notes)
        self._multi_line_editor("طلب شراء متعدد البنود", [("number", "رقم الطلب"), ("date", "التاريخ YYYY-MM-DD")],
            products, warehouses, False, save)

    def new_order(self):
        suppliers, products, warehouses = self._catalog()
        if not suppliers or not products or not warehouses:
            messagebox.showwarning("بيانات ناقصة", "أضف الموردين والأصناف والمخازن أولاً", parent=self); return
        smap={r['name']:r['id'] for r in suppliers}
        win = ctk.CTkToplevel(self); win.title("إنشاء أمر شراء متعدد البنود"); win.geometry("920x760")
        win.transient(self.winfo_toplevel()); win.grab_set()
        body = ctk.CTkScrollableFrame(win); body.pack(fill="both", expand=True, padx=14, pady=14)
        fields = {}
        for key, caption in [("number", "رقم الأمر"), ("date", "تاريخ الأمر YYYY-MM-DD"), ("expected", "تاريخ التسليم المتوقع YYYY-MM-DD")]:
            ctk.CTkLabel(body, text=caption, anchor="e").pack(fill="x", pady=(7,2)); ent=ctk.CTkEntry(body, width=650)
            if key in {"date", "expected"}: ent.insert(0,date.today().isoformat())
            ent.pack(fill="x"); fields[key]=ent
        ctk.CTkLabel(body,text="المورد",anchor="e").pack(fill="x",pady=(7,2))
        supplier=ctk.CTkComboBox(body,values=list(smap),width=650); supplier.set(next(iter(smap))); supplier.pack(fill="x")
        line_host=ctk.CTkFrame(body,fg_color="transparent"); line_host.pack(fill="x",pady=10)
        pmap={r['name']:int(r['id']) for r in products}; wmap={r['name']:int(r['id']) for r in warehouses}; lines=[]
        def add_line():
            frame=ctk.CTkFrame(line_host); frame.pack(fill="x",pady=3)
            product=ctk.CTkComboBox(frame,values=list(pmap),width=180); product.set(next(iter(pmap))); product.pack(side="left",padx=3)
            warehouse=ctk.CTkComboBox(frame,values=list(wmap),width=150); warehouse.set(next(iter(wmap))); warehouse.pack(side="left",padx=3)
            qty=ctk.CTkEntry(frame,width=85,placeholder_text="الكمية"); qty.pack(side="left",padx=3)
            cost=ctk.CTkEntry(frame,width=100,placeholder_text="سعر الوحدة"); cost.pack(side="left",padx=3)
            record={"frame":frame,"product":product,"warehouse":warehouse,"qty":qty,"cost":cost}; lines.append(record)
            def remove():
                if len(lines)==1: messagebox.showwarning("أمر الشراء","يجب وجود بند واحد على الأقل",parent=win); return
                lines.remove(record); frame.destroy()
            ctk.CTkButton(frame,text="حذف",width=55,fg_color=c("danger"),command=remove).pack(side="left",padx=3)
        add_line(); ctk.CTkButton(body,text="+ إضافة بند",command=add_line).pack(anchor="e")
        notes=ctk.CTkEntry(body,width=650,placeholder_text="ملاحظات"); notes.pack(fill="x",pady=8)
        def save():
            try:
                items=[]
                for line in lines:
                    items.append({"product_id":pmap[line['product'].get()],"warehouse_id":wmap[line['warehouse'].get()],
                        "quantity":float(line['qty'].get()),"unit_cost":float(line['cost'].get())})
                company,branch,user=self._scope()
                self.service.create_order(company,branch,smap[supplier.get()],fields['number'].get().strip(),fields['date'].get().strip(),
                    fields['expected'].get().strip() or None,user,items,notes=notes.get().strip(),require_approval=True)
                win.destroy(); self.refresh(); messagebox.showinfo("أمر الشراء","تم إنشاء الأمر متعدد البنود بانتظار الاعتماد",parent=self)
            except Exception as exc: messagebox.showerror("تعذر إنشاء الأمر",str(exc),parent=win)
        ctk.CTkButton(body,text="حفظ أمر الشراء",command=save).pack(pady=16)

    def _selected_order(self):
        row=self.orders.selected
        if not row:
            messagebox.showwarning("اختيار مطلوب", "حدد أمر شراء من الجدول أولاً", parent=self); return None
        return row

    def approve_order(self):
        row=self._selected_order()
        if row:
            try:
                company,branch,user=self._scope(); self.service.approve_order(company,branch,int(row['id']),user)
                self.refresh(); messagebox.showinfo("إدارة التوريد","تم اعتماد أمر الشراء",parent=self)
            except Exception as exc: messagebox.showerror("تعذر الاعتماد",str(exc),parent=self)

    def reject_order(self):
        row=self._selected_order()
        if not row: return
        self._form("رفض أمر الشراء", [("reason","سبب الرفض (إجباري)",None)], lambda v: self.service.reject_order(*self._scope()[:2],int(row['id']),self._scope()[2],v['reason']))

    def receive_order(self):
        row=self._selected_order()
        if not row: return
        lines=self._lookup("SELECT poi.id,poi.product_id,poi.warehouse_id,poi.ordered_quantity,poi.received_quantity,p.name product_name,w.name warehouse_name FROM purchase_order_items poi JOIN products p ON p.id=poi.product_id JOIN warehouses w ON w.id=poi.warehouse_id WHERE poi.order_id=? ORDER BY poi.id",(int(row['id']),))
        open_lines=[r for r in lines if float(r['ordered_quantity'])>float(r['received_quantity'])]
        if not open_lines:
            messagebox.showinfo("الاستلام","لا توجد كميات متبقية لهذا الأمر",parent=self); return
        win=ctk.CTkToplevel(self); win.title("استلام متعدد البنود"); win.geometry("850x650")
        win.transient(self.winfo_toplevel()); win.grab_set()
        body=ctk.CTkScrollableFrame(win); body.pack(fill="both",expand=True,padx=14,pady=14)
        number=ctk.CTkEntry(body,width=600,placeholder_text="رقم إذن الاستلام"); number.pack(fill="x",pady=5)
        receipt_date=ctk.CTkEntry(body,width=600); receipt_date.insert(0,date.today().isoformat()); receipt_date.pack(fill="x",pady=5)
        ctk.CTkLabel(body,text="أدخل الكمية المستلمة لكل بند (اترك الصفر للبنود غير المستلمة)",anchor="e").pack(fill="x",pady=8)
        entries=[]
        for line in open_lines:
            remaining=float(line['ordered_quantity'])-float(line['received_quantity'])
            frame=ctk.CTkFrame(body); frame.pack(fill="x",pady=3)
            ctk.CTkLabel(frame,text=f"{line['product_name']} — {line['warehouse_name']} — متبقي {remaining:g}",anchor="e").pack(side="left",padx=8)
            qty=ctk.CTkEntry(frame,width=110,placeholder_text="كمية الاستلام"); qty.pack(side="right",padx=8)
            entries.append((int(line['id']),qty,remaining))
        notes=ctk.CTkEntry(body,width=600,placeholder_text="ملاحظات"); notes.pack(fill="x",pady=8)
        def save():
            try:
                items=[]
                for line_id,widget,remaining in entries:
                    raw=widget.get().strip()
                    if not raw: continue
                    qty=float(raw)
                    if qty>0: items.append({"order_item_id":line_id,"quantity":qty})
                company,branch,user=self._scope()
                self.service.record_receipt(company,branch,int(row['id']),number.get().strip(),receipt_date.get().strip(),user,items,notes.get().strip())
                win.destroy(); self.refresh(); messagebox.showinfo("الاستلام","تم تسجيل إذن الاستلام متعدد البنود",parent=self)
            except Exception as exc: messagebox.showerror("تعذر تسجيل الاستلام",str(exc),parent=win)
        ctk.CTkButton(body,text="حفظ إذن الاستلام",command=save).pack(pady=16)

    def add_quote(self):
        suppliers, products, warehouses = self._catalog()
        if not suppliers or not products or not warehouses:
            messagebox.showwarning("عروض الموردين", "أضف الموردين والأصناف أولاً", parent=self); return
        smap={r['name']:r['id'] for r in suppliers}; pmap={r['name']:r['id'] for r in products}; wmap={r['name']:r['id'] for r in warehouses}
        def save(v):
            company, branch, user = self._scope()
            self.service.add_supplier_quote(company, branch, smap[v['supplier']], v['number'], v['date'],
                v['valid'] or None, [{'product_id':pmap[v['product']], 'warehouse_id':wmap[v['warehouse']],
                'quantity':float(v['qty']), 'unit_cost':float(v['cost']), 'delivery_days':int(v['days'] or 0)}],
                user, notes=v['notes'])
        self._form("تسجيل عرض سعر مورد", [("number","رقم العرض",None),("supplier","المورد",list(smap)),
            ("date","تاريخ العرض YYYY-MM-DD",None),("valid","صالح حتى YYYY-MM-DD (اختياري)",None),
            ("product","الصنف",list(pmap)),("warehouse","المخزن",list(wmap)),("qty","الكمية",None),("cost","سعر الوحدة",None),
            ("days","أيام التوريد",None),("notes","ملاحظات",None)], save)

    def compare_quotes(self):
        _, products, _ = self._catalog()
        if not products:
            messagebox.showinfo("مقارنة العروض", "لا توجد أصناف", parent=self); return
        pmap={r['name']:r['id'] for r in products}
        def show(v):
            rows=self.service.compare_quotes(self.company_id,pmap[v['product']],self.branch_id)
            if not rows:
                messagebox.showinfo("مقارنة العروض", "لا توجد عروض سارية لهذا الصنف", parent=self); return
            lines=[f"{r['supplier_name']} | سعر الوحدة: {float(r['unit_cost']):,.2f} | التوريد: {r['delivery_days']} يوم | العرض: {r['quote_number']}" for r in rows]
            messagebox.showinfo("مقارنة عروض الموردين", "\n".join(lines), parent=self)
        self._form("مقارنة عروض الموردين", [("product","الصنف",list(pmap))], show)

    def match_invoice(self):
        orders = [
            row for row in self.service.order_tracking(
                self.company_id, self.branch_id, self._scope()[2]
            )
            if row["approval_status"] == "APPROVED" and row["status"] != "CANCELLED"
        ]
        invoices=self._lookup("SELECT id,invoice_number,supplier_id FROM purchase_invoices WHERE company_id=? AND branch_id=? AND status='POSTED' ORDER BY id DESC",(self.company_id,self.branch_id))
        if not orders or not invoices:
            messagebox.showinfo("مطابقة الفاتورة", "يلزم وجود أمر معتمد وفاتورة شراء مرحلة", parent=self); return
        omap={r['order_number']:r for r in orders}; imap={r['invoice_number']:r for r in invoices}
        def do_match(v):
            order, invoice=omap[v['order']], imap[v['invoice']]
            if int(order['supplier_id']) != int(invoice['supplier_id']):
                raise ValueError("المورد في الفاتورة لا يطابق مورد أمر الشراء")
            conn=Database.connect()
            po_lines=conn.execute("SELECT * FROM purchase_order_items WHERE order_id=? ORDER BY id",(order['id'],)).fetchall()
            inv_lines=conn.execute("SELECT * FROM purchase_invoice_items WHERE invoice_id=? ORDER BY id",(invoice['id'],)).fetchall()
            matches=[]
            for pl in po_lines:
                used=float(conn.execute("SELECT COALESCE(SUM(matched_quantity),0) FROM purchase_order_invoice_links l JOIN purchase_invoices p ON p.id=l.invoice_id WHERE l.order_item_id=? AND p.status<>'CANCELLED'",(pl['id'],)).fetchone()[0] or 0)
                po_left=max(0.0,float(pl['received_quantity'])-used)
                for il in inv_lines:
                    if int(pl['product_id'])!=int(il['product_id']) or int(pl['warehouse_id'])!=int(il['warehouse_id']): continue
                    inv_used=float(conn.execute("SELECT COALESCE(SUM(matched_quantity),0) FROM purchase_order_invoice_links l JOIN purchase_invoices p ON p.id=l.invoice_id WHERE l.invoice_item_id=? AND p.status<>'CANCELLED'",(il['id'],)).fetchone()[0] or 0)
                    qty=min(po_left,max(0.0,float(il['quantity'])-inv_used))
                    if qty>1e-9:
                        matches.append({'order_item_id':pl['id'],'invoice_item_id':il['id'],'quantity':qty}); po_left-=qty
                    if po_left<=1e-9: break
            if not matches: raise ValueError("لا توجد كميات مستلمة وغير مفوترة قابلة للمطابقة")
            self.service.link_invoice(self.company_id,self.branch_id,int(order['id']),int(invoice['id']),self._scope()[2],matches)
            messagebox.showinfo("مطابقة الفاتورة",f"تمت مطابقة {len(matches)} بند/بنود بنجاح",parent=self)
        self._form("مطابقة فاتورة بأمر شراء", [("order","أمر الشراء",list(omap)),("invoice","فاتورة المورد",list(imap))], do_match)

    def review_invoice_variances(self):
        """Show read-only PO/invoice matching exceptions for the active scope."""
        try:
            rows = self.service.invoice_match_audit(
                self.company_id, self.branch_id, self._scope()[2]
            )
            exceptions = [r for r in rows if r["review_status"] == "REVIEW_REQUIRED"]
        except Exception as exc:
            messagebox.showerror("مراجعة فروق الفواتير", str(exc), parent=self)
            return
        win = ctk.CTkToplevel(self)
        win.title("مراجعة فروق فواتير الموردين")
        win.geometry("1050x560")
        win.transient(self.winfo_toplevel())
        body = ctk.CTkFrame(win, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=14, pady=14)
        ctk.CTkLabel(body,
            text=f"عدد البنود المفحوصة: {len(rows)}    |    تحتاج مراجعة: {len(exceptions)}",
            font=font(14, weight="bold"), anchor="e").pack(fill="x", pady=(0, 8))
        text_box = ctk.CTkTextbox(body, wrap="none", font=font(12))
        text_box.pack(fill="both", expand=True)
        headings = "الحالة | أمر الشراء | الفاتورة | المورد | الكمية | فرق السعر | فرق الخصم | فرق الضريبة | صافي الفرق"
        text_box.insert("end", headings + "\n" + "─" * 130 + "\n")
        for r in rows:
            status = "مراجعة" if r["review_status"] == "REVIEW_REQUIRED" else "مطابق"
            text_box.insert("end", f"{status} | {r['order_number']} | {r['invoice_number']} | {r['supplier_name']} | "
                f"{r['matched_quantity']:g} | {r['price_variance']:,.2f} | {r['discount_variance']:,.2f} | "
                f"{r['tax_variance']:,.2f} | {r['net_variance']:,.2f}\n")
        if not rows:
            text_box.insert("end", "لا توجد عمليات مطابقة فواتير في نطاق الشركة والفرع الحالي.\n")
        text_box.configure(state="disabled")
        ctk.CTkLabel(body,
            text="هذا التقرير للقراءة فقط؛ لا يعتمد الفروق ولا يغيّر الفواتير أو القيود المحاسبية.",
            text_color=c("muted"), font=font(11), anchor="e").pack(fill="x", pady=(8, 0))

    def refresh(self):
        if self.company_id <= 0:
            return
        try:
            user_id = self._scope()[2]
            orders = self.service.order_tracking(self.company_id, self.branch_id, user_id)
            self.cards["orders"].set(f"{len(orders):,}", "ضمن نطاق الشركة والفرع")
            self.cards["open"].set(sum(r["status"] in ("OPEN", "PARTIALLY_RECEIVED") for r in orders), "أوامر قيد التنفيذ")
            self.cards["late"].set(sum(r["is_late"] for r in orders), "تجاوزت تاريخ التسليم المتوقع")
            self.cards["received"].set(sum(r["status"] == "RECEIVED" for r in orders), "تم استلام كامل الكمية")
            self.orders.set_rows(orders, {"ordered_quantity": lambda x: f"{float(x or 0):,.2f}",
                                          "received_quantity": lambda x: f"{float(x or 0):,.2f}",
                                          "total_amount": lambda x: "" if x is None else f"{float(x):,.2f}",
                                          "is_late": lambda x: "نعم" if x else "لا"})
            suppliers = self.service.supplier_performance(
                self.company_id, self.branch_id, user_id
            )
            self.suppliers.set_rows(suppliers, {
                "on_time_rate": lambda x: "—" if x is None else f"{float(x)*100:.1f}%",
                "avg_days_vs_expected": lambda x: "—" if x is None else f"{float(x):.1f}",
            })
        except Exception as exc:
            ctk.CTkLabel(self.body, text=f"تعذر تحميل متابعة التوريد: {exc}",
                         text_color=c("danger"), font=font(12)).pack(fill="x", padx=10, pady=5)
