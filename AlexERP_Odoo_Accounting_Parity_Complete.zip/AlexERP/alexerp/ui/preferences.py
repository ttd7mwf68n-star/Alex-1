"""Small persisted UI preferences (theme mode, collapsed sidebar).

Stored as JSON next to the database folder. Never touches the database
itself; failures are silently ignored so the UI always starts.
"""
from __future__ import annotations

import json
from pathlib import Path

from alexerp.config import DATABASE_DIR

PREFS_PATH = Path(DATABASE_DIR) / "ui_preferences.json"
DEFAULTS = {"appearance": None, "sidebar_collapsed": False, "language": "ar"}


def load() -> dict:
    data = dict(DEFAULTS)
    try:
        data.update(json.loads(PREFS_PATH.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    return data


def save(**changes) -> bool:
    data = load()
    data.update(changes)
    try:
        PREFS_PATH.parent.mkdir(parents=True, exist_ok=True)
        PREFS_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except OSError:
        return False
