"""
AlexERP — Business Management System
Dashboard: KPI cards, charts, rankings and quick actions (read-only).
"""

from __future__ import annotations

from datetime import datetime

import customtkinter as ctk

from alexerp.services.dashboard_service import DashboardService
from alexerp.ui.components import (
    BarChart, Card, DonutChart, LineChart, Page, RankList, SectionHeader, StatCard,
    ghost_button, primary_button, subtle_button,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font, icon


def money(v) -> str:
    return f"{float(v or 0):,.0f}"


class DashboardPage(Page):

    def __init__(self, parent, user=None, navigate=None):
        name = (user["full_name"] or user["username"]) if user is not None else ""
        hour = datetime.now().hour
        greeting = "صباح الخير" if hour < 12 else "مساء الخير"
        super().__init__(parent, title=f"{greeting}، {name}",
                         subtitle=f"نظرة شاملة على أداء نشاطك · {datetime.now():%Y-%m-%d}",
                         user=user, scroll=True)
        self.service = DashboardService()
        self.company_id = int((user or {}).get("company_id") or 0)
        self.branch_id = int(user["branch_id"]) if user and user.get("branch_id") else None
        self.navigate = navigate

        ghost_button(self.actions, f"{icon('refresh')}  تحديث", self.refresh).pack(side="left", padx=4)
        if navigate:
            primary_button(self.actions, f"{icon('add')}  فاتورة بيع",
                           lambda: self._quick("sales", "add"), width=140).pack(side="left", padx=4)

        # ---- KPI cards (2 rows x 4) ----
        grid = ctk.CTkFrame(self.body, fg_color="transparent")
        grid.pack(fill="x")
        spec = [
            ("sales_today", "💰", "مبيعات اليوم", "primary", "sales"),
            ("sales_month", "📈", "مبيعات الشهر", "success", "sales"),
            ("purchases_month", "🛒", "مشتريات الشهر", "warning", "purchases"),
            ("stock_value", "🏬", "قيمة المخزون (بالتكلفة)", "info", "inventory"),
            ("receivables", "👥", "مستحقات العملاء", "primary", "reports"),
            ("payables", "🏭", "مستحقات الموردين", "danger", "reports"),
            ("low_stock", "⚠", "منتجات تحت الحد الأدنى", "warning", "products"),
            ("products", "📦", "الأصناف النشطة", "success", "products"),
        ]
        self.cards: dict[str, StatCard] = {}
        cols = 4
        for i, (key, glyph, text, tone, target) in enumerate(spec):
            command = (lambda t=target: self.navigate(t)) if navigate else None
            card = StatCard(grid, glyph, text, "-", tone, command=command)
            # RTL: first card at the right edge
            col = (cols - 1 - i % cols) if START == "right" else i % cols
            card.grid(row=i // cols, column=col, padx=7, pady=7, sticky="nsew")
            self.cards[key] = card
        for col in range(cols):
            grid.grid_columnconfigure(col, weight=1, uniform="stat")

        # ---- charts row ----
        row1 = self._row(weights=(3, 2))
        sales_card = self._card(row1, 0, "المبيعات اليومية", "آخر 14 يوم", "📊")
        self.chart = BarChart(sales_card, height=230)
        self.chart.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        stock_card = self._card(row1, 1, "حالة المخزون", "عدد الأصناف حسب الرصيد", "🏬")
        self.donut = DonutChart(stock_card, height=230, center_caption="صنف")
        self.donut.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        row2 = self._row(weights=(3, 2))
        flow_card = self._card(row2, 0, "المبيعات مقابل المشتريات", "آخر 30 يوم", "📈")
        self.flow = LineChart(flow_card, height=230)
        self.flow.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        quick = self._card(row2, 1, "إجراءات سريعة", "", "⚡")
        self._quick_actions(quick)

        # ---- lists row ----
        row3 = self._row(weights=(1, 1, 1))
        top_card = self._card(row3, 0, "الأكثر مبيعاً", "آخر 30 يوم", "🔥")
        self.top_list = RankList(top_card, tone="primary", empty_text="لا توجد مبيعات بعد")
        self.top_list.pack(fill="both", expand=True, padx=18, pady=(0, 16))

        low_card = self._card(row3, 1, "تحتاج إعادة طلب", "الرصيد / الحد الأدنى", "⚠")
        self.low_list = RankList(low_card, tone="warning", empty_text="المخزون سليم ✓")
        self.low_list.pack(fill="both", expand=True, padx=18, pady=(0, 16))

        debt_card = self._card(row3, 2, "أعلى مديونيات العملاء", "", "👥")
        self.debt_list = RankList(debt_card, tone="danger", empty_text="لا توجد مديونيات")
        self.debt_list.pack(fill="both", expand=True, padx=18, pady=(0, 16))

        self.refresh()

    # -------------------------------------------------

    def _row(self, weights):
        row = ctk.CTkFrame(self.body, fg_color="transparent")
        row.pack(fill="both", expand=True, pady=(4, 0))
        self._row_weights = weights
        n = len(weights)
        for i, w in enumerate(weights):
            col = (n - 1 - i) if START == "right" else i
            row.grid_columnconfigure(col, weight=w, uniform=f"r{id(row)}")
        row.grid_rowconfigure(0, weight=1)
        row._n = len(weights)
        return row

    def _card(self, row, index, title, subtitle, glyph):
        card = Card(row)
        col = (row._n - 1 - index) if START == "right" else index
        card.grid(row=0, column=col, padx=7, pady=7, sticky="nsew")
        SectionHeader(card, title, subtitle, glyph).pack(fill="x", padx=18, pady=(14, 8))
        return card

    def _quick(self, key, method=None):
        if not self.navigate:
            return
        page = self.navigate(key)
        if page is not None and method and hasattr(page, method):
            page.after(50, getattr(page, method))

    def _quick_actions(self, card):
        actions = [
            ("🧾", "فاتورة بيع جديدة", "sales", "add"),
            ("🛒", "فاتورة شراء جديدة", "purchases", "add"),
            ("📦", "إضافة منتج", "products", "add"),
            ("💸", "مدفوعات الموردين", "purchases", "open_payments"),
            ("📊", "التقارير المالية", "reports", None),
            ("✨", "اسأل المساعد الذكي", "ai", None),
        ]
        box = ctk.CTkFrame(card, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        for i, (glyph, text, key, method) in enumerate(actions):
            btn = subtle_button(box, f"{text}   {glyph}" if START == "right" else f"{glyph}   {text}",
                                lambda k=key, m=method: self._quick(k, m), width=10,
                                anchor=TEXT_ANCHOR, height=44)
            col = (1 - i % 2) if START == "right" else i % 2
            btn.grid(row=i // 2, column=col, padx=4, pady=4, sticky="nsew")
        for col in range(2):
            box.grid_columnconfigure(col, weight=1, uniform="qa")

    def refresh(self):
        if self.company_id <= 0:
            for card in self.cards.values():
                card.set("—", "لم يتم تحديد شركة للمستخدم")
            return
        s = self.service.summary(self.company_id, self.branch_id)
        self.cards["sales_today"].set(money(s["sales_today"]), "إجمالي فواتير اليوم المرحّلة")
        self.cards["sales_month"].set(money(s["sales_month"]), "منذ بداية الشهر")
        self.cards["purchases_month"].set(money(s["purchases_month"]), "منذ بداية الشهر")
        self.cards["stock_value"].set(money(s["stock_value"]), f"{s['products']} صنف نشط")
        self.cards["receivables"].set(money(s["receivables"]), f"{s['customers']} عميل")
        self.cards["payables"].set(money(s.get("payables", 0)), f"{s['suppliers']} مورد")
        self.cards["low_stock"].set(s["low_stock"], f"من أصل {s['products']} منتج")
        self.cards["products"].set(s["products"], "اضغط لعرض المنتجات")

        trend = self.service.sales_trend(14, self.company_id, self.branch_id)
        self.chart.set_data([t["label"] for t in trend], [t["total"] for t in trend])

        health = self.service.stock_health(self.company_id, self.branch_id)
        self.donut.set_data([
            ("متوفر", health["healthy"], "success"),
            ("منخفض", health["low"], "warning"),
            ("نفد", health["out_of_stock"], "danger"),
        ])

        sales30 = self.service.sales_trend(30, self.company_id, self.branch_id)
        purchases30 = self.service.purchases_trend(30, self.company_id, self.branch_id)
        self.flow.set_series([t["label"] for t in sales30], [
            ("المبيعات", [t["total"] for t in sales30], "primary"),
            ("المشتريات", [t["total"] for t in purchases30], "warning"),
        ])

        top = self.service.top_products(5, 30, self.company_id, self.branch_id)
        peak = max([float(p["revenue"] or 0) for p in top] or [1]) or 1
        self.top_list.set_items([(p["name"], money(p["revenue"]), float(p["revenue"] or 0) / peak)
                                 for p in top])

        low = self.service.low_stock_items(5, self.company_id, self.branch_id)
        self.low_list.set_items([
            (p["name"], f"{p['quantity']:g} / {p['minimum_stock']:g}",
             (float(p["quantity"] or 0) / float(p["minimum_stock"] or 1)) if p["minimum_stock"] else 0)
            for p in low])

        debtors = self.service.top_debtors(5, self.company_id, self.branch_id)
        dpeak = max([float(d["current_balance"] or 0) for d in debtors] or [1]) or 1
        self.debt_list.set_items([(d["name"], money(d["current_balance"]),
                                   float(d["current_balance"] or 0) / dpeak) for d in debtors])
