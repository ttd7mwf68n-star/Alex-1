"""Desktop user and role administration."""
from __future__ import annotations

from tkinter import messagebox

import customtkinter as ctk

from alexerp.database.db import Database
from alexerp.services.permission_service import PermissionService
from alexerp.services.security_admin_service import SecurityAdminService
from alexerp.ui.components import (
    DataTable, Dialog, Page, entry, field, ghost_button, primary_button,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font


class UserDialog(Dialog):
    def __init__(self, parent, service, company_id, actor_id, roles, branches, user=None, on_saved=None):
        super().__init__(parent, "تعديل مستخدم" if user else "إضافة مستخدم", 560, 610,
                         subtitle="صلاحيات المستخدم مرتبطة بدوره وشركته وفرعه", glyph="👤")
        self.service = service
        self.company_id = company_id
        self.actor_id = actor_id
        self.user = user
        self.on_saved = on_saved
        self.roles = roles
        self.branches = branches
        form = ctk.CTkScrollableFrame(self, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=24, pady=12)

        self.full_name = self._add_entry(form, "الاسم الكامل", user["full_name"] if user else "")
        self.username = None
        if user is None:
            self.username = self._add_entry(form, "اسم المستخدم", "")
            self.password = self._add_entry(form, "كلمة المرور الأولية (12 حرفًا على الأقل)", "", show="*")
        else:
            self.password = None
            ctk.CTkLabel(form, text=f"اسم المستخدم: {user['username']}", text_color=c("muted"),
                         font=font(12)).pack(fill="x", pady=5)

        self.email = self._add_entry(form, "البريد الإلكتروني", (user or {}).get("email") or "")
        self.phone = self._add_entry(form, "الهاتف", (user or {}).get("phone") or "")
        self.role_values = [f"{item['id']} — {item['name']}" for item in roles if item["is_active"]]
        self.role_by_label = {f"{item['id']} — {item['name']}": item for item in roles if item["is_active"]}
        role_field, self.role_combo = field(form, "الدور", lambda p: ctk.CTkComboBox(
            p, values=self.role_values, font=font(13), dropdown_font=font(13)))
        role_field.pack(fill="x", pady=5)
        branch_values = [f"{item['id']} — {item['name']}" for item in branches]
        self.branch_by_label = {f"{item['id']} — {item['name']}": item for item in branches}
        branch_field, self.branch_combo = field(form, "الفرع", lambda p: ctk.CTkComboBox(
            p, values=branch_values, font=font(13), dropdown_font=font(13)))
        branch_field.pack(fill="x", pady=5)

        initial_role_id = (user or {}).get("role_id")
        initial_branch_id = (user or {}).get("branch_id")
        self.role_combo.set(next((value for value, item in self.role_by_label.items()
                                  if item["id"] == initial_role_id), self.role_values[0] if self.role_values else ""))
        self.branch_combo.set(next((value for value, item in self.branch_by_label.items()
                                    if item["id"] == initial_branch_id), branch_values[0] if branch_values else ""))
        self.active = ctk.CTkCheckBox(form, text="حساب نشط", font=font(13))
        self.active.pack(anchor=TEXT_ANCHOR, pady=8)
        self.active.select() if user is None or user["is_active"] else self.active.deselect()
        self.error.pack(fill="x", padx=24, pady=(0, 4))
        self.footer([("حفظ", self.save, "primary"), ("إلغاء", self.destroy, "ghost")])

    @staticmethod
    def _add_entry(parent, caption, value, **kw):
        frame, control = field(parent, caption, lambda p: entry(p, width=420, **kw))
        frame.pack(fill="x", pady=5)
        if value:
            control.insert(0, value)
        return control

    def save(self):
        role = self.role_by_label.get(self.role_combo.get())
        branch = self.branch_by_label.get(self.branch_combo.get())
        if role is None or branch is None:
            self.error.configure(text="اختر دورًا وفرعًا صالحين.")
            return
        try:
            if self.user is None:
                if self.username is None or self.password is None:
                    raise ValueError("بيانات الدخول غير مكتملة.")
                self.service.create_user(
                    company_id=self.company_id,
                    branch_id=int(branch["id"]),
                    username=self.username.get().strip(),
                    full_name=self.full_name.get().strip(),
                    password=self.password.get(),
                    role_id=int(role["id"]),
                    email=self.email.get().strip(),
                    phone=self.phone.get().strip(),
                    actor_id=self.actor_id,
                )
            else:
                self.service.update_user(
                    actor_id=self.actor_id,
                    company_id=self.company_id,
                    user_id=int(self.user["id"]),
                    full_name=self.full_name.get().strip(),
                    role_id=int(role["id"]),
                    branch_id=int(branch["id"]),
                    is_active=bool(self.active.get()),
                    email=self.email.get().strip(),
                    phone=self.phone.get().strip(),
                )
        except (ValueError, PermissionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        self.destroy()


class RoleDialog(Dialog):
    def __init__(self, parent, service, company_id, actor_id, permissions, role=None, on_saved=None):
        super().__init__(parent, "تعديل دور" if role else "إضافة دور", 760, 700,
                         subtitle="الصلاحيات المحددة تتحكم في الوحدات والإجراءات المتاحة للمستخدم", glyph="🛡")
        self.service = service
        self.company_id = company_id
        self.actor_id = actor_id
        self.permissions = permissions
        self.role = role
        self.on_saved = on_saved
        self.code = None
        if role is None:
            self.code = UserDialog._add_entry(self, "كود الدور (مثل SALES_USER)", "")
        self.name = UserDialog._add_entry(self, "اسم الدور", role["name"] if role else "")
        self.description = UserDialog._add_entry(self, "الوصف", (role or {}).get("description") or "")
        self.active = ctk.CTkCheckBox(self, text="دور نشط", font=font(13))
        self.active.pack(anchor=TEXT_ANCHOR, padx=24, pady=6)
        self.active.select() if role is None or role["is_active"] else self.active.deselect()
        ctk.CTkLabel(self, text="حدد الصلاحيات المطلوبة لهذا الدور:", font=font(13, "bold"),
                     text_color=c("text"), anchor=TEXT_ANCHOR).pack(fill="x", padx=24, pady=(5, 2))
        self.permission_area = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.permission_area.pack(fill="both", expand=True, padx=18, pady=4)
        selected = set((role or {}).get("permissions") or [])
        self.checkboxes = {}
        modules = {}
        for item in permissions:
            modules.setdefault(item["module"], []).append(item)
        for module, items in modules.items():
            ctk.CTkLabel(self.permission_area, text=module, font=font(13, "bold"),
                         text_color=c("primary"), anchor=TEXT_ANCHOR).pack(fill="x", pady=(8, 2))
            for item in items:
                text = f"{item['permission_name']}  ({item['permission_key']})"
                checkbox = ctk.CTkCheckBox(self.permission_area, text=text, font=font(11))
                checkbox.pack(fill="x", anchor=TEXT_ANCHOR, pady=2)
                if item["permission_key"] in selected:
                    checkbox.select()
                self.checkboxes[item["permission_key"]] = checkbox
        self.error.pack(fill="x", padx=24, pady=(2, 0))
        self.footer([("حفظ", self.save, "primary"), ("إلغاء", self.destroy, "ghost")])

    def save(self):
        keys = [key for key, checkbox in self.checkboxes.items() if checkbox.get()]
        try:
            if self.role is None:
                if self.code is None:
                    raise ValueError("كود الدور مطلوب.")
                self.service.create_role(
                    self.company_id, self.code.get().strip(), self.name.get().strip(),
                    self.description.get().strip(), keys, actor_id=self.actor_id,
                )
            else:
                self.service.update_role(
                    self.company_id, int(self.role["id"]), self.name.get().strip(),
                    self.description.get().strip(), keys, bool(self.active.get()),
                    actor_id=self.actor_id,
                )
        except (ValueError, PermissionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        self.destroy()


class AccessPolicyDialog(Dialog):
    FIELD_LABELS = {
        "unit_cost": "سعر الوحدة",
        "discount": "الخصم",
        "tax": "الضريبة",
        "notes": "ملاحظات الأمر",
        "expected_date": "موعد التسليم المتوقع",
        "amount": "إجمالي الأمر",
    }
    RULE_FIELDS = {
        "created_by": "منشئ الأمر",
        "status": "حالة الاستلام",
        "approval_status": "حالة الاعتماد",
        "amount": "قيمة الأمر",
        "supplier_id": "المورد (المعرّف)",
    }
    ACCESS_LABELS = {
        "افتراضي": None,
        "قراءة وكتابة": "READ_WRITE",
        "قراءة فقط": "READ_ONLY",
        "مخفي": "HIDDEN",
    }
    OPERATOR_LABELS = {
        "=": "EQ", "لا يساوي": "NE", ">": "GT", ">=": "GTE", "<": "LT", "<=": "LTE",
    }
    EFFECT_LABELS = {"سماح": "ALLOW", "منع": "DENY"}

    def __init__(self, parent, service, company_id, actor_id, role, on_saved=None):
        super().__init__(parent, f"سياسات الدور: {role['name']}", 820, 720,
                         subtitle="قواعد آمنة على أوامر الشراء، دون SQL أو تعبيرات حرة", glyph="🛡")
        self.service = service
        self.company_id = company_id
        self.actor_id = actor_id
        self.role = role
        self.on_saved = on_saved
        self.rules = []
        saved = service.list_role_access_policies(
            company_id, int(role["id"]), actor_id=actor_id
        )
        existing_fields = {item["field_key"]: item["access_level"] for item in saved["fields"]}
        self.tabs = ctk.CTkTabview(self)
        self.tabs.pack(fill="both", expand=True, padx=20, pady=10)
        fields_tab = self.tabs.add("الحقول")
        rules_tab = self.tabs.add("السجلات")
        ctk.CTkLabel(fields_tab, text="حدد إظهار الحقول وإمكانية تعديلها:",
                     anchor=TEXT_ANCHOR, font=font(13, "bold")).pack(fill="x", pady=(8, 10))
        self.field_controls = {}
        access_values = list(self.ACCESS_LABELS)
        for key, caption in self.FIELD_LABELS.items():
            row = ctk.CTkFrame(fields_tab, fg_color="transparent")
            row.pack(fill="x", pady=4)
            ctk.CTkLabel(row, text=caption, anchor=TEXT_ANCHOR, width=220).pack(side=END, padx=6)
            control = ctk.CTkComboBox(row, values=access_values, width=190)
            current = existing_fields.get(key)
            control.set(next(
                (label for label, code in self.ACCESS_LABELS.items() if code == current),
                "افتراضي",
            ))
            control.pack(side=END, padx=6)
            self.field_controls[key] = control
        ctk.CTkLabel(
            rules_tab,
            text="قواعد السماح تُجمع بمنطق (أو)، وأي قاعدة منع مطابقة تتغلب عليها. "
                 "بدون قواعد، تبقى سجلات الشركة/الفرع متاحة وفق الصلاحيات الحالية.",
            anchor=TEXT_ANCHOR, justify="right", wraplength=720, font=font(12),
        ).pack(fill="x", padx=8, pady=8)
        self.rules_area = ctk.CTkScrollableFrame(rules_tab, fg_color="transparent")
        self.rules_area.pack(fill="both", expand=True, padx=4)
        self.add_rule_button = ctk.CTkButton(
            rules_tab, text="＋ إضافة قاعدة", command=self._add_rule
        )
        self.add_rule_button.pack(anchor=END, padx=8, pady=8)
        for rule in saved["rules"]:
            self._add_rule(rule)
        self.error.pack(fill="x", padx=24, pady=(0, 4))
        self.footer([("حفظ", self.save, "primary"), ("إلغاء", self.destroy, "ghost")])

    def _add_rule(self, initial: dict | None = None):
        initial = initial or {}
        row = ctk.CTkFrame(self.rules_area, fg_color="transparent")
        row.pack(fill="x", pady=4)
        field_values = list(self.RULE_FIELDS.values())
        field_combo = ctk.CTkComboBox(row, values=field_values, width=150)
        initial_field = str(initial.get("field_key") or "")
        field_combo.set(self.RULE_FIELDS.get(initial_field, field_values[0]))
        field_combo.pack(side=END, padx=3)
        operator_values = list(self.OPERATOR_LABELS)
        operator_combo = ctk.CTkComboBox(row, values=operator_values, width=90)
        operator_combo.set(next(
            (label for label, code in self.OPERATOR_LABELS.items()
             if code == str(initial.get("operator") or "")), "=",
        ))
        operator_combo.pack(side=END, padx=3)
        value_entry = ctk.CTkEntry(row, width=150, placeholder_text="current_user / OPEN / 1000")
        initial_value = initial.get("value", "")
        if initial_value == "current_user":
            initial_value = "المستخدم الحالي"
        if initial_value:
            value_entry.insert(0, str(initial_value))
        value_entry.pack(side=END, padx=3)
        effect_combo = ctk.CTkComboBox(row, values=list(self.EFFECT_LABELS), width=80)
        effect_combo.set("منع" if initial.get("effect") == "DENY" else "سماح")
        effect_combo.pack(side=END, padx=3)
        record = {
            "row": row, "field": field_combo, "operator": operator_combo,
            "value": value_entry, "effect": effect_combo,
        }
        ctk.CTkButton(
            row, text="×", width=34, command=lambda: self._remove_rule(record),
            fg_color=c("danger"),
        ).pack(side=END, padx=3)
        self.rules.append(record)

    def _remove_rule(self, record):
        self.rules.remove(record)
        record["row"].destroy()

    def save(self):
        fields = [
            {"field_key": key, "access_level": self.ACCESS_LABELS[control.get()]}
            for key, control in self.field_controls.items()
            if self.ACCESS_LABELS.get(control.get()) is not None
        ]
        rules = []
        for row in self.rules:
            value = row["value"].get().strip()
            if value == "المستخدم الحالي":
                value = "current_user"
            field_key = next(
                key for key, caption in self.RULE_FIELDS.items()
                if caption == row["field"].get()
            )
            rules.append({
                "field_key": field_key,
                "operator": self.OPERATOR_LABELS.get(row["operator"].get(), "EQ"),
                "value": value,
                "effect": self.EFFECT_LABELS.get(row["effect"].get(), "ALLOW"),
            })
        try:
            self.service.save_role_access_policies(
                self.company_id, int(self.role["id"]), fields, rules, actor_id=self.actor_id,
            )
        except (ValueError, PermissionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        self.destroy()


class SecurityAdminPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="إدارة المستخدمين والصلاحيات",
                         subtitle="إدارة المستخدمين والأدوار وتحديد ما يظهر لكل دور", user=user)
        self.company_id = int((user or {}).get("company_id") or 0)
        self.actor_id = int((user or {}).get("id") or 0)
        self.permissions = PermissionService()
        self.can_manage_users = self.permissions.has_permission(self.actor_id, "security.users.manage")
        self.can_manage_roles = self.permissions.has_permission(self.actor_id, "security.roles.manage")
        self.service = SecurityAdminService()
        self.tabs = ctk.CTkTabview(self.body)
        self.tabs.pack(fill="both", expand=True)
        if self.can_manage_users:
            users_tab = self.tabs.add("المستخدمون")
            self._build_users_tab(users_tab)
        if self.can_manage_roles:
            roles_tab = self.tabs.add("الأدوار والصلاحيات")
            self._build_roles_tab(roles_tab)

    def _branches(self):
        rows = Database.connect().execute(
            "SELECT id, name FROM branches WHERE company_id=? AND is_active=1 ORDER BY name",
            (self.company_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def _build_users_tab(self, parent):
        actions = ctk.CTkFrame(parent, fg_color="transparent")
        actions.pack(fill="x", pady=(8, 10))
        primary_button(actions, "＋ مستخدم جديد", self.add_user, width=140).pack(side=START, padx=4)
        ghost_button(actions, "تحديث", self.load_users, width=90).pack(side=END, padx=4)
        self.users_table = DataTable(parent, [
            ("username", "اسم المستخدم", 120, "w"),
            ("full_name", "الاسم", 180, "w"),
            ("role_name", "الدور", 140, "w"),
            ("branch_name", "الفرع", 130, "w"),
            ("status", "الحالة", 80, "w"),
            ("last_login", "آخر دخول", 150, "w"),
        ], on_double=self.edit_user, empty_text="لا يوجد مستخدمون")
        self.users_table.pack(fill="both", expand=True)
        self.load_users()

    def _build_roles_tab(self, parent):
        actions = ctk.CTkFrame(parent, fg_color="transparent")
        actions.pack(fill="x", pady=(8, 10))
        primary_button(actions, "＋ دور جديد", self.add_role, width=130).pack(side=START, padx=4)
        ghost_button(actions, "سياسات الحقول والسجلات", self.edit_access_policies, width=190).pack(
            side=START, padx=4
        )
        ghost_button(actions, "تحديث", self.load_roles, width=90).pack(side=END, padx=4)
        self.roles_table = DataTable(parent, [
            ("code", "الكود", 140, "w"),
            ("name", "اسم الدور", 180, "w"),
            ("description", "الوصف", 230, "w"),
            ("permission_count", "عدد الصلاحيات", 110, "e"),
            ("status", "الحالة", 80, "w"),
        ], on_double=self.edit_role, empty_text="لا توجد أدوار")
        self.roles_table.pack(fill="both", expand=True)
        self.load_roles()

    def load_users(self):
        try:
            branches = {item["id"]: item["name"] for item in self._branches()}
            users = self.service.list_users(self.company_id)
            for user in users:
                user["branch_name"] = branches.get(user["branch_id"], "—")
                user["status"] = "نشط" if user["is_active"] else "معطل"
                user["last_login"] = user.get("last_login") or "لم يسجل الدخول"
            self.users_table.set_rows(users)
        except Exception as exc:
            messagebox.showerror("تعذر تحميل المستخدمين", str(exc), parent=self.winfo_toplevel())

    def load_roles(self):
        try:
            roles = self.service.list_roles(self.company_id)
            for role in roles:
                role["permission_count"] = len(role["permissions"])
                role["status"] = "نشط" if role["is_active"] else "معطل"
            self.roles_table.set_rows(roles)
        except Exception as exc:
            messagebox.showerror("تعذر تحميل الأدوار", str(exc), parent=self.winfo_toplevel())

    def add_user(self):
        if not self.can_manage_users:
            return
        roles = self.service.list_roles(self.company_id)
        branches = self._branches()
        if not roles or not branches:
            messagebox.showerror("تعذر إضافة المستخدم", "يجب إعداد دور وفرع نشطين أولًا.",
                                 parent=self.winfo_toplevel())
            return
        UserDialog(self, self.service, self.company_id, self.actor_id, roles, branches,
                   on_saved=self.load_users)

    def edit_user(self, user):
        if not user or not self.can_manage_users:
            return
        roles = self.service.list_roles(self.company_id)
        branches = self._branches()
        UserDialog(self, self.service, self.company_id, self.actor_id, roles, branches,
                   user=user, on_saved=self.load_users)

    def add_role(self):
        if not self.can_manage_roles:
            return
        RoleDialog(self, self.service, self.company_id, self.actor_id,
                   self.service.list_permissions(), on_saved=self.load_roles)

    def edit_role(self, role):
        if not role or not self.can_manage_roles or role.get("is_system"):
            return
        RoleDialog(self, self.service, self.company_id, self.actor_id,
                   self.service.list_permissions(), role=role, on_saved=self.load_roles)

    def edit_access_policies(self):
        role = self.roles_table.selected
        if not role or not self.can_manage_roles:
            messagebox.showwarning("سياسات الوصول", "حدد دورًا أولًا.", parent=self.winfo_toplevel())
            return
        AccessPolicyDialog(
            self, self.service, self.company_id, self.actor_id, role, on_saved=self.load_roles
        )
