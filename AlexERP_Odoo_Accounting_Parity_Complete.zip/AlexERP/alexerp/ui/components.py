"""
AlexERP — Business Management System
Reusable UI components (single design system for every Desktop screen).

All components are right-to-left aware: reading order starts at the right
edge, labels are anchored to the right and table columns are laid out from
right to left, matching the Mobile/Web app.
"""

from __future__ import annotations

from typing import Callable, Iterable, Sequence

import customtkinter as ctk

from alexerp.ui.theme import (
    COLORS, CONTROL_HEIGHT, END, JUSTIFY, RADIUS, SERIES, START, TEXT_ANCHOR,
    c, flip_anchor, font, icon, resolve, status_info,
)


def current_mode() -> str:
    try:
        return ctk.get_appearance_mode()
    except Exception:
        return "Light"


def get_theme_color(name: str) -> str:
    """Single-colour lookup (used by core/theme.py)."""
    legacy = {"background": "bg", "disabled_text": "muted"}
    return resolve(legacy.get(name, name), current_mode())


def money(value, decimals: int = 2) -> str:
    try:
        return f"{float(value or 0):,.{decimals}f}"
    except (TypeError, ValueError):
        return str(value or "")


# ----------------------------------------------------------------------
# Basic blocks
# ----------------------------------------------------------------------

class Card(ctk.CTkFrame):
    def __init__(self, parent, **kw):
        kw.setdefault("fg_color", c("surface"))
        kw.setdefault("corner_radius", RADIUS["lg"])
        kw.setdefault("border_width", 1)
        kw.setdefault("border_color", c("border"))
        super().__init__(parent, **kw)


def _button(parent, text, command, width, fg, hover, text_color, **kw):
    kw.setdefault("height", CONTROL_HEIGHT)
    kw.setdefault("corner_radius", RADIUS["md"])
    kw.setdefault("font", font(13, "bold"))
    kw.setdefault("fg_color", fg)
    kw.setdefault("hover_color", hover)
    kw.setdefault("text_color", text_color)
    return ctk.CTkButton(parent, text=text, command=command, width=width, **kw)


def primary_button(parent, text, command=None, width=130, **kw):
    return _button(parent, text, command, width, c("primary"), c("primary_hover"),
                   "#FFFFFF", **kw)


def success_button(parent, text, command=None, width=130, **kw):
    return _button(parent, text, command, width, c("success"), c("success"),
                   "#FFFFFF", **kw)


def ghost_button(parent, text, command=None, width=110, **kw):
    kw.setdefault("font", font(13))
    kw.setdefault("border_width", 1)
    kw.setdefault("border_color", c("border"))
    return _button(parent, text, command, width, c("surface"), c("surface_hover"),
                   c("text"), **kw)


def subtle_button(parent, text, command=None, width=110, **kw):
    kw.setdefault("font", font(13, "bold"))
    return _button(parent, text, command, width, c("primary_soft"), c("surface_hover"),
                   c("primary"), **kw)


def danger_button(parent, text, command=None, width=110, **kw):
    kw.setdefault("font", font(13))
    return _button(parent, text, command, width, c("danger_soft"), c("danger"),
                   c("danger"), **kw)


def icon_button(parent, glyph, command=None, size=CONTROL_HEIGHT, tone="ghost", **kw):
    if tone == "sidebar":
        return ctk.CTkButton(parent, text=glyph, command=command, width=size, height=size,
                             corner_radius=RADIUS["md"], fg_color="transparent",
                             hover_color=c("sidebar_hover"), text_color=c("sidebar_text"),
                             font=font(15), **kw)
    kw.setdefault("border_width", 1)
    kw.setdefault("border_color", c("border"))
    kw.setdefault("fg_color", c("surface"))
    kw.setdefault("hover_color", c("surface_hover"))
    kw.setdefault("text_color", c("text"))
    kw.setdefault("font", font(15))
    return ctk.CTkButton(parent, text=glyph, command=command, width=size, height=size,
                         corner_radius=RADIUS["md"], **kw)


def entry(parent, placeholder="", width=260, **kw):
    kw.setdefault("justify", JUSTIFY)
    kw.setdefault("border_width", 1)
    kw.setdefault("fg_color", c("surface"))
    kw.setdefault("height", CONTROL_HEIGHT)
    return ctk.CTkEntry(
        parent, width=width, corner_radius=RADIUS["md"],
        placeholder_text=placeholder, font=font(13), border_color=c("border"),
        text_color=c("text"), placeholder_text_color=c("muted"), **kw,
    )


def combo(parent, values, width=200, command=None, **kw):
    """Combo box styled like the rest of the inputs."""
    kw.setdefault("justify", JUSTIFY)
    return ctk.CTkComboBox(
        parent, values=list(values), width=width, height=CONTROL_HEIGHT,
        corner_radius=RADIUS["md"], font=font(13), dropdown_font=font(13),
        fg_color=c("surface"), border_color=c("border"), border_width=1,
        button_color=c("surface_alt"), button_hover_color=c("surface_hover"),
        text_color=c("text"), dropdown_fg_color=c("surface"),
        dropdown_hover_color=c("primary_soft"), dropdown_text_color=c("text"),
        command=command, **kw,
    )


def label(parent, text, size="body", weight="normal", tone="text", **kw):
    kw.setdefault("anchor", TEXT_ANCHOR)
    kw.setdefault("justify", JUSTIFY)
    return ctk.CTkLabel(parent, text=text, font=font(size, weight),
                        text_color=c(tone), **kw)


class Badge(ctk.CTkLabel):
    TONES = {
        "primary": ("primary_soft", "primary"),
        "success": ("success_soft", "success"),
        "warning": ("warning_soft", "warning"),
        "danger": ("danger_soft", "danger"),
        "info": ("info_soft", "info"),
        "muted": ("surface_alt", "muted"),
    }

    def __init__(self, parent, text, tone="primary", **kw):
        bg, fg = self.TONES.get(tone, self.TONES["muted"])
        kw.setdefault("height", 24)
        super().__init__(
            parent, text=f"  {text}  ", corner_radius=12,
            fg_color=c(bg), text_color=c(fg), font=font(11, "bold"), **kw,
        )

    def set(self, text, tone=None):
        self.configure(text=f"  {text}  ")
        if tone:
            bg, fg = self.TONES.get(tone, self.TONES["muted"])
            self.configure(fg_color=c(bg), text_color=c(fg))


class StatusBadge(Badge):
    """Badge for document statuses (POSTED, CANCELLED, ...)."""

    def __init__(self, parent, status, **kw):
        text, tone = status_info(status)
        super().__init__(parent, text, tone, **kw)


def divider(parent, **pack):
    line = ctk.CTkFrame(parent, height=1, fg_color=c("border"), corner_radius=0)
    pack.setdefault("fill", "x")
    line.pack(**pack)
    return line


# ----------------------------------------------------------------------
# Page scaffold
# ----------------------------------------------------------------------

class Page(ctk.CTkFrame):
    """Standard page: title, subtitle, actions area and a body frame.

    ``scroll=True`` makes the body a vertically scrollable area (dashboard).
    """

    def __init__(self, parent, title="", subtitle="", user=None, scroll=False):
        super().__init__(parent, fg_color="transparent")
        self.user = user

        head = ctk.CTkFrame(self, fg_color="transparent")
        head.pack(fill="x", padx=28, pady=(22, 14))

        texts = ctk.CTkFrame(head, fg_color="transparent")
        texts.pack(side=START)
        self.title_label = ctk.CTkLabel(texts, text=title, font=font("display", "bold"),
                                        text_color=c("text"), anchor=TEXT_ANCHOR)
        self.title_label.pack(anchor=TEXT_ANCHOR)
        self.subtitle_label = ctk.CTkLabel(texts, text=subtitle, font=font(13),
                                           text_color=c("muted"), anchor=TEXT_ANCHOR)
        if subtitle:
            self.subtitle_label.pack(anchor=TEXT_ANCHOR, pady=(2, 0))

        self.actions = ctk.CTkFrame(head, fg_color="transparent", width=1, height=1)
        self.actions.pack(side=END)

        if scroll:
            self.body = ctk.CTkScrollableFrame(
                self, fg_color="transparent",
                scrollbar_button_color=c("border"),
                scrollbar_button_hover_color=c("muted"))
            self.body.pack(fill="both", expand=True, padx=(20, 14), pady=(0, 16))
        else:
            self.body = ctk.CTkFrame(self, fg_color="transparent")
            self.body.pack(fill="both", expand=True, padx=28, pady=(0, 22))


class SectionHeader(ctk.CTkFrame):
    def __init__(self, parent, title, subtitle="", glyph=""):
        super().__init__(parent, fg_color="transparent")
        text = f"{glyph}  {title}" if glyph else title
        ctk.CTkLabel(self, text=text, font=font("h3", "bold"), text_color=c("text"),
                     anchor=TEXT_ANCHOR).pack(side=START)
        self.actions = ctk.CTkFrame(self, fg_color="transparent", width=1, height=1)
        self.actions.pack(side=END)
        if subtitle:
            ctk.CTkLabel(self, text=subtitle, font=font(12), text_color=c("muted"),
                         anchor=TEXT_ANCHOR).pack(side=START, padx=10)


class Toolbar(Card):
    """Filter/search bar shown above tables. Add widgets to ``.row``."""

    def __init__(self, parent, **kw):
        super().__init__(parent, corner_radius=RADIUS["lg"], **kw)
        self.row = ctk.CTkFrame(self, fg_color="transparent")
        self.row.pack(fill="x", padx=10, pady=8)

    def add(self, widget, padx=4, side=START, **pack):
        widget.pack(side=side, padx=padx, pady=2, **pack)
        return widget

    def caption(self, text):
        lbl = ctk.CTkLabel(self.row, text=text, font=font(12), text_color=c("muted"))
        lbl.pack(side=START, padx=(8, 2))
        return lbl


class SearchBar(ctk.CTkFrame):
    """Search input with icon, clear button and debounced callback.

    Compatible with the CTkEntry API used by pages: ``get()``, ``bind()``,
    ``focus()``, ``delete()``, ``insert()``.
    """

    def __init__(self, parent, placeholder="بحث...", on_search: Callable | None = None,
                 width=320, delay_ms=250):
        super().__init__(parent, fg_color=c("surface"), corner_radius=RADIUS["md"],
                         border_width=1, border_color=c("border"), height=CONTROL_HEIGHT,
                         width=width)
        self.on_search = on_search
        self.delay_ms = delay_ms
        self._job = None
        self.pack_propagate(False)

        ctk.CTkLabel(self, text=icon("search"), width=26, font=font(13),
                     text_color=c("muted")).pack(side=START, padx=(0, 8) if START == "right" else (8, 0))
        self.entry = ctk.CTkEntry(self, placeholder_text=placeholder, border_width=0,
                                  fg_color="transparent", height=CONTROL_HEIGHT - 4,
                                  font=font(13), text_color=c("text"),
                                  placeholder_text_color=c("muted"), justify=JUSTIFY)
        self.entry.pack(side=START, fill="both", expand=True)
        self.clear_btn = ctk.CTkButton(self, text=icon("clear"), width=26, height=26,
                                       corner_radius=13, fg_color="transparent",
                                       hover_color=c("surface_hover"),
                                       text_color=c("muted"), font=font(12),
                                       command=self.clear)
        self.entry.bind("<KeyRelease>", self._changed, add="+")
        self.entry.bind("<Return>", lambda _e: self._fire(), add="+")
        self.entry.bind("<Escape>", lambda _e: self.clear(), add="+")
        self.entry.bind("<FocusIn>", lambda _e: self.configure(border_color=c("primary")), add="+")
        self.entry.bind("<FocusOut>", lambda _e: self.configure(border_color=c("border")), add="+")

    # CTkEntry-compatible API ------------------------------------------
    def get(self):
        return self.entry.get()

    def bind(self, sequence=None, command=None, add="+"):  # noqa: A003
        if sequence == "<KeyRelease>" and self.on_search is None and command is not None:
            # legacy usage: refresh on every key -> route through debounce
            self.on_search = lambda: command(None)
            return None
        return self.entry.bind(sequence, command, add=add)

    def focus(self):
        self.entry.focus()

    focus_set = focus

    def delete(self, first, last=None):
        self.entry.delete(first, last)
        self._toggle_clear()

    def insert(self, index, text):
        self.entry.insert(index, text)
        self._toggle_clear()

    # -----------------------------------------------------------------
    def set(self, text):
        self.entry.delete(0, "end")
        if text:
            self.entry.insert(0, text)
        self._toggle_clear()

    def clear(self):
        self.entry.delete(0, "end")
        self._toggle_clear()
        self._fire()
        self.entry.focus()

    def _toggle_clear(self):
        if self.entry.get():
            if not self.clear_btn.winfo_ismapped():
                self.clear_btn.pack(side=END, padx=6)
        elif self.clear_btn.winfo_ismapped():
            self.clear_btn.pack_forget()

    def _changed(self, event=None):
        if event is not None and getattr(event, "keysym", "") in ("Return", "Escape"):
            return
        self._toggle_clear()
        if self._job is not None:
            self.after_cancel(self._job)
        self._job = self.after(self.delay_ms, self._fire)

    def _fire(self):
        if self._job is not None:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        if self.on_search:
            self.on_search()


class Tabs(ctk.CTkFrame):
    """Segmented control. items: [(key, label), ...]."""

    def __init__(self, parent, items: Sequence[tuple[str, str]], command: Callable | None = None,
                 current: str | None = None, width=140):
        super().__init__(parent, fg_color=c("surface_alt"), corner_radius=RADIUS["md"])
        self.command = command
        self.buttons: dict[str, ctk.CTkButton] = {}
        self.current = current or (items[0][0] if items else None)
        for key, text in items:
            btn = ctk.CTkButton(self, text=text, width=width, height=CONTROL_HEIGHT - 6,
                                corner_radius=RADIUS["sm"], font=font(13, "bold"),
                                fg_color="transparent", hover_color=c("surface_hover"),
                                text_color=c("muted"),
                                command=lambda k=key: self._click(k))
            btn.pack(side=START, padx=3, pady=3)
            self.buttons[key] = btn
        self.set(self.current, notify=False)

    def _click(self, key):
        self.set(key)

    def set(self, key, notify=True):
        self.current = key
        for k, btn in self.buttons.items():
            active = k == key
            btn.configure(fg_color=c("surface") if active else "transparent",
                          text_color=c("primary") if active else c("muted"))
        if notify and self.command:
            self.command(key)

    def get(self):
        return self.current


class EmptyState(ctk.CTkFrame):
    def __init__(self, parent, text="لا توجد بيانات", glyph="🗂", hint=""):
        super().__init__(parent, fg_color="transparent")
        ctk.CTkLabel(self, text=glyph, font=font(34), text_color=c("muted")).pack(pady=(26, 4))
        ctk.CTkLabel(self, text=text, font=font(14, "bold"), text_color=c("muted")).pack()
        if hint:
            ctk.CTkLabel(self, text=hint, font=font(12), text_color=c("muted")).pack(pady=(2, 0))


class StatCard(Card):
    """KPI card: icon tile, label, big value and a hint line."""

    def __init__(self, parent, glyph, text, value="-", tone="primary", hint="", command=None):
        super().__init__(parent)
        bg, fg = Badge.TONES[tone]

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=18, pady=(16, 0))
        ctk.CTkLabel(
            top, text=glyph, width=42, height=42, corner_radius=12,
            fg_color=c(bg), text_color=c(fg), font=font(18),
        ).pack(side=START)
        ctk.CTkLabel(top, text=text, font=font(13), text_color=c("muted"),
                     anchor=TEXT_ANCHOR).pack(side=START, padx=12)

        self.value_label = ctk.CTkLabel(
            self, text=str(value), font=font(24, "bold"), text_color=c("text"),
            anchor=TEXT_ANCHOR)
        self.value_label.pack(anchor=TEXT_ANCHOR, padx=18, pady=(10, 0))

        self.hint_label = ctk.CTkLabel(
            self, text=hint, font=font(12), text_color=c("muted"), anchor=TEXT_ANCHOR)
        self.hint_label.pack(anchor=TEXT_ANCHOR, padx=18, pady=(0, 14))

        if command:
            for w in (self, top, self.value_label, self.hint_label):
                w.bind("<Button-1>", lambda _e: command())
            self.configure(cursor="hand2")

    def set(self, value, hint=None):
        self.value_label.configure(text=str(value))
        if hint is not None:
            self.hint_label.configure(text=hint)


# ----------------------------------------------------------------------
# Data table
# ----------------------------------------------------------------------

class DataTable(Card):
    """
    columns: sequence of (key, title, width, anchor)
    rows: list of dict / sqlite3.Row

    Columns are laid out right-to-left. A column whose key is ``status`` is
    rendered as a coloured status pill automatically.
    """

    MAX_ROWS = 300
    STATUS_KEYS = {"status"}
    _SCROLLBAR_GUTTER = 22

    def __init__(self, parent, columns: Sequence[tuple],
                 on_select: Callable | None = None,
                 on_double: Callable | None = None,
                 empty_text="لا توجد بيانات"):
        super().__init__(parent)
        self.columns = columns
        self.on_select = on_select
        self.on_double = on_double
        self.empty_text = empty_text
        self.selected = None
        self._row_frames = []
        self._selected_frame = None
        # the widest text column absorbs any extra horizontal space
        text_cols = [col for col in columns if col[3] == "w"]
        self._stretch_key = max(text_cols, key=lambda col: col[2])[0] if text_cols else None

        header_wrap = ctk.CTkFrame(self, fg_color=c("surface_alt"), corner_radius=RADIUS["md"])
        header_wrap.pack(fill="x", padx=10, pady=(10, 4))
        header = ctk.CTkFrame(header_wrap, fg_color="transparent")
        gutter = self._SCROLLBAR_GUTTER
        header.pack(fill="x", padx=(6, 6 + gutter) if START == "right" else (6 + gutter, 6))
        for key, title, width, anchor in columns:
            ctk.CTkLabel(header, text=title, width=width, anchor=flip_anchor(anchor),
                         font=font(12, "bold"), text_color=c("muted")
                         ).pack(side=START, padx=6, pady=9,
                                fill="x", expand=key == self._stretch_key)

        self.scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent", scrollbar_button_color=c("border"),
            scrollbar_button_hover_color=c("muted"))
        self.scroll.pack(fill="both", expand=True, padx=6, pady=(0, 6))

        self.footer = ctk.CTkLabel(self, text="", font=font(11), text_color=c("muted"),
                                   anchor=TEXT_ANCHOR)
        self.footer.pack(fill="x", padx=16, pady=(0, 8))

    def _cell(self, frame, key, text, width, anchor, value):
        if key in self.STATUS_KEYS:
            holder = ctk.CTkFrame(frame, fg_color="transparent", width=width, height=26)
            holder.pack_propagate(False)
            holder.pack(side=START, padx=6, pady=5)
            label_text, tone = status_info(value)
            pill = Badge(holder, label_text, tone)
            pill.pack(side=START, pady=1)
            return [holder, pill]
        lbl = ctk.CTkLabel(frame, text=text, width=width, anchor=flip_anchor(anchor),
                           font=font(13), text_color=c("text"))
        lbl.pack(side=START, padx=6, pady=6, fill="x", expand=key == self._stretch_key)
        return [lbl]

    def set_rows(self, rows, formatters: dict | None = None):
        formatters = formatters or {}
        for child in self.scroll.winfo_children():
            child.destroy()
        self._row_frames = []
        self._selected_frame = None
        self.selected = None

        rows = list(rows)
        if not rows:
            EmptyState(self.scroll, self.empty_text).pack(fill="x", pady=20)
            self.footer.configure(text="")
            return

        for i, row in enumerate(rows[: self.MAX_ROWS]):
            fg = "transparent" if i % 2 == 0 else c("surface_alt")
            frame = ctk.CTkFrame(self.scroll, fg_color=fg, corner_radius=RADIUS["sm"], height=36)
            frame.pack(fill="x", pady=1)
            self._row_frames.append((frame, fg, row))

            widgets = [frame]
            for key, _title, width, anchor in self.columns:
                try:
                    value = row[key]
                except (KeyError, IndexError):
                    value = None
                fmt = formatters.get(key)
                text = fmt(value) if fmt else ("" if value is None else str(value))
                widgets.extend(self._cell(frame, key, text, width, anchor, value))
            for w in widgets:
                w.bind("<Button-1>", lambda _e, f=frame, r=row: self._select(f, r))
                w.bind("<Double-Button-1>", lambda _e, f=frame, r=row: self._double(f, r))
                w.bind("<Enter>", lambda _e, f=frame: self._hover(f, True))
                w.bind("<Leave>", lambda _e, f=frame, g=fg: self._hover(f, False, g))

        shown = min(len(rows), self.MAX_ROWS)
        if len(rows) > self.MAX_ROWS:
            self.footer.configure(
                text=f"يتم عرض أول {self.MAX_ROWS} صف من {len(rows)} — استخدم البحث للتضييق")
        else:
            self.footer.configure(text=f"{shown} سجل")

    def _hover(self, frame, inside, base=None):
        if frame is self._selected_frame:
            return
        try:
            frame.configure(fg_color=c("surface_hover") if inside else (base or "transparent"))
        except Exception:
            pass

    def _select(self, frame, row):
        for f, fg, _r in self._row_frames:
            f.configure(fg_color=fg)
        frame.configure(fg_color=c("primary_soft"))
        self._selected_frame = frame
        self.selected = row
        if self.on_select:
            self.on_select(row)

    def _double(self, frame, row):
        self._select(frame, row)
        if self.on_double:
            self.on_double(row)


# ----------------------------------------------------------------------
# Charts (canvas based, theme aware)
# ----------------------------------------------------------------------

def _short(v: float) -> str:
    v = float(v or 0)
    if abs(v) >= 1_000_000:
        return f"{v / 1_000_000:.1f}M"
    if abs(v) >= 10_000:
        return f"{v / 1_000:.0f}K"
    if abs(v) >= 1_000:
        return f"{v / 1_000:.1f}K"
    return f"{v:,.0f}"


class _ChartBase(ctk.CTkCanvas):
    def __init__(self, parent, height=220):
        super().__init__(parent, height=height, highlightthickness=0, bd=0)
        self._tip = None
        self.bind("<Configure>", lambda _e: self.redraw())

    def colors(self):
        mode = current_mode()
        return {k: resolve(k, mode) for k in COLORS}

    def _empty(self, w, h, col):
        self.create_text(w // 2, h // 2, text="لا توجد بيانات للفترة", fill=col["muted"],
                         font=font(13))

    def _tooltip(self, x, y, text):
        self.delete("tip")
        col = self.colors()
        t = self.create_text(x, y - 14, text=text, fill="#FFFFFF", font=font(11, "bold"),
                             tags="tip")
        x1, y1, x2, y2 = self.bbox(t)
        r = self.create_rectangle(x1 - 8, y1 - 4, x2 + 8, y2 + 4, fill=col["text"],
                                  outline="", tags="tip")
        self.tag_raise(t, r)

    def redraw(self):  # pragma: no cover - drawing
        pass


class BarChart(_ChartBase):
    def __init__(self, parent, height=220, tone="primary"):
        super().__init__(parent, height=height)
        self.tone = tone
        self.labels: list[str] = []
        self.values: list[float] = []

    def set_data(self, labels, values):
        self.labels, self.values = list(labels), [float(v or 0) for v in values]
        self.redraw()

    def redraw(self):
        col = self.colors()
        self.configure(bg=col["surface"])
        self.delete("all")
        w = max(int(self.winfo_width()), 300)
        h = max(int(self.winfo_height()), 120)
        left, right, top, bottom = 52, 14, 22, 28

        if not self.values or max(self.values) <= 0:
            self._empty(w, h, col)
            return

        peak = max(self.values) or 1.0
        plot_h = h - top - bottom
        for i in range(4):
            y = top + plot_h * i / 3
            self.create_line(left, y, w - right, y, fill=col["border"], dash=(2, 4))
            self.create_text(left - 8, y, text=_short(peak * (3 - i) / 3),
                             anchor="e", fill=col["muted"], font=font(9))

        n = len(self.values)
        slot = (w - left - right) / n
        bw = max(min(slot * 0.56, 36), 4)
        bar = col[self.tone]
        soft = col[f"{self.tone}_soft"] if f"{self.tone}_soft" in col else col["surface_alt"]
        i_max = self.values.index(peak)
        for i, v in enumerate(self.values):
            x = left + slot * i + slot / 2
            bh = max(plot_h * (v / peak), 2 if v > 0 else 0)
            fill = bar if i == i_max or i == n - 1 else soft
            outline = bar
            tag = f"bar{i}"
            self.create_rectangle(x - bw / 2, top + plot_h - bh, x + bw / 2, top + plot_h,
                                  fill=fill, outline=outline, width=1, tags=tag)
            self.tag_bind(tag, "<Enter>", lambda _e, xx=x, yy=top + plot_h - bh, vv=v, ll=self.labels[i]:
                          self._tooltip(xx, yy, f"{ll}: {vv:,.0f}"))
            self.tag_bind(tag, "<Leave>", lambda _e: self.delete("tip"))
            if n <= 16 or i % 2 == 0:
                self.create_text(x, h - 12, text=self.labels[i], fill=col["muted"], font=font(9))
        x = left + slot * i_max + slot / 2
        self.create_text(x, top + plot_h - plot_h - 4, text=_short(peak), fill=col["text"],
                         font=font(10, "bold"), anchor="s")


class LineChart(_ChartBase):
    """Multi-series line/area chart. series: [(name, values, tone), ...]."""

    def __init__(self, parent, height=220):
        super().__init__(parent, height=height)
        self.labels: list[str] = []
        self.series: list[tuple[str, list[float], str]] = []

    def set_series(self, labels, series):
        self.labels = list(labels)
        self.series = [(n, [float(v or 0) for v in vals], tone) for n, vals, tone in series]
        self.redraw()

    def redraw(self):
        col = self.colors()
        self.configure(bg=col["surface"])
        self.delete("all")
        w = max(int(self.winfo_width()), 300)
        h = max(int(self.winfo_height()), 120)
        left, right, top, bottom = 52, 14, 30, 28
        values = [v for _n, vals, _t in self.series for v in vals]
        if not values or max(values) <= 0:
            self._empty(w, h, col)
            return
        peak = max(values) or 1.0
        plot_h = h - top - bottom
        plot_w = w - left - right
        for i in range(4):
            y = top + plot_h * i / 3
            self.create_line(left, y, w - right, y, fill=col["border"], dash=(2, 4))
            self.create_text(left - 8, y, text=_short(peak * (3 - i) / 3), anchor="e",
                             fill=col["muted"], font=font(9))
        n = max(len(self.labels), 1)
        step = plot_w / max(n - 1, 1)
        every = max(1, n // 8)
        for i, lab in enumerate(self.labels):
            if i % every == 0 or i == n - 1:
                self.create_text(left + step * i, h - 12, text=lab, fill=col["muted"], font=font(9))

        # legend (top, reading order from the right)
        lx = w - right
        for name, _vals, tone in self.series:
            t = self.create_text(lx, 10, text=name, anchor="e", fill=col["muted"], font=font(11))
            x1, _y1, _x2, _y2 = self.bbox(t)
            self.create_oval(x1 - 14, 5, x1 - 4, 15, fill=col[tone], outline="")
            lx = x1 - 28

        for name, vals, tone in self.series:
            pts = []
            for i, v in enumerate(vals):
                pts.extend([left + step * i, top + plot_h - plot_h * (v / peak)])
            if len(pts) >= 4:
                self.create_line(*pts, fill=col[tone], width=2.5, smooth=False, joinstyle="round")
            for i, v in enumerate(vals):
                x, y = left + step * i, top + plot_h - plot_h * (v / peak)
                tag = f"pt{name}{i}"
                self.create_oval(x - 3, y - 3, x + 3, y + 3, fill=col["surface"],
                                 outline=col[tone], width=2, tags=tag)
                self.tag_bind(tag, "<Enter>", lambda _e, xx=x, yy=y, nn=name, vv=v, ll=self.labels[i]:
                              self._tooltip(xx, yy, f"{nn} · {ll}: {vv:,.0f}"))
                self.tag_bind(tag, "<Leave>", lambda _e: self.delete("tip"))


class DonutChart(_ChartBase):
    """Donut with a centre total and a legend. data: [(label, value, tone), ...]."""

    def __init__(self, parent, height=200, center_caption=""):
        super().__init__(parent, height=height)
        self.data: list[tuple[str, float, str]] = []
        self.center_caption = center_caption

    def set_data(self, data):
        self.data = [(lab, float(v or 0), tone) for lab, v, tone in data]
        self.redraw()

    def redraw(self):
        col = self.colors()
        self.configure(bg=col["surface"])
        self.delete("all")
        w = max(int(self.winfo_width()), 240)
        h = max(int(self.winfo_height()), 140)
        total = sum(v for _l, v, _t in self.data)
        if total <= 0:
            self._empty(w, h, col)
            return
        size = min(h - 20, w * 0.5)
        cx = w - size / 2 - 16  # donut on the reading-start (right) side
        cy = h / 2
        r = size / 2
        start = 90.0
        for lab, v, tone in self.data:
            extent = -360.0 * v / total
            if abs(extent) >= 359.99:
                self.create_oval(cx - r, cy - r, cx + r, cy + r, fill=col[tone], outline="")
            elif v > 0:
                self.create_arc(cx - r, cy - r, cx + r, cy + r, start=start, extent=extent,
                                fill=col[tone], outline=col["surface"], width=2)
            start += extent
        ir = r * 0.62
        self.create_oval(cx - ir, cy - ir, cx + ir, cy + ir, fill=col["surface"], outline="")
        self.create_text(cx, cy - 8, text=f"{total:,.0f}", fill=col["text"], font=font(16, "bold"))
        if self.center_caption:
            self.create_text(cx, cy + 14, text=self.center_caption, fill=col["muted"], font=font(10))

        # legend on the left of the donut
        lx = cx - r - 24
        ly = cy - (len(self.data) - 1) * 14
        for lab, v, tone in self.data:
            pct = 100.0 * v / total
            self.create_oval(lx - 10, ly - 5, lx, ly + 5, fill=col[tone], outline="")
            self.create_text(lx - 16, ly, text=f"{lab}  {v:,.0f}  ({pct:.0f}%)", anchor="e",
                             fill=col["text"], font=font(11))
            ly += 28


class RankList(ctk.CTkFrame):
    """Ranked rows with a progress bar: [(name, value_text, ratio 0..1), ...]."""

    def __init__(self, parent, tone="primary", empty_text="لا توجد بيانات"):
        super().__init__(parent, fg_color="transparent")
        self.tone = tone
        self.empty_text = empty_text

    def set_items(self, items: Iterable[tuple[str, str, float]]):
        for child in self.winfo_children():
            child.destroy()
        items = list(items)
        if not items:
            ctk.CTkLabel(self, text=self.empty_text, font=font(13), text_color=c("muted"),
                         anchor=TEXT_ANCHOR).pack(fill="x", pady=8)
            return
        for idx, (name, value, ratio) in enumerate(items, start=1):
            row = ctk.CTkFrame(self, fg_color="transparent")
            row.pack(fill="x", pady=(6, 0))
            ctk.CTkLabel(row, text=f"{idx}", width=22, height=22, corner_radius=11,
                         fg_color=c("surface_alt"), text_color=c("muted"),
                         font=font(11, "bold")).pack(side=START)
            ctk.CTkLabel(row, text=name, font=font(13), text_color=c("text"),
                         anchor=TEXT_ANCHOR).pack(side=START, padx=8)
            ctk.CTkLabel(row, text=value, font=font(13, "bold"),
                         text_color=c("text")).pack(side=END)
            bar = ctk.CTkProgressBar(self, height=6, corner_radius=3,
                                     fg_color=c("surface_alt"), progress_color=c(self.tone))
            bar.pack(fill="x", padx=(0, 30) if START == "right" else (30, 0), pady=(4, 2))
            bar.set(max(0.0, min(1.0, float(ratio or 0))))


# ----------------------------------------------------------------------
# Dialogs and forms
# ----------------------------------------------------------------------

class Dialog(ctk.CTkToplevel):
    """Modal dialog with a branded header. Subclasses pack content into ``self``."""

    def __init__(self, parent, title, width=460, height=520, subtitle="", glyph="",
                 resizable=False):
        super().__init__(parent)
        self.title(title)
        self.resizable(resizable, resizable)
        self.configure(fg_color=c("surface"))
        try:
            self.transient(parent.winfo_toplevel())
        except Exception:
            pass
        self._center(parent, width, height)
        self.after(100, self._grab)
        self.bind("<Escape>", lambda _e: self.destroy())

        head = ctk.CTkFrame(self, fg_color=c("surface_alt"), corner_radius=0, height=58)
        head.pack(fill="x")
        head.pack_propagate(False)
        ctk.CTkLabel(head, text=glyph or "A", width=34, height=34, corner_radius=10,
                     fg_color=c("primary"), text_color="#FFFFFF",
                     font=font(15, "bold")).pack(side=START, padx=(0, 18) if START == "right" else (18, 0))
        texts = ctk.CTkFrame(head, fg_color="transparent")
        texts.pack(side=START, padx=10)
        ctk.CTkLabel(texts, text=title, font=font("h3", "bold"), text_color=c("text"),
                     anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR, pady=(10 if subtitle else 14, 0))
        if subtitle:
            ctk.CTkLabel(texts, text=subtitle, font=font(11), text_color=c("muted"),
                         anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)
        divider(self)
        self.error = ctk.CTkLabel(self, text="", text_color=c("danger"), font=font(12),
                                  wraplength=max(width - 60, 200), justify=JUSTIFY)

    def _grab(self):
        try:
            self.grab_set()
            self.focus_force()
        except Exception:
            pass

    def _center(self, parent, width, height):
        try:
            height = min(height, self.winfo_screenheight() - 70)
            width = min(width, self.winfo_screenwidth() - 20)
        except Exception:
            pass
        try:
            top = parent.winfo_toplevel()
            top.update_idletasks()
            x = top.winfo_rootx() + max((top.winfo_width() - width) // 2, 0)
            y = top.winfo_rooty() + max((top.winfo_height() - height) // 2, 0)
            y = max(0, min(y, self.winfo_screenheight() - height - 40))
            self.geometry(f"{width}x{height}+{x}+{y}")
        except Exception:
            self.geometry(f"{width}x{height}")

    def footer(self, buttons: Sequence[tuple[str, Callable, str]], width=130):
        """buttons: [(text, command, kind)] kind in primary/ghost/danger/success."""
        slaves = self.pack_slaves()
        anchor = {"before": slaves[1]} if len(slaves) > 1 else {}
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", padx=20, pady=12, side="bottom", **anchor)
        line = ctk.CTkFrame(self, height=1, fg_color=c("border"), corner_radius=0)
        line.pack(fill="x", side="bottom", after=bar)
        makers = {"primary": primary_button, "ghost": ghost_button,
                  "danger": danger_button, "success": success_button,
                  "subtle": subtle_button}
        for text, command, kind in buttons:
            makers.get(kind, ghost_button)(bar, text, command, width=width).pack(side=START, padx=4)
        return bar


def field(parent, caption, widget_factory: Callable, required=False, hint=""):
    """Vertical label + control; returns (frame, widget)."""
    frame = ctk.CTkFrame(parent, fg_color="transparent")
    text = f"{caption} *" if required and not caption.endswith("*") else caption
    ctk.CTkLabel(frame, text=text, font=font(12, "bold"), text_color=c("muted"),
                 anchor=TEXT_ANCHOR).pack(fill="x")
    widget = widget_factory(frame)
    widget.pack(fill="x", pady=(3, 0))
    if hint:
        ctk.CTkLabel(frame, text=hint, font=font(11), text_color=c("muted"),
                     anchor=TEXT_ANCHOR).pack(fill="x")
    return frame, widget


class ProductPicker(ctk.CTkComboBox):
    """Searchable product selector.

    * Typing filters the drop-down list by code, barcode or name.
    * Scanning/typing an exact barcode or code + Enter selects the product.
    * ``on_pick(product_row)`` fires whenever a product is resolved.
    Display values are ``"code - name"`` so the existing ``_pick`` helpers in
    the sales/purchase screens keep working unchanged.
    """

    def __init__(self, parent, products, on_pick: Callable | None = None, width=240, **kw):
        self.products = list(products)
        self.on_pick = on_pick
        self._labels = [self.display(p) for p in self.products]
        super().__init__(
            parent, values=self._labels[:200], width=width, height=CONTROL_HEIGHT - 2,
            corner_radius=RADIUS["md"], font=font(13), dropdown_font=font(13),
            fg_color=c("surface"), border_color=c("border"), border_width=1,
            button_color=c("surface_alt"), button_hover_color=c("surface_hover"),
            text_color=c("text"), dropdown_fg_color=c("surface"),
            dropdown_hover_color=c("primary_soft"), dropdown_text_color=c("text"),
            command=self._selected, justify=JUSTIFY, **kw)
        self.set("")
        try:
            self._entry.configure(placeholder_text="ابحث بالاسم أو امسح الباركود")
        except Exception:
            pass
        self._entry.bind("<KeyRelease>", self._filter, add="+")
        self._entry.bind("<Return>", self._resolve_typed, add="+")
        self._entry.bind("<FocusOut>", self._resolve_typed, add="+")

    @staticmethod
    def display(product) -> str:
        return f"{product['code']} - {product['name']}"

    def _field(self, product, key):
        try:
            return str(product[key] or "")
        except (KeyError, IndexError):
            return ""

    def _filter(self, event=None):
        if event is not None and getattr(event, "keysym", "") in ("Return", "Up", "Down", "Tab"):
            return
        q = self.get().strip().lower()
        if not q:
            values = self._labels[:200]
        else:
            values = [lab for p, lab in zip(self.products, self._labels)
                      if q in lab.lower() or q in self._field(p, "barcode").lower()][:200]
        self.configure(values=values or ["لا توجد نتائج"])

    def _resolve_typed(self, _event=None):
        q = self.get().strip()
        if not q or q in self._labels:
            if q in self._labels:
                self._selected(q)
            return
        ql = q.lower()
        exact = [p for p in self.products
                 if ql in (self._field(p, "barcode").lower(), self._field(p, "code").lower())]
        if not exact:
            matches = [p for p, lab in zip(self.products, self._labels) if ql in lab.lower()]
            exact = matches if len(matches) == 1 else []
        if exact:
            text = self.display(exact[0])
            self.set(text)
            self._selected(text)

    def _selected(self, value):
        product = self.product()
        if product is not None and self.on_pick:
            self.on_pick(product)

    def product(self):
        value = self.get().strip()
        for p, lab in zip(self.products, self._labels):
            if lab == value:
                return p
        return None


def toast(widget, text, tone="success", ms=2600):
    """Small non-blocking notification at the bottom of the window."""
    try:
        top = widget.winfo_toplevel()
        bg, fg = Badge.TONES.get(tone, Badge.TONES["primary"])
        note = ctk.CTkFrame(top, fg_color=c("text"), corner_radius=RADIUS["md"])
        glyph = {"success": "✓", "danger": "✕", "warning": "⚠"}.get(tone, "ℹ")
        ctk.CTkLabel(note, text=f"{glyph}   {text}", font=font(13, "bold"),
                     text_color=c("surface")).pack(padx=18, pady=10)
        note.place(relx=0.5, rely=0.97, anchor="s")
        note.lift()
        top.after(ms, note.destroy)
    except Exception:
        pass
