"""Read-only warehouse balances and stock movement browser."""
from __future__ import annotations

import customtkinter as ctk
from tkinter import messagebox

from alexerp.database.db import Database
from alexerp.ui.components import (
    Badge, DataTable, Page, SearchBar, Tabs, Toolbar, combo, entry, ghost_button,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font, icon


class InventoryPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="حركة المخزون",
                         subtitle="أرصدة المخازن وسجل الوارد والمنصرف", user=user)
        self.company_id = int((user or {}).get("company_id") or 0)
        self.branch_id = (user or {}).get("branch_id")
        self.warehouses = []
        self.warehouse_map = {}
        self._build()
        self.refresh()

    def _build(self):
        self.mode = "balances"
        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        self.mode_tabs = Tabs(bar.row, (("balances", "أرصدة المخازن"), ("movements", "سجل الحركات")),
                              command=self._set_mode, current="balances")
        bar.add(self.mode_tabs)
        self.search = SearchBar(bar.row, "بحث باسم المنتج أو الكود...  (Ctrl+F)",
                                on_search=self.refresh, width=300)
        bar.add(self.search, padx=8)
        bar.caption("المخزن")
        self.warehouse = combo(bar.row, ["كل المخازن"], 200, command=lambda _v: self.refresh())
        self.warehouse.set("كل المخازن")
        bar.add(self.warehouse, padx=4)
        ghost_button(bar.row, f"{icon('refresh')}  تحديث", self.refresh, width=100).pack(side=END, padx=4)
        self.summary = Badge(self.body, "", "info")
        self.summary.pack(anchor=TEXT_ANCHOR, pady=(0, 8))
        self.tab_buttons = {}
        self.host = ctk.CTkFrame(self.body, fg_color="transparent")
        self.host.pack(fill="both", expand=True)

    def _load_warehouses(self):
        if not self.company_id:
            return
        conn = Database.connect()
        sql = "SELECT id,name FROM warehouses WHERE company_id=? AND COALESCE(is_active,1)=1"
        params = [self.company_id]
        if self.branch_id is not None:
            sql += " AND (branch_id=? OR branch_id IS NULL)"
            params.append(int(self.branch_id))
        sql += " ORDER BY name"
        self.warehouses = [dict(r) for r in conn.execute(sql, params).fetchall()]
        self.warehouse_map = {r["name"]: r["id"] for r in self.warehouses}
        values = ["كل المخازن", *self.warehouse_map.keys()]
        current = self.warehouse.get()
        self.warehouse.configure(values=values)
        self.warehouse.set(current if current in values else "كل المخازن")

    def _set_mode(self, mode):
        self.mode = mode
        self.refresh()

    def refresh(self):
        try:
            if not self.company_id:
                self.summary.set("لا توجد شركة مرتبطة بهذا المستخدم")
                return
            self._load_warehouses()
            conn = Database.connect()
            selected = self.warehouse_map.get(self.warehouse.get())
            keyword = self.search.get().strip()
            if self.mode == "balances":
                sql = """SELECT p.code,p.name,w.name warehouse,ps.quantity,ps.average_cost,
                         (ps.quantity*ps.average_cost) stock_value
                         FROM product_stock ps JOIN products p ON p.id=ps.product_id
                         JOIN warehouses w ON w.id=ps.warehouse_id
                         WHERE ps.company_id=?"""
                args = [self.company_id]
                if selected:
                    sql += " AND ps.warehouse_id=?"; args.append(selected)
                if self.branch_id is not None:
                    sql += " AND (ps.branch_id=? OR ps.branch_id IS NULL)"; args.append(int(self.branch_id))
                if keyword:
                    sql += " AND (p.name LIKE ? OR p.code LIKE ?)"; args.extend([f"%{keyword}%"]*2)
                sql += " ORDER BY w.name,p.name LIMIT 500"
                rows = [dict(r) for r in conn.execute(sql, args).fetchall()]
                total_qty = sum(float(r["quantity"] or 0) for r in rows)
                total_value = sum(float(r["stock_value"] or 0) for r in rows)
                self.summary.set(f"عدد أرصدة الأصناف: {len(rows)} | إجمالي الوحدات: {total_qty:,.2f} | القيمة بالتكلفة المتوسطة: {total_value:,.2f}")
                columns = [("code","الكود",100,"w"),("name","المنتج",220,"w"),("warehouse","المخزن",160,"w"),("quantity","الرصيد",100,"e"),("average_cost","متوسط التكلفة",120,"e"),("stock_value","القيمة",130,"e")]
            else:
                sql = """SELECT sm.transaction_date,p.code,p.name,w.name warehouse,
                         sm.transaction_type,sm.quantity_in,sm.quantity_out,sm.balance_after,
                         sm.reference_type,sm.reference_id,sm.notes
                         FROM stock_movements sm JOIN products p ON p.id=sm.product_id
                         JOIN warehouses w ON w.id=sm.warehouse_id WHERE sm.company_id=?"""
                args = [self.company_id]
                if selected:
                    sql += " AND sm.warehouse_id=?"; args.append(selected)
                if self.branch_id is not None:
                    sql += " AND (sm.branch_id=? OR sm.branch_id IS NULL)"; args.append(int(self.branch_id))
                if keyword:
                    sql += " AND (p.name LIKE ? OR p.code LIKE ?)"; args.extend([f"%{keyword}%"]*2)
                sql += " ORDER BY sm.transaction_date DESC,sm.id DESC LIMIT 500"
                rows = [dict(r) for r in conn.execute(sql, args).fetchall()]
                self.summary.set(f"عدد الحركات المعروضة: {len(rows)} (آخر 500 حركة كحد أقصى)")
                columns = [("transaction_date","التاريخ",145,"w"),("code","الكود",85,"w"),("name","المنتج",180,"w"),("warehouse","المخزن",130,"w"),("transaction_type","النوع",105,"w"),("quantity_in","وارد",75,"e"),("quantity_out","منصرف",75,"e"),("balance_after","الرصيد",85,"e"),("reference_type","المرجع",95,"w"),("reference_id","رقم المرجع",85,"e")]
            for child in self.host.winfo_children(): child.destroy()
            self.table = DataTable(self.host, columns, empty_text="لا توجد بيانات مطابقة")
            self.table.pack(fill="both", expand=True)
            self.table.set_rows(rows, {k: (lambda v: f"{float(v or 0):,.2f}") for k in ("quantity","average_cost","stock_value","quantity_in","quantity_out","balance_after")})
        except Exception as exc:
            messagebox.showerror("تعذر تحميل المخزون", str(exc), parent=self.winfo_toplevel())
