"""
AlexERP — Business Management System
AI assistant chat page. The agent runs in a worker thread; the UI thread
communicates with it through a queue (Tk is not thread-safe).
"""

from __future__ import annotations

import queue
import threading
from tkinter import messagebox

import customtkinter as ctk

from alexerp.ai import settings
from alexerp.ai.agent import AIAgent, AgentError
from alexerp.ui.components import (
    Badge, Card, Dialog, Page, entry, field, ghost_button, primary_button, subtle_button,
)
from alexerp.ui.theme import BRAND_MARK, END, JUSTIFY, START, TEXT_ANCHOR, c, font

SUGGESTIONS = [
    "ما هي المنتجات الناقصة؟",
    "لخّص مبيعات آخر 7 أيام",
    "ما أعلى 5 منتجات مبيعاً؟",
    "من أكثر العملاء مديونية؟",
    "أعطني ملخصاً لحالة النشاط",
]


class SettingsDialog(Dialog):
    def __init__(self, parent, on_saved):
        super().__init__(parent, "إعدادات المساعد الذكي", 500, 400,
                         subtitle="ربط المساعد بمفتاح Anthropic", glyph="✨")
        self.on_saved = on_saved

        form = ctk.CTkFrame(self, fg_color="transparent")
        form.pack(fill="x", padx=26, pady=(14, 0))
        fr, self.key = field(form, "Anthropic API Key", lambda p: entry(p, "sk-ant-...", show="*", justify="left"))
        fr.pack(fill="x", pady=6)
        fr, self.model = field(form, "النموذج (Model)", lambda p: entry(p, justify="left"))
        fr.pack(fill="x", pady=6)
        self.model.insert(0, settings.get_model())
        ctk.CTkLabel(
            self, text="يُحفظ المفتاح محلياً على هذا الجهاز فقط.\n"
                       "يمكنك بدلاً من ذلك ضبط متغير البيئة ANTHROPIC_API_KEY.",
            font=font(12), text_color=c("muted"), justify=JUSTIFY, anchor=TEXT_ANCHOR,
        ).pack(fill="x", padx=28, pady=10)
        self.footer([("حفظ", self.save, "primary"), ("إلغاء", self.destroy, "ghost")])

    def save(self):
        key = self.key.get().strip()
        settings.save(api_key=key if key else None, model=self.model.get())
        self.on_saved()
        self.destroy()


class AIPage(Page):

    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="المساعد الذكي",
                         subtitle="اسأل عن مبيعاتك ومخزونك، وسيحلّل بياناتك الفعلية",
                         user=user)
        self.events: queue.Queue = queue.Queue()
        self.busy = False
        self.agent = AIAgent(user=user, confirm=self._confirm_from_worker)

        self.status_badge = Badge(self.actions, "", "muted")
        self.status_badge.pack(side="left", padx=6)
        ghost_button(self.actions, "🗑  محادثة جديدة", self.new_chat, width=140
                     ).pack(side="left", padx=4)
        ghost_button(self.actions, "⚙  الإعدادات", self.open_settings, width=120
                     ).pack(side="left", padx=4)

        self.chat = ctk.CTkScrollableFrame(self.body, fg_color=c("surface"),
                                           corner_radius=14, border_width=1,
                                           border_color=c("border"),
                                           scrollbar_button_color=c("border"))
        self.chat.pack(fill="both", expand=True)

        self.chips = ctk.CTkFrame(self.body, fg_color="transparent")
        self.chips.pack(fill="x", pady=(10, 0))
        for text in SUGGESTIONS:
            subtle_button(self.chips, text, lambda t=text: self.send(t), height=34,
                          width=len(text) * 8 + 28, font=font(12)).pack(side=START, padx=(0, 6) if START == "left" else (6, 0))

        bar = Card(self.body)
        bar.pack(fill="x", pady=(10, 0))
        inner = ctk.CTkFrame(bar, fg_color="transparent")
        inner.pack(fill="x", padx=8, pady=8)
        self.input = entry(inner, "اكتب سؤالك هنا...  (Enter للإرسال)", 400, border_width=0)
        self.input.pack(side=START, fill="x", expand=True)
        self.input.bind("<Return>", lambda _e: self.send())
        self.send_btn = primary_button(inner, "إرسال  ➤", self.send, width=110)
        self.send_btn.pack(side=END, padx=(0, 4))
        self.typing = ctk.CTkLabel(self.body, text="", font=font(12), text_color=c("muted"),
                                   anchor=TEXT_ANCHOR)
        self.typing.pack(fill="x", pady=(4, 0))

        self._welcome()
        self._update_status()
        self.after(150, self._poll)

    # ---------------- UI helpers ----------------

    def _update_status(self):
        ok = bool(settings.get_api_key())
        self.status_badge.configure(
            text="  ● متصل  " if ok else "  ● يحتاج مفتاح API  ",
            fg_color=c("success_soft" if ok else "warning_soft"),
            text_color=c("success" if ok else "warning"))
        self.agent.model = settings.get_model()

    def _welcome(self):
        self._bubble("مرحباً! أنا مساعد AlexERP. أستطيع تحليل المبيعات والمخزون والمديونيات، "
                     "وتنفيذ تعديلات بسيطة (بعد موافقتك). جرّب أحد الاقتراحات بالأسفل.",
                     user=False)

    def _bubble(self, text: str, user: bool, error: bool = False):
        row = ctk.CTkFrame(self.chat, fg_color="transparent")
        row.pack(fill="x", pady=5, padx=6)
        # RTL: assistant messages start at the right, the user's at the left
        side = END if user else START
        avatar = ctk.CTkLabel(row, text="أنت" if user else BRAND_MARK, width=32, height=32,
                              corner_radius=16, font=font(11 if user else 14, "bold"),
                              fg_color=c("surface_alt") if user else c("primary"),
                              text_color=c("muted") if user else "#FFFFFF")
        avatar.pack(side=side, anchor="n", padx=4)
        bubble = ctk.CTkLabel(
            row, text=text, wraplength=620, justify=JUSTIFY, anchor=TEXT_ANCHOR,
            corner_radius=14, font=font(14),
            fg_color=c("primary") if user else c("danger_soft" if error else "surface_alt"),
            text_color="#FFFFFF" if user else c("danger" if error else "text"),
        )
        bubble.pack(side=side, ipadx=10, ipady=8, padx=4)
        self.after(50, self._scroll_bottom)

    def _scroll_bottom(self):
        try:
            self.chat._parent_canvas.yview_moveto(1.0)
        except Exception:
            pass

    # ---------------- actions ----------------

    def open_settings(self):
        SettingsDialog(self, self._update_status)

    def new_chat(self):
        if self.busy:
            return
        self.agent.reset()
        for child in self.chat.winfo_children():
            child.destroy()
        self._welcome()

    def send(self, text: str | None = None):
        if self.busy:
            return
        text = (text or self.input.get()).strip()
        if not text:
            return
        self.input.delete(0, "end")
        self.chips.pack_forget()
        self._bubble(text, user=True)
        self._set_busy(True)
        threading.Thread(target=self._worker, args=(text,), daemon=True).start()

    def _set_busy(self, busy: bool):
        self.busy = busy
        self.send_btn.configure(state="disabled" if busy else "normal")
        if not busy:
            self.typing.configure(text="")

    # ---------------- worker <-> UI ----------------

    def _worker(self, text: str):
        try:
            answer = self.agent.ask(text, on_status=lambda s: self.events.put(("status", s)))
            self.events.put(("answer", answer or "لم أتمكن من توليد إجابة."))
        except AgentError as exc:
            self.events.put(("error", str(exc)))
        except Exception as exc:
            self.events.put(("error", f"تعذّر الاتصال بالمساعد ({type(exc).__name__}): {exc}"))

    def _confirm_from_worker(self, description: str) -> bool:
        """Called on the worker thread: ask the UI thread and wait."""
        done, result = threading.Event(), {"ok": False}
        self.events.put(("confirm", description, done, result))
        done.wait(timeout=300)
        return result["ok"]

    def _poll(self):
        try:
            while True:
                kind, *rest = self.events.get_nowait()
                if kind == "status":
                    self.typing.configure(text=f"⏳ {rest[0]}")
                elif kind == "answer":
                    self._bubble(rest[0], user=False)
                    self._set_busy(False)
                elif kind == "error":
                    self._bubble(rest[0], user=False, error=True)
                    self._set_busy(False)
                    self._update_status()
                elif kind == "confirm":
                    description, done, result = rest
                    result["ok"] = messagebox.askyesno(
                        "طلب موافقة من المساعد",
                        f"يريد المساعد تنفيذ الإجراء التالي:\n\n{description}\n\nهل توافق؟")
                    done.set()
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(150, self._poll)
