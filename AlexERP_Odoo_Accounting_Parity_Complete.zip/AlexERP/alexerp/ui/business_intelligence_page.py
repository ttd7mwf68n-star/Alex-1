"""Executive BI workspace: company-scoped KPIs and performance rankings."""
from __future__ import annotations

from datetime import date, timedelta

import customtkinter as ctk

from alexerp.services.business_intelligence_service import BusinessIntelligenceService
from alexerp.ui.components import (
    Card, LineChart, Page, RankList, SectionHeader, StatCard, ghost_button,
)
from alexerp.ui.theme import START, c, font, icon


def _money(value) -> str:
    return f"{float(value or 0):,.2f}"


class BusinessIntelligencePage(Page):
    """Read-only management dashboard, scoped to the signed-in user's tenant."""

    PERIODS = {"آخر 30 يوم": 30, "آخر 90 يوم": 90, "آخر 12 شهر": 365}

    def __init__(self, parent, user=None, navigate=None):
        user = user or {}
        name = user.get("full_name") or user.get("username") or ""
        super().__init__(parent, title="ذكاء الأعمال والتحليلات",
                         subtitle=f"مؤشرات أداء الشركة واتجاهات النشاط · {date.today():%Y-%m-%d}",
                         user=user, scroll=True)
        self.company_id = int(user.get("company_id") or 0)
        self.branch_id = int(user["branch_id"]) if user.get("branch_id") else None
        self.service = BusinessIntelligenceService()
        self.period_days = 365

        self.period_menu = ctk.CTkOptionMenu(
            self.actions, values=list(self.PERIODS), command=self._period_changed,
            width=145, font=font(12), dropdown_font=font(12),
        )
        self.period_menu.set("آخر 12 شهر")
        self.period_menu.pack(side="left", padx=5)
        ghost_button(self.actions, f"{icon('refresh')}  تحديث", self.refresh).pack(side="left", padx=4)

        cards_frame = ctk.CTkFrame(self.body, fg_color="transparent")
        cards_frame.pack(fill="x")
        card_specs = [
            ("sales_total", "💰", "إجمالي المبيعات", "primary"),
            ("gross_profit", "📈", "مجمل الربح", "success"),
            ("gross_margin_percent", "％", "هامش مجمل الربح", "info"),
            ("purchase_total", "🛒", "إجمالي المشتريات", "warning"),
            ("net_cash_movement", "💳", "صافي حركة النقدية", "primary"),
            ("receivables_open", "👥", "أرصدة العملاء المفتوحة", "danger"),
            ("payables_open", "🏭", "أرصدة الموردين المفتوحة", "warning"),
            ("sales_invoice_count", "🧾", "عدد فواتير البيع", "success"),
            ("ledger_expenses_total", "📉", "مصروفات الدفتر", "danger"),
            ("net_income", "💹", "صافي الربح المحاسبي", "success"),
        ]
        self.cards = {}
        for index, (key, glyph, title, tone) in enumerate(card_specs):
            card = StatCard(cards_frame, glyph, title, "—", tone)
            col = (3 - index % 4) if START == "right" else index % 4
            card.grid(row=index // 4, column=col, padx=6, pady=6, sticky="nsew")
            self.cards[key] = card
        for col in range(4):
            cards_frame.grid_columnconfigure(col, weight=1, uniform="bi-kpi")

        trend_card = Card(self.body)
        trend_card.pack(fill="both", expand=True, padx=6, pady=8)
        SectionHeader(trend_card, "الأداء الشهري", "المبيعات والمشتريات ومجمل الربح ومصروفات الدفتر", "📊").pack(
            fill="x", padx=18, pady=(14, 8))
        self.trend = LineChart(trend_card, height=270)
        self.trend.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        comparison = Card(self.body)
        comparison.pack(fill="x", padx=6, pady=8)
        SectionHeader(comparison, "مقارنة بالفترة السابقة", "مقارنة بنفس عدد الأيام السابقة مباشرة", "↔").pack(
            fill="x", padx=18, pady=(14, 8))
        self.comparison_box = ctk.CTkFrame(comparison, fg_color="transparent")
        self.comparison_box.pack(fill="x", padx=16, pady=(0, 14))

        ranking_row = ctk.CTkFrame(self.body, fg_color="transparent")
        ranking_row.pack(fill="both", expand=True, pady=4)
        ranking_row.grid_columnconfigure(0, weight=1, uniform="bi-rank")
        ranking_row.grid_columnconfigure(1, weight=1, uniform="bi-rank")
        customers_card = Card(ranking_row)
        customers_card.grid(row=0, column=1 if START == "right" else 0, padx=6, pady=6, sticky="nsew")
        SectionHeader(customers_card, "أفضل العملاء", "حسب قيمة فواتير البيع خلال الفترة", "👥").pack(
            fill="x", padx=18, pady=(14, 8))
        self.customer_rank = RankList(customers_card, tone="primary", empty_text="لا توجد مبيعات للعملاء")
        self.customer_rank.pack(fill="both", expand=True, padx=18, pady=(0, 14))

        products_card = Card(ranking_row)
        products_card.grid(row=0, column=0 if START == "right" else 1, padx=6, pady=6, sticky="nsew")
        SectionHeader(products_card, "أفضل المنتجات", "حسب إيرادات الأصناف خلال الفترة", "📦").pack(
            fill="x", padx=18, pady=(14, 8))
        self.product_rank = RankList(products_card, tone="success", empty_text="لا توجد مبيعات للأصناف")
        self.product_rank.pack(fill="both", expand=True, padx=18, pady=(0, 14))

        note = ctk.CTkLabel(
            self.body,
            text="ملاحظة محاسبية: مجمل الربح التشغيلي يُحسب من فواتير البيع والمرتجعات وتكلفة البنود المخزنة. مصروفات الدفتر وصافي الربح المحاسبي يُحسبان من حسابات الإيراد والمصروف في القيود المرحلة فقط، ولا يمثلان تصنيفًا مستقلًا للمصروفات التشغيلية. صافي حركة النقدية = المقبوضات المرحلة ناقص المدفوعات المرحلة، وليس قائمة تدفقات نقدية معيارية أو توقعًا مستقبليًا.",
            font=font(11), text_color=c("muted"), justify="right", wraplength=1050,
        )
        note.pack(fill="x", padx=12, pady=(4, 16))
        self.refresh()

    def _period_changed(self, label: str):
        self.period_days = self.PERIODS.get(label, 365)
        self.refresh()

    def _render_comparison(self, comparison: dict):
        for child in self.comparison_box.winfo_children():
            child.destroy()
        labels = {
            "sales_total": "المبيعات", "purchase_total": "المشتريات",
            "gross_profit": "مجمل الربح", "receipts_total": "المقبوضات",
            "payments_total": "المدفوعات", "ledger_expenses_total": "مصروفات الدفتر",
            "net_income": "صافي الربح المحاسبي",
        }
        for index, (key, title) in enumerate(labels.items()):
            metric = comparison["metrics"][key]
            pct = metric["change_percent"]
            if pct is None:
                change_text = "لا توجد فترة أساس للمقارنة"
            else:
                direction = "↑" if metric["change"] > 0 else "↓" if metric["change"] < 0 else "—"
                change_text = f"{direction} {abs(pct):,.1f}% عن الفترة السابقة"
            box = ctk.CTkFrame(self.comparison_box, fg_color=c("surface"), corner_radius=10)
            col = (len(labels) - 1 - index) if START == "right" else index
            box.grid(row=0, column=col, padx=4, pady=4, sticky="ew")
            ctk.CTkLabel(box, text=title, font=font(12, "bold"), text_color=c("muted")).pack(pady=(10, 2))
            ctk.CTkLabel(box, text=_money(metric["current"]), font=font(16, "bold"),
                         text_color=c("text")).pack(pady=2)
            ctk.CTkLabel(box, text=change_text, font=font(10), text_color=c("muted"),
                         wraplength=170).pack(pady=(2, 10))
            self.comparison_box.grid_columnconfigure(col, weight=1, uniform="bi-compare")

    def refresh(self):
        if self.company_id <= 0:
            for card in self.cards.values():
                card.set("—", "لم يتم تحديد شركة للمستخدم")
            return
        end = date.today()
        start = end - timedelta(days=self.period_days - 1)
        try:
            summary = self.service.executive_summary(
                self.company_id, start.isoformat(), end.isoformat(), self.branch_id)
            for key, card in self.cards.items():
                value = summary[key]
                if key == "gross_margin_percent":
                    shown = f"{float(value):,.1f}%"
                elif key == "sales_invoice_count":
                    shown = f"{int(value):,}"
                else:
                    shown = _money(value)
                card.set(shown, f"من {summary['date_from']} إلى {summary['date_to']}")

            months = self.service.monthly_performance(
                self.company_id, start.isoformat(), end.isoformat(), self.branch_id)
            self.trend.set_series([r["label"] for r in months], [
                ("المبيعات", [r["sales"] for r in months], "primary"),
                ("المشتريات", [r["purchases"] for r in months], "warning"),
                ("مجمل الربح", [r["gross_profit"] for r in months], "success"),
                ("مصروفات الدفتر", [r["ledger_expenses"] for r in months], "danger"),
            ])
            comparison = self.service.period_comparison(
                self.company_id, start.isoformat(), end.isoformat(), self.branch_id)
            self._render_comparison(comparison)

            customers = self.service.top_customers(
                self.company_id, start.isoformat(), end.isoformat(), self.branch_id, 8)
            peak = max([float(r["sales_total"]) for r in customers] or [1]) or 1
            self.customer_rank.set_items([
                (r["name"], _money(r["sales_total"]), float(r["sales_total"]) / peak)
                for r in customers
            ])
            products = self.service.top_products(
                self.company_id, start.isoformat(), end.isoformat(), self.branch_id, 8)
            peak = max([float(r["revenue"]) for r in products] or [1]) or 1
            self.product_rank.set_items([
                (r["name"], _money(r["revenue"]), float(r["revenue"]) / peak)
                for r in products
            ])
        except Exception as exc:
            # Keep UI alive and make data/query problems visible to the operator.
            for card in self.cards.values():
                card.set("—", "تعذر تحميل المؤشر")
            self.trend.set_series([], [])
            self.customer_rank.set_items([])
            self.product_rank.set_items([])
            ctk.CTkLabel(self.body, text=f"تعذر تحميل التحليلات: {exc}",
                         text_color=c("danger"), font=font(12)).pack(fill="x", padx=12, pady=6)
