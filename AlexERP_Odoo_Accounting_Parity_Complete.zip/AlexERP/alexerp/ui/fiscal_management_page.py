"""Desktop UI for accounting periods and fiscal-year closing."""
from __future__ import annotations

import customtkinter as ctk
from tkinter import messagebox

from alexerp.database.db import Database
from alexerp.accounting import FiscalPeriodService
from alexerp.services.fiscal_year_closing_service import FiscalYearClosingService
from alexerp.services.permission_service import PermissionService
from alexerp.ui.components import (
    Badge, Card, DataTable, Page, Tabs, Toolbar, entry, label,
    primary_button, success_button, danger_button, ghost_button,
)
from alexerp.ui.theme import START, END, TEXT_ANCHOR, c, font


class FiscalManagementPage(Page):
    """Manage company accounting periods and run controlled year closing."""

    def __init__(self, parent, user=None, navigate=None):
        super().__init__(
            parent,
            title="إدارة الفترات والسنة المالية",
            subtitle="إنشاء الفترات المحاسبية، مراجعة حالة الإقفال، وإقفال السنة المالية بصلاحيات معتمدة",
            user=user,
            scroll=True,
        )
        self.user = user or {}
        self.company_id = int(self.user.get("company_id") or 0)
        self.user_id = int(self.user.get("id") or self.user.get("user_id") or 0)
        perms = PermissionService()
        self.can_manage_periods = bool(self.user_id and perms.has_permission(
            self.user_id, "accounting.periods.manage"))
        self.can_close_year = bool(self.user_id and perms.has_permission(
            self.user_id, "accounting.fiscal_year.close"))

        self.tabs = Tabs(
            self.body,
            (("periods", "الفترات المحاسبية"), ("year", "إقفال السنة المالية")),
            command=self._switch,
            current="periods",
            width=180,
        )
        self.tabs.pack(anchor=TEXT_ANCHOR, pady=(0, 12))
        self.host = ctk.CTkFrame(self.body, fg_color="transparent")
        self.host.pack(fill="both", expand=True)
        self._switch("periods")

    def _switch(self, mode):
        for child in self.host.winfo_children():
            child.destroy()
        if mode == "periods":
            self._build_periods()
        else:
            self._build_year_closing()

    def _build_periods(self):
        if not self.company_id:
            label(self.host, "لا توجد شركة مرتبطة بالمستخدم الحالي.").pack(anchor=TEXT_ANCHOR)
            return

        if self.can_manage_periods:
            form = Card(self.host)
            form.pack(fill="x", pady=(0, 12))
            label(form, "إنشاء فترة محاسبية جديدة", size="h3", weight="bold").pack(
                anchor=TEXT_ANCHOR, padx=16, pady=(12, 8))
            row = ctk.CTkFrame(form, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=(0, 12))
            self.period_name = entry(row, "اسم الفترة — مثال: يناير 2027", width=230)
            self.period_name.pack(side=START, padx=5)
            self.period_start = entry(row, "تاريخ البداية YYYY-MM-DD", width=190)
            self.period_start.pack(side=START, padx=5)
            self.period_end = entry(row, "تاريخ النهاية YYYY-MM-DD", width=190)
            self.period_end.pack(side=START, padx=5)
            primary_button(row, "إنشاء الفترة", self._create_period, width=130).pack(side=END, padx=5)
        else:
            Badge(self.host, "لا تملك صلاحية إدارة الفترات المحاسبية", "warning").pack(
                anchor=TEXT_ANCHOR, pady=(0, 10))

        bar = Toolbar(self.host)
        bar.pack(fill="x", pady=(0, 8))
        label(bar.row, "الفترات المسجلة للشركة الحالية", weight="bold").pack(side=START, padx=8)
        ghost_button(bar.row, "تحديث", self.refresh_periods, width=90).pack(side=END, padx=5)
        self.period_table_host = ctk.CTkFrame(self.host, fg_color="transparent")
        self.period_table_host.pack(fill="both", expand=True)
        self.refresh_periods()

    def refresh_periods(self):
        if not hasattr(self, "period_table_host") or not self.period_table_host.winfo_exists():
            return
        for child in self.period_table_host.winfo_children():
            child.destroy()
        try:
            rows = [dict(r) for r in FiscalPeriodService().list_periods(self.company_id)]
            for row in rows:
                row["status"] = "CLOSED" if int(row.get("is_closed") or 0) else "OPEN"
                row["close_info"] = row.get("closed_at") or "—"
            columns = [
                ("name", "اسم الفترة", 190, "w"),
                ("start_date", "من", 115, "w"),
                ("end_date", "إلى", 115, "w"),
                ("status", "الحالة", 100, "w"),
                ("close_info", "تاريخ الإغلاق", 180, "w"),
            ]
            table = DataTable(self.period_table_host, columns, empty_text="لم يتم إنشاء فترات محاسبية بعد")
            table.pack(fill="both", expand=True)
            table.set_rows(rows)
            if self.can_manage_periods:
                actions = ctk.CTkFrame(self.period_table_host, fg_color="transparent")
                actions.pack(fill="x", pady=(8, 0))
                self.period_choice = ctk.CTkComboBox(
                    actions,
                    values=[f"{r['id']} — {r['name']} ({r['start_date']} إلى {r['end_date']})"
                            for r in rows if not int(r.get("is_closed") or 0)],
                    width=420,
                    state="readonly",
                )
                if self.period_choice.cget("values"):
                    self.period_choice.set(self.period_choice.cget("values")[0])
                self.period_choice.pack(side=START, padx=5)
                danger_button(actions, "إغلاق الفترة المحددة", self._close_period, width=170).pack(
                    side=END, padx=5)
        except Exception as exc:
            label(self.period_table_host, f"تعذر تحميل الفترات: {exc}", tone="danger").pack(
                anchor=TEXT_ANCHOR)

    def _create_period(self):
        try:
            period_id = FiscalPeriodService().create_period(
                company_id=self.company_id,
                name=self.period_name.get().strip(),
                start_date=self.period_start.get().strip(),
                end_date=self.period_end.get().strip(),
                created_by=self.user_id,
            )
            messagebox.showinfo("تم إنشاء الفترة", f"تم إنشاء الفترة المحاسبية بنجاح. رقمها: {period_id}",
                                parent=self.winfo_toplevel())
            self.period_name.delete(0, "end")
            self.period_start.delete(0, "end")
            self.period_end.delete(0, "end")
            self.refresh_periods()
        except Exception as exc:
            messagebox.showerror("تعذر إنشاء الفترة", str(exc), parent=self.winfo_toplevel())

    def _close_period(self):
        value = self.period_choice.get().strip() if hasattr(self, "period_choice") else ""
        try:
            period_id = int(value.split("—", 1)[0].strip())
        except (TypeError, ValueError):
            messagebox.showwarning("اختيار مطلوب", "اختر فترة مفتوحة أولاً.", parent=self.winfo_toplevel())
            return
        if not messagebox.askyesno(
            "تأكيد إغلاق الفترة",
            "سيتم منع الترحيل إلى هذه الفترة بعد إغلاقها. إذا كانت هذه آخر فترة في السنة المالية، "
            "نفّذ إقفال السنة أولاً حتى يتمكن النظام من ترحيل قيد الإقفال داخل فترة مفتوحة. هل تريد المتابعة؟",
            parent=self.winfo_toplevel(),
        ):
            return
        try:
            FiscalPeriodService().close_period(period_id=period_id, closed_by=self.user_id)
            messagebox.showinfo("تم الإغلاق", "تم إغلاق الفترة وتسجيل العملية في سجل التدقيق.",
                                parent=self.winfo_toplevel())
            self.refresh_periods()
        except Exception as exc:
            messagebox.showerror("تعذر إغلاق الفترة", str(exc), parent=self.winfo_toplevel())

    def _build_year_closing(self):
        if not self.company_id:
            label(self.host, "لا توجد شركة مرتبطة بالمستخدم الحالي.").pack(anchor=TEXT_ANCHOR)
            return
        if not self.can_close_year:
            Badge(self.host, "لا تملك صلاحية إقفال السنة المالية", "warning").pack(
                anchor=TEXT_ANCHOR, pady=(0, 10))
            self._show_closing_history()
            return

        intro = Card(self.host)
        intro.pack(fill="x", pady=(0, 12))
        label(intro, "مراجعة وإقفال السنة المالية", size="h3", weight="bold").pack(
            anchor=TEXT_ANCHOR, padx=16, pady=(12, 4))
        label(intro,
              "قبل التنفيذ، تأكد من اكتمال الفترات وتوازن القيود وترحيلها. العملية تنشئ قيد إقفال "
              "للإيرادات والمصروفات وتحوّل صافي النتيجة إلى الأرباح المحتجزة.",
              tone="muted").pack(anchor=TEXT_ANCHOR, padx=16, pady=(0, 12))

        form = Card(self.host)
        form.pack(fill="x", pady=(0, 12))
        label(form, "بيانات السنة المالية", size="h3", weight="bold").pack(
            anchor=TEXT_ANCHOR, padx=16, pady=(12, 8))
        row1 = ctk.CTkFrame(form, fg_color="transparent")
        row1.pack(fill="x", padx=12, pady=4)
        self.year_name = entry(row1, "اسم السنة — مثال: FY2027", width=220)
        self.year_name.pack(side=START, padx=5)
        self.year_start = entry(row1, "تاريخ البداية YYYY-MM-DD", width=200)
        self.year_start.pack(side=START, padx=5)
        self.year_end = entry(row1, "تاريخ النهاية YYYY-MM-DD", width=200)
        self.year_end.pack(side=START, padx=5)

        row2 = ctk.CTkFrame(form, fg_color="transparent")
        row2.pack(fill="x", padx=12, pady=(4, 12))
        self.retained_accounts = self._load_retained_accounts()
        account_labels = [f"{r['id']} — {r['account_code']} | {r['account_name']}"
                          for r in self.retained_accounts]
        self.retained_choice = ctk.CTkComboBox(
            row2, values=account_labels or ["لا توجد حسابات حقوق ملكية قابلة للترحيل"],
            width=440, state="readonly")
        self.retained_choice.pack(side=START, padx=5)
        if account_labels:
            self.retained_choice.set(account_labels[0])
        success_button(row2, "مراجعة جاهزية الإقفال", self._review_year, width=180).pack(side=END, padx=5)
        self.review_box = Card(self.host)
        self.review_box.pack(fill="x", pady=(0, 10))
        label(self.review_box, "مراجعة الجاهزية", size="h3", weight="bold").pack(
            anchor=TEXT_ANCHOR, padx=14, pady=(10, 4))
        self.review_text = label(self.review_box, "أدخل نطاق السنة ثم اضغط مراجعة الجاهزية.", tone="muted")
        self.review_text.pack(anchor=TEXT_ANCHOR, padx=14, pady=(0, 10))
        self._show_closing_history()

    def _load_retained_accounts(self):
        conn = Database.connect()
        return [dict(r) for r in conn.execute(
            """SELECT coa.id, coa.account_code, coa.account_name
               FROM chart_of_accounts coa
               JOIN account_types at ON at.id=coa.account_type_id
               WHERE coa.company_id=? AND at.code='EQUITY'
                 AND COALESCE(coa.is_active,1)=1 AND COALESCE(coa.allow_posting,1)=1
               ORDER BY coa.account_code""", (self.company_id,)
        ).fetchall()]

    def _review_year(self):
        try:
            start = self.year_start.get().strip()
            end = self.year_end.get().strip()
            # Validate strict ISO dates and collect a read-only preflight summary.
            from datetime import date
            start_d, end_d = date.fromisoformat(start), date.fromisoformat(end)
            if start_d.isoformat() != start or end_d.isoformat() != end or start_d > end_d:
                raise ValueError("أدخل تاريخين صحيحين بصيغة YYYY-MM-DD، وتأكد أن البداية قبل النهاية.")
            preflight = FiscalPeriodService().close_preflight(self.company_id, start, end)
            periods_total = preflight["periods_total"]
            periods_closed = preflight["periods_closed"]
            pending = preflight["unposted_journals"]
            invalid = preflight["invalid_journals"]
            text = (f"الفترات الموجودة داخل النطاق: {periods_total} — المغلقة مسبقًا: {periods_closed}\n"
                    f"القيود غير المرحلة: {pending}\nالقيود الفارغة أو غير المتوازنة: {invalid}\n"
                    "هذه مراجعة أولية فقط؛ خدمة الإقفال تعيد فحص جميع الشروط داخل معاملة قاعدة البيانات.")
            self.review_text.configure(text=text)
            ready = periods_total > 0 and pending == 0 and invalid == 0
            if ready and self.retained_accounts:
                if not hasattr(self, "execute_close_button") or not self.execute_close_button.winfo_exists():
                    self.execute_close_button = danger_button(
                        self.review_box, "تنفيذ إقفال السنة نهائيًا", self._execute_year_close, width=210)
                    self.execute_close_button.pack(anchor=END, padx=14, pady=(0, 12))
            else:
                if hasattr(self, "execute_close_button") and self.execute_close_button.winfo_exists():
                    self.execute_close_button.destroy()
        except Exception as exc:
            messagebox.showerror("تعذر إتمام المراجعة", str(exc), parent=self.winfo_toplevel())

    def _execute_year_close(self):
        try:
            account_text = self.retained_choice.get().strip()
            account_id = int(account_text.split("—", 1)[0].strip())
        except (ValueError, AttributeError):
            messagebox.showwarning("حساب مطلوب", "اختر حساب أرباح محتجزة صالحًا.", parent=self.winfo_toplevel())
            return
        if not messagebox.askyesno(
            "تأكيد نهائي لإقفال السنة",
            "هذا الإجراء ينشئ قيد إقفال ويغلق الفترات المحاسبية الداخلة في السنة. "
            "لا يمكن تكرار إقفال نفس النطاق. هل أنت متأكد؟",
            icon="warning", parent=self.winfo_toplevel(),
        ):
            return
        try:
            result = FiscalYearClosingService().close_year(
                company_id=self.company_id,
                year_name=self.year_name.get().strip(),
                start_date=self.year_start.get().strip(),
                end_date=self.year_end.get().strip(),
                retained_earnings_account_id=account_id,
                closed_by=self.user_id,
            )
            messagebox.showinfo(
                "اكتمل إقفال السنة",
                f"تم إقفال السنة بنجاح.\nصافي النتيجة: {result['net_income']}\n"
                f"رقم قيد الإقفال: {result['closing_entry_id'] or 'لا يوجد قيد (لا توجد حركة أرباح/مصروفات)'}\n"
                f"الفترات التي أغلقت الآن: {result['periods_closed']}",
                parent=self.winfo_toplevel(),
            )
            self._switch("year")
        except Exception as exc:
            messagebox.showerror("فشل إقفال السنة", str(exc), parent=self.winfo_toplevel())

    def _show_closing_history(self):
        history = Card(self.host)
        history.pack(fill="both", expand=True)
        label(history, "سجل إقفالات السنوات المالية", size="h3", weight="bold").pack(
            anchor=TEXT_ANCHOR, padx=14, pady=(10, 6))
        try:
            rows = [dict(r) for r in Database.connect().execute(
                """SELECT fy.year_name, fy.start_date, fy.end_date, fy.net_income,
                          fy.closing_entry_id, fy.closed_at, u.full_name AS closed_by_name
                   FROM fiscal_year_closings fy LEFT JOIN users u ON u.id=fy.closed_by
                   WHERE fy.company_id=? ORDER BY fy.start_date DESC, fy.id DESC LIMIT 100""",
                (self.company_id,),
            ).fetchall()]
            for row in rows:
                row["closing_entry_id"] = row["closing_entry_id"] or "—"
                row["closed_by_name"] = row["closed_by_name"] or "—"
            table = DataTable(history, [
                ("year_name", "السنة المالية", 140, "w"),
                ("start_date", "من", 105, "w"),
                ("end_date", "إلى", 105, "w"),
                ("net_income", "صافي الربح / الخسارة", 150, "e"),
                ("closing_entry_id", "رقم قيد الإقفال", 120, "e"),
                ("closed_by_name", "بواسطة", 130, "w"),
                ("closed_at", "تاريخ التنفيذ", 160, "w"),
            ], empty_text="لا توجد سنوات مالية مغلقة حتى الآن")
            table.pack(fill="both", expand=True, padx=8, pady=(0, 8))
            table.set_rows(rows)
        except Exception as exc:
            label(history, f"تعذر تحميل سجل الإقفالات: {exc}", tone="danger").pack(
                anchor=TEXT_ANCHOR, padx=14, pady=10)
