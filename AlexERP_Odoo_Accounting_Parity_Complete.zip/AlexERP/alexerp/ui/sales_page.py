"""
AlexERP — Business Management System
Sales page: post invoices with stock and accounting effects, cancel, and returns.
"""

from __future__ import annotations

import secrets
from datetime import date
from tkinter import messagebox

import customtkinter as ctk

from alexerp.database.db import Database
from alexerp.database.transaction import TransactionError
from alexerp.core.helpers import allocate_discount
from alexerp.services.sales_service import SalesService, SalesError
from alexerp.services.sales_settings_service import SalesSettingsService
from alexerp.services.sales_return_service import SalesReturnService, SalesReturnError
from alexerp.services.permission_service import PermissionService
from alexerp.services.customer_service import CustomerService
from alexerp.services.product_service import ProductService
from alexerp.core import context
from alexerp.ui.components import (
    Badge, Card, DataTable, Dialog, Page, SearchBar, Toolbar, combo, danger_button, entry,
    field, label, primary_button, subtle_button, toast,
)
from alexerp.ui.invoice_form import InvoiceDialogBase
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font, icon

COLUMNS = [
    ("invoice_number", "رقم الفاتورة", 120, "w"),
    ("invoice_date", "التاريخ", 105, "w"),
    ("customer_name", "العميل", 210, "w"),
    ("total", "الإجمالي", 105, "e"),
    ("paid_amount", "المدفوع", 100, "e"),
    ("remaining_amount", "المتبقي", 100, "e"),
    ("status", "الحالة", 95, "w"),
    ("delivery_status", "التسليم", 105, "w"),
]


def _accounts(company_id=None):
    company_id = int(company_id or context.current_company_id())
    rows = Database.connect().execute(
        "SELECT id, account_code || ' - ' || account_name AS label "
        "FROM chart_of_accounts WHERE company_id=? AND is_header=0 AND allow_posting=1 AND is_active=1 "
        "AND id NOT IN (SELECT account_id FROM customers WHERE company_id=? AND account_id IS NOT NULL) "
        "ORDER BY account_code",
        (company_id, company_id),
    ).fetchall()
    return rows


def _warehouses():
    from alexerp.core import context
    return Database.connect().execute(
        "SELECT id, name FROM warehouses WHERE company_id=? ORDER BY id",
        (context.current_company_id(),),
    ).fetchall()


def _pick(rows, widget):
    """Resolve a selected value from account, entity, warehouse, or product rows."""
    label = widget.get().strip()
    for row in rows:
        keys = row.keys()
        if "label" in keys and str(row["label"]) == label:
            return int(row["id"])
        if "name" in keys and str(row["name"]) == label:
            return int(row["id"])
        if "code" in keys and "name" in keys:
            display = f"{row['code']} - {row['name']}"
            if display == label:
                return int(row["id"])
    raise ValueError("اختر قيمة من القوائم أولاً")


def _set_account_defaults(accounts, widgets, settings):
    for key, setting_key in (
        ("receivable", "receivable_account_id"),
        ("sales", "sales_account_id"),
        ("inventory", "inventory_account_id"),
        ("cogs", "cogs_account_id"),
        ("tax", "tax_account_id"),
        ("cash", "cash_account_id"),
    ):
        widget = widgets.get(key)
        if widget is None:
            continue
        account_id = settings.get(setting_key)
        if account_id is None:
            continue
        account = next((row for row in accounts if int(row["id"]) == int(account_id)), None)
        if account is not None:
            widget.set(str(account["label"]))


def _optional_pick(rows, widget):
    if not widget.get().strip():
        return None
    return _pick(rows, widget)


def _delivery_label(value):
    return {
        "PREPARING": "قيد التجهيز",
        "SHIPPED": "تم الشحن",
        "DELIVERED": "تم التسليم",
        "CANCELLED": "ملغاة",
    }.get(str(value or "").upper(), str(value or ""))


class _Dialog(Dialog):
    def __init__(self, parent, title, width=720, height=640, **kw):
        super().__init__(parent, title, width, height, **kw)


class SalesInvoiceDialog(InvoiceDialogBase):
    """Post a new sales invoice: items, customer, warehouse, ledger accounts."""

    ACCOUNT_SPECS = [("المبيعات (دائن)", "sales"),
                     ("المخزون (دائن)", "inventory"), ("تكلفة البضاعة (مدين)", "cogs"),
                     ("ضريبة المخرجات (دائن)", "tax"), ("النقدية/البنك (إن وُجد دفع)", "cash")]

    def __init__(self, parent, user, on_saved=None):
        self.user, self.on_saved = user, on_saved
        self.service = SalesService()
        self.settings_service = SalesSettingsService()
        self.settings = self.settings_service.get_settings(context.current_company_id())
        self.customers = CustomerService().get_all(context.current_company_id())
        self.accounts = _accounts(context.current_company_id())
        super().__init__(
            parent, "فاتورة بيع جديدة", party_label="العميل", parties=self.customers,
            products=ProductService().list(), warehouses=_warehouses(),
            price_key="sale_price", price_caption="السعر", accounts=self.accounts,
            account_specs=self.ACCOUNT_SPECS,
            subtitle=(
                "الترحيل يحجز المخزون حتى التسليم وينشئ القيد المحاسبي تلقائياً"
                if self.settings["inventory_policy"] == "RESERVE_UNTIL_DELIVERY"
                else "الترحيل يخصم المخزون وينشئ القيد المحاسبي تلقائياً"
            ),
            glyph="🧾")
        self.warehouses = self._warehouses
        self.customer = self.party
        _set_account_defaults(self.accounts, self.acc_widgets, self.settings)
        if not self.customers:
            self.error.configure(text="أضف عميلاً أولاً من شاشة العملاء")
        if not self.accounts:
            self.error.configure(text="أضف حسابات في شجرة الحسابات أولاً")
        self.footer([("ترحيل الفاتورة", self.save, "primary"), ("إلغاء", self.destroy, "ghost")],
                    width=160)

    # -------------------------------------------------

    def _line(self, qty_e, price_e, tax_e):
        q = float(qty_e.get() or 0)
        p = float(price_e.get() or 0)
        t = float(tax_e.get() or 0)
        return q, p, t, round(q * p + t, 2)

    def save(self):
        try:
            customer_id = _pick(self.customers, self.customer)
            warehouse_id = _pick(self.warehouses, self.warehouse)
            items, subtotal, tax = [], 0.0, 0.0
            for _, cb, q, p, t in self.item_rows:
                lq, lp, lt, lt_total = self._line(q, p, t)
                if lq <= 0:
                    continue
                pid = _pick(self.products, cb)
                items.append({"product_id": pid, "warehouse_id": warehouse_id,
                              "quantity": lq, "unit_price": lp, "discount": 0,
                              "tax": lt, "total": lt_total})
                subtotal += lq * lp
                tax += lt
            if not items:
                self.error.configure(text="أضف بنداً واحداً على الأقل بكمية موجبة")
                return
            discount = float(self.discount.get() or 0)
            allocations = allocate_discount(
                [item["quantity"] * item["unit_price"] for item in items], discount
            )
            for item, line_discount in zip(items, allocations):
                item["discount"] = line_discount
                item["total"] = round(
                    item["quantity"] * item["unit_price"] - line_discount + item["tax"], 2
                )
            paid = float(self.paid.get() or 0)
            total = round(subtotal - discount + tax, 2)
            number = f"S-{date.today():%Y%m%d}-{len(self.service.search('')) + 1}"
            company_id = context.current_company_id()
            user_id = context.current_user_id()
            remaining = round(total - paid, 2)
            credit_status = self.service.credit_limit_status(
                company_id, customer_id, remaining, user_id
            )
            override_credit_limit = False
            if credit_status["exceeded"]:
                if not credit_status["can_override"]:
                    self.error.configure(
                        text=(f"تجاوز حد ائتمان العميل: الرصيد المتوقع "
                              f"{credit_status['projected_balance']:.2f} والحد "
                              f"{credit_status['limit']:.2f}.")
                    )
                    return
                override_credit_limit = messagebox.askyesno(
                    "تأكيد تجاوز حد الائتمان",
                    (f"الرصيد المتوقع للعميل {credit_status['projected_balance']:.2f} "
                     f"ويتجاوز الحد {credit_status['limit']:.2f}. هل تريد المتابعة؟"),
                    parent=self,
                )
                if not override_credit_limit:
                    return
            self.service.create_invoice(
                company_id=company_id, branch_id=context.current_branch_id(), customer_id=customer_id,
                invoice_number=number, invoice_date=self.invoice_date.get().strip() or date.today().isoformat(),
                items=items, subtotal=round(subtotal, 2), discount=discount, tax=round(tax, 2),
                total=total, paid_amount=paid, remaining_amount=remaining,
                notes="", created_by=user_id,
                sales_account=_pick(self.accounts, self.acc_widgets["sales"]),
                inventory_account=_pick(self.accounts, self.acc_widgets["inventory"]),
                cogs_account=_pick(self.accounts, self.acc_widgets["cogs"]),
                tax_account=_optional_pick(self.accounts, self.acc_widgets["tax"]) if tax else None,
                cash_account=_optional_pick(self.accounts, self.acc_widgets["cash"]) if paid else None,
                override_credit_limit=bool(override_credit_limit),
            )
        except (ValueError, SalesError, TransactionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, f"تم ترحيل الفاتورة {number}")
        self.destroy()


class SalesSettingsDialog(_Dialog):
    POLICY_LABELS = {
        "خصم المخزون عند ترحيل الفاتورة": "DEDUCT_ON_POST",
        "حجز المخزون حتى التسليم": "RESERVE_UNTIL_DELIVERY",
    }

    def __init__(self, parent, company_id, user_id, on_saved=None):
        super().__init__(parent, "إعدادات المبيعات", 760, 600)
        self.company_id, self.user_id, self.on_saved = company_id, user_id, on_saved
        self.service = SalesSettingsService()
        self.settings = self.service.get_settings(company_id)
        self.accounts = _accounts(company_id)
        self.account_widgets = {}

        card = Card(self)
        card.pack(fill="both", expand=True, padx=20, pady=14)
        fr, self.policy = field(
            card, "سياسة المخزون عند ترحيل البيع",
            lambda parent: combo(parent, list(self.POLICY_LABELS), 300),
        )
        fr.pack(fill="x", padx=12, pady=(12, 6))
        policy_label = next(
            (label for label, value in self.POLICY_LABELS.items()
             if value == self.settings["inventory_policy"]),
            "خصم المخزون عند ترحيل الفاتورة",
        )
        self.policy.set(policy_label)

        specs = [
            ("ذمم العملاء", "receivable_account_id"),
            ("إيرادات المبيعات", "sales_account_id"),
            ("حساب المخزون", "inventory_account_id"),
            ("تكلفة البضاعة المباعة", "cogs_account_id"),
            ("النقدية / البنك", "cash_account_id"),
            ("ضريبة المبيعات (اختياري)", "tax_account_id"),
        ]
        account_labels = [str(row["label"]) for row in self.accounts]
        for caption, key in specs:
            row, widget = field(
                card, caption,
                lambda parent, labels=account_labels: combo(parent, labels, 380),
            )
            row.pack(fill="x", padx=12, pady=5)
            self.account_widgets[key] = widget
            account_id = self.settings.get(key)
            if account_id is not None:
                match = next(
                    (item for item in self.accounts if int(item["id"]) == int(account_id)),
                    None,
                )
                if match is not None:
                    widget.set(str(match["label"]))

        self.error.pack(fill="x", padx=26, pady=(0, 4))
        self.footer(
            [("حفظ الإعدادات", self.save, "primary"), ("إلغاء", self.destroy, "ghost")],
            width=160,
        )

    def save(self):
        try:
            required_values = {
                key: _pick(self.accounts, self.account_widgets[key])
                for key in (
                    "receivable_account_id", "sales_account_id",
                    "inventory_account_id", "cogs_account_id", "cash_account_id",
                )
            }
            self.service.save_settings(
                company_id=self.company_id,
                actor_id=self.user_id,
                inventory_policy=self.POLICY_LABELS[self.policy.get()],
                **required_values,
                tax_account_id=_optional_pick(
                    self.accounts, self.account_widgets["tax_account_id"]
                ),
            )
        except (ValueError, PermissionError, TransactionError, KeyError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, "تم حفظ إعدادات المبيعات")
        self.destroy()


class SalesDeliveryDialog(_Dialog):
    STATUS_LABELS = {
        "تم الشحن": "SHIPPED",
        "تم التسليم": "DELIVERED",
    }

    def __init__(self, parent, invoice, user_id, on_saved=None):
        super().__init__(parent, "تحديث حالة التسليم", 520, 300)
        self.invoice, self.user_id, self.on_saved = invoice, user_id, on_saved
        current = str(invoice["delivery_status"] or "PREPARING").upper()
        options = list(self.STATUS_LABELS)
        if current == "SHIPPED":
            options = ["تم التسليم"]

        card = Card(self)
        card.pack(fill="both", expand=True, padx=20, pady=14)
        label(card, f"الفاتورة: {invoice['invoice_number']}").pack(anchor=TEXT_ANCHOR, padx=12, pady=(16, 8))
        row, self.status = field(
            card, "الحالة التالية",
            lambda parent: combo(parent, options, 260),
        )
        row.pack(fill="x", padx=12, pady=8)
        self.status.set(options[0])
        self.error.pack(fill="x", padx=26, pady=(0, 4))
        self.footer(
            [("تحديث الحالة", self.save, "primary"), ("إلغاء", self.destroy, "ghost")],
            width=150,
        )

    def save(self):
        try:
            status = self.STATUS_LABELS[self.status.get()]
            SalesService().update_delivery_status(
                int(self.invoice["id"]), status, self.user_id,
            )
        except (KeyError, SalesError, TransactionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, "تم تحديث حالة التسليم")
        self.destroy()


class SalesReturnDialog(_Dialog):
    """Return part or all of a posted sales invoice at its original cost/tax."""

    def __init__(self, parent, user, invoice, on_saved=None, delivery=None):
        super().__init__(parent, f"مرتجع فاتورة {invoice['invoice_number']}", 720, 600,
                         subtitle=(f"مرتجع من مستند التسليم {delivery['delivery_number']}"
                                   if delivery else "أدخل الكمية المرتجعة لكل بند"), glyph="↩")
        self.user, self.invoice, self.on_saved, self.delivery = user, invoice, on_saved, delivery
        self.service = SalesReturnService()
        self.service_sales = SalesService()
        self.accounts = _accounts(context.current_company_id())
        self.rows = []
        prior = {} if delivery else self.service.repo.get_returned_quantities(invoice["id"])

        card = Card(self)
        card.pack(fill="x", padx=20, pady=(14, 0))
        box = ctk.CTkFrame(card, fg_color="transparent")
        box.pack(fill="x", padx=12, pady=10)
        headers = ["المنتج", "المسلّم" if delivery else "المباع",
                   "المتاح للمرتجع", "الكمية المرتجعة"]
        n = len(headers)

        def col(i):
            return (n - 1 - i) if START == "right" else i

        for i, h in enumerate(headers):
            ctk.CTkLabel(box, text=h, font=font(12, "bold"), text_color=c("muted")).grid(
                row=0, column=col(i), padx=6, pady=(0, 4), sticky="e" if i == 0 and START == "right" else "")
        box.grid_columnconfigure(col(0), weight=1)

        r = 1
        if delivery:
            source_items = self.service.get_delivery_return_items(
                int(delivery["id"]), int(invoice["company_id"]),
                int(invoice["branch_id"]), int((user or {}).get("id") or 0),
            )
        else:
            source_items = SalesService().get_items(invoice["id"])
        for item in source_items:
            if delivery:
                sold = float(item["delivered_quantity"])
                available = float(item["available_quantity"])
                unit_total = float(item["invoice_line_total"] or 0) / float(item["invoiced_quantity"] or 1)
                product_name = item["product_name"]
            else:
                key = (int(item["product_id"]), int(item["warehouse_id"] or 0))
                sold = float(item["quantity"])
                available = sold - float(prior.get(key, 0.0))
                unit_total = float(item["total"]) / sold
                product_name = self.service_sales.get_product_name(
                    int(item["product_id"]), int(invoice["company_id"])
                )
            if available <= 0:
                continue
            ctk.CTkLabel(box, text=product_name or str(item["product_id"]), font=font(13),
                         text_color=c("text"), anchor=TEXT_ANCHOR).grid(row=r, column=col(0), padx=6, sticky="ew")
            ctk.CTkLabel(box, text=f"{sold:g}", font=font(13), text_color=c("text")).grid(row=r, column=col(1), padx=6)
            ctk.CTkLabel(box, text=f"{available:g}", font=font(13), text_color=c("text")).grid(row=r, column=col(2), padx=6)
            e = entry(box, "0", 90, justify="center")
            e.grid(row=r, column=col(3), padx=6, pady=2)
            self.rows.append((item, available, unit_total, e))
            r += 1

        if not self.rows:
            self.error.configure(text="كل بنود هذه الفاتورة مرتجعة بالفعل")

        acc_card = Card(self)
        acc_card.pack(fill="x", padx=20, pady=(10, 0))
        acc = ctk.CTkFrame(acc_card, fg_color="transparent")
        acc.pack(fill="x", padx=12, pady=10)
        names = [a["label"] for a in self.accounts]
        self.acc_widgets = {}
        specs = [("المبيعات", "sales"), ("المخزون", "inventory"),
                 ("التكلفة", "cogs"), ("الضريبة", "tax")]
        for i, (lab, key) in enumerate(specs):
            fr, cb = field(acc, lab, lambda p: combo(p, names, 200))
            cc = (2 - i % 3) if START == "right" else i % 3
            fr.grid(row=i // 3, column=cc, sticky="ew", padx=6, pady=3)
            self.acc_widgets[key] = cb
        _set_account_defaults(
            self.accounts, self.acc_widgets,
            SalesSettingsService().get_settings(context.current_company_id()),
        )
        for cc in range(3):
            acc.grid_columnconfigure(cc, weight=1, uniform="acc")

        self.error.pack(fill="x", padx=26, pady=(8, 0))
        self.footer([("ترحيل المرتجع", self.save, "primary"), ("إلغاء", self.destroy, "ghost")],
                    width=160)

    def save(self):
        try:
            items, total = [], 0.0
            for item, available, unit_total, e in self.rows:
                qty = float(e.get() or 0)
                if qty <= 0:
                    continue
                if qty > available:
                    raise SalesReturnError(f"الكمية المرتجعة تتجاوز المتاح للمنتج {item['product_id']}")
                line_total = round(unit_total * qty, 2)
                line = {"product_id": item["product_id"], "warehouse_id": item["warehouse_id"],
                        "quantity": qty, "total": line_total}
                if self.delivery:
                    line["delivery_item_id"] = int(item["delivery_item_id"])
                items.append(line)
                total += line_total
            if not items:
                self.error.configure(text="أدخل كمية مرتجعة واحدة على الأقل")
                return
            source_number = self.delivery["delivery_number"] if self.delivery else self.invoice["invoice_number"]
            number = f"R-{source_number}-{secrets.token_hex(2).upper()}"
            accounts = dict(
                company_id=context.current_company_id(), branch_id=context.current_branch_id(),
                return_number=number, return_date=date.today().isoformat(), notes="",
                created_by=context.current_user_id(),
                sales_account=_pick(self.accounts, self.acc_widgets["sales"]),
                receivable_account=CustomerService().ensure_customer_account(
                    int(self.invoice["company_id"]), int(self.invoice["customer_id"])
                ),
                inventory_account=_pick(self.accounts, self.acc_widgets["inventory"]),
                cogs_account=_pick(self.accounts, self.acc_widgets["cogs"]),
                tax_account=_pick(self.accounts, self.acc_widgets["tax"]),
            )
            if self.delivery:
                self.service.create_return_from_delivery(
                    sales_delivery_id=int(self.delivery["id"]),
                    items=[{"delivery_item_id": line["delivery_item_id"], "quantity": line["quantity"]}
                           for line in items],
                    **accounts,
                )
            else:
                self.service.create_return(
                    sales_invoice_id=self.invoice["id"], customer_id=self.invoice["customer_id"],
                    items=items, total=round(total, 2), **accounts,
                )
        except (ValueError, SalesReturnError, TransactionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        self.destroy()


class SalesPage(Page):

    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="المبيعات",
                         subtitle="ترحيل فواتير البيع مع تأثيرها المخزني والمحاسبي", user=user)
        self.service = SalesService()
        self.user_id = int((user or {}).get("id") or 0)
        permissions = PermissionService()
        self.can_create = permissions.has_permission(self.user_id, "sales.create")
        self.can_cancel = permissions.has_permission(self.user_id, "sales.cancel")
        self.can_return = permissions.has_permission(self.user_id, "sales.return")
        company_id = int((user or {}).get("company_id") or context.current_company_id())
        self.can_manage_settings = permissions.has_permission_for_company(
            self.user_id, company_id, "companies.manage"
        )
        self.can_update_delivery = permissions.has_permission_for_company(
            self.user_id, company_id, "sales.delivery.update"
        )

        if self.can_create:
            primary_button(self.actions, f"{icon('add')}  فاتورة بيع", self.add, width=140).pack(side="left", padx=4)
        if self.can_manage_settings:
            subtle_button(self.actions, "إعدادات المبيعات", self.open_settings, width=150).pack(
                side="left", padx=4
            )

        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        self.search = SearchBar(bar.row, "ابحث برقم الفاتورة أو اسم العميل...  (Ctrl+F)",
                                on_search=self.refresh, width=380)
        bar.add(self.search)
        self.count = Badge(bar.row, "", "info")
        bar.add(self.count, side=END, padx=8)

        self.table = DataTable(self.body, COLUMNS, empty_text="لا توجد فواتير مبيعات",
                               on_double=lambda _r: self.make_return())
        self.table.pack(fill="both", expand=True)

        foot = ctk.CTkFrame(self.body, fg_color="transparent")
        foot.pack(fill="x", pady=(10, 0))
        if self.can_return:
            subtle_button(foot, "↩  مرتجع", self.make_return).pack(side=START, padx=4)
        if self.can_cancel:
            danger_button(foot, "✕  إلغاء الفاتورة", self.cancel, width=140).pack(side=START, padx=4)
        if self.can_update_delivery:
            subtle_button(foot, "تحديث التسليم", self.update_delivery, width=140).pack(
                side=START, padx=4
            )
        Badge(foot, "الإلغاء يعكس القيد ويرجع المخزون ولا يحذف الفاتورة", "muted").pack(side=END)

        self.refresh()

    def refresh(self):
        kw = self.search.get().strip()
        rows = SalesService().list_for_company(context.current_company_id(), kw)
        self.table.set_rows(rows, {
            "total": lambda v: f"{(v or 0):,.2f}",
            "paid_amount": lambda v: f"{(v or 0):,.2f}",
            "remaining_amount": lambda v: f"{(v or 0):,.2f}",
            "delivery_status": _delivery_label,
        })
        self.count.set(f"{len(rows)} فاتورة")

    def _selected(self):
        row = self.table.selected
        if row is None:
            messagebox.showinfo("المبيعات", "اختر فاتورة من الجدول أولاً")
        return row

    def add(self):
        if not self.can_create:
            return
        SalesInvoiceDialog(self, self.user, self.refresh)

    def open_settings(self):
        if not self.can_manage_settings:
            return
        SalesSettingsDialog(
            self, context.current_company_id(), self.user_id, self.refresh,
        )

    def update_delivery(self):
        if not self.can_update_delivery:
            return
        row = self._selected()
        if row is None:
            return
        if str(row["status"]).upper() != "POSTED":
            messagebox.showwarning("التسليم", "يمكن تحديث تسليم الفواتير المرحلة فقط")
            return
        SalesDeliveryDialog(self, row, self.user_id, self.refresh)

    def cancel(self):
        if not self.can_cancel:
            return
        row = self._selected()
        if row is None:
            return
        if str(row["status"]).upper() != "POSTED":
            messagebox.showwarning("إلغاء", "يمكن إلغاء الفواتير المرحلة فقط")
            return
        if not messagebox.askyesno("إلغاء فاتورة", f"إلغاء الفاتورة {row['invoice_number']}؟ سيتم عكس القيد وإرجاع المخزون."):
            return
        try:
            self.service.cancel_invoice(row["id"], created_by=self.user["id"] if self.user is not None else 1)
        except (SalesError, TransactionError) as exc:
            messagebox.showerror("إلغاء فاتورة", str(exc))
            return
        toast(self, "تم إلغاء الفاتورة وعكس القيد", "warning")
        self.refresh()

    def make_return(self):
        if not self.can_return:
            return
        row = self._selected()
        if row is None:
            return
        if str(row["status"]).upper() != "POSTED":
            messagebox.showwarning("مرتجع", "يمكن إرجاع الفواتير المرحلة فقط")
            return
        SalesReturnDialog(self, self.user, row, self.refresh)
