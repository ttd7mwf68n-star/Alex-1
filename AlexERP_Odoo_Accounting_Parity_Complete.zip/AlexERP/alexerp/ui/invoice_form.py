"""
AlexERP — Business Management System
Shared invoice form used by sales and purchase screens.

The form only builds widgets and live totals; posting logic stays in each
screen's ``save()`` so the accounting behaviour is unchanged.
"""

from __future__ import annotations

from datetime import date

import customtkinter as ctk

from alexerp.ui.components import (
    Card, Dialog, ProductPicker, SectionHeader, combo, entry, field, icon_button,
    subtle_button,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font, icon


def _f(widget) -> float:
    return float(str(widget.get() or 0).replace(",", "") or 0)


class InvoiceDialogBase(Dialog):
    """Invoice editor: header fields, searchable item lines, accounts and totals."""

    ITEM_COLUMNS = (("المنتج", 0), ("الكمية", 80), ("السعر", 100), ("الضريبة", 80),
                    ("الإجمالي", 100), ("", 36))

    def __init__(self, parent, title, *, party_label, parties, products, warehouses, price_key,
                 price_caption, accounts, account_specs, subtitle="", glyph="🧾"):
        super().__init__(parent, title, 1000, 740, subtitle=subtitle, glyph=glyph,
                         resizable=True)
        self.minsize(900, 640)
        self.products = products
        self._warehouses = warehouses
        self.price_key = price_key
        self.item_rows = []
        names = [r["label"] for r in accounts]

        content = ctk.CTkFrame(self, fg_color="transparent")
        content.pack(fill="both", expand=True, padx=20, pady=(12, 0))
        self._content = content

        # ---- header fields ----
        head = Card(content)
        head.pack(fill="x")
        grid = ctk.CTkFrame(head, fg_color="transparent")
        grid.pack(fill="x", padx=12, pady=10)
        specs = [
            (party_label, lambda p: combo(p, [r["name"] for r in parties], 220), 3),
            ("المخزن", lambda p: combo(p, [r["name"] for r in self._warehouses], 160), 2),
            ("التاريخ", lambda p: entry(p, "YYYY-MM-DD", 130), 2),
            ("الخصم", lambda p: entry(p, "0", 110), 1),
            ("مدفوع الآن", lambda p: entry(p, "0", 110), 1),
        ]
        widgets = []
        for i, (caption, factory, weight) in enumerate(specs):
            fr, w = field(grid, caption, factory, required=i < 2)
            col = (len(specs) - 1 - i) if START == "right" else i
            fr.grid(row=0, column=col, sticky="ew", padx=6)
            grid.grid_columnconfigure(col, weight=weight)
            widgets.append(w)
        self.party, self.warehouse, self.invoice_date, self.discount, self.paid = widgets
        self.invoice_date.insert(0, date.today().isoformat())
        self.discount.insert(0, "0")
        self.paid.insert(0, "0")
        for w in (self.discount, self.paid):
            w.bind("<KeyRelease>", lambda _e: self._update_totals(), add="+")

        # ---- items ----
        items = Card(content)
        items.pack(fill="both", expand=True, pady=(10, 0))
        sh = SectionHeader(items, "البنود", "ابحث بالاسم أو الكود أو امسح الباركود ثم Enter", "📦")
        sh.pack(fill="x", padx=14, pady=(10, 4))
        subtle_button(sh.actions, f"{icon('add')}  إضافة بند", self.add_item_row,
                      width=120).pack(side=END)

        hdr = ctk.CTkFrame(items, fg_color=c("surface_alt"), corner_radius=8)
        hdr.pack(fill="x", padx=12, pady=(2, 2))
        hdr_in = ctk.CTkFrame(hdr, fg_color="transparent")
        hdr_in.pack(fill="x", padx=(28, 8) if START == "right" else (8, 28))
        for text, width in self.ITEM_COLUMNS:
            ctk.CTkLabel(hdr_in, text=text, width=width or 10, font=font(12, "bold"),
                         text_color=c("muted"), anchor=TEXT_ANCHOR if width == 0 else "center"
                         ).pack(side=START, padx=3, pady=6, fill="x", expand=width == 0)

        self.items_frame = ctk.CTkScrollableFrame(items, fg_color="transparent", height=150,
                                                  scrollbar_button_color=c("border"))
        self.items_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        # ---- accounts ----
        acc_card = Card(content)
        acc_card.pack(fill="x", pady=(10, 0), side="bottom", before=items)
        SectionHeader(acc_card, "الحسابات المحاسبية", "تُستخدم لإنشاء القيد تلقائياً", "📒"
                      ).pack(fill="x", padx=14, pady=(10, 2))
        acc = ctk.CTkFrame(acc_card, fg_color="transparent")
        acc.pack(fill="x", padx=12, pady=(0, 10))
        self.acc_widgets = {}
        per_row = 3
        for i, (lab, key) in enumerate(account_specs):
            fr, cb = field(acc, lab, lambda p: combo(p, names, 200))
            col = (per_row - 1 - i % per_row) if START == "right" else i % per_row
            fr.grid(row=i // per_row, column=col, sticky="ew", padx=6, pady=3)
            self.acc_widgets[key] = cb
        for col in range(per_row):
            acc.grid_columnconfigure(col, weight=1, uniform="acc")

        # ---- totals ----
        self.summary = ctk.CTkFrame(self, fg_color=c("primary_soft"), corner_radius=12)
        self.summary.pack(fill="x", padx=20, pady=(10, 0), side="bottom", before=content)
        self._sum_labels = {}
        for key, caption in (("sub", "قبل الخصم"), ("disc", "الخصم"), ("tax", "الضريبة"),
                             ("net", "الصافي"), ("rem", "المتبقي")):
            box = ctk.CTkFrame(self.summary, fg_color="transparent")
            box.pack(side=START, expand=True, fill="x", pady=8)
            ctk.CTkLabel(box, text=caption, font=font(11), text_color=c("muted")).pack()
            lbl = ctk.CTkLabel(box, text="0.00", font=font(16 if key == "net" else 14, "bold"),
                               text_color=c("primary") if key == "net" else c("text"))
            lbl.pack()
            self._sum_labels[key] = lbl
        # legacy text summary (kept for compatibility)
        self.totals = ctk.CTkLabel(self, text="", font=font(1))

        self.error.pack(fill="x", padx=26, pady=(6, 0), side="bottom", before=self.summary)
        self.add_item_row()

    def footer(self, buttons, width=130):
        """Footer pinned to the bottom so it stays visible on small screens."""
        return super().footer(buttons, width)

    # -------------------------------------------------

    def add_item_row(self):
        row = ctk.CTkFrame(self.items_frame, fg_color="transparent")
        row.pack(fill="x", pady=2)
        widths = [w for _t, w in self.ITEM_COLUMNS]
        qty = entry(row, "1", widths[1], justify="center")
        price = entry(row, "0.00", widths[2], justify="center")
        tax = entry(row, "0", widths[3], justify="center")
        tax.insert(0, "0")
        total = ctk.CTkLabel(row, text="0.00", width=widths[4], font=font(13, "bold"),
                             text_color=c("text"))

        def recalc(*_a):
            try:
                t = _f(qty) * _f(price) + _f(tax)
                total.configure(text=f"{t:,.2f}")
            except ValueError:
                total.configure(text="—")
            self._update_totals()

        def picked(product):
            try:
                value = float(product[self.price_key] or 0)
            except (KeyError, IndexError, TypeError, ValueError):
                value = 0.0
            price.delete(0, "end")
            price.insert(0, f"{value:g}")
            if not qty.get().strip():
                qty.insert(0, "1")
            recalc()
            qty.focus()
            qty.select_range(0, "end")

        cb = ProductPicker(row, self.products, on_pick=picked, width=260)
        cb.pack(side=START, padx=3, fill="x", expand=True)
        for w in (qty, price, tax):
            w.pack(side=START, padx=3)
            w.bind("<KeyRelease>", recalc, add="+")
        total.pack(side=START, padx=3)
        icon_button(row, "✕", lambda: self._remove_item(row), size=widths[5],
                    text_color=c("danger")).pack(side=START, padx=3)
        tax.bind("<Return>", lambda _e: self.add_item_row(), add="+")
        self.item_rows.append((row, cb, qty, price, tax))
        self.after(80, cb.focus)

    def _remove_item(self, row):
        if len(self.item_rows) > 1:
            self.item_rows = [r for r in self.item_rows if r[0] is not row]
            row.destroy()
            self._update_totals()

    def _update_totals(self):
        sub = tax = 0.0
        for _r, _cb, q, p, t in self.item_rows:
            try:
                sub += _f(q) * _f(p)
                tax += _f(t)
            except ValueError:
                continue
        try:
            disc = _f(self.discount)
        except ValueError:
            disc = 0.0
        try:
            paid = _f(self.paid)
        except ValueError:
            paid = 0.0
        net = sub - disc + tax
        for key, value in (("sub", sub), ("disc", disc), ("tax", tax), ("net", net),
                           ("rem", net - paid)):
            self._sum_labels[key].configure(text=f"{value:,.2f}")
        self.totals.configure(
            text=f"الإجمالي قبل الخصم: {sub:,.2f}   الضريبة: {tax:,.2f}   الصافي: {net:,.2f}")
