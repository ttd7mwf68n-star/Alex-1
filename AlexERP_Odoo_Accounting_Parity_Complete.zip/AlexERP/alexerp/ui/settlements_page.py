"""Desktop UI for allocating posted receipts/payments to posted invoices.

The page is company-scoped at query time and delegates every write to
InvoiceSettlementService, which repeats authorization and balance checks.
"""
from __future__ import annotations

import sqlite3
from datetime import date
from decimal import Decimal
from tkinter import messagebox

import customtkinter as ctk

from alexerp.core import context
from alexerp.database.db import Database
from alexerp.database.transaction import TransactionError
from alexerp.services.customer_financial_note_service import CustomerFinancialNoteService
from alexerp.services.invoice_settlement_service import InvoiceSettlementService
from alexerp.services.permission_service import PermissionService
from alexerp.services.sales_service import SalesService
from alexerp.ui.components import (
    Card, DataTable, Page, Tabs, Toolbar, combo, danger_button, entry, label,
    primary_button, ghost_button,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font


def _fmt(value):
    return f"{float(value or 0):,.2f}"


class SettlementsPage(Page):
    """Receipt/payment allocation workspace plus receivables/payables aging."""

    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="التسويات والتحصيلات",
                         subtitle="تخصيص سندات القبض والصرف على الفواتير ومتابعة المديونيات",
                         user=user, scroll=False)
        self.company_id = int((user or {}).get("company_id") or context.current_company_id())
        self.user_id = int((user or {}).get("id") or context.current_user_id())
        self.permissions = PermissionService()
        self.service = InvoiceSettlementService()
        self.note_service = CustomerFinancialNoteService()
        self.kind = "receipt"
        self.doc_rows = []
        self.invoice_rows = []
        self.doc_by_label = {}
        self.invoice_by_label = {}
        self._build()
        initial_tab = ("receipt" if self._can("receipts.view") else
                       "payment" if self._can("payments.view") else
                       "aging" if self._can("reports.view") else "statement")
        self._select_tab(initial_tab)

    def _can(self, key):
        try:
            return bool(self.permissions.has_permission(self.user_id, key))
        except Exception:
            return False

    def _build(self):
        self.tabs = Tabs(self.body, (("receipt", "تخصيص إيصالات العملاء"),
                                     ("payment", "تخصيص مدفوعات الموردين"),
                                     ("aging", "متابعة أعمار الديون"),
                                     ("statement", "كشوف الحساب وشروط السداد"),
                                     ("customer_notes", "إشعارات العميل")),
                         command=self._select_tab, current="receipt", width=190)
        self.tabs.pack(anchor=TEXT_ANCHOR, pady=(0, 12))
        self.host = ctk.CTkFrame(self.body, fg_color="transparent")
        self.host.pack(fill="both", expand=True)

    def _select_tab(self, key):
        self.kind = key
        for child in self.host.winfo_children():
            child.destroy()
        if key == "aging":
            self._build_aging()
        elif key == "statement":
            self._build_statement()
        elif key == "customer_notes":
            self._build_customer_notes()
        else:
            self._build_allocator()

    def _build_allocator(self):
        permission = "receipts.view" if self.kind == "receipt" else "payments.view"
        create_permission = "receipts.create" if self.kind == "receipt" else "payments.create"
        if not self._can(permission):
            label(self.host, "ليس لديك صلاحية عرض هذه المستندات.", tone="danger").pack(pady=30)
            return

        self.toolbar = Toolbar(self.host)
        self.toolbar.pack(fill="x", pady=(0, 10))
        self.toolbar.caption("سند القبض" if self.kind == "receipt" else "سند الصرف")
        self.document = combo(self.toolbar.row, ["جارٍ التحميل..."], 300,
                              command=lambda _v: self._load_invoices())
        self.toolbar.add(self.document)
        self.toolbar.caption("الفاتورة المفتوحة")
        self.invoice = combo(self.toolbar.row, ["اختر سنداً أولاً"], 300)
        self.toolbar.add(self.invoice)
        self.toolbar.caption("مبلغ التخصيص")
        self.amount = entry(self.toolbar.row, "0.00", 110)
        self.toolbar.add(self.amount)
        self.allocate_btn = primary_button(
            self.toolbar.row, "تخصيص المبلغ", self._allocate, width=125,
            state="normal" if self._can(create_permission) else "disabled")
        self.toolbar.add(self.allocate_btn, side=END)
        ghost_button(self.toolbar.row, "تحديث", self._load_documents, width=80).pack(side=END, padx=4)

        self.summary = Card(self.host)
        self.summary.pack(fill="x", pady=(0, 10))
        self.summary_text = label(self.summary, "اختر سنداً لعرض الرصيد المتاح والفواتير المفتوحة.")
        self.summary_text.pack(fill="x", padx=16, pady=12)

        self.alloc_host = ctk.CTkFrame(self.host, fg_color="transparent")
        self.alloc_host.pack(fill="both", expand=True)
        self._load_documents()

    def _load_documents(self):
        if not hasattr(self, "document") or not self.document.winfo_exists():
            return
        if self.kind == "receipt":
            sql = """SELECT r.id,r.receipt_number AS number,r.receipt_date AS doc_date,
                            r.customer_id AS party_id,c.name AS party_name,r.amount,
                            COALESCE(SUM(a.amount),0) AS allocated
                     FROM receipts r JOIN customers c ON c.id=r.customer_id
                     LEFT JOIN receipt_allocations a ON a.receipt_id=r.id AND a.status='ACTIVE'
                     WHERE r.company_id=? AND c.company_id=? AND UPPER(COALESCE(r.status,'POSTED'))='POSTED'
                     GROUP BY r.id HAVING CAST(r.amount AS REAL)-CAST(COALESCE(SUM(a.amount),0) AS REAL)>0.004
                     ORDER BY r.receipt_date DESC,r.id DESC"""
        else:
            sql = """SELECT p.id,p.payment_number AS number,p.payment_date AS doc_date,
                            p.supplier_id AS party_id,s.name AS party_name,p.amount,
                            COALESCE(SUM(a.amount),0) AS allocated
                     FROM payments p JOIN suppliers s ON s.id=p.supplier_id
                     LEFT JOIN payment_allocations a ON a.payment_id=p.id AND a.status='ACTIVE'
                     WHERE p.company_id=? AND s.company_id=? AND UPPER(COALESCE(p.status,'POSTED'))='POSTED'
                     GROUP BY p.id HAVING CAST(p.amount AS REAL)-CAST(COALESCE(SUM(a.amount),0) AS REAL)>0.004
                     ORDER BY p.payment_date DESC,p.id DESC"""
        self.doc_rows = [dict(r) for r in Database.connect().execute(sql, (self.company_id, self.company_id)).fetchall()]
        self.doc_by_label = {}
        values = []
        for row in self.doc_rows:
            available = Decimal(str(row["amount"] or 0)) - Decimal(str(row["allocated"] or 0))
            text = f"{row['number']} | {row['party_name']} | متاح {_fmt(available)}"
            self.doc_by_label[text] = row
            values.append(text)
        self.document.configure(values=values or ["لا توجد سندات غير مخصصة"])
        self.document.set(values[0] if values else "لا توجد سندات غير مخصصة")
        self._load_invoices()

    def _load_invoices(self, *_):
        if not hasattr(self, "document") or not self.document.winfo_exists():
            return
        doc = self.doc_by_label.get(self.document.get())
        if not doc:
            self.invoice_rows = []
            self.invoice_by_label = {}
            self.invoice.configure(values=["لا توجد فاتورة"])
            self.invoice.set("لا توجد فاتورة")
            self.summary_text.configure(text="لا توجد سندات متاحة للتخصيص.")
            self._show_allocations([])
            return
        if self.kind == "receipt":
            table, fk = "sales_invoices", "customer_id"
        else:
            table, fk = "purchase_invoices", "supplier_id"
        rows = Database.connect().execute(
            f"""SELECT id,invoice_number,invoice_date,due_date,total,paid_amount,remaining_amount
                FROM {table} WHERE company_id=? AND {fk}=?
                AND UPPER(COALESCE(status,''))='POSTED'
                AND CAST(COALESCE(remaining_amount,0) AS REAL)>0.004
                AND date(invoice_date)<=date(?) ORDER BY invoice_date,id""",
            (self.company_id, doc["party_id"], doc["doc_date"]),
        ).fetchall()
        self.invoice_rows = [dict(r) for r in rows]
        self.invoice_by_label = {}
        values = []
        for row in self.invoice_rows:
            text = f"{row['invoice_number']} | استحقاق {row.get('due_date') or row['invoice_date']} | متبقي {_fmt(row['remaining_amount'])}"
            self.invoice_by_label[text] = row
            values.append(text)
        self.invoice.configure(values=values or ["لا توجد فواتير مفتوحة"])
        self.invoice.set(values[0] if values else "لا توجد فواتير مفتوحة")
        available = Decimal(str(doc["amount"] or 0)) - Decimal(str(doc["allocated"] or 0))
        self.summary_text.configure(
            text=f"السند: {doc['number']}    الطرف: {doc['party_name']}    التاريخ: {doc['doc_date']}    "
                 f"قيمة السند: {_fmt(doc['amount'])}    المخصص: {_fmt(doc['allocated'])}    "
                 f"المتاح: {_fmt(available)}")
        self._show_allocations(doc["id"])

    def _show_allocations(self, document_id):
        for child in self.alloc_host.winfo_children():
            child.destroy()
        if not document_id:
            return
        if self.kind == "receipt":
            sql = """SELECT a.id,a.amount,a.created_at,a.status,i.invoice_number
                     FROM receipt_allocations a JOIN sales_invoices i ON i.id=a.sales_invoice_id
                     WHERE a.company_id=? AND a.receipt_id=? ORDER BY a.id DESC"""
        else:
            sql = """SELECT a.id,a.amount,a.created_at,a.status,i.invoice_number
                     FROM payment_allocations a JOIN purchase_invoices i ON i.id=a.purchase_invoice_id
                     WHERE a.company_id=? AND a.payment_id=? ORDER BY a.id DESC"""
        rows = [dict(r) for r in Database.connect().execute(sql, (self.company_id, document_id)).fetchall()]
        card = Card(self.alloc_host)
        card.pack(fill="both", expand=True)
        label(card, "سجل التخصيصات", size=15, weight="bold").pack(anchor=TEXT_ANCHOR, padx=14, pady=(12, 4))
        table = DataTable(card, [("invoice_number", "رقم الفاتورة", 220, "w"),
                                 ("amount", "المبلغ", 130, "e"),
                                 ("created_at", "تاريخ العملية", 180, "w"),
                                 ("status", "الحالة", 100, "w")])
        table.pack(fill="both", expand=True, padx=8, pady=8)
        table.set_rows(rows, formatters={"amount": _fmt})

    def _allocate(self):
        if not self._can("receipts.create" if self.kind == "receipt" else "payments.create"):
            messagebox.showerror("الصلاحيات", "ليس لديك صلاحية تنفيذ التخصيص.", parent=self.winfo_toplevel())
            return
        doc = self.doc_by_label.get(self.document.get())
        invoice = self.invoice_by_label.get(self.invoice.get())
        if not doc or not invoice:
            messagebox.showwarning("بيانات ناقصة", "اختر سنداً وفاتورة مفتوحة أولاً.", parent=self.winfo_toplevel())
            return
        try:
            if self.kind == "receipt":
                allocation_id = self.service.allocate_receipt(
                    int(doc["id"]), int(invoice["id"]), self.amount.get().strip(), self.user_id)
            else:
                allocation_id = self.service.allocate_payment(
                    int(doc["id"]), int(invoice["id"]), self.amount.get().strip(), self.user_id)
        except Exception as exc:
            messagebox.showerror("تعذر التخصيص", str(exc), parent=self.winfo_toplevel())
            return
        messagebox.showinfo("تم التخصيص", f"تم حفظ التخصيص رقم {allocation_id} بنجاح.", parent=self.winfo_toplevel())
        self.amount.delete(0, "end")
        self._load_documents()

    def _build_aging(self):
        if not (self._can("reports.view") or self._can("receipts.view") or self._can("payments.view")):
            label(self.host, "ليس لديك صلاحية عرض تقارير المديونيات.", tone="danger").pack(pady=30)
            return
        bar = Toolbar(self.host)
        bar.pack(fill="x", pady=(0, 10))
        bar.caption("حتى تاريخ")
        self.as_of = entry(bar.row, "YYYY-MM-DD", 130)
        self.as_of.insert(0, date.today().isoformat())
        bar.add(self.as_of)
        primary_button(bar.row, "تحديث المديونيات", self._refresh_aging, width=145).pack(side=END, padx=4)
        self.aging_summary = Card(self.host)
        self.aging_summary.pack(fill="x", pady=(0, 10))
        self.aging_summary_text = label(self.aging_summary, "", wraplength=1100)
        self.aging_summary_text.pack(fill="x", padx=16, pady=12)
        self.aging_table_host = ctk.CTkFrame(self.host, fg_color="transparent")
        self.aging_table_host.pack(fill="both", expand=True)
        self._refresh_aging()

    def _refresh_aging(self):
        try:
            cutoff = self.as_of.get().strip()
            customer = self.service.customer_aging(self.company_id, cutoff)
            supplier = self.service.supplier_aging(self.company_id, cutoff)
            ctotal = customer["totals"]["total"]
            stotal = supplier["totals"]["total"]
            overdue_c = sum(customer["totals"][k] for k in ("days_31_60", "days_61_90", "over_90"))
            overdue_s = sum(supplier["totals"][k] for k in ("days_31_60", "days_61_90", "over_90"))
            self.aging_summary_text.configure(
                text=f"إجمالي مديونية العملاء: {_fmt(ctotal)}    المتأخر منها: {_fmt(overdue_c)}     |     "
                     f"إجمالي مستحقات الموردين: {_fmt(stotal)}    المتأخر منها: {_fmt(overdue_s)}\n"
                     "التأخير محسوب من تاريخ الاستحقاق المحفوظ، والفواتير القديمة تستخدم تاريخ الفاتورة كبديل.")
            rows = []
            for title, report in (("عميل", customer), ("مورد", supplier)):
                for item in report["rows"]:
                    rows.append({"party_type": title, "party": item["party_name"],
                                 "invoice": item["invoice_number"], "date": item["invoice_date"],
                                 "due_date": item.get("due_date", item["invoice_date"]),
                                 "age": item["age_days"], "bucket": item["bucket"],
                                 "remaining": _fmt(item["remaining_amount"])})
            rows.sort(key=lambda r: int(r["age"]), reverse=True)
            for child in self.aging_table_host.winfo_children():
                child.destroy()
            table = DataTable(self.aging_table_host,
                              [("party_type", "النوع", 70, "w"), ("party", "العميل / المورد", 190, "w"),
                               ("invoice", "الفاتورة", 120, "w"), ("date", "التاريخ", 100, "w"),
                               ("due_date", "الاستحقاق", 100, "w"), ("age", "أيام التأخير", 80, "e"),
                               ("bucket", "الشريحة", 110, "w"),
                               ("remaining", "المتبقي", 120, "e")],
                              empty_text="لا توجد فواتير مفتوحة حتى التاريخ المحدد")
            table.pack(fill="both", expand=True)
            table.set_rows(rows)
        except Exception as exc:
            messagebox.showerror("تعذر تحميل المديونيات", str(exc), parent=self.winfo_toplevel())

    def _build_statement(self):
        if not (self._can("reports.view") or self._can("customers.view") or self._can("suppliers.view")):
            label(self.host, "ليس لديك صلاحية عرض كشوف الحساب.", tone="danger").pack(pady=30)
            return
        bar = Toolbar(self.host)
        bar.pack(fill="x", pady=(0, 10))
        bar.caption("نوع الطرف")
        self.statement_party_type = combo(bar.row, ["عميل", "مورد"], 105,
                                          command=lambda _v: self._load_statement_parties())
        self.statement_party_type.set("عميل")
        bar.add(self.statement_party_type)
        bar.caption("الطرف")
        self.statement_party = combo(bar.row, ["جارٍ التحميل..."], 245,
                                     command=lambda _v: self._sync_statement_terms())
        bar.add(self.statement_party)
        bar.caption("من تاريخ")
        self.statement_from = entry(bar.row, "YYYY-MM-DD", 112)
        bar.add(self.statement_from)
        bar.caption("إلى تاريخ")
        self.statement_to = entry(bar.row, "YYYY-MM-DD", 112)
        self.statement_to.insert(0, date.today().isoformat())
        bar.add(self.statement_to)
        primary_button(bar.row, "عرض كشف الحساب", self._refresh_statement, width=135).pack(side=END, padx=4)

        terms_bar = Toolbar(self.host)
        terms_bar.pack(fill="x", pady=(0, 10))
        terms_bar.caption("شروط السداد الافتراضية (أيام)")
        self.statement_terms = entry(terms_bar.row, "0", 90)
        terms_bar.add(self.statement_terms)
        self.terms_save_button = primary_button(
            terms_bar.row, "حفظ شروط السداد", self._save_statement_terms, width=145,
            state="normal" if self._can("parties.payment_terms.manage") else "disabled")
        terms_bar.add(self.terms_save_button, side=END)
        self.statement_summary = Card(self.host)
        self.statement_summary.pack(fill="x", pady=(0, 10))
        self.statement_summary_text = label(self.statement_summary, "اختر العميل أو المورد ثم اعرض كشف الحساب.", wraplength=1100)
        self.statement_summary_text.pack(fill="x", padx=16, pady=12)
        self.statement_table_host = ctk.CTkFrame(self.host, fg_color="transparent")
        self.statement_table_host.pack(fill="both", expand=True)
        self.statement_party_rows = []
        self.statement_party_map = {}
        self._load_statement_parties()

    def _load_statement_parties(self):
        if not hasattr(self, "statement_party") or not self.statement_party.winfo_exists():
            return
        is_customer = self.statement_party_type.get() == "عميل"
        permission = "customers.view" if is_customer else "suppliers.view"
        if not (self._can("reports.view") or self._can(permission)):
            self.statement_party.configure(values=["لا توجد صلاحية"])
            self.statement_party.set("لا توجد صلاحية")
            return
        table = "customers" if is_customer else "suppliers"
        rows = Database.connect().execute(
            f"SELECT id,code,name,payment_terms_days FROM {table} WHERE company_id=? AND COALESCE(is_active,1)=1 ORDER BY name",
            (self.company_id,),
        ).fetchall()
        self.statement_party_rows = [dict(row) for row in rows]
        self.statement_party_map = {}
        self.statement_terms.delete(0, "end")
        values = []
        for row in self.statement_party_rows:
            text = f"{row['code']} | {row['name']}"
            self.statement_party_map[text] = row
            values.append(text)
        self.statement_party.configure(values=values or ["لا توجد أطراف مسجلة"])
        self.statement_party.set(values[0] if values else "لا توجد أطراف مسجلة")
        if rows:
            self.statement_terms.delete(0, "end")
            self.statement_terms.insert(0, str(rows[0]["payment_terms_days"] or 0))

    def _sync_statement_terms(self):
        party = self.statement_party_map.get(self.statement_party.get())
        if not party or not hasattr(self, "statement_terms"):
            return
        self.statement_terms.delete(0, "end")
        self.statement_terms.insert(0, str(party.get("payment_terms_days") or 0))

    def _save_statement_terms(self):
        if not self._can("parties.payment_terms.manage"):
            messagebox.showerror("الصلاحيات", "ليس لديك صلاحية تعديل شروط السداد.", parent=self.winfo_toplevel())
            return
        party = self.statement_party_map.get(self.statement_party.get())
        if not party:
            messagebox.showwarning("بيانات ناقصة", "اختر عميلاً أو مورداً أولاً.", parent=self.winfo_toplevel())
            return
        kind = "customer" if self.statement_party_type.get() == "عميل" else "supplier"
        try:
            self.service.set_payment_terms(kind, self.company_id, int(party["id"]),
                                           self.statement_terms.get().strip(), self.user_id)
        except Exception as exc:
            messagebox.showerror("تعذر حفظ شروط السداد", str(exc), parent=self.winfo_toplevel())
            return
        messagebox.showinfo("تم الحفظ", "تم تحديث شروط السداد الافتراضية. لن تتغير شروط الفواتير السابقة.",
                            parent=self.winfo_toplevel())
        self._load_statement_parties()

    def _refresh_statement(self):
        party = self.statement_party_map.get(self.statement_party.get())
        if not party:
            messagebox.showwarning("اختيار الطرف", "اختر عميلاً أو مورداً.", parent=self.winfo_toplevel())
            return
        kind = "customer" if self.statement_party_type.get() == "عميل" else "supplier"
        view_permission = "customers.view" if kind == "customer" else "suppliers.view"
        if not (self._can("reports.view") or self._can(view_permission)):
            messagebox.showerror("الصلاحيات", "ليس لديك صلاحية عرض هذا الكشف.", parent=self.winfo_toplevel())
            return
        try:
            date_from = self.statement_from.get().strip() or None
            date_to = self.statement_to.get().strip() or date.today().isoformat()
            if kind == "customer":
                report = self.service.customer_statement(self.company_id, int(party["id"]), date_from, date_to)
            else:
                report = self.service.supplier_statement(self.company_id, int(party["id"]), date_from, date_to)
        except Exception as exc:
            messagebox.showerror("تعذر إنشاء كشف الحساب", str(exc), parent=self.winfo_toplevel())
            return
        side = "رصيد مدين على العميل" if kind == "customer" else "الرصيد (مدين ناقص دائن؛ السالب مستحق للمورد)"
        self.statement_summary_text.configure(
            text=f"{report['party_name']} ({report['party_code']})   |   شروط السداد: {report['payment_terms_days']} يوم   |   "
                 f"رصيد أول المدة: {_fmt(report['opening_balance'])}   |   {side}: {_fmt(report['closing_balance'])}   |   "
                 f"عدد الحركات: {len(report['rows'])}")
        for child in self.statement_table_host.winfo_children():
            child.destroy()
        table = DataTable(
            self.statement_table_host,
            [("date", "التاريخ", 100, "w"), ("type", "نوع الحركة", 130, "w"),
             ("reference", "رقم المستند", 130, "w"), ("description", "البيان", 220, "w"),
             ("due_date", "الاستحقاق", 100, "w"), ("debit", "مدين", 110, "e"),
             ("credit", "دائن", 110, "e"), ("balance", "الرصيد", 120, "e")],
            empty_text="لا توجد حركات خلال الفترة المحددة")
        table.pack(fill="both", expand=True)
        table.set_rows(report["rows"], formatters={"debit": _fmt, "credit": _fmt, "balance": _fmt})

    def _build_customer_notes(self):
        can_view = self._can("customers.notes.view")
        can_create = self._can("customers.notes.create")
        if not can_view and not can_create:
            label(self.host, "ليس لديك صلاحية عرض أو إنشاء إشعارات العملاء.",
                  tone="danger").pack(pady=30)
            return

        if can_create:
            self.note_customers = [
                dict(row) for row in Database.connect().execute(
                    """SELECT id,code,name FROM customers
                       WHERE company_id=? AND COALESCE(is_active,1)=1 ORDER BY name""",
                    (self.company_id,),
                ).fetchall()
            ]
            self.note_customer_map = {}
            customer_values = []
            for row in self.note_customers:
                text = f"{row['code']} | {row['name']}"
                self.note_customer_map[text] = row
                customer_values.append(text)

            form = Card(self.host)
            form.pack(fill="x", pady=(0, 10))
            first = Toolbar(form)
            first.pack(fill="x", padx=8, pady=(8, 2))
            first.caption("العميل")
            self.note_customer = combo(
                first.row, customer_values or ["لا يوجد عملاء"], 220,
                command=lambda _value: self._load_note_invoices(),
            )
            first.add(self.note_customer)
            if customer_values:
                self.note_customer.set(customer_values[0])
            first.caption("الفاتورة المرتبطة")
            self.note_invoice = combo(first.row, ["اختر عميلاً أولاً"], 290)
            first.add(self.note_invoice)
            first.caption("نوع الإشعار")
            self.note_type = combo(
                first.row, ["إشعار مدين", "إشعار دائن"], 130,
            )
            self.note_type.set("إشعار مدين")
            first.add(self.note_type)
            first.caption("التاريخ")
            self.note_date = entry(first.row, date.today().isoformat(), 125)
            self.note_date.insert(0, date.today().isoformat())
            first.add(self.note_date)

            second = Toolbar(form)
            second.pack(fill="x", padx=8, pady=(2, 8))
            second.caption("المبلغ")
            self.note_amount = entry(second.row, "0.00", 110)
            second.add(self.note_amount)
            second.caption("الحساب المقابل")
            account_rows = Database.connect().execute(
                """SELECT id,account_code || ' - ' || account_name AS label
                   FROM chart_of_accounts
                   WHERE company_id=? AND COALESCE(is_active,1)=1 AND account_code<>'1201'
                     AND COALESCE(is_header,0)=0 AND COALESCE(allow_posting,1)=1
                     AND id NOT IN (SELECT account_id FROM customers WHERE company_id=? AND account_id IS NOT NULL)
                     AND id<>COALESCE((SELECT receivable_account_id FROM company_sales_settings
                                       WHERE company_id=?),-1)
                   ORDER BY account_code""",
                (self.company_id, self.company_id, self.company_id),
            ).fetchall()
            self.note_account_map = {row["label"]: int(row["id"]) for row in account_rows}
            self.note_account = combo(
                second.row, list(self.note_account_map) or ["لا توجد حسابات مقابلة"], 240,
            )
            if self.note_account_map:
                self.note_account.set(next(iter(self.note_account_map)))
            second.add(self.note_account)
            second.caption("البيان")
            self.note_description = entry(second.row, "سبب الإشعار", 250)
            second.add(self.note_description)
            primary_button(second.row, "ترحيل الإشعار", self._create_customer_note,
                           width=130).pack(side=END, padx=4)
            self._load_note_invoices()

        if can_view:
            self.note_table_host = ctk.CTkFrame(self.host, fg_color="transparent")
            self.note_table_host.pack(fill="both", expand=True)
            self._refresh_customer_notes()

    def _load_note_invoices(self):
        if not hasattr(self, "note_invoice") or not self.note_invoice.winfo_exists():
            return
        customer = self.note_customer_map.get(self.note_customer.get())
        if customer is None:
            self.note_invoice_map = {}
            self.note_invoice.configure(values=["لا توجد فواتير"])
            self.note_invoice.set("لا توجد فواتير")
            return
        rows = Database.connect().execute(
            """SELECT id,invoice_number,invoice_date,due_date,remaining_amount
               FROM sales_invoices
               WHERE company_id=? AND customer_id=? AND UPPER(COALESCE(status,''))='POSTED'
                 AND CAST(COALESCE(remaining_amount,0) AS REAL)>0.004
               ORDER BY invoice_date DESC,id DESC""",
            (self.company_id, customer["id"]),
        ).fetchall()
        self.note_invoice_map = {}
        values = []
        for row in rows:
            text = (f"{row['invoice_number']} | متبقي {_fmt(row['remaining_amount'])} | "
                    f"استحقاق {row['due_date'] or row['invoice_date']}")
            self.note_invoice_map[text] = dict(row)
            values.append(text)
        self.note_invoice.configure(values=values or ["لا توجد فواتير مفتوحة"])
        self.note_invoice.set(values[0] if values else "لا توجد فواتير مفتوحة")

    def _create_customer_note(self):
        if not self._can("customers.notes.create"):
            messagebox.showerror("الصلاحيات", "ليس لديك صلاحية إنشاء إشعار عميل.",
                                 parent=self.winfo_toplevel())
            return
        customer = self.note_customer_map.get(self.note_customer.get())
        invoice = self.note_invoice_map.get(self.note_invoice.get())
        account_id = self.note_account_map.get(self.note_account.get())
        if not customer or not invoice or account_id is None:
            messagebox.showwarning("بيانات ناقصة", "اختر العميل والفاتورة والحساب المقابل.",
                                   parent=self.winfo_toplevel())
            return
        try:
            amount = float(self.note_amount.get().strip().replace(",", ""))
            kind = "DEBIT" if self.note_type.get() == "إشعار مدين" else "CREDIT"
            override = False
            if kind == "DEBIT":
                credit = SalesService().credit_limit_status(
                    self.company_id, int(customer["id"]), float(amount), self.user_id
                )
                if credit["exceeded"]:
                    if not credit["can_override"]:
                        raise ValueError(
                            f"سيؤدي الإشعار إلى تجاوز حد الائتمان "
                            f"({credit['projected_balance']:.2f} من {credit['limit']:.2f})."
                        )
                    override = messagebox.askyesno(
                        "تأكيد تجاوز حد الائتمان",
                        (f"الرصيد المتوقع للعميل {credit['projected_balance']:.2f} "
                         f"ويتجاوز الحد {credit['limit']:.2f}. هل تريد المتابعة؟"),
                        parent=self.winfo_toplevel(),
                    )
                    if not override:
                        return
            next_id = Database.connect().execute(
                "SELECT COALESCE(MAX(id),0)+1 FROM customer_financial_notes WHERE company_id=?",
                (self.company_id,),
            ).fetchone()[0]
            prefix = "DN" if kind == "DEBIT" else "CN"
            note_number = f"{prefix}-{self.company_id}-{date.today():%Y%m%d}-{int(next_id):06d}"
            self.note_service.create_note(
                company_id=self.company_id,
                branch_id=int(context.current_branch_id()),
                customer_id=int(customer["id"]),
                sales_invoice_id=int(invoice["id"]),
                note_number=note_number,
                note_type=kind,
                note_date=self.note_date.get().strip(),
                amount=self.note_amount.get().strip().replace(",", ""),
                counter_account_id=account_id,
                description=self.note_description.get().strip(),
                created_by=self.user_id,
                override_credit_limit=bool(override),
            )
        except (ValueError, PermissionError, TransactionError, sqlite3.IntegrityError) as exc:
            messagebox.showerror("تعذر ترحيل الإشعار", str(exc),
                                 parent=self.winfo_toplevel())
            return
        messagebox.showinfo("تم الترحيل", f"تم ترحيل الإشعار {note_number}.",
                            parent=self.winfo_toplevel())
        self.note_amount.delete(0, "end")
        self.note_description.delete(0, "end")
        if self._can("customers.notes.view"):
            self._refresh_customer_notes()
        self._load_note_invoices()

    def _refresh_customer_notes(self):
        rows = self.note_service.list_notes(self.company_id, self.user_id)
        for child in self.note_table_host.winfo_children():
            child.destroy()
        table = DataTable(
            self.note_table_host,
            [("note_number", "رقم الإشعار", 175, "w"),
             ("note_type", "النوع", 95, "w"),
             ("note_date", "التاريخ", 100, "w"),
             ("customer_name", "العميل", 190, "w"),
             ("invoice_number", "الفاتورة", 135, "w"),
             ("amount", "المبلغ", 115, "e"),
             ("status", "الحالة", 100, "w")],
            empty_text="لا توجد إشعارات مالية للعملاء",
        )
        table.pack(fill="both", expand=True)
        table.set_rows(
            rows,
            formatters={
                "note_type": lambda value: "مدين" if value == "DEBIT" else "دائن",
                "amount": _fmt,
            },
        )
        self.note_table = table
        if self._can("customers.notes.cancel"):
            foot = ctk.CTkFrame(self.note_table_host, fg_color="transparent")
            foot.pack(fill="x", pady=(8, 0))
            danger_button(foot, "إلغاء الإشعار المحدد", self._cancel_customer_note,
                          width=150).pack(side=START, padx=6)

    def _cancel_customer_note(self):
        if not self._can("customers.notes.cancel"):
            messagebox.showerror("الصلاحيات", "ليس لديك صلاحية إلغاء الإشعار.",
                                 parent=self.winfo_toplevel())
            return
        note = self.note_table.selected
        if note is None:
            messagebox.showinfo("إلغاء إشعار", "اختر إشعاراً من الجدول أولاً.",
                                parent=self.winfo_toplevel())
            return
        if str(note["status"]).upper() != "POSTED":
            messagebox.showinfo("إلغاء إشعار", "الإشعار المحدد غير مرحل.",
                                parent=self.winfo_toplevel())
            return
        if not messagebox.askyesno(
            "إلغاء إشعار", f"إلغاء الإشعار «{note['note_number']}»؟",
            parent=self.winfo_toplevel(),
        ):
            return
        try:
            self.note_service.cancel_note(int(note["id"]), self.user_id)
        except Exception as exc:
            messagebox.showerror("تعذر إلغاء الإشعار", str(exc),
                                 parent=self.winfo_toplevel())
            return
        self._refresh_customer_notes()

