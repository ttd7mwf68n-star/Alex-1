"""Financial reports UI with branded CSV, Excel and PDF export."""
from __future__ import annotations

from datetime import date
from tkinter import filedialog, messagebox

import customtkinter as ctk

from alexerp.database.db import Database
from alexerp.services.trial_balance_service import TrialBalanceService
from alexerp.services.general_ledger_service import GeneralLedgerService
from alexerp.services.balance_sheet_service import BalanceSheetService
from alexerp.services.profit_loss_service import ProfitLossService
from alexerp.services.invoice_settlement_service import InvoiceSettlementService
from alexerp.exports.financial_report_exporter import export_csv, export_xlsx, export_pdf
from alexerp.ui.components import (
    Card, DataTable, Page, Tabs, Toolbar, combo, entry, ghost_button, primary_button,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font, icon


def _money(value):
    return f"{float(value or 0):,.2f}"


class ReportsPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="التقارير المالية",
                         subtitle="ميزان المراجعة، الأستاذ العام، قائمة الدخل، والميزانية العمومية",
                         user=user)
        self.company_id = int((user or {}).get("company_id") or 0)
        self.accounts = self._load_accounts()
        self.account_by_label = {f"{r['account_code']} - {r['account_name']}": int(r["id"]) for r in self.accounts}
        self.export_columns = []
        self.export_rows = []
        self._build_filters()
        self.account.configure(state="disabled")
        self._build_tabs()
        self._build_content()
        self.load_report()

    def _load_accounts(self):
        if not self.company_id:
            return []
        rows = Database.connect().execute(
            "SELECT id, account_code, account_name FROM chart_of_accounts "
            "WHERE company_id=? AND COALESCE(is_active,1)=1 AND COALESCE(allow_posting,1)=1 "
            "ORDER BY account_code", (self.company_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def _build_filters(self):
        self.tab = "trial"
        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        bar.caption("من تاريخ")
        self.date_from = entry(bar.row, "YYYY-MM-DD", 112)
        self.date_from.insert(0, f"{date.today().year}-01-01")
        bar.add(self.date_from)
        bar.caption("إلى تاريخ")
        self.date_to = entry(bar.row, "YYYY-MM-DD", 112)
        self.date_to.insert(0, date.today().isoformat())
        bar.add(self.date_to)
        self.account_caption = bar.caption("الحساب")
        self.account = combo(bar.row, list(self.account_by_label) or ["لا توجد حسابات"], 210)
        if self.account_by_label:
            self.account.set(next(iter(self.account_by_label)))
        bar.add(self.account)
        primary_button(bar.row, f"{icon('reports')}  عرض", self.load_report, width=95).pack(side=END, padx=3)
        ghost_button(bar.row, "Excel", lambda: self._export("xlsx"), width=72).pack(side=END, padx=3)
        ghost_button(bar.row, "PDF", lambda: self._export("pdf"), width=65).pack(side=END, padx=3)
        ghost_button(bar.row, "CSV", lambda: self._export("csv"), width=65).pack(side=END, padx=3)

    def _build_tabs(self):
        self.tabs = Tabs(self.body, (("trial", "ميزان المراجعة"), ("ledger", "الأستاذ العام"),
                                    ("pnl", "قائمة الدخل"), ("balance", "الميزانية العمومية"),
                                    ("customer_aging", "أعمار ديون العملاء"),
                                    ("supplier_aging", "أعمار ديون الموردين")),
                         command=self._select_tab, current="trial", width=145)
        self.tabs.pack(anchor=TEXT_ANCHOR, pady=(0, 10))

    def _build_content(self):
        self.summary = Card(self.body)
        self.summary.pack(fill="x", pady=(0, 8))
        self.summary_label = ctk.CTkLabel(self.summary, text="", font=font(13, "bold"),
                                          text_color=c("text"), anchor=TEXT_ANCHOR, justify="right",
                                          wraplength=1100)
        self.summary_label.pack(fill="x", padx=16, pady=12)
        self.table_host = ctk.CTkFrame(self.body, fg_color="transparent")
        self.table_host.pack(fill="both", expand=True)
        self.table = None

    def _select_tab(self, key):
        self.tab = key
        self.account.configure(state="normal" if key == "ledger" else "disabled")
        self.load_report()

    def _show_table(self, columns, rows, empty="لا توجد بيانات للفترة المحددة"):
        self.export_columns = list(columns)
        self.export_rows = [dict(row) for row in rows]
        for child in self.table_host.winfo_children():
            child.destroy()
        self.table = DataTable(self.table_host, columns, empty_text=empty)
        self.table.pack(fill="both", expand=True)
        self.table.set_rows(rows)

    def _export(self, kind):
        if not self.export_columns:
            messagebox.showinfo("التصدير", "اعرض تقريرًا أولًا قبل التصدير.", parent=self.winfo_toplevel())
            return
        extensions = {"xlsx": ("Excel Workbook", "*.xlsx"), "pdf": ("PDF", "*.pdf"), "csv": ("CSV", "*.csv")}
        label, pattern = extensions[kind]
        path = filedialog.asksaveasfilename(
            parent=self.winfo_toplevel(), title=f"تصدير {label}",
            defaultextension=f".{kind}", filetypes=[(label, pattern), ("All files", "*.*")]
        )
        if not path:
            return
        title = {
            "trial": "ميزان المراجعة", "ledger": "الأستاذ العام",
            "pnl": "قائمة الدخل", "balance": "الميزانية العمومية",
            "customer_aging": "أعمار ديون العملاء", "supplier_aging": "أعمار ديون الموردين",
        }.get(self.tab, "تقرير مالي")
        try:
            exporter = {"xlsx": export_xlsx, "pdf": export_pdf, "csv": export_csv}[kind]
            exporter(path, title, self.date_from.get().strip(), self.date_to.get().strip(),
                     self.export_columns, self.export_rows)
            messagebox.showinfo("تم التصدير", f"تم حفظ التقرير بنجاح:\n{path}", parent=self.winfo_toplevel())
        except Exception as exc:
            messagebox.showerror("تعذر التصدير", str(exc), parent=self.winfo_toplevel())

    def load_report(self):
        try:
            start, end = self.date_from.get().strip(), self.date_to.get().strip()
            if self.tab == "trial":
                report = TrialBalanceService().get_report(self.company_id, start, end)
                self.summary_label.configure(text=(
                    f"افتتاحي مدين: {_money(report['opening_debit'])} | افتتاحي دائن: {_money(report['opening_credit'])}     "
                    f"ختامي مدين: {_money(report['closing_debit'])} | ختامي دائن: {_money(report['closing_credit'])}     "
                    f"{'متزن ✓' if report['balanced'] else 'غير متزن'}"))
                rows = [{"code": r["code"], "name": r["name"],
                         "opening": _money(r["opening_debit"] - r["opening_credit"]),
                         "debit": _money(r["period_debit"]), "credit": _money(r["period_credit"]),
                         "closing_debit": _money(r["closing_debit"]), "closing_credit": _money(r["closing_credit"])} for r in report["rows"]]
                self._show_table([("code", "الكود", 90, "w"), ("name", "الحساب", 190, "w"),
                                  ("opening", "رصيد أول المدة", 120, "e"), ("debit", "مدين الفترة", 110, "e"),
                                  ("credit", "دائن الفترة", 110, "e"), ("closing_debit", "ختامي مدين", 110, "e"),
                                  ("closing_credit", "ختامي دائن", 110, "e")], rows)
            elif self.tab == "ledger":
                account_id = self.account_by_label.get(self.account.get())
                if not account_id:
                    raise ValueError("اختر حسابًا صحيحًا لعرض الأستاذ العام")
                report = GeneralLedgerService().get_report(self.company_id, account_id, start, end)
                self.summary_label.configure(text=f"رصيد أول المدة: {_money(report['opening_balance'])} | رصيد آخر المدة: {_money(report['closing_balance'])}")
                rows = [{"date": r["entry_date"], "number": r["entry_number"], "description": r["description"] or r["line_description"] or "",
                         "debit": _money(r["debit"]), "credit": _money(r["credit"]), "balance": _money(r["balance"])} for r in report["rows"]]
                self._show_table([("date", "التاريخ", 100, "w"), ("number", "رقم القيد", 110, "w"),
                                  ("description", "البيان", 230, "w"), ("debit", "مدين", 110, "e"),
                                  ("credit", "دائن", 110, "e"), ("balance", "الرصيد", 120, "e")], rows)
            elif self.tab == "pnl":
                report = ProfitLossService().get_report(self.company_id, start, end)
                self.summary_label.configure(text=(
                    f"إجمالي الإيرادات: {_money(report['total_revenue'])} | "
                    f"إجمالي المصروفات: {_money(report['total_expenses'])} | "
                    f"صافي {'الربح' if report['is_profitable'] else 'الخسارة'}: {_money(abs(report['net_profit']))}"))
                rows = []
                rows.extend({"group": "الإيرادات", "code": r["code"], "name": r["name"], "amount": _money(r["amount"])} for r in report["revenue"])
                rows.append({"group": "إجمالي الإيرادات", "code": "", "name": "", "amount": _money(report["total_revenue"])})
                rows.extend({"group": "المصروفات", "code": r["code"], "name": r["name"], "amount": _money(r["amount"])} for r in report["expenses"])
                rows.append({"group": "إجمالي المصروفات", "code": "", "name": "", "amount": _money(report["total_expenses"])})
                rows.append({"group": "صافي النتيجة", "code": "", "name": "ربح موجب / خسارة سالبة", "amount": _money(report["net_profit"])})
                self._show_table([("group", "البند", 150, "w"), ("code", "الكود", 100, "w"),
                                  ("name", "الحساب", 330, "w"), ("amount", "القيمة", 150, "e")], rows)
            elif self.tab in ("customer_aging", "supplier_aging"):
                settlement = InvoiceSettlementService()
                if self.tab == "customer_aging":
                    report = settlement.customer_aging(self.company_id, end)
                    party_label = "العميل"
                else:
                    report = settlement.supplier_aging(self.company_id, end)
                    party_label = "المورد"
                totals = report["totals"]
                self.summary_label.configure(text=(
                    f"تاريخ التقرير: {report['as_of_date']} | أساس العمر: تاريخ الفاتورة | "
                    f"غير مستحق/0 يوم: {_money(totals['current'])} | 1-30: {_money(totals['days_1_30'])} | "
                    f"31-60: {_money(totals['days_31_60'])} | 61-90: {_money(totals['days_61_90'])} | "
                    f"أكثر من 90: {_money(totals['over_90'])} | الإجمالي: {_money(totals['total'])}"))
                bucket_labels = {"current": "0 يوم", "days_1_30": "1-30 يوم",
                                 "days_31_60": "31-60 يوم", "days_61_90": "61-90 يوم",
                                 "over_90": "أكثر من 90 يوم"}
                rows = [{"party": row["party_name"], "invoice": row["invoice_number"],
                         "date": row["invoice_date"], "age": row["age_days"],
                         "bucket": bucket_labels[row["bucket"]],
                         "remaining": _money(row["remaining_amount"])} for row in report["rows"]]
                self._show_table([("party", party_label, 180, "w"), ("invoice", "رقم الفاتورة", 125, "w"),
                                  ("date", "تاريخ الفاتورة", 110, "w"), ("age", "العمر بالأيام", 95, "e"),
                                  ("bucket", "الشريحة", 115, "w"), ("remaining", "المتبقي", 120, "e")], rows)
            else:
                report = BalanceSheetService().get_report(self.company_id, end)
                self.summary_label.configure(text=(
                    f"الأصول: {_money(report['total_assets'])} | الالتزامات: {_money(report['total_liabilities'])} | "
                    f"حقوق الملكية مع نتيجة النشاط: {_money(report['equity_including_unclosed_profit'])} | "
                    f"الفرق: {_money(report['difference'])} | {'متزنة ✓' if report['balanced'] else 'تحتاج مراجعة'}"))
                rows = []
                for group, items in (("الأصول", report["assets"]), ("الالتزامات", report["liabilities"]), ("حقوق الملكية", report["equity"])):
                    rows.extend({"group": group, "code": r["code"], "name": r["name"], "balance": _money(r["balance"])} for r in items)
                rows.extend({"group": "غير مصنف", "code": r["code"], "name": r["name"], "balance": f"مدين {_money(r['debit'])} / دائن {_money(r['credit'])}"} for r in report["unclassified"])
                rows.append({"group": "نتيجة النشاط", "code": "", "name": "ربح / (خسارة) غير مقفلة حتى التاريخ", "balance": _money(report["unclosed_profit"])})
                self._show_table([("group", "التصنيف", 115, "w"), ("code", "الكود", 90, "w"),
                                  ("name", "الحساب", 270, "w"), ("balance", "الرصيد", 180, "e")], rows)
            self.summary_label.configure(text_color=c("text"))
        except Exception as exc:
            messagebox.showerror("تعذر عرض التقرير", str(exc), parent=self.winfo_toplevel())
