"""Executive inventory workspace: valuation, replenishment and non-moving stock."""
from __future__ import annotations

from datetime import date, timedelta

import customtkinter as ctk

from alexerp.services.inventory_intelligence_service import InventoryIntelligenceService
from alexerp.ui.components import DataTable, Page, SectionHeader, StatCard, ghost_button
from alexerp.ui.theme import START, c, font, icon


def _number(value) -> str:
    return f"{float(value or 0):,.2f}"


class InventoryIntelligencePage(Page):
    """Read-only company/branch scoped inventory intelligence page."""

    def __init__(self, parent, user=None, navigate=None):
        user = user or {}
        super().__init__(parent, title="ذكاء المخزون", subtitle="تقييم المخزون وإعادة الطلب والأصناف بطيئة الحركة",
                         user=user, scroll=True)
        self.company_id = int(user.get("company_id") or 0)
        self.branch_id = int(user["branch_id"]) if user.get("branch_id") else None
        self.service = InventoryIntelligenceService()
        self.days = 90
        self.period = ctk.CTkOptionMenu(
            self.actions, values=["30 يوم", "90 يوم", "180 يوم", "365 يوم"],
            command=self._period_changed, width=120, font=font(12), dropdown_font=font(12),
        )
        self.period.set("90 يوم")
        self.period.pack(side="left", padx=5)
        ghost_button(self.actions, f"{icon('refresh')}  تحديث", self.refresh, width=100).pack(side="left", padx=4)

        cards = ctk.CTkFrame(self.body, fg_color="transparent")
        cards.pack(fill="x")
        specs = [
            ("inventory_value", "💰", "قيمة المخزون بالتكلفة", "primary"),
            ("total_quantity", "📦", "إجمالي الكميات", "success"),
            ("low_stock_products", "⚠️", "أصناف تحت الحد الأدنى", "warning"),
            ("negative_stock_rows", "🔻", "أرصدة سالبة", "danger"),
            ("unallocated_legacy_products", "🧩", "أصناف بأرصدة قديمة غير موزعة", "info"),
        ]
        self.cards = {}
        for index, (key, glyph, title, tone) in enumerate(specs):
            card = StatCard(cards, glyph, title, "—", tone)
            col = (4 - index) if START == "right" else index
            card.grid(row=0, column=col, padx=5, pady=6, sticky="nsew")
            self.cards[key] = card
        for col in range(5):
            cards.grid_columnconfigure(col, weight=1, uniform="inventory-kpi")

        self.tables_host = ctk.CTkFrame(self.body, fg_color="transparent")
        self.tables_host.pack(fill="both", expand=True, pady=8)
        self.reorder_table = self._table_section(
            "اقتراحات إعادة الطلب", "الكمية المقترحة للوصول إلى الحد الأقصى أو الأدنى المحدد",
            [("code", "الكود", 100, "w"), ("name", "الصنف", 220, "w"),
             ("on_hand", "المتاح", 90, "e"), ("minimum_stock", "الحد الأدنى", 100, "e"),
             ("suggested_reorder", "كمية مقترحة", 110, "e")],
        )
        self.warehouse_table = self._table_section(
            "تقييم المستودعات", "قيمة الكمية المتاحة حسب متوسط التكلفة المخزنة",
            [("code", "الكود", 100, "w"), ("warehouse", "المستودع", 220, "w"),
             ("product_count", "عدد الأصناف", 100, "e"), ("quantity", "الكمية", 100, "e"),
             ("inventory_value", "القيمة", 130, "e")],
        )
        self.slow_table = self._table_section(
            "أصناف بدون مبيعات حديثة", "أصناف لها رصيد ولم تسجل حركة بيع خلال الفترة المختارة",
            [("code", "الكود", 100, "w"), ("name", "الصنف", 220, "w"),
             ("on_hand", "الرصيد", 90, "e"), ("stock_value", "القيمة", 120, "e"),
             ("last_sale_date", "آخر بيع", 130, "w")],
        )
        note = ctk.CTkLabel(
            self.body,
            text="أساس التقييم: الكمية × متوسط التكلفة في product_stock. الأرصدة القديمة غير الموزعة تظهر منفصلة ولا تدخل في قيمة المخزون. الأصناف بطيئة الحركة تُحدد حسب آخر حركة SALE، وليس أي حركة مخزنية. معدل دوران المخزون غير معروض حتى تتم مطابقة متوسط قيمة المخزون وتكلفة المبيعات لجميع أنواع الحركات.",
            font=font(11), text_color=c("muted"), justify="right", wraplength=1100,
        )
        note.pack(fill="x", padx=10, pady=(4, 14))
        self.refresh()

    def _table_section(self, title, subtitle, columns):
        section = ctk.CTkFrame(self.tables_host, fg_color="transparent")
        section.pack(fill="both", expand=True, pady=6)
        SectionHeader(section, title, subtitle, "📦").pack(fill="x", padx=8, pady=(8, 5))
        table = DataTable(section, columns, empty_text="لا توجد بيانات في هذا التصنيف")
        table.pack(fill="both", expand=True, padx=4)
        return table

    def _period_changed(self, value: str):
        self.days = int(value.split()[0])
        self.refresh()

    def refresh(self):
        if self.company_id <= 0:
            for card in self.cards.values():
                card.set("—", "لا توجد شركة مرتبطة بالمستخدم")
            return
        try:
            summary = self.service.inventory_summary(self.company_id, self.branch_id)
            for key, card in self.cards.items():
                value = summary[key]
                shown = _number(value) if key == "total_quantity" else f"{int(value):,}" if key != "inventory_value" else _number(value)
                hint = (f"الكمية غير الموزعة: {_number(summary['unallocated_legacy_quantity'])}"
                        if key == "unallocated_legacy_products" else "حسب نطاق الشركة والفرع")
                card.set(shown, hint)

            reorder = self.service.reorder_suggestions(self.company_id, self.branch_id, 100)
            self.reorder_table.set_rows(reorder, {k: _number for k in ("on_hand", "minimum_stock", "suggested_reorder")})
            warehouses = self.service.warehouse_valuation(self.company_id, self.branch_id, 100)
            self.warehouse_table.set_rows(warehouses, {k: _number for k in ("quantity", "inventory_value")})
            slow = self.service.non_moving_stock(
                self.company_id, date.today().isoformat(), self.days, self.branch_id, 100)
            self.slow_table.set_rows(slow, {k: _number for k in ("on_hand", "stock_value")})
        except Exception as exc:
            for card in self.cards.values():
                card.set("—", "تعذر تحميل بيانات المخزون")
            ctk.CTkLabel(self.body, text=f"تعذر تحميل تحليلات المخزون: {exc}",
                         text_color=c("danger"), font=font(12)).pack(fill="x", padx=10, pady=6)
