"""
AlexERP — Business Management System
Login screen (split layout: brand identity panel + sign-in form).
"""

from __future__ import annotations

from typing import Callable

import customtkinter as ctk

from alexerp.config import APP_NAME, APP_VERSION
from alexerp.services.auth_service import AuthService, AuthenticationError
from alexerp.ui.components import entry, primary_button
from alexerp.ui.theme import (
    BRAND_MARK, BRAND_MODULES_AR, BRAND_NAME, BRAND_TAGLINE_AR, BRAND_TAGLINE_EN,
    END, START, TEXT_ANCHOR, c, font,
)


class LoginFrame(ctk.CTkFrame):
    """Calls on_success(user_row) after a successful login."""

    def __init__(self, parent, on_success: Callable):
        super().__init__(parent, fg_color=c("bg"))
        self.on_success = on_success
        self.auth = AuthService()
        self._build()

    def _build(self):
        brand = ctk.CTkFrame(self, width=500, corner_radius=0, fg_color=c("sidebar"))
        brand.pack(side=START, fill="y")
        brand.pack_propagate(False)

        card = ctk.CTkFrame(brand, fg_color="#14213A", corner_radius=20,
                            border_width=1, border_color="#22324F")
        card.place(relx=0.5, rely=0.47, anchor="center", relwidth=0.82)

        top = ctk.CTkFrame(card, fg_color="transparent")
        top.pack(fill="x", padx=24, pady=(24, 14))
        ctk.CTkLabel(top, text=BRAND_MARK, width=64, height=64, corner_radius=16,
                     fg_color=c("primary"), text_color="#FFFFFF",
                     font=font(32, "bold")).pack(side=START)
        names = ctk.CTkFrame(top, fg_color="transparent")
        names.pack(side=START, padx=14)
        ctk.CTkLabel(names, text=BRAND_NAME, font=font(30, "bold"),
                     text_color="#FFFFFF", anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)
        ctk.CTkLabel(names, text=BRAND_TAGLINE_EN, font=font(10, "bold"),
                     text_color="#8C9AB5", anchor=TEXT_ANCHOR).pack(anchor=TEXT_ANCHOR)

        ctk.CTkFrame(card, height=1, fg_color="#22324F").pack(fill="x", padx=24, pady=(4, 14))
        ctk.CTkLabel(card, text=BRAND_TAGLINE_AR, font=font(20, "bold"),
                     text_color="#FFFFFF", anchor=TEXT_ANCHOR).pack(fill="x", padx=24)
        ctk.CTkLabel(card, text=BRAND_MODULES_AR, font=font(13),
                     text_color="#AEB9CE", anchor=TEXT_ANCHOR).pack(fill="x", padx=24, pady=(6, 14))

        bars = ctk.CTkFrame(card, fg_color="transparent", height=10)
        bars.pack(fill="x", padx=24, pady=(0, 24))
        for i, color in enumerate(("#3D6BF5", "#1E2A44", "#3FC37A", "#FFFFFF")):
            bars.grid_columnconfigure(i, weight=1, uniform="bars")
            ctk.CTkFrame(bars, height=10, corner_radius=5, fg_color=color).grid(
                row=0, column=i, padx=4, sticky="ew")

        ctk.CTkLabel(brand, text=f"v{APP_VERSION}  ·  {APP_NAME}", font=font(11),
                     text_color=c("sidebar_muted")).place(relx=0.5, rely=0.96, anchor="s")

        form = ctk.CTkFrame(self, fg_color="transparent")
        form.pack(side=START, fill="both", expand=True)
        box = ctk.CTkFrame(form, fg_color=c("surface"), corner_radius=18,
                           border_width=1, border_color=c("border"))
        box.place(relx=0.5, rely=0.5, anchor="center")
        inner = ctk.CTkFrame(box, fg_color="transparent")
        inner.pack(padx=36, pady=34)

        ctk.CTkLabel(inner, text="أهلاً بعودتك", font=font(26, "bold"),
                     text_color=c("text"), anchor=TEXT_ANCHOR).pack(fill="x")
        ctk.CTkLabel(inner, text=f"سجّل الدخول إلى {APP_NAME}", font=font(14),
                     text_color=c("muted"), anchor=TEXT_ANCHOR).pack(fill="x", pady=(4, 24))

        ctk.CTkLabel(inner, text="اسم المستخدم", font=font(12, "bold"),
                     text_color=c("muted"), anchor=TEXT_ANCHOR).pack(fill="x")
        self.username = entry(inner, "اسم المستخدم", 340)
        self.username.pack(pady=(4, 12))
        ctk.CTkLabel(inner, text="كلمة المرور", font=font(12, "bold"),
                     text_color=c("muted"), anchor=TEXT_ANCHOR).pack(fill="x")
        self.password = entry(inner, "كلمة المرور", 340, show="•")
        self.password.pack(pady=(4, 0))

        self.error = ctk.CTkLabel(inner, text="", text_color=c("danger"), font=font(12),
                                  anchor=TEXT_ANCHOR)
        self.error.pack(fill="x", pady=(8, 0))

        primary_button(inner, "تسجيل الدخول", self.submit, width=340, height=42).pack(pady=(10, 0))
        ctk.CTkLabel(inner, text="Enter للانتقال · Enter مرة أخرى للدخول", font=font(11),
                     text_color=c("muted")).pack(pady=(12, 0))

        self.username.focus()
        self.username.bind("<Return>", lambda _e: self.password.focus())
        self.password.bind("<Return>", lambda _e: self.submit())

    def submit(self):
        username = self.username.get().strip()
        password = self.password.get()

        if not username or not password:
            self.error.configure(text="أدخل اسم المستخدم وكلمة المرور")
            return

        try:
            user = self.auth.login(username, password)
        except AuthenticationError as exc:
            self.error.configure(text=str(exc))
            self.password.delete(0, "end")
            return

        self.on_success(user)
