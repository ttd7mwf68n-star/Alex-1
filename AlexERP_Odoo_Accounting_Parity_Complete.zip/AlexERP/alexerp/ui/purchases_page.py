"""
AlexERP — Business Management System
Purchases page: post supplier invoices with stock receipt and accounting,
and audit-preserving cancellation.
"""

from __future__ import annotations

from datetime import date
from tkinter import messagebox

import customtkinter as ctk

from alexerp.database.db import Database
from alexerp.database.transaction import TransactionError
from alexerp.core.helpers import allocate_discount
from alexerp.services.purchase_service import PurchaseService, PurchaseError
from alexerp.services.payment_service import PaymentService, PaymentError
from alexerp.services.permission_service import PermissionService
from alexerp.services.supplier_service import SupplierService
from alexerp.services.product_service import ProductService
from alexerp.core import context
from alexerp.ui.components import (
    Badge, Card, DataTable, Dialog, Page, SearchBar, Toolbar, combo, danger_button, entry,
    field, ghost_button, primary_button, subtle_button, toast,
)
from alexerp.ui.invoice_form import InvoiceDialogBase
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font, icon

COLUMNS = [
    ("invoice_number", "رقم الفاتورة", 120, "w"),
    ("invoice_date", "التاريخ", 105, "w"),
    ("supplier_name", "المورد", 210, "w"),
    ("total", "الإجمالي", 105, "e"),
    ("paid_amount", "المدفوع", 100, "e"),
    ("remaining_amount", "المتبقي", 100, "e"),
    ("status", "الحالة", 95, "w"),
]


def _accounts():
    return Database.connect().execute(
        "SELECT id, account_code || ' - ' || account_name AS label "
        "FROM chart_of_accounts WHERE company_id=? ORDER BY account_code",
        (context.current_company_id(),),
    ).fetchall()


def _warehouses():
    from alexerp.core import context
    return Database.connect().execute(
        "SELECT id, name FROM warehouses WHERE company_id=? ORDER BY id",
        (context.current_company_id(),),
    ).fetchall()


def _pick(rows, widget):
    """Resolve a selected value from account, entity, warehouse, or product rows."""
    label = widget.get().strip()
    for row in rows:
        keys = row.keys()
        if "label" in keys and str(row["label"]) == label:
            return int(row["id"])
        if "name" in keys and str(row["name"]) == label:
            return int(row["id"])
        if "code" in keys and "name" in keys:
            display = f"{row['code']} - {row['name']}"
            if display == label:
                return int(row["id"])
    raise ValueError("اختر قيمة من القوائم أولاً")


class PurchaseInvoiceDialog(InvoiceDialogBase):
    """Post a new purchase invoice: items, supplier, warehouse, ledger accounts."""

    ACCOUNT_SPECS = [("ذمم الموردين (دائن)", "supplier"), ("المخزون (مدين)", "inventory"),
                     ("ضريبة المدخلات (مدين)", "tax"), ("النقدية/البنك (دائن)", "cash")]

    def __init__(self, parent, user, on_saved=None):
        self.user, self.on_saved = user, on_saved
        self.service = PurchaseService()
        self.suppliers = [r for r in SupplierService().get_all() if int(r["company_id"]) == context.current_company_id()]
        self.accounts = _accounts()
        super().__init__(
            parent, "فاتورة شراء جديدة", party_label="المورد", parties=self.suppliers,
            products=ProductService().list(), warehouses=_warehouses(),
            price_key="purchase_price", price_caption="التكلفة", accounts=self.accounts,
            account_specs=self.ACCOUNT_SPECS,
            subtitle="الترحيل يضيف للمخزون وينشئ القيد المحاسبي تلقائياً", glyph="🛒")
        self.warehouses = self._warehouses
        self.supplier = self.party
        if not self.suppliers:
            self.error.configure(text="أضف مورداً أولاً")
        self.footer([("ترحيل الفاتورة", self.save, "primary"), ("إلغاء", self.destroy, "ghost")],
                    width=160)

    def save(self):
        try:
            supplier_id = _pick(self.suppliers, self.supplier)
            warehouse_id = _pick(self.warehouses, self.warehouse)
            items, subtotal, tax = [], 0.0, 0.0
            for _r, cb, q, p, t in self.item_rows:
                lq, lc, lt = float(q.get() or 0), float(p.get() or 0), float(t.get() or 0)
                if lq <= 0:
                    continue
                pid = _pick(self.products, cb)
                line_total = round(lq * lc + lt, 2)
                items.append({"product_id": pid, "warehouse_id": warehouse_id,
                              "quantity": lq, "unit_cost": lc, "discount": 0,
                              "tax": lt, "total": line_total})
                subtotal += lq * lc
                tax += lt
            if not items:
                self.error.configure(text="أضف بنداً واحداً على الأقل بكمية موجبة")
                return
            discount = float(self.discount.get() or 0)
            allocations = allocate_discount(
                [item["quantity"] * item["unit_cost"] for item in items], discount
            )
            for item, line_discount in zip(items, allocations):
                gross_base = item["quantity"] * item["unit_cost"]
                item["discount"] = line_discount
                item["unit_cost"] = round((gross_base - line_discount) / item["quantity"], 8)
                item["total"] = round(gross_base - line_discount + item["tax"], 2)
            paid = float(self.paid.get() or 0)
            total = round(subtotal - discount + tax, 2)
            number = f"P-{date.today():%Y%m%d}-{Database.connect().execute('SELECT COUNT(*) c FROM purchase_invoices').fetchone()['c'] + 1}"
            self.service.create_invoice(
                company_id=context.current_company_id(), branch_id=context.current_branch_id(), supplier_id=supplier_id,
                invoice_number=number, supplier_invoice_number="",
                invoice_date=self.invoice_date.get().strip() or date.today().isoformat(),
                items=items, subtotal=round(subtotal, 2), discount=discount, tax=round(tax, 2),
                total=total, paid_amount=paid, remaining_amount=round(total - paid, 2),
                notes="", created_by=context.current_user_id(),
                supplier_account=_pick(self.accounts, self.acc_widgets["supplier"]),
                inventory_account=_pick(self.accounts, self.acc_widgets["inventory"]),
                tax_account=_pick(self.accounts, self.acc_widgets["tax"]) if tax else None,
                cash_account=_pick(self.accounts, self.acc_widgets["cash"]) if paid else None,
            )
        except (ValueError, PurchaseError, TransactionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, f"تم ترحيل الفاتورة {number}")
        self.destroy()


class SupplierPaymentsDialog(Dialog):
    """Create, inspect, and audit-cancel supplier payments from Desktop."""

    COLUMNS = [
        ("payment_number", "رقم السند", 150, "w"),
        ("payment_date", "التاريخ", 110, "w"),
        ("supplier_name", "المورد", 190, "w"),
        ("amount", "المبلغ", 110, "e"),
        ("status", "الحالة", 100, "w"),
    ]

    def __init__(self, parent, user, on_saved=None):
        super().__init__(parent, "مدفوعات الموردين", 960, 640,
                         subtitle="تسجيل سندات الصرف للموردين وإلغاؤها بقيد عكسي", glyph="💸",
                         resizable=True)
        self.minsize(820, 540)
        self.user, self.on_saved = user, on_saved
        self.user_id = int((user or {}).get("id") or 0)
        permissions = PermissionService()
        self.can_create = permissions.has_permission(self.user_id, "payments.create")
        self.can_view = permissions.has_permission(self.user_id, "payments.view")
        self.can_cancel = self.can_view and permissions.has_permission(self.user_id, "payments.cancel")
        self.service = PaymentService()
        self.suppliers = [r for r in SupplierService().get_all() if int(r["company_id"]) == context.current_company_id()]
        self.accounts = _accounts()

        card = Card(self)
        card.pack(fill="x", padx=18, pady=14)
        form = ctk.CTkFrame(card, fg_color="transparent")
        form.pack(fill="x", padx=12, pady=10)
        labels = [r["label"] for r in self.accounts]
        specs = [
            ("المورد", lambda p: combo(p, [r["name"] for r in self.suppliers], 190)),
            ("حساب النقدية/البنك", lambda p: combo(p, labels, 190)),
            ("حساب الموردين", lambda p: combo(p, labels, 190)),
            ("المبلغ", lambda p: entry(p, "0.00", 120)),
            ("التاريخ", lambda p: entry(p, "YYYY-MM-DD", 130)),
            ("ملاحظات", lambda p: entry(p, "اختياري", 180)),
        ]
        widgets = []
        for i, (caption, factory) in enumerate(specs):
            fr, w = field(form, caption, factory, required=i < 4)
            cc = (2 - i % 3) if START == "right" else i % 3
            fr.grid(row=i // 3, column=cc, sticky="ew", padx=6, pady=3)
            widgets.append(w)
        for cc in range(3):
            form.grid_columnconfigure(cc, weight=1, uniform="pay")
        self.supplier, self.cash, self.payable, self.amount, self.payment_date, self.notes = widgets
        self.payment_date.insert(0, date.today().isoformat())
        actions = ctk.CTkFrame(card, fg_color="transparent")
        actions.pack(fill="x", padx=18, pady=(0, 10))
        if self.can_create:
            primary_button(actions, "تسجيل الدفعة", self.save, width=150).pack(side=END)
        self.error = ctk.CTkLabel(actions, text="", text_color=c("danger"), font=font(12),
                                  anchor=TEXT_ANCHOR)
        self.error.pack(side=START, fill="x", expand=True)

        self.table = DataTable(self, self.COLUMNS, empty_text="لا توجد مدفوعات موردين")
        self.table.pack(fill="both", expand=True, padx=18, pady=(0, 10))
        if self.can_cancel:
            foot = ctk.CTkFrame(self, fg_color="transparent")
            foot.pack(fill="x", padx=18, pady=(0, 12), side="bottom", before=self.table)
            danger_button(foot, "إلغاء الدفعة المحددة", self.cancel, width=170).pack(side=START)
            Badge(foot, "الإلغاء يعكس القيد ولا يحذف السند", "muted").pack(side=END)
        self.refresh()

    def refresh(self):
        if not self.can_view:
            self.table.set_rows([])
            return
        rows = Database.connect().execute(
            "SELECT p.*, s.name AS supplier_name FROM payments p "
            "LEFT JOIN suppliers s ON s.id=p.supplier_id "
            "WHERE p.company_id=? AND p.branch_id=? ORDER BY p.id DESC",
            (context.current_company_id(), context.current_branch_id()),
        ).fetchall()
        self.table.set_rows(rows, {"amount": lambda v: f"{(v or 0):,.2f}"})

    def save(self):
        if not self.can_create:
            return
        try:
            supplier_id = _pick(self.suppliers, self.supplier)
            cash_id = _pick(self.accounts, self.cash)
            payable_id = _pick(self.accounts, self.payable)
            amount = float(self.amount.get())
            if not amount > 0:
                raise ValueError("أدخل مبلغاً أكبر من صفر")
            count = Database.connect().execute(
                "SELECT COUNT(*) AS c FROM payments WHERE company_id=? AND branch_id=?",
                (context.current_company_id(), context.current_branch_id()),
            ).fetchone()["c"]
            number = f"PAY-{date.today():%Y%m%d}-{int(count) + 1:04d}"
            self.service.create_payment(
                company_id=context.current_company_id(),
                branch_id=context.current_branch_id(), payment_number=number,
                payment_date=self.payment_date.get().strip() or date.today().isoformat(),
                supplier_id=supplier_id, cash_account=cash_id,
                payable_account=payable_id, amount=amount,
                created_by=context.current_user_id(), notes=self.notes.get().strip(),
            )
        except (ValueError, PaymentError, TransactionError) as exc:
            self.error.configure(text=str(exc))
            return
        self.amount.delete(0, "end")
        self.notes.delete(0, "end")
        self.error.configure(text="")
        toast(self, f"تم تسجيل الدفعة {number}")
        self.refresh()
        if self.on_saved:
            self.on_saved()

    def cancel(self):
        if not self.can_cancel:
            return
        row = self.table.selected
        if row is None:
            messagebox.showinfo("مدفوعات الموردين", "اختر دفعة من الجدول أولاً")
            return
        if str(row["status"]).upper() != "POSTED":
            messagebox.showwarning("إلغاء الدفعة", "يمكن إلغاء الدفعات المرحلة فقط")
            return
        if not messagebox.askyesno("إلغاء دفعة", f"إلغاء الدفعة {row['payment_number']}؟ سيتم عكس القيد المحاسبي."):
            return
        try:
            self.service.cancel_payment(row["id"], created_by=context.current_user_id())
        except (PaymentError, TransactionError) as exc:
            messagebox.showerror("إلغاء الدفعة", str(exc))
            return
        self.refresh()
        if self.on_saved:
            self.on_saved()


class PurchasesPage(Page):

    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="المشتريات",
                         subtitle="ترحيل فواتير الموردين مع إثبات المخزون والقيود", user=user)
        self.service = PurchaseService()
        self.user_id = int((user or {}).get("id") or 0)
        permissions = PermissionService()
        self.can_create = permissions.has_permission(self.user_id, "purchases.create")
        self.can_cancel = permissions.has_permission(self.user_id, "purchases.cancel")
        self.can_view_payments = permissions.has_permission(self.user_id, "payments.view")
        self.can_create_payments = permissions.has_permission(self.user_id, "payments.create")

        if self.can_create:
            primary_button(self.actions, f"{icon('add')}  فاتورة شراء", self.add, width=140).pack(side="left", padx=4)
        if self.can_view_payments or self.can_create_payments:
            ghost_button(self.actions, "💸  مدفوعات الموردين", self.open_payments, width=170).pack(side="left", padx=4)

        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        self.search = SearchBar(bar.row, "ابحث برقم الفاتورة أو اسم المورد...  (Ctrl+F)",
                                on_search=self.refresh, width=380)
        bar.add(self.search)
        self.count = Badge(bar.row, "", "info")
        bar.add(self.count, side=END, padx=8)

        self.table = DataTable(self.body, COLUMNS, empty_text="لا توجد فواتير مشتريات")
        self.table.pack(fill="both", expand=True)

        foot = ctk.CTkFrame(self.body, fg_color="transparent")
        foot.pack(fill="x", pady=(10, 0))
        if self.can_cancel:
            danger_button(foot, "✕  إلغاء الفاتورة", self.cancel, width=140).pack(side=START, padx=4)
        Badge(foot, "الإلغاء يعكس القيد ويخصم المخزون ولا يحذف الفاتورة", "muted").pack(side=END)

        self.refresh()

    def refresh(self):
        kw = self.search.get().strip()
        base_sql = (
            "SELECT p.*, COALESCE(s.name, '') AS supplier_name "
            "FROM purchase_invoices p LEFT JOIN suppliers s ON s.id = p.supplier_id"
        )
        if kw:
            rows = Database.connect().execute(
                base_sql + " WHERE p.invoice_number LIKE ? OR s.name LIKE ? ORDER BY p.id DESC",
                (f"%{kw}%", f"%{kw}%")
            ).fetchall()
        else:
            rows = Database.connect().execute(base_sql + " ORDER BY p.id DESC").fetchall()
        self.table.set_rows(rows, {
            "total": lambda v: f"{(v or 0):,.2f}",
            "paid_amount": lambda v: f"{(v or 0):,.2f}",
            "remaining_amount": lambda v: f"{(v or 0):,.2f}",
        })
        self.count.set(f"{len(rows)} فاتورة")

    def add(self):
        if not self.can_create:
            return
        PurchaseInvoiceDialog(self, self.user, self.refresh)

    def open_payments(self):
        if not (self.can_view_payments or self.can_create_payments):
            return
        SupplierPaymentsDialog(self, self.user, self.refresh)

    def cancel(self):
        if not self.can_cancel:
            return
        row = self.table.selected
        if row is None:
            messagebox.showinfo("المشتريات", "اختر فاتورة من الجدول أولاً")
            return
        if str(row["status"]).upper() != "POSTED":
            messagebox.showwarning("إلغاء", "يمكن إلغاء الفواتير المرحلة فقط")
            return
        if not messagebox.askyesno("إلغاء فاتورة", f"إلغاء الفاتورة {row['invoice_number']}؟ سيتم عكس القيد وخصم المخزون."):
            return
        try:
            self.service.cancel_invoice(row["id"], created_by=self.user["id"] if self.user is not None else 1)
        except (PurchaseError, TransactionError) as exc:
            messagebox.showerror("إلغاء فاتورة", str(exc))
            return
        toast(self, "تم إلغاء الفاتورة وعكس القيد", "warning")
        self.refresh()
