"""Desktop workspace for quotations and sales orders."""
from __future__ import annotations

import secrets
from datetime import date
from tkinter import messagebox

import customtkinter as ctk

from alexerp.database.db import Database
from alexerp.database.transaction import TransactionError
from alexerp.services.customer_service import CustomerService
from alexerp.services.permission_service import PermissionService
from alexerp.services.sales_order_service import SalesOrderService
from alexerp.services.sales_delivery_service import SalesDeliveryService
from alexerp.services.sales_return_service import SalesReturnError, SalesReturnService
from alexerp.services.sales_settings_service import SalesSettingsService
from alexerp.core import context
from alexerp.ui.components import (
    Badge, DataTable, Dialog, Page, SearchBar, Toolbar, combo, danger_button,
    entry, field, primary_button, subtle_button, toast,
)
from alexerp.ui.theme import END, START
from alexerp.ui.sales_page import SalesReturnDialog

COLUMNS = [
    ("quotation_number", "عرض السعر", 135, "w"),
    ("order_number", "أمر البيع", 135, "w"),
    ("customer_name", "العميل", 190, "w"),
    ("document_date", "التاريخ", 100, "w"),
    ("total", "الإجمالي", 110, "e"),
    ("status", "الحالة", 150, "w"),
]


def _label(row):
    code = str(row["code"] or "").strip() if "code" in row.keys() else ""
    name = str(row["name"] or "").strip()
    return f"{code} - {name}" if code else name


class QuotationDialog(Dialog):
    def __init__(self, parent, user, on_saved):
        super().__init__(parent, "عرض سعر جديد", 900, 760,
                         subtitle="عرض السعر لا يحجز المخزون ولا ينشئ قيداً محاسبياً", glyph="📄",
                         resizable=True)
        self.user = user or {}
        self.on_saved = on_saved
        self.service = SalesOrderService()
        self.company_id = int(self.user.get("company_id") or context.current_company_id())
        self.customers = CustomerService().get_all(self.company_id)
        branch_id = int(self.user.get("branch_id") or context.current_branch_id())
        self.products = Database.connect().execute(
            "SELECT id,code,name,sale_price FROM products WHERE company_id=? "
            "AND (branch_id=? OR branch_id IS NULL) AND COALESCE(is_active,1)=1 ORDER BY name",
            (self.company_id, branch_id),
        ).fetchall()
        self.warehouses = Database.connect().execute(
            "SELECT id,name FROM warehouses WHERE company_id=? AND is_active=1 "
            "AND (branch_id=? OR branch_id IS NULL) ORDER BY name",
            (self.company_id, branch_id),
        ).fetchall()
        self.product_by_label = {_label(row): row for row in self.products}
        self.customer_by_label = {_label(row): row for row in self.customers}
        self.warehouse_by_label = {str(row["name"]): row for row in self.warehouses}
        self.lines = []

        body = ctk.CTkScrollableFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=22, pady=12)
        top = ctk.CTkFrame(body, fg_color="transparent")
        top.pack(fill="x")
        self.customer = self._add_field(top, "العميل", list(self.customer_by_label), 260)
        self.warehouse = self._add_field(top, "المخزن", list(self.warehouse_by_label), 210)
        self.expiry = self._add_field(top, "تاريخ انتهاء العرض (اختياري)", [], 170, is_entry=True)
        self.expiry.insert(0, "")
        self.number = self._add_field(top, "رقم عرض السعر", [], 190, is_entry=True)
        self.number.insert(0, f"Q-{date.today():%Y%m%d}-{secrets.token_hex(2).upper()}")

        self.line_host = ctk.CTkFrame(body, fg_color="transparent")
        self.line_host.pack(fill="x", pady=(18, 6))
        header = ctk.CTkFrame(self.line_host, fg_color="transparent")
        header.pack(fill="x", pady=(0, 5))
        for text, width in (("الصنف", 280), ("الكمية", 90), ("السعر", 100), ("الخصم", 90), ("الضريبة", 90)):
            ctk.CTkLabel(header, text=text, width=width, anchor="center").pack(side=START, padx=3)
        self.add_line()
        subtle_button(body, "+ إضافة صنف", self.add_line, width=130).pack(anchor="w", pady=6)
        self.notes = entry(body, "ملاحظات وشروط العرض", width=600)
        self.notes.pack(fill="x", pady=(10, 0))
        self.error.pack(fill="x", padx=24, pady=(0, 4))
        self.footer([("حفظ عرض السعر", self.save, "primary"), ("إلغاء", self.destroy, "ghost")], width=150)

    def _add_field(self, parent, caption, values, width, is_entry=False):
        frame, widget = field(parent, caption,
            (lambda p: entry(p, width=width)) if is_entry else (lambda p: combo(p, values, width=width)))
        frame.pack(side=START, padx=5, pady=4, fill="x", expand=True)
        return widget

    def add_line(self):
        row = ctk.CTkFrame(self.line_host, fg_color="transparent")
        row.pack(fill="x", pady=3)
        product = combo(row, list(self.product_by_label), width=280)
        product.pack(side=START, padx=3)
        qty = entry(row, "1", width=90)
        qty.insert(0, "1")
        qty.pack(side=START, padx=3)
        price = entry(row, "السعر", width=100)
        price.pack(side=START, padx=3)
        discount = entry(row, "0", width=90)
        discount.insert(0, "0")
        discount.pack(side=START, padx=3)
        tax = entry(row, "0", width=90)
        tax.insert(0, "0")
        tax.pack(side=START, padx=3)
        remove = ctk.CTkButton(row, text="×", width=30, command=lambda: self._remove_line(row))
        remove.pack(side=START, padx=3)
        self.lines.append((row, product, qty, price, discount, tax))

    def _remove_line(self, row):
        if len(self.lines) <= 1:
            self.error.configure(text="يجب الاحتفاظ ببند واحد على الأقل.")
            return
        self.lines = [line for line in self.lines if line[0] is not row]
        row.destroy()

    def save(self):
        try:
            customer_label = self.customer.get().strip()
            warehouse_label = self.warehouse.get().strip()
            if customer_label not in self.customer_by_label or warehouse_label not in self.warehouse_by_label:
                raise ValueError("اختر العميل والمخزن من القوائم.")
            customer_id = int(self.customer_by_label[customer_label]["id"])
            warehouse_id = int(self.warehouse_by_label[warehouse_label]["id"])
            items = []
            for index, (_, product_widget, qty_widget, price_widget, discount_widget, tax_widget) in enumerate(self.lines, 1):
                product_label = product_widget.get().strip()
                if not product_label:
                    raise ValueError(f"اختر الصنف في البند {index}.")
                product = self.product_by_label.get(product_label)
                if product is None:
                    raise ValueError(f"الصنف في البند {index} غير صحيح.")
                qty = float(qty_widget.get() or 0)
                price = float(price_widget.get() or product["sale_price"] or 0)
                discount = float(discount_widget.get() or 0)
                tax = float(tax_widget.get() or 0)
                total = round(qty * price - discount + tax, 2)
                items.append({"product_id": int(product["id"]), "warehouse_id": warehouse_id,
                              "quantity": qty, "unit_price": price, "discount": discount,
                              "tax": tax, "total": total})
            expiry = self.expiry.get().strip() or None
            self.service.create_quotation(
                company_id=self.company_id,
                branch_id=int(self.user.get("branch_id") or context.current_branch_id()),
                customer_id=customer_id, quotation_number=self.number.get().strip(),
                document_date=date.today().isoformat(), expiry_date=expiry,
                items=items, notes=self.notes.get().strip(),
                created_by=int(self.user.get("id") or 0),
            )
        except (ValueError, TransactionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, "تم حفظ عرض السعر")
        self.destroy()


class InvoiceFromOrderDialog(Dialog):
    """Select quantities per order line to support partial invoices on desktop."""
    def __init__(self, parent, order, user, on_saved):
        super().__init__(parent, "إنشاء فاتورة من أمر البيع", 620, 600,
                         subtitle="اترك الكمية فارغة لتخطي البند، أو أدخل كمية أقل للفوترة الجزئية",
                         glyph="🧾", resizable=True)
        self.order = order
        self.user = user or {}
        self.on_saved = on_saved
        self.service = SalesOrderService()
        self.quantity_fields = {}
        body = ctk.CTkScrollableFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=22, pady=12)
        lines = self.service.get_items(int(order["id"]))
        for line in lines:
            remaining = max(0.0, float(line["quantity"]) - float(line["invoiced_quantity"] or 0))
            if remaining <= 0.000001:
                continue
            product = Database.connect().execute(
                "SELECT code,name FROM products WHERE id=?", (int(line["product_id"]),)
            ).fetchone()
            product_name = f"{product['code']} - {product['name']}" if product and product["code"] else (product["name"] if product else f"منتج {line['product_id']}")
            row = ctk.CTkFrame(body, fg_color="transparent")
            row.pack(fill="x", pady=5)
            ctk.CTkLabel(row, text=f"{product_name}  |  المتبقي: {remaining:g}", anchor="w").pack(side=START, fill="x", expand=True, padx=6)
            quantity = entry(row, "الكمية", width=110)
            quantity.insert(0, f"{remaining:g}")
            quantity.pack(side=END, padx=6)
            self.quantity_fields[int(line["id"])] = quantity
        self.error.pack(fill="x", padx=24, pady=(0, 4))
        self.footer([("إصدار الفاتورة", self.save, "primary"), ("إلغاء", self.destroy, "ghost")], width=150)

    def save(self):
        try:
            quantities = {}
            for line_id, widget in self.quantity_fields.items():
                raw = widget.get().strip()
                if not raw:
                    continue
                quantities[line_id] = float(raw)
            if not quantities:
                raise ValueError("أدخل كمية واحدة على الأقل للفوترة.")
            company_id = int(self.user.get("company_id") or context.current_company_id())
            settings = SalesSettingsService().get_settings(company_id)
            accounts = {
                "sales_account": settings.get("sales_account_id"),
                "inventory_account": settings.get("inventory_account_id"),
                "cogs_account": settings.get("cogs_account_id"),
                "tax_account": settings.get("tax_account_id"),
                "cash_account": settings.get("cash_account_id"),
            }
            accounts = {key: value for key, value in accounts.items() if value is not None}
            invoice_number = f"INV-{date.today():%Y%m%d}-{secrets.token_hex(2).upper()}"
            self.service.create_invoice_from_order(
                int(self.order["id"]), invoice_number, date.today().isoformat(),
                int(self.user.get("id") or 0), quantities=quantities,
                invoice_accounts=accounts,
            )
        except (ValueError, TransactionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, "تم إصدار الفاتورة وتحديث الكميات المفوترة")
        self.destroy()


class SalesDeliveryDialog(Dialog):
    """Create and post a partial/full delivery against a posted invoice."""
    def __init__(self, parent, order, user, on_saved):
        super().__init__(parent, "مستند تسليم", 720, 650,
                         subtitle="التسليم مرتبط بفاتورة مرحلة، ويدعم الشحن الجزئي",
                         glyph="🚚", resizable=True)
        self.order = order
        self.user = user or {}
        self.on_saved = on_saved
        self.service = SalesDeliveryService()
        self.invoices = self.service.list_invoices_for_order(int(order["id"]), int(order["company_id"]))
        self.invoice_by_label = {f"{r['invoice_number']} | {r['delivery_status']}": r for r in self.invoices}
        body = ctk.CTkScrollableFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=22, pady=12)
        self.number = entry(body, "رقم مستند التسليم", width=240)
        self.number.insert(0, f"DN-{date.today():%Y%m%d}-{secrets.token_hex(2).upper()}")
        self.number.pack(anchor="w", pady=5)
        self.invoice = combo(body, list(self.invoice_by_label), width=340)
        self.invoice.pack(anchor="w", pady=5)
        self.line_host = ctk.CTkFrame(body, fg_color="transparent")
        self.line_host.pack(fill="x", pady=8)
        self.qty_fields = {}
        self.invoice.configure(command=self.load_lines)
        if self.invoice_by_label:
            self.invoice.set(next(iter(self.invoice_by_label)))
            self.load_lines(next(iter(self.invoice_by_label)))
        self.notes = entry(body, "ملاحظات التسليم", width=480)
        self.notes.pack(fill="x", pady=5)
        self.error.pack(fill="x", padx=24, pady=4)
        self.footer([("اعتماد التسليم", self.post, "primary"), ("إغلاق", self.destroy, "ghost")], width=150)

    def load_lines(self, label=None):
        for child in self.line_host.winfo_children():
            child.destroy()
        self.qty_fields = {}
        row = self.invoice_by_label.get(label or self.invoice.get())
        if row is None:
            return
        for line in self.service.get_invoice_lines(int(row["id"])):
            remaining = max(0.0, float(line["quantity"]) - float(line["delivered_quantity"] or 0))
            if remaining <= 0.000001:
                continue
            line_frame = ctk.CTkFrame(self.line_host, fg_color="transparent")
            line_frame.pack(fill="x", pady=3)
            ctk.CTkLabel(line_frame, text=f"{line['product_name']} | متبقي {remaining:g}", anchor="w").pack(side=START, padx=5)
            qty = entry(line_frame, f"الكمية (حد أقصى {remaining:g})", width=170)
            qty.pack(side=END, padx=5)
            self.qty_fields[int(line["id"])] = qty

    def post(self):
        try:
            invoice = self.invoice_by_label.get(self.invoice.get())
            if invoice is None:
                raise ValueError("اختر فاتورة مرحلة مرتبطة بأمر البيع.")
            quantities = {}
            for line_id, widget in self.qty_fields.items():
                raw = widget.get().strip()
                if raw:
                    quantities[line_id] = float(raw)
            delivery_id = self.service.create_and_post(
                order_id=int(self.order["id"]), invoice_id=int(invoice["id"]),
                delivery_number=self.number.get().strip(), delivery_date=date.today().isoformat(),
                quantities=quantities, created_by=int(self.user.get("id") or 0),
                notes=self.notes.get().strip(),
            )
        except (ValueError, TransactionError) as exc:
            self.error.configure(text=str(exc))
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, f"تم اعتماد مستند التسليم #{delivery_id}")
        self.destroy()


class SalesDeliveryReturnChooser(Dialog):
    """Select an unreturned posted delivery before opening the return form."""

    def __init__(self, parent, order, user, on_saved):
        super().__init__(parent, "مرتجع من مستند تسليم", 620, 360,
                         subtitle="اختر مستندًا معتمدًا لإرجاع الكمية التي تم تسليمها فقط",
                         glyph="↩")
        self.order, self.user, self.on_saved = order, user or {}, on_saved
        self.service = SalesReturnService()
        self.deliveries = self.service.list_returnable_deliveries(
            int(order["id"]), int(order["company_id"]), int(order["branch_id"]),
            int(self.user.get("id") or 0),
        )
        self.delivery_by_label = {}
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=22, pady=18)
        if not self.deliveries:
            ctk.CTkLabel(
                body,
                text="لا توجد مستندات تسليم معتمدة بها كميات متبقية للإرجاع.",
                text_color="#6C757D",
                anchor="e",
                wraplength=520,
            ).pack(fill="x", pady=24)
        else:
            values = []
            for row in self.deliveries:
                text = (f"{row['delivery_number']}  ·  {row['invoice_number']}  ·  "
                        f"متاح {float(row['remaining_quantity'] or 0):g}")
                values.append(text)
                self.delivery_by_label[text] = row
            self.delivery = combo(body, values, width=500)
            self.delivery.pack(anchor="e", pady=(12, 6))
            self.delivery.set(values[0])
        self.error.pack(fill="x", padx=24, pady=(0, 4))
        self.footer([
            ("متابعة المرتجع", self.open_return, "primary"),
            ("إغلاق", self.destroy, "ghost"),
        ], width=145)

    def open_return(self):
        delivery = self.delivery_by_label.get(self.delivery.get()) if self.deliveries else None
        if delivery is None:
            self.error.configure(text="لا يوجد مستند تسليم قابل للإرجاع.")
            return
        invoice = Database.connect().execute(
            "SELECT * FROM sales_invoices WHERE id=? AND company_id=? AND branch_id=?",
            (int(delivery["sales_invoice_id"]), int(self.order["company_id"]),
             int(self.order["branch_id"])),
        ).fetchone()
        if invoice is None:
            self.error.configure(text="الفاتورة المرتبطة بالتسليم غير متاحة في نطاق الشركة والفرع.")
            return
        self.destroy()
        SalesReturnDialog(self.master, self.user, invoice, self.on_saved, delivery=delivery)


class SalesOrdersPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="عروض الأسعار وأوامر البيع",
                         subtitle="من عرض السعر إلى أمر البيع والفوترة الجزئية أو الكاملة", user=user)
        self.user = user or {}
        self.user_id = int(self.user.get("id") or 0)
        self.company_id = int(self.user.get("company_id") or context.current_company_id())
        self.branch_id = int(self.user.get("branch_id") or context.current_branch_id())
        self.service = SalesOrderService()
        permissions = PermissionService()
        self.can_create = permissions.has_permission_for_company(self.user_id, self.company_id, "sales.create")
        self.can_confirm = permissions.has_permission_for_company(self.user_id, self.company_id, "sales.confirm")
        self.can_invoice = permissions.has_permission_for_company(self.user_id, self.company_id, "sales.invoice_from_order")
        self.can_cancel = permissions.has_permission_for_company(self.user_id, self.company_id, "sales.cancel")
        self.can_deliver = (permissions.has_permission_for_company(self.user_id, self.company_id, "sales.delivery.create")
                            and permissions.has_permission_for_company(self.user_id, self.company_id, "sales.delivery.post"))
        self.can_return = permissions.has_permission_for_company(
            self.user_id, self.company_id, "sales.return"
        )
        if self.can_create:
            primary_button(self.actions, "+ عرض سعر", self.new_quotation, width=125).pack(side=START, padx=4)
        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        self.search = SearchBar(bar.row, "ابحث برقم العرض أو أمر البيع أو العميل...", on_search=self.refresh, width=380)
        bar.add(self.search)
        self.count = Badge(bar.row, "", "info")
        bar.add(self.count, side=END, padx=8)
        self.table = DataTable(self.body, COLUMNS, empty_text="لا توجد عروض أسعار أو أوامر بيع")
        self.table.pack(fill="both", expand=True)
        foot = ctk.CTkFrame(self.body, fg_color="transparent")
        foot.pack(fill="x", pady=(10, 0))
        if self.can_create:
            subtle_button(foot, "إرسال العرض", self.send_selected, width=115).pack(side=START, padx=4)
        if self.can_confirm:
            primary_button(foot, "تأكيد أمر البيع", self.confirm_selected, width=145).pack(side=START, padx=4)
        if self.can_invoice:
            subtle_button(foot, "إنشاء فاتورة", self.invoice_selected, width=120).pack(side=START, padx=4)
        if self.can_cancel:
            danger_button(foot, "إلغاء الأمر", self.cancel_selected, width=115).pack(side=START, padx=4)
        if self.can_deliver:
            subtle_button(foot, "تسليم جزئي / كامل", self.deliver_selected, width=155).pack(side=START, padx=4)
        if self.can_return:
            subtle_button(foot, "مرتجع تسليم", self.return_delivery_selected, width=120).pack(side=START, padx=4)
        self.refresh()

    def refresh(self):
        rows = self.service.list_for_company(self.company_id, self.search.get().strip(), self.branch_id)
        self.table.set_rows(rows, {"total": lambda value: f"{float(value or 0):,.2f}"})
        self.count.set(f"{len(rows)} مستند")

    def new_quotation(self):
        QuotationDialog(self, self.user, self.refresh)

    def _selected(self):
        if self.table.selected is None:
            messagebox.showinfo("عروض البيع", "اختر مستنداً من الجدول أولاً", parent=self)
            return None
        return self.table.selected

    def _run(self, action, success):
        row = self._selected()
        if row is None:
            return
        try:
            completed = action(row)
            if completed is False:
                return
        except (ValueError, TransactionError) as exc:
            messagebox.showerror("تعذر تنفيذ العملية", str(exc), parent=self)
            return
        self.refresh()
        toast(self.master, success)

    def send_selected(self):
        def action(row):
            if row["status"] != "DRAFT":
                raise ValueError("إرسال العرض متاح للمسودة فقط.")
            if self.service.send_quotation(int(row["id"]), self.user_id) is False:
                raise ValueError("انتهت صلاحية عرض السعر وتم تحديث حالته إلى منتهي.")
        self._run(action, "تم إرسال عرض السعر")

    def confirm_selected(self):
        def action(row):
            if row["status"] not in {"DRAFT", "SENT"}:
                raise ValueError("المستند ليس عرض سعر قابلاً للتأكيد.")
            if not messagebox.askyesno("تأكيد أمر البيع", "سيتم اعتماد الأسعار والكميات والتحقق من المخزون. متابعة؟", parent=self):
                return False
            if self.service.confirm_order(int(row["id"]), self.user_id) is False:
                raise ValueError("انتهت صلاحية عرض السعر وتم تحديث حالته إلى منتهي.")
        self._run(action, "تم تأكيد أمر البيع")

    def invoice_selected(self):
        row = self._selected()
        if row is None:
            return
        if row["status"] not in {"CONFIRMED", "PARTIALLY_INVOICED"}:
            messagebox.showinfo("الفوترة", "لا توجد كميات قابلة للفوترة في هذا الأمر.", parent=self)
            return
        InvoiceFromOrderDialog(self, row, self.user, self.refresh)

    def deliver_selected(self):
        row = self._selected()
        if row is None:
            return
        if row["status"] not in {"CONFIRMED", "PARTIALLY_INVOICED", "INVOICED"}:
            messagebox.showinfo("التسليم", "يجب تأكيد أمر البيع أولاً.", parent=self)
            return
        SalesDeliveryDialog(self, row, self.user, self.refresh)

    def return_delivery_selected(self):
        row = self._selected()
        if row is None:
            return
        try:
            SalesDeliveryReturnChooser(self, row, self.user, self.refresh)
        except (SalesReturnError, TransactionError, ValueError) as exc:
            messagebox.showerror("المرتجعات", str(exc), parent=self)

    def cancel_selected(self):
        def action(row):
            if row["status"] not in {"DRAFT", "SENT", "CONFIRMED", "PARTIALLY_INVOICED"}:
                raise ValueError("المستند لا يمكن إلغاؤه.")
            if not messagebox.askyesno("إلغاء أمر البيع", "سيتم إلغاء الكميات المتبقية من الأمر. متابعة؟", parent=self):
                return False
            self.service.cancel_order(int(row["id"]), self.user_id)
        self._run(action, "تم إلغاء أمر البيع")
