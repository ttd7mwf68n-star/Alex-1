"""Desktop backup center with explicit, guarded restore/delete actions."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from tkinter import messagebox, filedialog, simpledialog

import customtkinter as ctk

from alexerp.database.backup import BackupManager
from alexerp.services.permission_service import PermissionService
from alexerp.services.audit_service import AuditService
from alexerp.ui.components import (
    Badge, Card, EmptyState, Page, SectionHeader, danger_button, ghost_button, primary_button,
    subtle_button,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font, icon


class BackupPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="مركز النسخ الاحتياطي",
                         subtitle="إنشاء النسخ وفحصها واستعادتها مع الاحتفاظ بنسخة أمان قبل الاستعادة", user=user)
        self.user_id = int((user or {}).get("id") or 0)
        from alexerp.config import DATABASE_BACKEND
        self.backend = DATABASE_BACKEND
        permissions = PermissionService()
        self.can_manage = permissions.has_permission(self.user_id, "backup.manage")
        self.manager = BackupManager()
        info = Card(self.body, fg_color=c("primary_soft"), border_width=0)
        info.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(info, text="💾", width=44, height=44, corner_radius=12, fg_color=c("primary"),
                     text_color="#FFFFFF", font=font(18)).pack(side=START, padx=14, pady=12)
        self.status = ctk.CTkLabel(info, text="", font=font(12, "bold"), text_color=c("text"),
                                   anchor=TEXT_ANCHOR, justify="right", wraplength=760)
        self.status.pack(side=START, fill="x", expand=True, padx=4)
        actions = ctk.CTkFrame(self.body, fg_color="transparent")
        actions.pack(fill="x", pady=(0, 10))
        if self.can_manage:
            primary_button(actions, "＋  إنشاء نسخة احتياطية الآن", self.create_backup, width=210).pack(side=START, padx=4)
            if self.backend == "sqlite":
                subtle_button(actions, "🔒  إنشاء نسخة مشفرة", self.create_encrypted_backup, width=160).pack(side=START, padx=4)
                ghost_button(actions, "📥  استيراد نسخة مشفرة", self.import_encrypted_backup, width=170).pack(side=START, padx=4)
        ghost_button(actions, f"{icon('refresh')}  تحديث القائمة", self.load_backups, width=130).pack(side=END, padx=4)
        self.list_host = ctk.CTkScrollableFrame(self.body, fg_color="transparent",
                                                scrollbar_button_color=c("border"))
        self.list_host.pack(fill="both", expand=True)
        self.load_backups()

    @staticmethod
    def _size_text(size: int) -> str:
        if size >= 1024 * 1024:
            return f"{size / (1024 * 1024):.2f} MB"
        return f"{size / 1024:.1f} KB"

    def _backup_rows(self):
        return self.manager.list_backups()[:100]

    def load_backups(self):
        for child in self.list_host.winfo_children():
            child.destroy()
        backups = self._backup_rows()
        from alexerp.config import AUTO_BACKUP_ENABLED, AUTO_BACKUP_HOUR, AUTO_BACKUP_MINUTE
        state_path = self.manager.backup_dir / ".daily_backup_state.json"
        try:
            import json
            daily_state = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            daily_state = {}
        if AUTO_BACKUP_ENABLED:
            if self.backend == "postgresql" and not self.manager.postgresql_backup_tools_available():
                schedule_text = "النسخ التلقائي يتطلب أدوات pg_dump و pg_restore"
            else:
                schedule_text = (
                    f"نسخ تلقائي يوميًا {AUTO_BACKUP_HOUR:02d}:{AUTO_BACKUP_MINUTE:02d} بالتوقيت المحلي · "
                    f"آخر نجاح: {daily_state.get('last_success') or 'لم يتم بعد'} · أثناء تشغيل البرنامج فقط"
                )
        else:
            schedule_text = "النسخ التلقائي متوقف"
        self.status.configure(text=f"عدد النسخ المعروضة: {len(backups)} · {schedule_text}")
        if not backups and not self.manager.list_encrypted_backups():
            EmptyState(self.list_host, "لا توجد نسخ احتياطية حتى الآن", "💾",
                       "أنشئ أول نسخة من الزر بالأعلى").pack(fill="x", pady=30)
            return
        if backups:
            SectionHeader(self.list_host, "النسخ المحلية", f"{len(backups)} نسخة", "🗂").pack(fill="x", pady=(4, 6))
        for backup in backups:
            card = Card(self.list_host)
            card.pack(fill="x", pady=4)
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=14, pady=10)
            ctk.CTkLabel(row, text="🗄", width=38, height=38, corner_radius=10,
                         fg_color=c("surface_alt"), font=font(16)).pack(side=START)
            texts = ctk.CTkFrame(row, fg_color="transparent")
            texts.pack(side=START, padx=10, fill="x", expand=True)
            ctk.CTkLabel(texts, text=backup.name, font=font(13, "bold"),
                         text_color=c("text"), anchor=TEXT_ANCHOR).pack(fill="x")
            try:
                stat = backup.stat()
                details = f"الحجم: {self._size_text(stat.st_size)}   ·   التاريخ: {datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')}"
            except OSError:
                details = "تعذر قراءة بيانات الملف"
            ctk.CTkLabel(texts, text=details, font=font(11), text_color=c("muted"),
                         anchor=TEXT_ANCHOR).pack(fill="x")
            Badge(row, "نسخة محلية", "muted").pack(side=START, padx=8)
            buttons = ctk.CTkFrame(row, fg_color="transparent")
            buttons.pack(side=END)
            if self.can_manage:
                danger_button(buttons, "حذف", lambda p=backup: self.delete_backup(p), width=65).pack(side="left", padx=3)
                primary_button(buttons, "استعادة هذه النسخة", lambda p=backup: self.restore_backup(p), width=140).pack(side="left", padx=3)
            ghost_button(buttons, "✓  فحص السلامة", lambda p=backup: self.verify_backup(p), width=120).pack(side="left", padx=3)

        encrypted_backups = self.manager.list_encrypted_backups()[:100]
        if encrypted_backups:
            SectionHeader(self.list_host, "النسخ المشفرة القابلة للنقل", f"{len(encrypted_backups)} نسخة",
                          "🔒").pack(fill="x", pady=(16, 6))
        for encrypted in encrypted_backups:
            card = Card(self.list_host)
            card.pack(fill="x", pady=4)
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=14, pady=10)
            ctk.CTkLabel(row, text="🔒", width=38, height=38, corner_radius=10,
                         fg_color=c("success_soft"), font=font(16)).pack(side=START)
            texts = ctk.CTkFrame(row, fg_color="transparent")
            texts.pack(side=START, padx=10, fill="x", expand=True)
            ctk.CTkLabel(texts, text=encrypted.name, font=font(13, "bold"),
                         text_color=c("text"), anchor=TEXT_ANCHOR).pack(fill="x")
            try:
                details = f"الحجم: {self._size_text(encrypted.stat().st_size)} · ملف مشفر بكلمة مرور"
            except OSError:
                details = "تعذر قراءة بيانات الملف"
            ctk.CTkLabel(texts, text=details, font=font(11), text_color=c("muted"),
                         anchor=TEXT_ANCHOR).pack(fill="x")
            if self.can_manage:
                buttons = ctk.CTkFrame(row, fg_color="transparent")
                buttons.pack(side=END)
                ghost_button(buttons, "نسخ إلى مجلد خارجي", lambda p=encrypted: self.export_encrypted_backup(p), width=150).pack(side="left", padx=3)
                primary_button(buttons, "استعادة المشفرة", lambda p=encrypted: self.restore_encrypted_backup(p), width=130).pack(side="left", padx=3)

    def _ask_backup_password(self, title: str) -> str | None:
        return simpledialog.askstring(title, "أدخل كلمة مرور النسخة (12 حرفًا على الأقل):",
                                       show="*", parent=self.winfo_toplevel())

    def create_encrypted_backup(self):
        password = self._ask_backup_password("إنشاء نسخة مشفرة")
        if password is None:
            return
        confirmation = self._ask_backup_password("تأكيد كلمة المرور")
        if confirmation is None:
            return
        if password != confirmation:
            messagebox.showerror("كلمتا المرور غير متطابقتين", "أعد المحاولة وتأكد من كتابة نفس كلمة المرور.", parent=self.winfo_toplevel())
            return
        try:
            encrypted = self.manager.create_encrypted_backup(password)
            self.status.configure(text=f"تم إنشاء نسخة مشفرة بنجاح · {encrypted.name}", text_color=c("success"))
            AuditService.record(user_id=self.user_id, company_id=int(self.user.get("company_id") or 0),
                                branch_id=int(self.user.get("branch_id") or 0), module="backup", action="create_encrypted",
                                entity_type="backup", description="إنشاء نسخة احتياطية مشفرة", after={"name": encrypted.name})
            self.load_backups()
        except Exception as exc:
            messagebox.showerror("فشل إنشاء النسخة المشفرة", str(exc), parent=self.winfo_toplevel())

    def restore_encrypted_backup(self, encrypted):
        if not messagebox.askyesno("تأكيد الاستعادة", "سيتم استبدال قاعدة التشغيل. سينشئ النظام نسخة أمان أولًا. هل تريد المتابعة؟", parent=self.winfo_toplevel()):
            return
        password = self._ask_backup_password("استعادة نسخة مشفرة")
        if password is None:
            return
        try:
            safety = self.manager.restore_encrypted_backup(encrypted, password)
            messagebox.showinfo("تمت الاستعادة", f"تمت الاستعادة بنجاح.\nنسخة الأمان: {safety.name}\nأعد تشغيل البرنامج.", parent=self.winfo_toplevel())
            self.load_backups()
        except Exception as exc:
            messagebox.showerror("فشلت الاستعادة", str(exc), parent=self.winfo_toplevel())

    def import_encrypted_backup(self):
        filename = filedialog.askopenfilename(title="اختيار نسخة مشفرة", filetypes=[("Encrypted backups", "*.db.enc"), ("All files", "*.*")], parent=self.winfo_toplevel())
        if not filename:
            return
        password = self._ask_backup_password("استيراد نسخة مشفرة")
        if password is None:
            return
        try:
            safety = self.manager.restore_encrypted_backup(Path(filename), password)
            messagebox.showinfo("تمت الاستعادة", f"تمت الاستعادة بنجاح.\nنسخة الأمان: {safety.name}\nأعد تشغيل البرنامج.", parent=self.winfo_toplevel())
            self.load_backups()
        except Exception as exc:
            messagebox.showerror("فشل استيراد النسخة", str(exc), parent=self.winfo_toplevel())

    def export_encrypted_backup(self, encrypted):
        folder = filedialog.askdirectory(title="اختيار مجلد خارجي لحفظ النسخة المشفرة", parent=self.winfo_toplevel())
        if not folder:
            return
        try:
            exported = self.manager.export_encrypted_backup(encrypted, Path(folder))
            self.status.configure(text=f"تم نسخ الملف المشفر والتحقق منه · {exported}", text_color=c("success"))
            messagebox.showinfo("اكتمل النقل", "تم نقل النسخة المشفرة والتحقق من تطابقها. النسخة المحلية لم تُحذف.", parent=self.winfo_toplevel())
        except Exception as exc:
            messagebox.showerror("فشل النقل", str(exc), parent=self.winfo_toplevel())

    def create_backup(self):
        try:
            backup = self.manager.create_backup()
            info = self.manager.verify_backup(backup)
            AuditService.record(user_id=self.user_id, company_id=int(self.user.get("company_id") or 0),
                                branch_id=int(self.user.get("branch_id") or 0), module="backup", action="create",
                                entity_type="backup", description="إنشاء نسخة احتياطية من Desktop",
                                after={"name": backup.name, "table_count": info["table_count"]})
            self.status.configure(text=f"تم إنشاء النسخة وفحصها بنجاح · {backup.name} · {info['table_count']} جدولًا",
                                  text_color=c("success"))
            self.load_backups()
        except Exception as exc:
            messagebox.showerror("فشل إنشاء النسخة", str(exc), parent=self.winfo_toplevel())

    def verify_backup(self, backup):
        try:
            info = self.manager.verify_backup(backup)
            self.status.configure(text=f"النسخة سليمة ✓ · {info['table_count']} جدولًا · SHA-256: {info['sha256'][:16]}…",
                                  text_color=c("success"))
        except Exception as exc:
            self.status.configure(text=f"فشل التحقق: {exc}", text_color=c("danger"))

    def restore_backup(self, backup):
        approved = messagebox.askyesno(
            "تأكيد الاستعادة",
            "سيتم استبدال قاعدة التشغيل بالنسخة المختارة. سينشئ النظام نسخة أمان تلقائية من الوضع الحالي أولًا.\n\n"
            "تأكد من إغلاق أي عمليات أخرى تستخدم قاعدة البيانات. هل تريد المتابعة؟",
            parent=self.winfo_toplevel(),
        )
        if not approved:
            return
        try:
            AuditService.record(user_id=self.user_id, company_id=int(self.user.get("company_id") or 0),
                                branch_id=int(self.user.get("branch_id") or 0), module="backup", action="restore_attempt",
                                entity_type="backup", description="طلب استعادة نسخة احتياطية من Desktop",
                                after={"requested_backup": backup.name})
            safety = self.manager.restore_backup(backup)
            messagebox.showinfo("تمت الاستعادة", f"تمت استعادة النسخة بنجاح.\nنسخة الأمان السابقة: {safety.name}\n\nأعد تشغيل البرنامج قبل متابعة العمل.",
                                parent=self.winfo_toplevel())
            self.load_backups()
        except Exception as exc:
            messagebox.showerror("فشلت الاستعادة", str(exc), parent=self.winfo_toplevel())

    def delete_backup(self, backup):
        if len(self.manager.list_backups()) <= 1:
            messagebox.showwarning("لا يمكن الحذف", "يجب الاحتفاظ بنسخة احتياطية واحدة على الأقل.", parent=self.winfo_toplevel())
            return
        if not messagebox.askyesno("تأكيد الحذف", f"هل تريد حذف النسخة {backup.name}؟ لا يمكن التراجع عن حذفها.", parent=self.winfo_toplevel()):
            return
        try:
            AuditService.record(user_id=self.user_id, company_id=int(self.user.get("company_id") or 0),
                                branch_id=int(self.user.get("branch_id") or 0), module="backup", action="delete",
                                entity_type="backup", description="حذف نسخة احتياطية من Desktop",
                                before={"name": backup.name})
            self.manager.delete_backup(backup)
            self.load_backups()
        except Exception as exc:
            messagebox.showerror("فشل حذف النسخة", str(exc), parent=self.winfo_toplevel())
