"""Company-scoped accounting dashboard, chart of accounts, and journal views."""
from __future__ import annotations

import customtkinter as ctk

from alexerp.database.db import Database
from alexerp.accounting import AccountingReadService
from alexerp.services.permission_service import PermissionService
from alexerp.ui.components import (
    Badge, Card, DataTable, Page, SearchBar, SectionHeader, Tabs, Toolbar, primary_button,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font


class AccountingPage(Page):
    def __init__(self, parent, user=None, navigate=None):
        super().__init__(
            parent,
            title="الحسابات",
            subtitle="لوحة المحاسبة، دليل الحسابات، والقيود التفصيلية",
            user=user,
        )
        self.user = user or {}
        self.company_id = int(self.user.get("company_id") or 0)
        self.accounting_reads = AccountingReadService()
        self.navigate = navigate
        self.mode = "dashboard"
        permissions = PermissionService()
        user_id = int(self.user.get("id") or 0)
        self.can_create_sale = (
            permissions.has_permission(user_id, "sales.view")
            and permissions.has_permission(user_id, "sales.create")
        )
        self.can_create_purchase = (
            permissions.has_permission(user_id, "purchases.view")
            and permissions.has_permission(user_id, "purchases.create")
        )

        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        self.mode_tabs = Tabs(
            bar.row,
            (
                ("dashboard", "لوحة المحاسبة"),
                ("accounts", "دليل الحسابات"),
                ("journals", "القيود اليومية"),
                ("journal_items", "بنود القيود"),
            ),
            command=self._set_mode,
            current=self.mode,
            width=140,
        )
        bar.add(self.mode_tabs)
        self.search = SearchBar(
            bar.row,
            "بحث بالحساب أو رقم القيد أو البيان...",
            on_search=self.refresh,
            width=310,
        )
        bar.add(self.search, padx=8)
        self.search.pack_forget()
        self.status_filter = ctk.CTkOptionMenu(
            bar.row,
            values=["المرحلة فقط", "الكل"],
            command=lambda _value: self.refresh(),
            width=125,
            font=font(12),
            dropdown_font=font(12),
        )
        self.status_filter.set("المرحلة فقط")
        self.status_filter.pack(side=END, padx=4)

        self.summary = Badge(self.body, "", "info")
        self.summary.pack(anchor=TEXT_ANCHOR, pady=(0, 8))
        self.host = ctk.CTkFrame(self.body, fg_color="transparent")
        self.host.pack(fill="both", expand=True)
        self.refresh()

    def _set_mode(self, mode):
        self.mode = mode
        if mode == "dashboard":
            self.search.pack_forget()
        else:
            self.search.pack(side=START, padx=8)
        if mode == "accounts":
            self.status_filter.configure(values=["حسابات نشطة", "الكل"])
            self.status_filter.set("حسابات نشطة")
        else:
            self.status_filter.configure(values=["المرحلة فقط", "الكل"])
            self.status_filter.set("المرحلة فقط")
        if mode == "journal_items":
            self.status_filter.pack(side=END, padx=4)
        else:
            self.status_filter.pack_forget()
        self.refresh()

    def _clear_host(self):
        for child in self.host.winfo_children():
            child.destroy()

    def _set_summary(self, text, tone="info"):
        self.summary.set(text, tone)

    def _open_page(self, key, method=None):
        if not self.navigate:
            return
        page = self.navigate(key)
        if page is not None and method and callable(getattr(page, method, None)):
            page.after(50, getattr(page, method))

    @staticmethod
    def _money(value):
        return f"{float(value or 0):,.2f}"

    def _overview_document(self, table, date_column, company_id):
        return Database.connect().execute(
            f"""SELECT
                    SUM(CASE WHEN UPPER(COALESCE(status,''))='DRAFT' THEN 1 ELSE 0 END) AS drafts,
                    SUM(CASE WHEN UPPER(COALESCE(status,'')) NOT IN
                        ('DRAFT','CANCELLED','CANCELED','VOID')
                        AND COALESCE(remaining_amount,0)>0 THEN 1 ELSE 0 END) AS open_count,
                    COALESCE(SUM(CASE WHEN UPPER(COALESCE(status,'')) NOT IN
                        ('DRAFT','CANCELLED','CANCELED','VOID')
                        THEN remaining_amount ELSE 0 END),0) AS open_amount,
                    SUM(CASE WHEN UPPER(COALESCE(status,'')) NOT IN
                        ('DRAFT','CANCELLED','CANCELED','VOID')
                        AND COALESCE(remaining_amount,0)>0
                        AND COALESCE(due_date,{date_column})<date('now')
                        THEN 1 ELSE 0 END) AS overdue_count
                FROM {table}
                WHERE company_id=?""",
            (company_id,),
        ).fetchone()

    def _overview_card(self, parent, title, glyph, summary_rows, action, command):
        card = Card(parent)
        SectionHeader(card, title, glyph=glyph).pack(
            fill="x", padx=16, pady=(14, 8)
        )
        body = ctk.CTkFrame(card, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=16)
        for caption, value in summary_rows:
            row = ctk.CTkFrame(body, fg_color="transparent")
            row.pack(fill="x", pady=4)
            ctk.CTkLabel(
                row, text=caption, font=font(12), text_color=c("muted"), anchor="e"
            ).pack(side=START)
            ctk.CTkLabel(
                row, text=value, font=font(12, "bold"), text_color=c("text"), anchor="w"
            ).pack(side=END)
        if action and command:
            primary_button(card, action, command, width=145).pack(
                anchor="e", padx=14, pady=(8, 14)
            )
        else:
            ctk.CTkFrame(card, height=8, fg_color="transparent").pack()
        return card

    def _load_dashboard(self):
        self._clear_host()
        if not self.company_id:
            self._set_summary("لا توجد شركة مرتبطة بهذا المستخدم", "warning")
            return
        conn = Database.connect()
        sales = self._overview_document("sales_invoices", "invoice_date", self.company_id)
        purchases = self._overview_document("purchase_invoices", "invoice_date", self.company_id)
        bank = conn.execute(
            "SELECT COUNT(*) AS count,COALESCE(SUM(current_balance),0) AS balance "
            "FROM bank_accounts WHERE company_id=? AND COALESCE(is_active,1)=1",
            (self.company_id,),
        ).fetchone()
        cash = conn.execute(
            "SELECT COUNT(*) AS count,COALESCE(SUM(current_balance),0) AS balance "
            "FROM cash_boxes WHERE company_id=? AND COALESCE(is_active,1)=1",
            (self.company_id,),
        ).fetchone()

        grid = ctk.CTkFrame(self.host, fg_color="transparent")
        grid.pack(fill="both", expand=True)
        for column in range(2):
            grid.grid_columnconfigure(column, weight=1, uniform="accounting-overview")
        sales_action = (
            lambda: self._open_page("sales", "add")
            if self.can_create_sale else None
        )
        purchase_action = (
            lambda: self._open_page("purchases", "add")
            if self.can_create_purchase else None
        )
        cards = [
            (
                "فواتير العملاء", "🧾",
                [
                    ("فواتير بانتظار الترحيل", f"{int(sales['drafts'] or 0):,}"),
                    ("فواتير مفتوحة للتحصيل", f"{int(sales['open_count'] or 0):,}"),
                    ("إجمالي المتبقي", self._money(sales["open_amount"])),
                    ("فواتير متأخرة", f"{int(sales['overdue_count'] or 0):,}"),
                ],
                "فاتورة بيع جديدة" if self.can_create_sale else None,
                sales_action if self.can_create_sale else None,
            ),
            (
                "فواتير الموردين", "🏭",
                [
                    ("فواتير بانتظار الترحيل", f"{int(purchases['drafts'] or 0):,}"),
                    ("فواتير مفتوحة للدفع", f"{int(purchases['open_count'] or 0):,}"),
                    ("إجمالي المتبقي", self._money(purchases["open_amount"])),
                    ("فواتير متأخرة", f"{int(purchases['overdue_count'] or 0):,}"),
                ],
                "فاتورة شراء جديدة" if self.can_create_purchase else None,
                purchase_action if self.can_create_purchase else None,
            ),
            (
                "الحسابات البنكية", "🏦",
                [
                    ("حسابات نشطة", f"{int(bank['count'] or 0):,}"),
                    ("الرصيد المسجل", self._money(bank["balance"])),
                    ("المطابقة البنكية", "غير متاحة بعد"),
                ],
                "دليل الحسابات", lambda: self._set_mode("accounts"),
            ),
            (
                "الصناديق النقدية", "💵",
                [
                    ("صناديق نشطة", f"{int(cash['count'] or 0):,}"),
                    ("الرصيد المسجل", self._money(cash["balance"])),
                    ("المطابقة النقدية", "غير متاحة بعد"),
                ],
                "القيود اليومية", lambda: self._set_mode("journals"),
            ),
        ]
        for index, (title, glyph, rows, action, callback) in enumerate(cards):
            column = 1 - index % 2 if START == "right" else index % 2
            row = index // 2
            self._overview_card(grid, title, glyph, rows, action, callback).grid(
                row=row, column=column, padx=7, pady=7, sticky="nsew"
            )
        grid.grid_rowconfigure(0, weight=1)
        grid.grid_rowconfigure(1, weight=1)
        self._set_summary("ملخص فواتير العملاء والموردين والأرصدة النقدية للشركة")

    def _load_accounts(self):
        query = self.search.get().strip()
        sql = """SELECT coa.account_code,coa.account_name,at.name AS account_type,
                        coa.account_level,coa.is_header,coa.allow_posting,coa.is_active,
                        co.currency_code,co.name AS company_name
                 FROM chart_of_accounts coa
                 LEFT JOIN account_types at ON at.id=coa.account_type_id
                 JOIN companies co ON co.id=coa.company_id
                 WHERE coa.company_id=?"""
        args: list[object] = [self.company_id]
        if self.status_filter.get() == "حسابات نشطة":
            sql += " AND COALESCE(coa.is_active,1)=1"
        if query:
            sql += " AND (coa.account_code LIKE ? OR coa.account_name LIKE ?)"
            args.extend((f"%{query}%", f"%{query}%"))
        sql += " ORDER BY coa.account_code LIMIT 500"
        rows = [dict(row) for row in Database.connect().execute(sql, args).fetchall()]
        for row in rows:
            row["kind"] = "رئيسي" if row["is_header"] else "فرعي"
            row["posting"] = "نعم" if row["allow_posting"] else "لا"
            row["status"] = "ACTIVE" if row["is_active"] else "موقوف"
            row["currency_code"] = row["currency_code"] or "EGP"
        columns = [
            ("account_code", "الكود", 105, "w"),
            ("account_name", "اسم الحساب", 205, "w"),
            ("account_type", "النوع", 130, "w"),
            ("kind", "المستوى", 80, "w"),
            ("posting", "يسمح بالترحيل", 105, "w"),
            ("currency_code", "العملة", 75, "w"),
            ("company_name", "الشركة", 130, "w"),
            ("status", "الحالة", 85, "w"),
        ]
        self._show_table(columns, rows, f"عدد الحسابات المعروضة: {len(rows)}")

    def _load_journals(self):
        query = self.search.get().strip()
        rows = [dict(row) for row in self.accounting_reads.search_journal_entries(
            self.company_id, query, limit=500,
        )]
        for row in rows:
            row["status"] = "POSTED" if row["is_posted"] else "DRAFT"
        columns = [
            ("entry_date", "التاريخ", 110, "w"),
            ("entry_number", "رقم القيد", 130, "w"),
            ("description", "البيان", 250, "w"),
            ("reference_type", "نوع المرجع", 125, "w"),
            ("reference_id", "رقم المرجع", 100, "e"),
            ("status", "الحالة", 95, "w"),
        ]
        self._show_table(columns, rows, f"عدد القيود المعروضة: {len(rows)}")

    def _load_journal_items(self):
        query = self.search.get().strip()
        rows = [dict(row) for row in self.accounting_reads.search_journal_lines(
            self.company_id, query,
            posted_only=self.status_filter.get() == "المرحلة فقط", limit=500,
        )]
        for row in rows:
            row["account"] = f"{row['account_code']} {row['account_name']}"
            row["label"] = row["line_description"] or row["entry_description"] or ""
            row["matching_number"] = "—"
            row["debit"] = self._money(row["debit"])
            row["credit"] = self._money(row["credit"])
        columns = [
            ("entry_date", "التاريخ", 100, "w"),
            ("entry_number", "القيد", 125, "w"),
            ("account", "الحساب", 210, "w"),
            ("partner_name", "الطرف", 145, "w"),
            ("label", "البيان", 200, "w"),
            ("debit", "مدين", 105, "e"),
            ("credit", "دائن", 105, "e"),
            ("matching_number", "رقم المطابقة", 100, "w"),
        ]
        self._show_table(columns, rows, f"عدد بنود القيود المعروضة: {len(rows)}")

    def _show_table(self, columns, rows, summary):
        self._clear_host()
        self._set_summary(summary)
        self.table = DataTable(self.host, columns, empty_text="لا توجد بيانات مطابقة")
        self.table.pack(fill="both", expand=True)
        self.table.set_rows(rows)

    def refresh(self):
        try:
            if not self.company_id:
                self._set_summary("لا توجد شركة مرتبطة بهذا المستخدم", "warning")
                return
            if self.mode == "dashboard":
                self.status_filter.pack_forget()
                self._load_dashboard()
            elif self.mode == "accounts":
                self.status_filter.pack(side=END, padx=4)
                self._load_accounts()
            elif self.mode == "journal_items":
                self._load_journal_items()
            else:
                self._load_journals()
        except Exception as exc:
            self._set_summary(f"تعذر تحميل بيانات المحاسبة: {exc}", "danger")
            self._clear_host()
