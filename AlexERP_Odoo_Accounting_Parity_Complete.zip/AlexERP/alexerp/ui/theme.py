"""
AlexERP — Business Management System
Desktop design tokens. The Mobile/Web interface has its own theme and can
be aligned with this palette in a later phase.

Every colour is a (light, dark) tuple, which customtkinter switches
automatically when the appearance mode changes.
"""

from __future__ import annotations

# ----------------------------------------------------------------------
# Brand identity
# ----------------------------------------------------------------------

BRAND_NAME = "AlexERP"
BRAND_TAGLINE_EN = "BUSINESS MANAGEMENT SYSTEM"
BRAND_TAGLINE_AR = "إدارة أعمالك من مكان واحد"
BRAND_MODULES_AR = "المبيعات • المخازن • الحسابات • المشتريات • التقارير"
BRAND_MARK = "A"

# Odoo-inspired purple application shell with teal actions.
COLORS = {
    "bg":            ("#F7F7F7", "#0B1220"),
    "surface":       ("#FFFFFF", "#121A2B"),
    "surface_alt":   ("#F1F1F1", "#182238"),
    "surface_hover": ("#E8E8E8", "#1E2A44"),
    "border":        ("#D8DADD", "#243149"),
    "text":          ("#212529", "#E8EDF7"),
    "muted":         ("#6C757D", "#8D9AB2"),
    "primary":       ("#017E84", "#38A7AB"),
    "primary_hover": ("#01666A", "#53B8BC"),
    "primary_soft":  ("#E0F1F0", "#163537"),
    "success":       ("#16A34A", "#3FC37A"),
    "success_soft":  ("#DDF6E7", "#123524"),
    "warning":       ("#C77700", "#F2A93B"),
    "warning_soft":  ("#FFF1D6", "#3A2B0F"),
    "danger":        ("#D92D20", "#F2665B"),
    "danger_soft":   ("#FDE4E1", "#3B1716"),
    "info":          ("#017E84", "#38BDF8"),
    "info_soft":     ("#E0F1F0", "#0F2E40"),
    "sidebar":       ("#714B67", "#261D27"),
    "sidebar_hover": ("#835B78", "#382A39"),
    "sidebar_active": ("#017E84", "#176F73"),
    "sidebar_text":  ("#FFFFFF", "#F2EAF0"),
    "sidebar_muted": ("#E0D1DC", "#C4B4C0"),
    "sidebar_line":  ("#8A6A80", "#49384A"),
}

# Chart series, in order.
SERIES = ["primary", "success", "warning", "info", "danger"]

# ----------------------------------------------------------------------
# Typography
# ----------------------------------------------------------------------

# Preferred UI fonts in order.  Segoe UI ships with Windows and has full
# Arabic shaping; the rest are fallbacks for macOS / Linux.
FONT_CANDIDATES = (
    "Segoe UI", "Tahoma", "Noto Sans Arabic UI", "Noto Sans Arabic",
    "Noto Sans", "Geeza Pro", "Arial", "DejaVu Sans",
)
FONT = FONT_CANDIDATES[0]
_FONT_RESOLVED = False

TYPE = {
    "display": 26,
    "h1": 22,
    "h2": 17,
    "h3": 15,
    "body": 13,
    "small": 12,
    "tiny": 11,
}

# Spacing / radius scale (pixels).
SPACE = {"xs": 4, "sm": 8, "md": 12, "lg": 16, "xl": 24, "xxl": 32}
RADIUS = {"sm": 4, "md": 6, "lg": 8, "xl": 10}
CONTROL_HEIGHT = 38


def _resolve_font_family() -> str:
    """Pick the first installed font from FONT_CANDIDATES (once a Tk root exists)."""
    global FONT, _FONT_RESOLVED
    if _FONT_RESOLVED:
        return FONT
    try:
        import tkinter as _tk
        import tkinter.font as _tkfont
        if _tk._default_root is None:  # no root yet: try again later
            return FONT
        families = {f.lower() for f in _tkfont.families()}
        for name in FONT_CANDIDATES:
            if name.lower() in families:
                FONT = name
                break
        _FONT_RESOLVED = True
    except Exception:
        pass
    return FONT


def font(size: int | str = 13, weight: str = "normal"):
    """Font tuple. ``size`` may be a number or a TYPE key ("h1", "body", ...)."""
    if isinstance(size, str):
        size = TYPE.get(size, 13)
    return (_resolve_font_family(), size, weight)


def c(name: str):
    """Colour tuple for customtkinter widgets."""
    return COLORS[name]


def resolve(name: str, mode: str) -> str:
    """Single colour for raw canvas drawing. mode: 'Light' or 'Dark'."""
    light, dark = COLORS[name]
    return dark if str(mode).lower() == "dark" else light


# ----------------------------------------------------------------------
# Right-to-left layout helpers (Arabic UI)
# ----------------------------------------------------------------------

RTL = True
START = "right" if RTL else "left"     # where reading starts
END = "left" if RTL else "right"
TEXT_ANCHOR = "e" if RTL else "w"       # anchor for text labels
JUSTIFY = "right" if RTL else "left"


def flip_anchor(anchor: str) -> str:
    """Mirror a legacy LTR anchor ("w"/"e") for the RTL layout."""
    if not RTL:
        return anchor
    return {"w": "e", "e": "w", "nw": "ne", "ne": "nw", "sw": "se", "se": "sw"}.get(anchor, anchor)


# ----------------------------------------------------------------------
# Unified icon set (one glyph per concept, used everywhere)
# ----------------------------------------------------------------------

ICONS = {
    "dashboard": "🏠", "ai": "✨", "products": "📦", "inventory": "🏬",
    "sales": "🧾", "purchases": "🛒", "accounting": "📒", "reports": "📊",
    "audit": "🛡", "backups": "💾", "customers": "👥", "suppliers": "🏭",
    "add": "＋", "edit": "✎", "delete": "🗑", "refresh": "⟳", "search": "🔍",
    "clear": "✕", "close": "✕", "menu": "☰", "collapse": "⇥", "expand": "⇤",
    "logout": "⎋", "settings": "⚙", "moon": "☾", "sun": "☀", "cancel": "⊘",
    "return": "↩", "money": "💰", "trend": "📈", "warning": "⚠", "check": "✓",
    "stock": "📦", "payment": "💸", "receipt": "💵", "filter": "⏷",
    "calendar": "📅", "send": "➤", "chat": "💬", "shield": "🛡", "user": "👤",
}


def icon(name: str) -> str:
    return ICONS.get(name, "•")


# ----------------------------------------------------------------------
# Document status vocabulary (tables, badges, mobile)
# ----------------------------------------------------------------------

STATUS = {
    "POSTED": ("مرحّلة", "success"),
    "PAID": ("مسددة", "success"),
    "ACTIVE": ("نشط", "success"),
    "DRAFT": ("مسودة", "muted"),
    "PENDING": ("معلّقة", "warning"),
    "PARTIAL": ("مسددة جزئياً", "warning"),
    "CANCELLED": ("ملغاة", "danger"),
    "CANCELED": ("ملغاة", "danger"),
    "VOID": ("ملغاة", "danger"),
    "RETURNED": ("مرتجعة", "info"),
    "IN_STOCK": ("متوفر", "success"),
    "LOW_STOCK": ("منخفض", "warning"),
    "OUT_OF_STOCK": ("نفد", "danger"),
}


def status_info(value) -> tuple[str, str]:
    """(Arabic label, tone) for a status code; unknown values pass through."""
    key = str(value or "").strip().upper()
    if key in STATUS:
        return STATUS[key]
    return (str(value or "—"), "muted")
