"""
AlexERP — Business Management System
Products page: search, add, edit, delete, adjust stock.
"""

from __future__ import annotations

import sqlite3
from tkinter import messagebox

import customtkinter as ctk

from alexerp.services.product_service import ProductService
from alexerp.services.permission_service import PermissionService
from alexerp.ui.components import (
    Badge, DataTable, Dialog, Page, SearchBar, Toolbar, danger_button, entry, field,
    ghost_button, primary_button, subtle_button, toast,
)
from alexerp.ui.theme import END, START, TEXT_ANCHOR, c, font, icon

COLUMNS = [
    ("code", "الكود", 90, "w"),
    ("barcode", "الباركود", 110, "w"),
    ("name", "اسم المنتج", 220, "w"),
    ("purchase_price", "سعر الشراء", 95, "e"),
    ("sale_price", "سعر البيع", 95, "e"),
    ("quantity", "الكمية", 70, "e"),
    ("minimum_stock", "الحد الأدنى", 85, "e"),
    ("stock_state", "الحالة", 80, "w"),
]


def _num(text) -> float:
    text = str(text or "").strip().replace(",", "")
    return float(text or 0)


class ProductDialog(Dialog):
    FIELDS = [
        ("code", "الكود"), ("barcode", "الباركود"), ("name", "اسم المنتج *"),
        ("purchase_price", "سعر الشراء"), ("sale_price", "سعر البيع"),
        ("minimum_stock", "الحد الأدنى للمخزون"), ("maximum_stock", "الحد الأقصى للمخزون"),
        ("description", "ملاحظات"),
    ]
    NUMERIC = {"purchase_price", "sale_price", "minimum_stock", "maximum_stock"}
    LAYOUT = [("code", "barcode"), ("name",), ("purchase_price", "sale_price"),
              ("minimum_stock", "maximum_stock"), ("description",)]

    def __init__(self, parent, service: ProductService, product=None, on_saved=None, user=None):
        super().__init__(parent, "تعديل منتج" if product else "منتج جديد", 600, 600,
                         subtitle="بيانات الصنف والأسعار وحدود المخزون", glyph="📦")
        self.service, self.product, self.on_saved = service, product, on_saved
        self.user = user or {}
        self.user_id = int(self.user.get("id") or 0)
        self.inputs: dict[str, ctk.CTkEntry] = {}
        labels = dict(self.FIELDS)

        form = ctk.CTkFrame(self, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=24, pady=(14, 0))
        for r, keys in enumerate(self.LAYOUT):
            for i, key in enumerate(keys):
                caption = labels[key].replace(" *", "")
                fr, e = field(form, caption, lambda p: entry(p, "0" if key in self.NUMERIC else ""),
                              required=key == "name")
                span = 2 if len(keys) == 1 else 1
                col = (1 - i) if (START == "right" and span == 1) else i
                fr.grid(row=r, column=col, columnspan=span, sticky="ew", padx=6, pady=6)
                if product is not None and product[key] is not None:
                    e.insert(0, f"{product[key]:g}" if key in self.NUMERIC else str(product[key]))
                if key in self.NUMERIC:
                    e.bind("<KeyRelease>", lambda _e: self._update_margin(), add="+")
                e.bind("<Return>", lambda _e: self.save(), add="+")
                self.inputs[key] = e
        form.grid_columnconfigure(0, weight=1, uniform="f")
        form.grid_columnconfigure(1, weight=1, uniform="f")

        self.margin = Badge(self, "", "muted")
        self.margin.pack(anchor=TEXT_ANCHOR, padx=30, pady=(4, 0))
        self.error.pack(fill="x", padx=30, pady=(6, 0))
        buttons = [("حفظ", self.save, "primary")]
        if product is None:
            buttons.append(("حفظ وإضافة آخر", lambda: self.save(keep_open=True), "subtle"))
        buttons.append(("إلغاء", self.destroy, "ghost"))
        self.footer(buttons, width=140)
        self._update_margin()
        self.after(150, lambda: self.inputs["name" if product else "code"].focus())

    def _update_margin(self):
        try:
            cost = _num(self.inputs["purchase_price"].get())
            price = _num(self.inputs["sale_price"].get())
        except ValueError:
            self.margin.set("أدخل أرقاماً صحيحة في الأسعار", "danger")
            return
        if price <= 0:
            self.margin.set("هامش الربح يظهر بعد إدخال سعر البيع", "muted")
            return
        profit = price - cost
        pct = profit / price * 100
        tone = "success" if profit > 0 else "danger"
        self.margin.set(f"هامش الربح: {profit:,.2f}  ({pct:.1f}%)", tone)

    def save(self, keep_open=False):
        data: dict[str, object] = {k: e.get().strip() for k, e in self.inputs.items()}
        name = data["name"]
        if not isinstance(name, str) or not name:
            self.error.configure(text="اسم المنتج مطلوب")
            self.inputs["name"].focus()
            return
        try:
            numbers = {}
            for k in self.NUMERIC:
                numbers[k] = _num(data[k])
            if any(value < 0 for value in numbers.values()):
                raise ValueError("لا يمكن إدخال قيم سالبة")
            data.update(numbers)
            if self.product is None:
                data["company_id"] = int(self.user.get("company_id") or 0)
                branch_id = self.user.get("branch_id")
                data["branch_id"] = int(branch_id) if branch_id is not None else None
                self.service.create(actor_id=self.user_id, **data)
            else:
                self.service.update(self.product["id"], actor_id=self.user_id, **data)
        except (ValueError, PermissionError) as exc:
            msg = str(exc)
            self.error.configure(text="أدخل أرقاماً صحيحة" if "could not convert" in msg else msg)
            return
        except sqlite3.IntegrityError:
            self.error.configure(text="الكود أو الباركود مستخدم من قبل")
            return
        if self.on_saved:
            self.on_saved()
        if keep_open:
            toast(self.master, f"تم حفظ «{data['name']}»")
            for k, e in self.inputs.items():
                e.delete(0, "end")
            self.error.configure(text="")
            self._update_margin()
            self.inputs["code"].focus()
            return
        toast(self.master, "تم حفظ المنتج")
        self.destroy()


class StockDialog(Dialog):
    def __init__(self, parent, service, product, user, on_saved=None):
        super().__init__(parent, "تعديل الكمية", 460, 420,
                         subtitle=product["name"], glyph="🏬")
        self.service, self.product, self.user, self.on_saved = service, product, user, on_saved

        info = ctk.CTkFrame(self, fg_color=c("surface_alt"), corner_radius=12)
        info.pack(fill="x", padx=24, pady=(16, 6))
        ctk.CTkLabel(info, text="الكمية الحالية", font=font(12), text_color=c("muted")
                     ).pack(side=START, padx=14, pady=12)
        ctk.CTkLabel(info, text=f"{product['quantity']:g}", font=font(20, "bold"),
                     text_color=c("text")).pack(side=END, padx=14)

        form = ctk.CTkFrame(self, fg_color="transparent")
        form.pack(fill="x", padx=24)
        fr, self.delta = field(form, "مقدار التغيير (موجب للزيادة، سالب للخصم)",
                               lambda p: entry(p, "مثال: 10 أو -3"))
        fr.pack(fill="x", pady=6)
        fr, self.reason = field(form, "السبب", lambda p: entry(p, "جرد، تالف، ..."))
        fr.pack(fill="x", pady=6)
        self.delta.bind("<Return>", lambda _e: self.apply(), add="+")
        self.reason.bind("<Return>", lambda _e: self.apply(), add="+")

        self.error.pack(fill="x", padx=30, pady=(4, 0))
        self.footer([("تطبيق", self.apply, "primary"), ("إلغاء", self.destroy, "ghost")])
        self.after(150, self.delta.focus)

    def apply(self):
        try:
            self.service.adjust_stock(
                self.product["id"], float(self.delta.get()),
                self.reason.get().strip(),
                self.user["id"] if self.user is not None else None)
        except (ValueError, PermissionError) as exc:
            self.error.configure(
                text="أدخل رقماً صحيحاً" if "could not convert" in str(exc) else str(exc))
            return
        if self.on_saved:
            self.on_saved()
        toast(self.master, "تم تعديل الكمية")
        self.destroy()


class ProductsPage(Page):

    def __init__(self, parent, user=None, navigate=None):
        super().__init__(parent, title="المنتجات",
                         subtitle="إدارة الأصناف والأسعار والمخزون", user=user)
        self.service = ProductService()
        self.user_id = int((user or {}).get("id") or 0)
        self.permissions = PermissionService()
        self.can_create = self.permissions.has_permission(self.user_id, "products.create")
        self.can_update = self.permissions.has_permission(self.user_id, "products.update")
        self.can_delete = self.permissions.has_permission(self.user_id, "products.delete")
        self.can_adjust_stock = self.permissions.has_permission(self.user_id, "inventory.adjust")
        self.low_only = False

        if self.can_create:
            primary_button(self.actions, f"{icon('add')}  منتج جديد", self.add, width=140).pack(side="left", padx=4)

        bar = Toolbar(self.body)
        bar.pack(fill="x", pady=(0, 10))
        self.search = SearchBar(bar.row, "ابحث بالكود أو الباركود أو الاسم...  (Ctrl+F)",
                                on_search=self.refresh, width=380)
        bar.add(self.search)
        self.low_btn = ghost_button(bar.row, "⚠  النواقص فقط", self.toggle_low, width=140)
        bar.add(self.low_btn, padx=8)
        self.count = Badge(bar.row, "", "info")
        bar.add(self.count, side=END, padx=8)

        self.table = DataTable(self.body, COLUMNS, on_double=self.edit if self.can_update else None,
                               empty_text="لا توجد منتجات مطابقة")
        self.table.pack(fill="both", expand=True)

        foot = ctk.CTkFrame(self.body, fg_color="transparent")
        foot.pack(fill="x", pady=(10, 0))
        if self.can_update:
            subtle_button(foot, "✏  تعديل", self.edit).pack(side=START, padx=(0, 8) if START == "left" else (8, 0))
        if self.can_adjust_stock:
            subtle_button(foot, "📦  تعديل الكمية", self.adjust, width=140).pack(side=START, padx=8)
        if self.can_delete:
            danger_button(foot, "🗑  حذف", self.delete).pack(side=START, padx=8)
        Badge(foot, "اضغط مرتين على الصف للتعديل", "muted").pack(side=END)

        self.refresh()

    # -------------------------------------------------

    @staticmethod
    def _state(row):
        qty = float(row["quantity"] or 0)
        minimum = float(row["minimum_stock"] or 0)
        if qty <= 0:
            return "out_of_stock"
        if minimum and qty <= minimum:
            return "low_stock"
        return "in_stock"

    def refresh(self):
        keyword = self.search.get().strip()
        if self.low_only:
            rows = self.service.low_stock()
            if keyword:
                k = keyword.lower()
                rows = [r for r in rows if k in f"{r['code']} {r['barcode'] or ''} {r['name']}".lower()]
        elif keyword:
            rows = self.service.search(keyword)
        else:
            rows = self.service.list()
        view = []
        for r in rows:
            d = dict(r)
            d["stock_state"] = self._state(r)
            view.append(d)
        self.table.STATUS_KEYS = {"status", "stock_state"}
        self.table.set_rows(view, {
            "purchase_price": lambda v: f"{(v or 0):,.2f}",
            "sale_price": lambda v: f"{(v or 0):,.2f}",
            "quantity": lambda v: f"{(v or 0):g}",
            "minimum_stock": lambda v: f"{(v or 0):g}",
        })
        self.count.set(f"{len(rows)} منتج")

    def toggle_low(self):
        self.low_only = not self.low_only
        self.low_btn.configure(
            fg_color=c("warning_soft") if self.low_only else c("surface"),
            text_color=c("warning") if self.low_only else c("text"))
        self.refresh()

    def _selected(self, row=None):
        row = row or self.table.selected
        if row is None:
            messagebox.showinfo("المنتجات", "اختر منتجاً من الجدول أولاً")
        return row

    def add(self):
        if not self.can_create:
            return
        ProductDialog(self, self.service, on_saved=self.refresh, user=self.user)

    def edit(self, row=None):
        if not self.can_update:
            return
        row = self._selected(row if isinstance(row, (dict, sqlite3.Row)) else None)
        if row is not None:
            ProductDialog(self, self.service, row, self.refresh, user=self.user)

    def adjust(self):
        if not self.can_adjust_stock:
            return
        row = self._selected()
        if row is not None:
            StockDialog(self, self.service, row, self.user, self.refresh)

    def delete(self):
        if not self.can_delete:
            return
        row = self._selected()
        if row is None:
            return
        if messagebox.askyesno("حذف", f"حذف المنتج «{row['name']}»؟"):
            try:
                self.service.delete(row["id"], actor_id=self.user_id)
            except PermissionError as exc:
                messagebox.showerror("حذف", str(exc), parent=self.winfo_toplevel())
                return
            except sqlite3.IntegrityError:
                messagebox.showerror(
                    "حذف", "لا يمكن حذف منتج له حركات أو فواتير مرتبطة.")
                return
            toast(self, "تم حذف المنتج", "warning")
            self.refresh()
