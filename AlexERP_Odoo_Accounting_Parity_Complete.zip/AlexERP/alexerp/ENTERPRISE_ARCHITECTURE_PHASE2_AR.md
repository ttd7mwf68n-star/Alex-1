# Alex ERP — المرحلة المعمارية الثانية: فصل نواة القيود وتحديد اعتماديات الكود

> هذا التقرير يوثق حالة المشروع عند نهاية المرحلة الثانية. توصيات نقل قراءات الأستاذ والفترات الواردة فيه نُفذت في [تقرير المرحلة الثالثة](ENTERPRISE_ARCHITECTURE_PHASE3_AR.md).

## الملخص التنفيذي

فصلت أول قدرة محاسبية مشتركة لها مالك واضح: إنشاء قيد الأستاذ العام والتحقق منه وعكسه. أصبحت `alexerp.accounting` الحزمة المالكة لـ`AccountingService` و`AccountingRepository`. تستورد تطبيقات الأعمال من واجهتها الجديدة، وتبقى المسارات القديمة في `services/accounting_service.py` و`repositories/accounting_repository.py` كواجهات إعادة تصدير انتقالية.

فصلت ملفات manifests أيضًا بين `depends` للوحدات التقنية المطلوبة و`integrates_with` للتكامل الوظيفي بين تطبيقات المستخدم. أُضيف `accounting_core` بوصفه وحدة تقنية (`application: false`) تشير إلى حزمة Python الفعلية، وأُعلنت تطبيقات المحاسبة والمبيعات والمشتريات والعملاء والتسويات والفترات والتقارير وذكاء الأعمال كمستهلكين تقنيين لها.

## خريطة الاعتماديات المؤكدة في الشيفرة

### مزوّد دفتر القيود

- `alexerp/accounting/posting_service.py::AccountingService.create_entry` هو الممر الفعلي لإنشاء قيد: يتحقق من توازن المبالغ، وصحة الشركة/الفرع والحساب ومركز التكلفة، وكون الحساب نشطًا وقابلًا للترحيل، وصلاحية الفترة، وتكرار المرجع ورقم القيد، ثم يكتب الرأس والبنود عبر `alexerp/accounting/repository.py::AccountingRepository`.
- `AccountingService.reverse_entry` يعكس البنود من دون حذف القيد الأصلي، مستخدمًا `reference_type='REVERSAL'` ومرجع القيد الأصلي.
- يستخدم المزود `Database` و`transaction` و`tenancy` مباشرة. `alexerp/database/transaction.py::transaction` يفتح `BEGIN IMMEDIATE` للعمل الخارجي ويستخدم savepoints عند التعشيق؛ لذلك استدعاء الترحيل داخل معاملة مستند يظل ذريًا وفق السلوك المختبر الحالي.

### مستهلكو Accounting Core الفعليون

| المجال | المستهلك | مواضع الاستخدام المؤكدة |
|---|---|---|
| المبيعات | `SalesService` | ينشئ قيد الفاتورة، ويعكس قيد البيع وعند الحاجة قيد التسليم، وله مسار قديم لإنشاء قيد `SALE_DELIVERY`؛ `sales_service.py:224, 400-408, 510` |
| التسليم | `SalesDeliveryService` | ينشئ قيد تكلفة البضاعة/المخزون بمرجع مستند التسليم؛ `sales_delivery_service.py:159` |
| المرتجعات | `SalesReturnService` | ينشئ قيد `SALE_RETURN` ويحدث رصيد العميل؛ `sales_return_service.py:392` |
| المشتريات | `PurchaseService` | ينشئ قيد فاتورة المورد ويعكسه عند الإلغاء؛ `purchase_service.py:104,155` |
| القبوض | `ReceiptService` | يرحّل سند القبض ويعكس قيده عند الإلغاء؛ `receipt_service.py:123,174` |
| المدفوعات | `PaymentService` | يرحّل سند الصرف ويعكس قيده عند الإلغاء؛ `payment_service.py:44,81` |
| التسويات المالية للعميل | `CustomerFinancialNoteService` | يرحّل المذكرة المالية ويعكسها؛ `customer_financial_note_service.py:199,259`، وتظهر في مساحة التسويات |
| إقفال السنة | `FiscalYearClosingService` | ينشئ قيد الإقفال؛ `fiscal_year_closing_service.py:246` |

هذه استيرادات/استدعاءات فعلية لخدمة الترحيل وليست استنتاجًا من أسماء التطبيقات أو `integrates_with`. سجل `python_import_graph.json` يحتوي رسم AST للاستيرادات الساكنة وحواف نقاط دخول الصفحات التي تُحل من manifests؛ لا يدّعي أنه call graph كامل.

## اقتران موجود خارج واجهة الترحيل

فصل موفر الكتابة لا يزيل كل اقتران ببيانات الأستاذ العام. رصدت مسارات قراءة مباشرة خارج `AccountingService`:

- `FiscalPeriodService` يقرأ `journal_entries/journal_details` للتحقق قبل إغلاق فترة (`fiscal_period_service.py:102-117`).
- `FiscalYearClosingService` يقرأ `chart_of_accounts` و`journal_entries/journal_details` و`accounting_periods` مباشرة قبل إنشاء قيد الإقفال (`fiscal_year_closing_service.py:98-180,271-290`).
- مستودعات الميزانية والأستاذ العام والأرباح والخسائر وميزان المراجعة تنفذ استعلامات SQL على جداول الأستاذ، بينما `BusinessIntelligenceService` وواجهتا المحاسبة والفترات تحتويان استعلامات مباشرة أيضًا.
- `SalesService` يفحص مباشرة وجود قيد `SALE_DELIVERY` عند إلغاء الفاتورة (`sales_service.py:404`).
- إعدادات المبيعات والعملاء وواجهة البيع تلامس `chart_of_accounts` مباشرة؛ إنشاء الحساب الفرعي للعميل موجود في `CustomerService.ensure_customer_account` و`_ensure_receivable_account`.

هذه علاقات مخطط/قراءة مستقلة عن import إلى موفر القيد؛ يجب تحويلها لاحقًا إلى خدمات قراءة أو مستودعات يملكها `accounting_core` قبل الادعاء بأن حدود الوحدة مغلقة.

## خدمات مالية مشتركة لم تُنقل عمدًا

- `PartyBalanceService` ليس دفتر الأستاذ العام: يحسب ويحدّث الرصيد الجاري من فواتير البيع والشراء والقبوض والدفعات والمرتجعات (`party_balance_service.py:17-63`). نقله إلى حزمة الأستاذ سيصنع حدًا خاطئًا؛ الأنسب تحليل طبقة subledger/party balances وعقود تحديثها مع المجالات.
- `InvoiceSettlementService` يملك تخصيص القبوض والمدفوعات للفواتير، وعكس التخصيص، وتقادم الأرصدة وكشوف الحساب. يقرأ ويكتب جداول الفواتير والقبوض/المدفوعات مباشرة (`invoice_settlement_service.py`, methods `allocate_receipt`, `allocate_payment`, `reverse_*_allocations`, `_aging`, and `_statement`). هو قدرة مالية مشتركة، لكنها ليست ترحيل أستاذ عام؛ تحتاج حدًا/حزمة منفصلة بعد إزالة الكتابة المتبادلة من الخدمات.
- `SalesService._record_invoice_receipt` ينشئ `receipts` و`receipt_allocations` مباشرة (`sales_service.py:281-298`). استدعاء `ReceiptService` بلا عقد خاص قد يضيف قيد `RECEIPT` لا يضيفه المسار الحالي؛ يجب الحفاظ على هذا الفرق في أي استخراج.
- `CustomerService` يربط العميل بحساب الذمم وينشئ حسابًا فرعيًا في `chart_of_accounts`; هذه وظيفة تكامل طرف/دفتر فرعي، لا وظيفة ترحيل قيد.

## تغييرات هذه المرحلة

- نُقلت الخدمة ومستودعها إلى `alexerp/accounting/` دون تغيير منطق الأعمال أو توقيعات الدوال.
- عُدلت المستهلكات الإنتاجية الثمانية لتستورد `AccountingService` من `alexerp.accounting`.
- بقي المساران القديمان كـshims لضمان انتقال تدريجي.
- أصبح لكل manifest تطبيق `integrates_with` لعلاقات التكامل السابقة، بينما `depends` يسجل الاعتماد التقني على `accounting_core` حيث تأكد الاستهلاك المباشر أو الاعتماد على مخطط الأستاذ.
- يولد `module_dependency_graph.json` مستويي الاعتماد والتكامل، ويولد `python_import_graph.json` imports Python الفعلية وحواف نقاط الدخول. أضيفت اختبارات لمنع رجوع المستهلكين إلى المسارات القديمة وكشف انحراف الرسوم عن المصدر.
- يحصي الرسم الحالي 132 وحدة Python داخلية، و368 حافة استيراد ساكنة، و18 نقطة دخول ديناميكية للتطبيقات؛ ولا تُحتسب الاختبارات أو SQL النصي ضمن حواف الاستيراد.

## الخطوة التالية الآمنة

1. إنشاء واجهات قراءة محاسبية لعمليات البحث عن قيد مرجعي، التحقق من وجود أثر، ميزان الفترة/الحساب، والتقارير؛ نقل SQL المباشر إليها تدريجيًا مع الحفاظ على الاستعلامات ونطاق الشركة.
2. نقل إدارة الفترة والإقفال السنوي إلى خدمات محاسبية تملك مخطط الأستاذ، أو إبقاؤها كمجال `fiscal` يعتمد على واجهة محاسبية صريحة بدل SQL مباشر.
3. فصل `InvoiceSettlementService` و`PartyBalanceService` إلى قدرة مالية فرعية مستقلة بعد تحديد مالك رصيد الفاتورة مقابل رصيد الطرف ومنع وجود كاتبين للمبلغ نفسه.
4. استبدال الكتابة المباشرة لإنشاء القبض داخل `SalesService` بواجهة settling ذات وضع متوافق مع التحصيل عند الفاتورة، ثم اختبار عدم إنشاء قيد إضافي.
5. بعد ذلك فقط تُفصل حزم `sales` و`purchase` و`settlements` فعليًا، ثم تُراجع واجهات الترحيل/الإلغاء وترحيلات المخطط.

## التحقق

نجحت اختبارات حد المحاسبة وسجل الوحدات: **18 passed**. نجحت مجموعة المشروع كاملة: **312 passed، و18 subtests، و1022 تحذيرًا** (تحذيرات `sqlite3` الخاصة بمحوّلات التاريخ/الوقت، وليست حالات فشل). نجح `compileall`، ونجح فحص `--check` لكل من رسم manifests ورسم Python.

## مراجع هندسة Odoo 19

- [Odoo 19 Architecture Overview](https://www.odoo.com/documentation/19.0/developer/tutorials/server_framework_101/01_architecture.html)
- [Odoo 19 Module Manifests](https://www.odoo.com/documentation/19.0/developer/reference/backend/module.html)
