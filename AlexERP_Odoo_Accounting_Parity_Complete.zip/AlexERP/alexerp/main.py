"""
AlexERP — Business Management System
Application entry point.

Run from the folder that CONTAINS the `alexerp` package:

    python -m alexerp.main

(or simply `python main.py` from inside `alexerp/`).
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make `import alexerp...` work no matter how the script is launched.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))


def bootstrap_database() -> None:
    """Create tables (idempotent) and insert default data."""
    from alexerp.config import DATABASE_BACKEND
    from alexerp.database.schema import create_database
    from alexerp.database.seed import seed_database

    if DATABASE_BACKEND == "postgresql":
        _bootstrap_postgresql_database(create_database, seed_database)
        return

    create_database()
    seed_database()
    from alexerp.services.customer_service import CustomerService
    CustomerService().ensure_customer_accounts()
    from alexerp.services.party_balance_service import PartyBalanceService
    PartyBalanceService().refresh_all()


def _bootstrap_postgresql_database(create_database, seed_database) -> None:
    """Serialize shared-database schema setup and run initial data seeding once."""
    from alexerp.database.db import Database
    from alexerp.database.postgres_compat import (
        POSTGRES_BOOTSTRAP_LOCK_ID,
        synchronize_postgresql_sequences,
    )

    connection = Database.connect()
    lock_acquired = False
    try:
        connection.execute(
            "SELECT pg_advisory_lock(?)", (POSTGRES_BOOTSTRAP_LOCK_ID,)
        ).fetchone()
        lock_acquired = True
        connection.commit()
        connection.execute(
            """CREATE TABLE IF NOT EXISTS alexerp_runtime_metadata (
                   metadata_key TEXT PRIMARY KEY,
                   metadata_value TEXT NOT NULL
               )"""
        )
        connection.commit()

        create_database()
        synchronize_postgresql_sequences(connection)
        seeded = connection.execute(
            "SELECT metadata_value FROM alexerp_runtime_metadata WHERE metadata_key=?",
            ("initial_seed_v1",),
        ).fetchone()
        if seeded is None:
            seed_database()
            from alexerp.services.customer_service import CustomerService
            CustomerService().ensure_customer_accounts()
            from alexerp.services.party_balance_service import PartyBalanceService
            PartyBalanceService().refresh_all()
            synchronize_postgresql_sequences(connection)
            connection.execute(
                """INSERT INTO alexerp_runtime_metadata(metadata_key, metadata_value)
                   VALUES(?, ?)
                   ON CONFLICT(metadata_key) DO UPDATE SET metadata_value=excluded.metadata_value""",
                ("initial_seed_v1", "complete"),
            )
            connection.commit()
    finally:
        if lock_acquired:
            if connection.in_transaction:
                connection.rollback()
            connection.execute(
                "SELECT pg_advisory_unlock(?)", (POSTGRES_BOOTSTRAP_LOCK_ID,)
            ).fetchone()
            connection.commit()


def _load_main_window():
    from alexerp.ui.main_window import MainWindow

    return MainWindow


def main() -> int:
    scheduler = None
    try:
        try:
            MainWindow = _load_main_window()
        except ModuleNotFoundError as exc:
            if exc.name and exc.name.startswith(("customtkinter", "tkinter")):
                print(
                    "Missing GUI dependency. Install it with:\n"
                    "    pip install customtkinter",
                    file=sys.stderr,
                )
                return 1
            raise

        try:
            bootstrap_database()
        except Exception as exc:  # database problems must be visible, not silent
            print(f"Database initialisation failed: {exc}", file=sys.stderr)
            return 1

        app = MainWindow()
        from alexerp.config import (
            AUTO_BACKUP_ENABLED, AUTO_BACKUP_HOUR, AUTO_BACKUP_MINUTE,
            AUTO_BACKUP_CHECK_SECONDS, AUTO_BACKUP_KEEP, DATABASE_BACKEND,
        )
        if AUTO_BACKUP_ENABLED and DATABASE_BACKEND == "sqlite":
            from alexerp.database.backup_scheduler import DailyBackupScheduler
            scheduler = DailyBackupScheduler(hour=AUTO_BACKUP_HOUR, minute=AUTO_BACKUP_MINUTE,
                                             interval_seconds=AUTO_BACKUP_CHECK_SECONDS, keep_last=AUTO_BACKUP_KEEP)
            scheduler.start()
        elif AUTO_BACKUP_ENABLED:
            from alexerp.database.backup import BackupManager
            if BackupManager.postgresql_backup_tools_available():
                from alexerp.database.backup_scheduler import DailyBackupScheduler
                scheduler = DailyBackupScheduler(
                    hour=AUTO_BACKUP_HOUR, minute=AUTO_BACKUP_MINUTE,
                    interval_seconds=AUTO_BACKUP_CHECK_SECONDS,
                    keep_last=AUTO_BACKUP_KEEP,
                )
                scheduler.start()
            else:
                print(
                    "PostgreSQL automatic backups require pg_dump and pg_restore; "
                    "configure ALEXERP_PG_DUMP and ALEXERP_PG_RESTORE or install PostgreSQL client tools.",
                    file=sys.stderr,
                )
        app.mainloop()
        return 0
    finally:
        try:
            if scheduler:
                scheduler.stop()
        finally:
            from alexerp.database.db import Database
            Database.close()


if __name__ == "__main__":
    raise SystemExit(main())
