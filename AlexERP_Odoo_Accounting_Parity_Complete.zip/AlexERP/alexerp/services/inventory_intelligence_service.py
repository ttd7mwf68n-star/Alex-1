"""Company-scoped, read-only inventory intelligence.

Valuation uses the operational product_stock quantity and average_cost fields.
Unallocated legacy balances are surfaced separately and deliberately excluded
from valuation because they have no warehouse assignment.
"""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP

from alexerp.repositories.base_repository import BaseRepository

_CENT = Decimal("0.01")


def _money(value) -> Decimal:
    return Decimal(str(value or 0)).quantize(_CENT, rounding=ROUND_HALF_UP)


class InventoryIntelligenceService(BaseRepository):
    """Read-only inventory KPIs and actionable stock lists for one tenant."""

    table_name = "product_stock"

    @staticmethod
    def _scope(company_id: int, branch_id: int | None = None) -> tuple[int, int | None]:
        if isinstance(company_id, bool) or not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("A valid company_id is required.")
        if branch_id is not None:
            if isinstance(branch_id, bool) or int(branch_id) <= 0:
                raise ValueError("branch_id must be a positive integer.")
            branch_id = int(branch_id)
        return int(company_id), branch_id

    @staticmethod
    def _date(value: str) -> date:
        try:
            return date.fromisoformat(str(value))
        except (TypeError, ValueError) as exc:
            raise ValueError("Date must be a valid ISO date (YYYY-MM-DD).") from exc

    def inventory_summary(self, company_id: int, branch_id: int | None = None) -> dict:
        company_id, branch_id = self._scope(company_id, branch_id)
        sql = """SELECT COUNT(DISTINCT ps.product_id) AS product_count,
                        COALESCE(SUM(ps.quantity),0) AS total_quantity,
                        COALESCE(SUM(ps.quantity * ps.average_cost),0) AS inventory_value,
                        SUM(CASE WHEN ps.quantity < 0 THEN 1 ELSE 0 END) AS negative_rows
                 FROM product_stock ps
                 JOIN products p ON p.id=ps.product_id AND p.company_id=ps.company_id
                 WHERE ps.company_id=?"""
        params: tuple = (company_id,)
        if branch_id is not None:
            sql += " AND (ps.branch_id=? OR ps.branch_id IS NULL) AND (p.branch_id=? OR p.branch_id IS NULL)"
            params += (branch_id, branch_id)
        row = self.fetchone(sql, params)

        product_scope = "p.company_id=? AND COALESCE(p.is_active,1)=1"
        product_params: tuple = (company_id,)
        if branch_id is not None:
            product_scope += " AND (p.branch_id=? OR p.branch_id IS NULL)"
            product_params += (branch_id,)
        low_legacy_scope = ""
        low_params = product_params
        if branch_id is not None:
            low_legacy_scope = " AND p.branch_id=?"
            low_params = (branch_id,) + product_params
        low = self.fetchone(
            f"""SELECT COUNT(*) FROM (
                    SELECT p.id, p.minimum_stock,
                           COALESCE(SUM(ps.quantity),0) +
                           COALESCE(MAX(lu.quantity),0) AS quantity
                    FROM products p
                    LEFT JOIN product_stock ps ON ps.product_id=p.id AND ps.company_id=p.company_id
                    LEFT JOIN legacy_stock_unallocated lu ON lu.product_id=p.id AND lu.resolved_at IS NULL{low_legacy_scope}
                    WHERE {product_scope}
                    GROUP BY p.id,p.minimum_stock
                    HAVING COALESCE(p.minimum_stock,0)>0
                       AND COALESCE(SUM(ps.quantity),0)+COALESCE(MAX(lu.quantity),0)<=p.minimum_stock
                )""", low_params,
        )
        legacy_sql = """SELECT COUNT(*) AS product_count, COALESCE(SUM(lu.quantity),0) AS quantity
                        FROM legacy_stock_unallocated lu JOIN products p ON p.id=lu.product_id
                        WHERE p.company_id=? AND lu.resolved_at IS NULL"""
        legacy_params: tuple = (company_id,)
        if branch_id is not None:
            # Legacy balances have no warehouse/branch allocation. Only count
            # them in a branch view when the product itself is branch-owned.
            legacy_sql += " AND p.branch_id=?"
            legacy_params += (branch_id,)
        legacy = self.fetchone(legacy_sql, legacy_params)
        return {
            "product_count": int(row["product_count"] or 0),
            "total_quantity": float(_money(row["total_quantity"])),
            "inventory_value": float(_money(row["inventory_value"])),
            "negative_stock_rows": int(row["negative_rows"] or 0),
            "low_stock_products": int(low[0] or 0),
            "unallocated_legacy_products": int(legacy["product_count"] or 0),
            "unallocated_legacy_quantity": float(_money(legacy["quantity"])),
            "valuation_basis": "product_stock.quantity * product_stock.average_cost; unallocated legacy stock excluded",
        }

    def reorder_suggestions(self, company_id: int, branch_id: int | None = None,
                            limit: int = 100) -> list[dict]:
        company_id, branch_id = self._scope(company_id, branch_id)
        try:
            limit = max(1, min(int(limit), 500))
        except (TypeError, ValueError) as exc:
            raise ValueError("limit must be an integer between 1 and 500") from exc
        scope = "p.company_id=? AND COALESCE(p.is_active,1)=1"
        params: tuple = ()
        stock_join_scope = ""
        legacy_join_scope = ""
        if branch_id is not None:
            stock_join_scope = " AND (ps.branch_id=? OR ps.branch_id IS NULL)"
            legacy_join_scope = " AND p.branch_id=?"
            params += (branch_id, branch_id)
            scope += " AND (p.branch_id=? OR p.branch_id IS NULL)"
        params += (company_id,)
        if branch_id is not None:
            params += (branch_id,)
        rows = self.fetchall(
            f"""SELECT p.id AS product_id,p.code,p.name,
                       COALESCE(p.minimum_stock,0) AS minimum_stock,
                       COALESCE(p.maximum_stock,0) AS maximum_stock,
                       COALESCE(SUM(ps.quantity),0)+COALESCE(MAX(lu.quantity),0) AS on_hand,
                       COALESCE(SUM(ps.quantity*ps.average_cost),0) AS stock_value
                FROM products p
                LEFT JOIN product_stock ps ON ps.product_id=p.id AND ps.company_id=p.company_id{stock_join_scope}
                LEFT JOIN legacy_stock_unallocated lu ON lu.product_id=p.id AND lu.resolved_at IS NULL{legacy_join_scope}
                WHERE {scope}
                GROUP BY p.id,p.code,p.name,p.minimum_stock,p.maximum_stock
                HAVING COALESCE(p.minimum_stock,0)>0
                   AND COALESCE(SUM(ps.quantity),0)+COALESCE(MAX(lu.quantity),0)<=p.minimum_stock
                ORDER BY (p.minimum_stock-(COALESCE(SUM(ps.quantity),0)+COALESCE(MAX(lu.quantity),0))) DESC,
                         p.name LIMIT ?""",
            params + (limit,),
        )
        output = []
        for row in rows:
            on_hand = _money(row["on_hand"])
            minimum = _money(row["minimum_stock"])
            maximum = _money(row["maximum_stock"])
            target = maximum if maximum > minimum else minimum
            output.append({
                "product_id": int(row["product_id"]), "code": row["code"], "name": row["name"],
                "on_hand": float(on_hand), "minimum_stock": float(minimum),
                "maximum_stock": float(maximum),
                "suggested_reorder": float(max(Decimal("0.00"), target - on_hand)),
                "stock_value": float(_money(row["stock_value"])),
            })
        return output

    def warehouse_valuation(self, company_id: int, branch_id: int | None = None,
                            limit: int = 100) -> list[dict]:
        company_id, branch_id = self._scope(company_id, branch_id)
        limit = max(1, min(int(limit), 500))
        ps_branch_scope = ""
        params: tuple = ()
        if branch_id is not None:
            ps_branch_scope = " AND (ps.branch_id=? OR ps.branch_id IS NULL)"
            params += (branch_id,)
        sql = f"""SELECT w.id AS warehouse_id,w.code,w.name AS warehouse,
                        COUNT(DISTINCT ps.product_id) AS product_count,
                        COALESCE(SUM(ps.quantity),0) AS quantity,
                        COALESCE(SUM(ps.quantity*ps.average_cost),0) AS inventory_value
                 FROM warehouses w
                 LEFT JOIN product_stock ps ON ps.warehouse_id=w.id AND ps.company_id=w.company_id{ps_branch_scope}
                 WHERE w.company_id=? AND COALESCE(w.is_active,1)=1"""
        params += (company_id,)
        if branch_id is not None:
            sql += " AND (w.branch_id=? OR w.branch_id IS NULL)"
            params += (branch_id,)
        sql += " GROUP BY w.id,w.code,w.name ORDER BY inventory_value DESC,w.name LIMIT ?"
        params += (limit,)
        return [{
            "warehouse_id": int(r["warehouse_id"]), "code": r["code"],
            "warehouse": r["warehouse"], "product_count": int(r["product_count"] or 0),
            "quantity": float(_money(r["quantity"])),
            "inventory_value": float(_money(r["inventory_value"])),
        } for r in self.fetchall(sql, params)]

    def non_moving_stock(self, company_id: int, as_of: str | None = None,
                         days_without_sale: int = 90, branch_id: int | None = None,
                         limit: int = 100) -> list[dict]:
        company_id, branch_id = self._scope(company_id, branch_id)
        as_of_date = self._date(as_of or date.today().isoformat())
        if isinstance(days_without_sale, bool) or not 1 <= int(days_without_sale) <= 3650:
            raise ValueError("days_without_sale must be between 1 and 3650")
        cutoff = as_of_date - timedelta(days=int(days_without_sale))
        limit = max(1, min(int(limit), 500))
        scope = "p.company_id=? AND COALESCE(p.is_active,1)=1"
        movement_filter = "transaction_type='SALE'"
        stock_join_scope = ""
        params: tuple = ()
        if branch_id is not None:
            movement_filter += " AND branch_id=?"
            params += (branch_id,)
            stock_join_scope = " AND (ps.branch_id=? OR ps.branch_id IS NULL)"
            params += (branch_id,)
            scope += " AND (p.branch_id=? OR p.branch_id IS NULL)"
        params += (company_id,)
        if branch_id is not None:
            params += (branch_id,)
        params += (cutoff.isoformat(), max(1, min(int(limit), 500)))
        rows = self.fetchall(
            f"""SELECT p.id AS product_id,p.code,p.name,
                       COALESCE(SUM(ps.quantity),0) AS on_hand,
                       COALESCE(SUM(ps.quantity*ps.average_cost),0) AS stock_value,
                       ls.last_sale_date
                FROM products p
                JOIN product_stock ps ON ps.product_id=p.id AND ps.company_id=p.company_id{stock_join_scope}
                LEFT JOIN (
                    SELECT company_id,product_id,MAX(transaction_date) AS last_sale_date
                    FROM stock_movements WHERE {movement_filter}
                    GROUP BY company_id,product_id
                ) ls ON ls.company_id=p.company_id AND ls.product_id=p.id
                WHERE {scope}
                GROUP BY p.id,p.code,p.name,ls.last_sale_date
                HAVING COALESCE(SUM(ps.quantity),0)>0
                   AND (ls.last_sale_date IS NULL OR date(ls.last_sale_date)<=date(?))
                ORDER BY stock_value DESC,p.name LIMIT ?""",
            params,
        )
        output = []
        for row in rows:
            last_sale = str(row["last_sale_date"])[:10] if row["last_sale_date"] else None
            days = (as_of_date - date.fromisoformat(last_sale)).days if last_sale else None
            output.append({
                "product_id": int(row["product_id"]), "code": row["code"], "name": row["name"],
                "on_hand": float(_money(row["on_hand"])),
                "stock_value": float(_money(row["stock_value"])),
                "last_sale_date": last_sale, "days_without_sale": days,
            })
        return output

    def movement_summary(self, company_id: int, date_from: str, date_to: str,
                         branch_id: int | None = None) -> dict:
        company_id, branch_id = self._scope(company_id, branch_id)
        start, end = self._date(date_from), self._date(date_to)
        if start > end or (end - start).days > 3660:
            raise ValueError("Invalid inventory movement date range.")
        sql = """SELECT transaction_type,COUNT(*) AS movement_count,
                        COALESCE(SUM(quantity_in),0) AS quantity_in,
                        COALESCE(SUM(quantity_out),0) AS quantity_out
                 FROM stock_movements WHERE company_id=?
                   AND date(transaction_date) BETWEEN date(?) AND date(?)"""
        params: tuple = (company_id, start.isoformat(), end.isoformat())
        if branch_id is not None:
            sql += " AND branch_id=?"
            params += (branch_id,)
        sql += " GROUP BY transaction_type ORDER BY transaction_type"
        rows = self.fetchall(sql, params)
        return {"date_from": start.isoformat(), "date_to": end.isoformat(),
                "movements": [{"transaction_type": r["transaction_type"],
                               "movement_count": int(r["movement_count"] or 0),
                               "quantity_in": float(_money(r["quantity_in"])),
                               "quantity_out": float(_money(r["quantity_out"]))} for r in rows]}
