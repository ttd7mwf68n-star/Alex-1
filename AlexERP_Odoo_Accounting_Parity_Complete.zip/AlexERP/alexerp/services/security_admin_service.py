"""Administrative role and user management with company-safe boundaries."""
from __future__ import annotations

import re
import sqlite3
import math
from alexerp.database.db import Database
from alexerp.core.context import get_current_user
from alexerp.database.auth import PasswordManager
from alexerp.services.session_service import SessionService
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionDenied, PermissionService
from alexerp.services.advanced_access_service import AdvancedAccessService


class SecurityAdminError(ValueError):
    pass


class SecurityAdminService:
    USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,40}$")
    RECORD_RULE_VALUES = {
        "status": {"OPEN", "PARTIALLY_RECEIVED", "RECEIVED", "CLOSED", "CANCELLED"},
        "approval_status": {"PENDING", "APPROVED", "REJECTED"},
    }

    @staticmethod
    def _actor_id(actor_id):
        if actor_id is not None:
            return int(actor_id)
        user = get_current_user()
        return int(user["id"]) if user and user.get("id") else None

    @staticmethod
    def _require_permission(
        actor_id: int | None, company_id: int, permission_key: str
    ) -> int:
        if actor_id is None:
            raise PermissionDenied(f"Permission required for company: {permission_key}")
        PermissionService().require_for_company(
            actor_id, int(company_id), permission_key
        )
        return actor_id

    def list_roles(self, company_id: int, *, actor_id: int | None = None):
        permissions = PermissionService()
        actor_id = self._actor_id(actor_id)
        if actor_id is None:
            raise PermissionDenied("Permission required to view roles.")
        if not (
            permissions.has_permission_for_company(
                actor_id, int(company_id), "security.roles.manage"
            )
            or permissions.has_permission_for_company(
                actor_id, int(company_id), "security.users.manage"
            )
        ):
            raise PermissionDenied("Permission required to view roles.")
        conn = Database.connect()
        rows = conn.execute(
            "SELECT id, code, name, description, is_system, is_active, company_id FROM roles "
            "WHERE company_id IS NULL OR company_id=? ORDER BY is_system DESC, name", (int(company_id),)
        ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["permissions"] = [r[0] for r in conn.execute(
                "SELECT p.permission_key FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id "
                "WHERE rp.role_id=? ORDER BY p.module,p.permission_key", (row["id"],)
            ).fetchall()]
            result.append(item)
        return result

    def list_permissions(self):
        user = get_current_user()
        if user is None:
            raise PermissionDenied("Permission required to view role permissions.")
        self._require_permission(
            self._actor_id(None), int(user["company_id"]), "security.roles.manage"
        )
        rows = Database.connect().execute(
            "SELECT module, permission_key, permission_name, description FROM permissions ORDER BY module, permission_key"
        ).fetchall()
        return [dict(r) for r in rows]

    def list_users(self, company_id: int, *, actor_id: int | None = None):
        self._require_permission(
            self._actor_id(actor_id), company_id, "security.users.manage"
        )
        rows = Database.connect().execute(
            "SELECT u.id,u.username,u.full_name,u.email,u.phone,u.role_id,u.branch_id,u.is_active,u.last_login,"
            "r.code AS role_code,r.name AS role_name FROM users u LEFT JOIN roles r ON r.id=u.role_id "
            "WHERE u.company_id=? ORDER BY u.full_name,u.username", (int(company_id),)
        ).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def _validate_permission_keys(conn, keys):
        if not isinstance(keys, list) or len(keys) > 200 or any(not isinstance(k, str) for k in keys):
            raise SecurityAdminError("قائمة الصلاحيات غير صحيحة.")
        normalized = list(dict.fromkeys(k.strip() for k in keys if k.strip()))
        if normalized:
            placeholders = ",".join("?" for _ in normalized)
            found = {r[0] for r in conn.execute(
                f"SELECT permission_key FROM permissions WHERE permission_key IN ({placeholders})", normalized
            ).fetchall()}
            if found != set(normalized):
                raise SecurityAdminError("توجد صلاحية غير معروفة.")
        return normalized

    def create_role(self, company_id: int, code: str, name: str, description: str, permission_keys: list[str], *, actor_id: int | None = None):
        actor_id = self._actor_id(actor_id)
        actor_id = self._require_permission(actor_id, company_id, "security.roles.manage")
        code = str(code or "").strip().upper()
        name = str(name or "").strip()
        if code == "ADMIN" or not re.fullmatch(r"[A-Z][A-Z0-9_]{2,39}", code):
            raise SecurityAdminError("كود الدور يجب أن يبدأ بحرف ويحتوي على 3 إلى 40 حرفًا أو رقمًا أو _.")
        if not name or len(name) > 80:
            raise SecurityAdminError("اسم الدور مطلوب وبحد أقصى 80 حرفًا.")
        conn = Database.connect()
        try:
            keys = self._validate_permission_keys(conn, permission_keys)
            cur = conn.execute(
                "INSERT INTO roles(code,name,description,is_system,is_active,company_id) VALUES(?,?,?,0,1,?)",
                (code, name, str(description or "").strip()[:250], int(company_id)),
            )
            if cur.lastrowid is None:
                raise SecurityAdminError("تعذر إنشاء الدور.")
            role_id = int(cur.lastrowid)
            for key in keys:
                conn.execute(
                    "INSERT INTO role_permissions(role_id,permission_id) SELECT ?,id FROM permissions WHERE permission_key=?",
                    (role_id, key),
                )
            AuditService.record(user_id=actor_id, company_id=int(company_id), module="security", action="role_created",
                                entity_type="role", record_id=role_id, after={"code": code, "name": name,
                                "permissions": keys}, connection=conn)
            conn.commit()
            return role_id
        except sqlite3.IntegrityError as exc:
            conn.rollback()
            raise SecurityAdminError("كود الدور مستخدم بالفعل.") from exc
        except Exception:
            conn.rollback()
            raise

    def update_role(self, company_id: int, role_id: int, name: str, description: str, permission_keys: list[str], is_active: bool, *, actor_id: int | None = None):
        actor_id = self._actor_id(actor_id)
        actor_id = self._require_permission(actor_id, company_id, "security.roles.manage")
        conn = Database.connect()
        try:
            role = conn.execute("SELECT * FROM roles WHERE id=? AND company_id=?",
                                (int(role_id), int(company_id))).fetchone()
            if role is None:
                raise SecurityAdminError("الدور غير موجود.")
            if int(role["is_system"]):
                raise SecurityAdminError("لا يمكن تعديل الدور الأساسي من هذه الشاشة.")
            name = str(name or "").strip()
            if not name or len(name) > 80:
                raise SecurityAdminError("اسم الدور مطلوب وبحد أقصى 80 حرفًا.")
            keys = self._validate_permission_keys(conn, permission_keys)
            workflow_use = conn.execute(
                """SELECT 1 FROM approval_workflow_steps s
                   JOIN approval_workflows w ON w.id=s.workflow_id
                   WHERE s.role_id=? AND w.company_id=? AND w.is_active=1
                   UNION ALL
                   SELECT 1 FROM purchase_order_approval_steps s
                   JOIN purchase_orders po ON po.id=s.order_id
                   WHERE s.role_id=? AND po.company_id=? AND s.approval_status='PENDING'
                   LIMIT 1""",
                (int(role_id), int(company_id), int(role_id), int(company_id)),
            ).fetchone()
            if workflow_use and (
                not bool(is_active) or "purchases.approve" not in keys
            ):
                raise SecurityAdminError(
                    "لا يمكن تعطيل الدور أو إزالة صلاحية الاعتماد ما دام مستخدمًا في تدفق نشط أو خطوة معلقة."
                )
            if not bool(is_active):
                used = conn.execute("SELECT 1 FROM users WHERE role_id=? AND is_active=1 LIMIT 1", (int(role_id),)).fetchone()
                if used:
                    raise SecurityAdminError("لا يمكن تعطيل دور مرتبط بمستخدمين نشطين. غيّر أدوارهم أولًا.")
            conn.execute(
                "UPDATE roles SET name=?,description=?,is_active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (name, str(description or "").strip()[:250], int(bool(is_active)), int(role_id)),
            )
            before_snapshot = {"name": role["name"], "description": role["description"],
                               "is_active": int(role["is_active"])}
            conn.execute("DELETE FROM role_permissions WHERE role_id=?", (int(role_id),))
            for key in keys:
                conn.execute(
                    "INSERT INTO role_permissions(role_id,permission_id) SELECT ?,id FROM permissions WHERE permission_key=?",
                    (int(role_id), key),
                )
            AuditService.record(user_id=actor_id, company_id=int(company_id), module="security", action="role_updated",
                                entity_type="role", record_id=int(role_id), before=before_snapshot,
                                after={"name": name, "description": str(description or "")[:250],
                                       "is_active": int(bool(is_active)), "permissions": keys}, connection=conn)
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    def create_user(self, *, company_id: int, branch_id: int, username: str, full_name: str,
                    password: str, role_id: int, email: str = "", phone: str = "",
                    actor_id: int | None = None):
        actor_id = self._actor_id(actor_id)
        actor_id = self._require_permission(actor_id, company_id, "security.users.manage")
        username = str(username or "").strip()
        full_name = str(full_name or "").strip()
        password = str(password or "")
        if not self.USERNAME_RE.fullmatch(username):
            raise SecurityAdminError("اسم المستخدم يجب أن يكون 3 إلى 40 حرفًا إنجليزيًا أو رقمًا أو _ . -.")
        if not full_name or len(full_name) > 100:
            raise SecurityAdminError("الاسم الكامل مطلوب وبحد أقصى 100 حرف.")
        try:
            PasswordManager.validate_password(password)
        except ValueError as exc:
            raise SecurityAdminError(str(exc)) from exc
        conn = Database.connect()
        role = conn.execute("SELECT id FROM roles WHERE id=? AND is_active=1 AND (company_id=? OR company_id IS NULL)",
                             (int(role_id), int(company_id))).fetchone()
        branch = conn.execute("SELECT id FROM branches WHERE id=? AND company_id=? AND is_active=1",
                              (int(branch_id), int(company_id))).fetchone()
        if role is None or branch is None:
            raise SecurityAdminError("الدور أو الفرع غير صالح لهذه الشركة.")
        try:
            cur = conn.execute(
                "INSERT INTO users(username,password_hash,full_name,email,phone,role_id,company_id,branch_id,is_active) "
                "VALUES(?,?,?,?,?,?,?,?,1)",
                (username, PasswordManager.hash_password(password), full_name, str(email or "").strip() or None,
                 str(phone or "").strip(), int(role_id), int(company_id), int(branch_id)),
            )
            if cur.lastrowid is None:
                raise SecurityAdminError("تعذر إنشاء المستخدم.")
            user_id = int(cur.lastrowid)
            AuditService.record(user_id=actor_id, company_id=int(company_id), branch_id=int(branch_id),
                                module="security", action="user_created", entity_type="user",
                                record_id=user_id, after={"username": username, "full_name": full_name,
                                "role_id": int(role_id), "branch_id": int(branch_id), "is_active": 1},
                                connection=conn)
            conn.commit()
            return user_id
        except sqlite3.IntegrityError as exc:
            conn.rollback()
            raise SecurityAdminError("اسم المستخدم أو البريد الإلكتروني مستخدم بالفعل.") from exc

    def update_user(self, *, actor_id: int, company_id: int, user_id: int, full_name: str,
                    role_id: int, branch_id: int, is_active: bool, email: str = "", phone: str = ""):
        self._require_permission(actor_id, company_id, "security.users.manage")
        conn = Database.connect()
        try:
            user = conn.execute("SELECT * FROM users WHERE id=? AND company_id=?", (int(user_id), int(company_id))).fetchone()
            if user is None:
                raise SecurityAdminError("المستخدم غير موجود داخل الشركة الحالية.")
            if not str(full_name or "").strip() or len(str(full_name).strip()) > 100:
                raise SecurityAdminError("الاسم الكامل مطلوب وبحد أقصى 100 حرف.")
            if int(actor_id) == int(user_id) and (not is_active or int(role_id) != int(user["role_id"])):
                raise SecurityAdminError("لا يمكنك تعطيل حسابك أو تغيير دورك بنفسك.")
            role = conn.execute("SELECT id FROM roles WHERE id=? AND is_active=1 AND (company_id=? OR company_id IS NULL)",
                             (int(role_id), int(company_id))).fetchone()
            branch = conn.execute("SELECT id FROM branches WHERE id=? AND company_id=? AND is_active=1",
                                  (int(branch_id), int(company_id))).fetchone()
            if role is None or branch is None:
                raise SecurityAdminError("الدور أو الفرع غير صالح لهذه الشركة.")
            target_is_admin = conn.execute("SELECT code FROM roles WHERE id=?", (int(user["role_id"]),)).fetchone()
            new_role = conn.execute("SELECT code FROM roles WHERE id=?", (int(role_id),)).fetchone()
            removes_admin = target_is_admin and target_is_admin["code"] == "ADMIN" and (not is_active or not new_role or new_role["code"] != "ADMIN")
            if removes_admin:
                remaining = conn.execute(
                    "SELECT COUNT(*) FROM users u JOIN roles r ON r.id=u.role_id "
                    "WHERE u.company_id=? AND u.is_active=1 AND r.code='ADMIN' AND u.id<>?",
                    (int(company_id), int(user_id)),
                ).fetchone()[0]
                if int(remaining) == 0:
                    raise SecurityAdminError("لا يمكن إزالة آخر مدير نشط في الشركة.")
            before_snapshot = {"full_name": user["full_name"], "email": user["email"],
                               "phone": user["phone"], "role_id": int(user["role_id"]),
                               "branch_id": int(user["branch_id"]), "is_active": int(user["is_active"])}
            conn.execute(
                "UPDATE users SET full_name=?,email=?,phone=?,role_id=?,branch_id=?,is_active=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND company_id=?",
                (str(full_name or "").strip()[:100], str(email or "").strip() or None,
                 str(phone or "").strip(), int(role_id), int(branch_id), int(bool(is_active)), int(user_id), int(company_id)),
            )
            AuditService.record(user_id=int(actor_id), company_id=int(company_id), branch_id=int(branch_id),
                                module="security", action="user_updated", entity_type="user",
                                record_id=int(user_id), before=before_snapshot,
                                after={"full_name": str(full_name).strip()[:100], "email": str(email or "").strip() or None,
                                       "phone": str(phone or "").strip(), "role_id": int(role_id),
                                       "branch_id": int(branch_id), "is_active": int(bool(is_active))},
                                connection=conn)
            conn.commit()
            if (not bool(is_active) or int(role_id) != int(user["role_id"]) or int(branch_id) != int(user["branch_id"])):
                SessionService().revoke_user_sessions(int(user_id), reason="user_access_changed")
        except Exception:
            conn.rollback()
            raise

    def list_role_access_policies(self, company_id: int, role_id: int, *, actor_id: int | None = None):
        actor_id = self._actor_id(actor_id)
        self._require_permission(actor_id, company_id, "security.roles.manage")
        role = Database.connect().execute(
            "SELECT id FROM roles WHERE id=? AND (company_id=? OR company_id IS NULL)",
            (int(role_id), int(company_id)),
        ).fetchone()
        if role is None:
            raise SecurityAdminError("الدور غير موجود داخل الشركة الحالية.")
        conn = Database.connect()
        return {
            "fields": [dict(row) for row in conn.execute(
                """SELECT field_key,access_level FROM role_field_policies
                   WHERE role_id=? AND entity_type='purchase_order' ORDER BY field_key""",
                (int(role_id),),
            ).fetchall()],
            "rules": [dict(row) for row in conn.execute(
                """SELECT effect,field_key,operator,value FROM role_record_rules
                   WHERE role_id=? AND entity_type='purchase_order' ORDER BY id""",
                (int(role_id),),
            ).fetchall()],
        }

    def _validate_access_policies(self, fields, rules):
        if not isinstance(fields, list) or len(fields) > 20:
            raise SecurityAdminError("قائمة صلاحيات الحقول غير صحيحة.")
        field_map = {}
        for item in fields:
            if not isinstance(item, dict):
                raise SecurityAdminError("إعداد أحد الحقول غير صحيح.")
            key = str(item.get("field_key") or "")
            level = str(item.get("access_level") or "").upper()
            if (key not in AdvancedAccessService.ENTITY_POLICY_FIELDS["purchase_order"]
                    or level not in AdvancedAccessService.FIELD_ACCESS_LEVELS):
                raise SecurityAdminError("حقل أو مستوى صلاحية غير معروف.")
            if key in field_map:
                raise SecurityAdminError("لا يمكن تكرار سياسة الحقل.")
            field_map[key] = level
        if not isinstance(rules, list) or len(rules) > 30:
            raise SecurityAdminError("قائمة قواعد السجلات غير صحيحة.")
        normalized_rules = []
        for item in rules:
            if not isinstance(item, dict):
                raise SecurityAdminError("إعداد إحدى قواعد السجلات غير صحيح.")
            field_key = str(item.get("field_key") or "")
            effect = str(item.get("effect") or "").upper()
            operator = str(item.get("operator") or "").upper()
            value = str(item.get("value") or "").strip()
            if (field_key not in AdvancedAccessService.ENTITY_FIELDS["purchase_order"]
                    or effect not in AdvancedAccessService.RULE_EFFECTS
                    or operator not in AdvancedAccessService.RULE_OPERATORS
                    or not value or len(value) > 100):
                raise SecurityAdminError("حقل أو تأثير أو مقارنة غير صالحة في قاعدة السجل.")
            if field_key != "amount" and operator not in {"EQ", "NE"}:
                raise SecurityAdminError("المقارنة الرقمية مسموحة فقط مع قيمة الأمر.")
            if field_key == "created_by":
                if value != "current_user" or operator not in {"EQ", "NE"}:
                    raise SecurityAdminError("قاعدة منشئ الأمر يجب أن تكون للمستخدم الحالي.")
            elif field_key == "amount":
                try:
                    amount = float(value)
                except ValueError as exc:
                    raise SecurityAdminError("قيمة الأمر يجب أن تكون رقمية.") from exc
                if not math.isfinite(amount) or amount < 0:
                    raise SecurityAdminError("قيمة الأمر يجب أن تكون رقمية موجبة أو صفرًا.")
            elif field_key in self.RECORD_RULE_VALUES:
                value = value.upper()
                if value not in self.RECORD_RULE_VALUES[field_key]:
                    raise SecurityAdminError("حالة غير معروفة في قاعدة السجل.")
            elif field_key == "supplier_id":
                if not value.isdigit() or int(value) <= 0:
                    raise SecurityAdminError("معرّف المورد يجب أن يكون رقمًا موجبًا.")
            normalized_rules.append({
                "effect": effect, "field_key": field_key, "operator": operator, "value": value,
            })
        return field_map, normalized_rules

    def save_role_access_policies(
        self, company_id: int, role_id: int, fields, rules, *, actor_id: int | None = None
    ):
        actor_id = self._actor_id(actor_id)
        actor_id = self._require_permission(actor_id, company_id, "security.roles.manage")
        field_map, normalized_rules = self._validate_access_policies(fields, rules)
        conn = Database.connect()
        role = conn.execute(
            "SELECT id FROM roles WHERE id=? AND (company_id=? OR company_id IS NULL)",
            (int(role_id), int(company_id)),
        ).fetchone()
        if role is None:
            raise SecurityAdminError("الدور غير موجود داخل الشركة الحالية.")
        try:
            conn.execute(
                "DELETE FROM role_field_policies WHERE role_id=? AND entity_type='purchase_order'",
                (int(role_id),),
            )
            conn.execute(
                "DELETE FROM role_record_rules WHERE role_id=? AND entity_type='purchase_order'",
                (int(role_id),),
            )
            conn.executemany(
                """INSERT INTO role_field_policies(role_id,entity_type,field_key,access_level)
                   VALUES(?,'purchase_order',?,?)""",
                [(int(role_id), key, level) for key, level in field_map.items()],
            )
            conn.executemany(
                """INSERT INTO role_record_rules(role_id,entity_type,effect,field_key,operator,value)
                   VALUES(?,'purchase_order',?,?,?,?)""",
                [(int(role_id), item["effect"], item["field_key"], item["operator"], item["value"])
                 for item in normalized_rules],
            )
            AuditService.record(
                user_id=actor_id, company_id=int(company_id), module="security",
                action="role_access_policies_updated", entity_type="role", record_id=int(role_id),
                after={"fields": field_map, "rules": normalized_rules}, connection=conn,
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
