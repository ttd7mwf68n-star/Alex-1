"""Append-oriented audit event writer and company-scoped reader."""
from __future__ import annotations

import json
import re
import uuid
from datetime import date
from typing import Any

from alexerp.database.db import Database


class AuditService:
    MAX_DESCRIPTION = 500

    @staticmethod
    def _json(value: Any) -> str | None:
        if value is None:
            return None
        # Recursively redact credential-like fields, including nested payloads.
        blocked = {
            "password", "password_hash", "passwd", "token", "session_token",
            "access_token", "refresh_token", "secret", "api_key", "authorization",
            "cookie", "private_key",
        }

        def clean(item):
            if isinstance(item, dict):
                return {
                    key: clean(val) for key, val in item.items()
                    if re.sub(r"(?<!^)(?=[A-Z])", "_", str(key).strip()).lower().replace("-", "_") not in blocked
                }
            if isinstance(item, (list, tuple, set)):
                return [clean(part) for part in item]
            return item

        return json.dumps(clean(value), ensure_ascii=False, default=str, separators=(",", ":"))

    @classmethod
    def record(cls, *, user_id: int | None, company_id: int | None, branch_id: int | None = None,
               module: str, action: str, entity_type: str | None = None, record_id: int | None = None,
               description: str = "", before: Any = None, after: Any = None,
               ip_address: str = "", request_id: str | None = None, connection=None) -> int:
        conn = connection or Database.connect()
        # Standalone audit writes (no caller-supplied connection and no open
        # transaction) must commit themselves; otherwise the implicit
        # transaction keeps a write lock on the shared per-thread connection
        # and blocks every other writer ("database is locked").
        autocommit = connection is None and not conn.in_transaction
        request_id = str(request_id or uuid.uuid4().hex)[:64]
        cur = conn.execute(
            "INSERT INTO audit_logs(user_id,module,action,record_id,description,company_id,branch_id,entity_type,"
            "before_json,after_json,ip_address,request_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (int(user_id) if user_id is not None else None, str(module)[:60], str(action)[:60],
             int(record_id) if record_id is not None else None, str(description or "")[:cls.MAX_DESCRIPTION],
             int(company_id) if company_id is not None else None, int(branch_id) if branch_id is not None else None,
             str(entity_type)[:80] if entity_type else None, cls._json(before), cls._json(after),
             str(ip_address or "")[:80], request_id),
        )
        if autocommit:
            conn.commit()
        return int(cur.lastrowid)

    def list_events(self, *, company_id: int, limit: int = 100, offset: int = 0,
                    module: str | None = None, action: str | None = None,
                    entity_type: str | None = None, user_id: int | None = None,
                    date_from: str | None = None, date_to: str | None = None):
        limit = max(1, min(int(limit), 500))
        offset = max(0, int(offset))
        parsed_from = date.fromisoformat(str(date_from)) if date_from else None
        parsed_to = date.fromisoformat(str(date_to)) if date_to else None
        if parsed_from and parsed_to and parsed_from > parsed_to:
            raise ValueError("تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")
        clauses = ["a.company_id=?"]
        params: list[Any] = [int(company_id)]
        for column, value in (("a.module", module), ("a.action", action),
                              ("a.entity_type", entity_type), ("a.user_id", user_id)):
            if value is not None and value != "":
                clauses.append(f"{column}=?")
                params.append(int(value) if column == "user_id" else str(value))
        if date_from:
            clauses.append("date(a.created_at)>=date(?)")
            params.append(str(date_from))
        if date_to:
            clauses.append("date(a.created_at)<=date(?)")
            params.append(str(date_to))
        params.extend([limit, offset])
        rows = Database.connect().execute(
            "SELECT a.id,a.user_id,u.username AS actor_username,u.full_name AS actor_name,"
            "a.module,a.action,a.record_id,a.description,a.created_at,a.company_id,a.branch_id,"
            "a.entity_type,a.before_json,a.after_json,a.ip_address,a.request_id "
            "FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id WHERE "
            + " AND ".join(clauses) + " ORDER BY a.id DESC LIMIT ? OFFSET ?", params
        ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            for key in ("before_json", "after_json"):
                try:
                    item[key.removesuffix("_json")] = json.loads(item.pop(key)) if item[key] else None
                except (TypeError, json.JSONDecodeError):
                    item[key.removesuffix("_json")] = None
                    item.pop(key, None)
            result.append(item)
        return result
