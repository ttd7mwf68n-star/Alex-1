"""
AlexERP — Business Management System
Supplier Service
"""

from __future__ import annotations

from alexerp.repositories.supplier_repository import SupplierRepository
from alexerp.services.permission_service import PermissionService


class SupplierService:

    def __init__(self):

        self.repo = SupplierRepository()

    # =====================================================
    # Create Supplier
    # =====================================================

    def create_supplier(
        self,
        company_id: int,
        code: str,
        name: str,
        tax_number: str = "",
        phone: str = "",
        mobile: str = "",
        email: str = "",
        address: str = "",
        city: str = "",
        account_id: int | None = None,
        *,
        actor_id: int,
    ) -> int:
        PermissionService().require_for_company(actor_id, company_id, "suppliers.create")

        if self.repo.find_by_code(company_id, code):
            raise ValueError("Supplier code already exists.")

        supplier_id = self.repo.add(
            company_id=company_id,
            code=code,
            name=name,
            tax_number=tax_number,
            phone=phone,
            mobile=mobile,
            email=email,
            address=address,
            city=city,
            account_id=account_id,
        )

        self.repo.commit()

        return supplier_id

    # =====================================================
    # Update Supplier
    # =====================================================

    def update_supplier(
        self,
        supplier_id: int,
        code: str,
        name: str,
        tax_number: str,
        phone: str,
        mobile: str,
        email: str,
        address: str,
        city: str,
        account_id: int | None,
        *,
        actor_id: int,
    ):
        supplier = self.repo.find_by_id(supplier_id)
        if supplier is None:
            raise ValueError("Supplier not found.")
        PermissionService().require_for_company(
            actor_id, int(supplier["company_id"]), "suppliers.update"
        )

        self.repo.update(
            supplier_id,
            code,
            name,
            tax_number,
            phone,
            mobile,
            email,
            address,
            city,
            account_id,
        )

        self.repo.commit()

    # =====================================================
    # Get Supplier
    # =====================================================

    def get_supplier(self, supplier_id: int):

        return self.repo.find_by_id(supplier_id)

    # =====================================================
    # Get All Suppliers
    # =====================================================

    def get_all(self):

        return self.repo.find_all()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        return self.repo.search(keyword)

    # =====================================================
    # Update Balance
    # =====================================================

    def update_balance(self, supplier_id: int, balance: float):
        raise ValueError(
            "Supplier balances are derived from posted documents; "
            "manual balance updates are disabled."
        )

    # =====================================================
    # Delete Supplier
    # =====================================================

    def delete(self, supplier_id: int, *, actor_id: int):
        supplier = self.repo.find_by_id(supplier_id)
        if supplier is None:
            raise ValueError("Supplier not found.")
        PermissionService().require_for_company(
            actor_id, int(supplier["company_id"]), "suppliers.delete"
        )

        self.repo.delete(supplier_id)

        self.repo.commit()
