"""Compatibility import for the accounting-core-owned fiscal period service."""
from alexerp.accounting.period_service import FiscalPeriodError, FiscalPeriodService

__all__ = ["FiscalPeriodError", "FiscalPeriodService"]
