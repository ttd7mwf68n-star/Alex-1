"""Inventory count entry and posting service."""
from __future__ import annotations

import math

from alexerp.database.transaction import transaction
from alexerp.repositories.inventory_count_repository import InventoryCountRepository
from alexerp.services.adjustment_service import AdjustmentService
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService


class InventoryCountService:
    def __init__(self):
        self.repo = InventoryCountRepository()
        self.adjustment = AdjustmentService()

    def create_count(
        self,
        company_id,
        branch_id,
        warehouse_id,
        count_number,
        count_date,
        items,
        notes,
        created_by,
    ):
        PermissionService().require_for_company(created_by, company_id, "inventory.adjust")
        from alexerp.core import tenancy
        tenancy.require_branch(company_id, branch_id)
        for item in items or []:
            tenancy.require_item_scope(company_id, branch_id, int(item["product_id"]), warehouse_id)

        with transaction():
            count_id = self.repo.create_count(
                company_id,
                branch_id,
                warehouse_id,
                count_number,
                count_date,
                notes,
                created_by,
            )
            for item in items or []:
                system_quantity = float(item.get("system_quantity", 0))
                counted_quantity = float(item.get("counted_quantity", 0))
                unit_cost = float(item.get("unit_cost", 0))
                if any(not math.isfinite(value) or value < 0 for value in
                       (system_quantity, counted_quantity, unit_cost)):
                    raise ValueError("Count quantities and unit cost must be finite and non-negative.")
                difference = counted_quantity - system_quantity
                supplied_difference = item.get("difference")
                if supplied_difference is not None and not math.isclose(
                    float(supplied_difference), difference, abs_tol=1e-9
                ):
                    raise ValueError("Count difference must equal counted quantity minus system quantity.")
                self.repo.add_item(
                    inventory_count_id=count_id,
                    product_id=item["product_id"],
                    system_quantity=system_quantity,
                    counted_quantity=counted_quantity,
                    difference=difference,
                    unit_cost=unit_cost,
                )
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="inventory", action="inventory_count_created", entity_type="inventory_count",
                record_id=count_id, description=f"Inventory count {count_number} created",
                after={"count_number": count_number, "warehouse_id": warehouse_id,
                       "item_count": len(items or []), "status": "DRAFT"})
            return count_id

    def post_count(
        self,
        count_id: int,
        company_id: int,
        branch_id: int,
        warehouse_id: int,
        created_by: int,
    ):
        PermissionService().require_for_company(created_by, company_id, "inventory.adjust")
        with transaction():
            count = self.repo.get_count(count_id)
            if count is None:
                raise ValueError("Inventory Count not found.")
            if str(count["status"]).casefold() == "posted":
                raise ValueError("Inventory Count is already posted.")
            if (
                int(count["company_id"]) != int(company_id)
                or int(count["branch_id"]) != int(branch_id)
                or int(count["warehouse_id"]) != int(warehouse_id)
            ):
                raise ValueError("Posting scope must match the inventory count company, branch, and warehouse.")

            items = self.repo.get_items(count_id)
            adjustment_items = []
            for item in items:
                system_quantity = float(item["system_quantity"])
                counted_quantity = float(item["counted_quantity"])
                difference = counted_quantity - system_quantity
                if difference == 0:
                    continue
                adjustment_items.append(
                    {
                        "product_id": item["product_id"],
                        "system_quantity": system_quantity,
                        "actual_quantity": counted_quantity,
                        "difference": difference,
                        "unit_cost": float(item["unit_cost"]),
                    }
                )

            if adjustment_items:
                self.adjustment.create_adjustment(
                    company_id=count["company_id"],
                    branch_id=count["branch_id"],
                    warehouse_id=count["warehouse_id"],
                    adjustment_number=f"ADJ-{count['count_number']}",
                    adjustment_date=count["count_date"],
                    adjustment_type="COUNT",
                    items=adjustment_items,
                    notes=f"Inventory Count {count['count_number']}",
                    created_by=created_by,
                )
            self.repo.close_count(count_id)
            AuditService.record(user_id=created_by, company_id=int(count["company_id"]),
                branch_id=int(count["branch_id"]), module="inventory", action="inventory_count_posted",
                entity_type="inventory_count", record_id=count_id,
                description=f"Inventory count {count['count_number']} posted",
                before={"status": str(count["status"]), "warehouse_id": int(count["warehouse_id"])},
                after={"status": "POSTED", "warehouse_id": int(count["warehouse_id"]),
                       "item_count": len(items)})
