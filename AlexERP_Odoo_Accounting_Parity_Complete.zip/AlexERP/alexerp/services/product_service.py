from __future__ import annotations

from alexerp.repositories.product_repository import ProductRepository
from alexerp.services.inventory_service import InventoryService
from alexerp.database.transaction import transaction
from alexerp.services.permission_service import PermissionDenied, PermissionService


class ProductService:
    _UPDATABLE = ("code", "barcode", "name", "category_id", "brand_id", "unit_id",
                  "purchase_price", "sale_price", "minimum_stock", "maximum_stock",
                  "description")
    """Business rules for products. Warehouse balances live in product_stock."""

    def __init__(self):
        self.repo = ProductRepository()

    # --------------------------------------------------

    @staticmethod
    def _validate(data: dict) -> None:
        if not str(data.get("name", "")).strip():
            raise ValueError("اسم المنتج مطلوب")
        if float(data.get("purchase_price", 0) or 0) < 0 or float(data.get("sale_price", 0) or 0) < 0:
            raise ValueError("السعر غير صحيح")
        if float(data.get("minimum_stock", 0) or 0) < 0 or float(data.get("maximum_stock", 0) or 0) < 0:
            raise ValueError("حد المخزون غير صحيح")

    # --------------------------------------------------

    def list(self):
        return self.repo.find_all()

    def get(self, product_id: int):
        return self.repo.get_by_id(product_id)

    # --------------------------------------------------

    def create(self, *, actor_id: int, **data) -> int:
        company_id = int(data.get("company_id") or 0)
        PermissionService().require_for_company(actor_id, company_id, "products.create")
        self._validate(data)
        data["name"] = data["name"].strip()
        data.setdefault("code", None)
        data.setdefault("barcode", None)
        # empty strings would collide on the UNIQUE constraints
        data["code"] = data["code"] or None
        data["barcode"] = data["barcode"] or None
        if data["code"] and self.repo.find_by_code(data["code"]):
            raise ValueError("كود المنتج مستخدم من قبل")
        if data["barcode"] and self.repo.find_by_barcode(data["barcode"]):
            raise ValueError("الباركود مستخدم من قبل")
        return self.repo.add(**data)

    # --------------------------------------------------

    def update(self, product_id: int, *, actor_id: int, **data) -> None:
        current = self.repo.get_by_id(product_id)
        if current is None:
            raise ValueError("المنتج غير موجود")
        PermissionService().require_for_company(
            actor_id, int(current["company_id"]), "products.update"
        )
        merged = {
            k: current[k]
            for k in (
                "code", "barcode", "name", "category_id", "brand_id", "unit_id",
                "purchase_price", "sale_price", "minimum_stock", "maximum_stock",
                "description",
            )
        }
        merged.update(data)
        merged["code"] = merged.get("code") or None
        merged["barcode"] = merged.get("barcode") or None
        self._validate(merged)
        merged = {k: merged[k] for k in current.keys() if k in merged and k in self._UPDATABLE}
        self.repo.update(product_id, **merged)

    # --------------------------------------------------

    def delete(self, product_id: int, *, actor_id: int) -> None:
        current = self.repo.get_by_id(product_id)
        if current is None:
            raise ValueError("المنتج غير موجود")
        PermissionService().require_for_company(
            actor_id, int(current["company_id"]), "products.delete"
        )
        self.repo.delete(product_id)

    def search(self, keyword: str):
        return self.repo.search(keyword)

    def low_stock(self):
        return self.repo.low_stock()

    # --------------------------------------------------

    def _change_stock(self, product_id: int, delta: float,
                      warehouse_id: int = 1, user_id: int | None = None,
                      reason: str = "Manual stock adjustment") -> float:
        row = self.repo.get_by_id(product_id)
        if row is None:
            raise ValueError("المنتج غير موجود")
        if user_id is None:
            raise PermissionDenied("A signed-in user is required to adjust inventory.")
        PermissionService().require_for_company(user_id, int(row["company_id"]), "inventory.adjust")
        if not delta:
            raise ValueError("مقدار التعديل لا يمكن أن يكون صفراً")
        company_id = int(row["company_id"])
        branch_id = int(row["branch_id"] or 1)
        inventory = InventoryService()
        with transaction():
            if delta > 0:
                balance = inventory.increase_stock(
                    product_id, delta, warehouse_id, company_id, branch_id,
                    float(row["purchase_price"] or 0),
                )
                qty_in, qty_out = delta, 0
            else:
                balance = inventory.decrease_stock(
                    product_id, abs(delta), warehouse_id, company_id, branch_id,
                    float(row["purchase_price"] or 0),
                )
                qty_in, qty_out = 0, abs(delta)
            inventory.add_stock_movement(
                company_id=company_id, branch_id=branch_id,
                warehouse_id=warehouse_id, product_id=product_id,
                transaction_type="ADJUSTMENT", reference_type="MANUAL",
                reference_id=None, quantity_in=qty_in, quantity_out=qty_out,
                unit_cost=float(row["purchase_price"] or 0),
                balance_after=balance, notes=reason, created_by=user_id,
            )
        return balance

    def increase_stock(self, product_id: int, qty: float,
                       warehouse_id: int = 1, user_id: int | None = None) -> float:
        if qty <= 0:
            raise ValueError("الكمية يجب أن تكون أكبر من صفر")
        return self._change_stock(product_id, float(qty), warehouse_id, user_id,
                                  "Manual stock increase")

    def decrease_stock(self, product_id: int, qty: float,
                       warehouse_id: int = 1, user_id: int | None = None) -> float:
        if qty <= 0:
            raise ValueError("الكمية يجب أن تكون أكبر من صفر")
        return self._change_stock(product_id, -float(qty), warehouse_id, user_id,
                                  "Manual stock decrease")

    def adjust_stock(self, product_id: int, delta: float, reason: str = "",
                     user_id: int | None = None, warehouse_id: int = 1) -> float:
        return self._change_stock(product_id, float(delta), warehouse_id,
                                  user_id, reason or "Manual stock adjustment")
