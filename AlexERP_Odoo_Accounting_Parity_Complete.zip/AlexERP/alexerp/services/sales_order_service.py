"""Quotation and sales-order lifecycle, integrated with existing invoice posting."""
from __future__ import annotations

import math
from datetime import date

from alexerp.core import tenancy
from alexerp.database.db import Database
from alexerp.database.transaction import transaction
from alexerp.services.audit_service import AuditService
from alexerp.services.inventory_service import InventoryService
from alexerp.services.permission_service import PermissionDenied, PermissionService
from alexerp.services.sales_service import SalesService


class SalesOrderError(ValueError):
    pass


class SalesOrderService:
    STATUSES = {"DRAFT", "SENT", "CONFIRMED", "PARTIALLY_INVOICED", "INVOICED", "CANCELLED", "EXPIRED"}

    def __init__(self):
        self.inventory = InventoryService()
        self.permissions = PermissionService()

    @property
    def conn(self):
        # Resolve per-thread, matching BaseRepository's connection behavior.
        return Database.connect()

    def _permission(self, user_id: int, company_id: int, key: str):
        try:
            self.permissions.require_for_company(user_id, company_id, key)
        except PermissionDenied as exc:
            raise SalesOrderError(f"User is not authorized: {key}.") from exc

    @staticmethod
    def _line_values(item: dict, index: int) -> tuple:
        try:
            qty = float(item["quantity"])
            price = float(item["unit_price"])
            discount = float(item.get("discount", 0) or 0)
            tax = float(item.get("tax", 0) or 0)
            total = float(item.get("line_total", item.get("total")))
        except (KeyError, TypeError, ValueError) as exc:
            raise SalesOrderError(f"Invalid values in quotation line {index}.") from exc
        values = (qty, price, discount, tax, total)
        if any(not math.isfinite(v) for v in values):
            raise SalesOrderError(f"Quotation line {index} contains a non-finite amount.")
        if qty <= 0 or min(price, discount, tax, total) < 0:
            raise SalesOrderError(f"Quotation line {index} contains a negative amount or invalid quantity.")
        expected = qty * price - discount + tax
        if expected < -0.005 or round(expected, 2) != round(total, 2):
            raise SalesOrderError(f"Quotation line {index} total does not reconcile.")
        return qty, price, discount, tax, total

    def create_quotation(self, *, company_id: int, branch_id: int, customer_id: int,
                         quotation_number: str, document_date: str, items: list,
                         created_by: int, expiry_date: str | None = None,
                         notes: str = "") -> int:
        if not items:
            raise SalesOrderError("Quotation must contain at least one line.")
        quotation_number = str(quotation_number or "").strip()
        if not quotation_number:
            raise SalesOrderError("Quotation number is required.")
        try:
            doc_date = date.fromisoformat(str(document_date)).isoformat()
            expiry = date.fromisoformat(str(expiry_date)).isoformat() if expiry_date else None
        except ValueError as exc:
            raise SalesOrderError("Invalid quotation date or expiry date.") from exc
        if expiry and expiry < doc_date:
            raise SalesOrderError("Quotation expiry date cannot be earlier than its date.")
        tenancy.require_branch(company_id, branch_id)
        tenancy.require_customer(company_id, customer_id)
        self._permission(created_by, company_id, "sales.create")

        prepared = []
        subtotal = discount_total = tax_total = total = 0.0
        for index, item in enumerate(items, 1):
            qty, price, discount, tax, line_total = self._line_values(item, index)
            product_id, warehouse_id = int(item["product_id"]), int(item["warehouse_id"])
            tenancy.require_item_scope(company_id, branch_id, product_id, warehouse_id)
            prepared.append((product_id, warehouse_id, qty, price, discount, tax, line_total))
            subtotal += round(qty * price, 2)
            discount_total += discount
            tax_total += tax
            total += line_total
        subtotal, discount_total, tax_total, total = map(
            lambda x: round(x, 2), (subtotal, discount_total, tax_total, total)
        )
        if round(subtotal - discount_total + tax_total, 2) != total:
            raise SalesOrderError("Quotation totals do not reconcile.")

        with transaction():
            cur = self.conn.execute(
                """INSERT INTO sales_orders(company_id,branch_id,customer_id,quotation_number,
                   document_date,expiry_date,status,subtotal,discount,tax,total,notes,created_by)
                   VALUES(?,?,?,?,?,?,'DRAFT',?,?,?,?,?,?)""",
                (company_id, branch_id, customer_id, quotation_number, doc_date, expiry,
                 subtotal, discount_total, tax_total, total, notes, created_by),
            )
            order_id = int(cur.lastrowid)
            for line in prepared:
                self.conn.execute(
                    """INSERT INTO sales_order_items(sales_order_id,product_id,warehouse_id,
                       quantity,unit_price,discount,tax,line_total) VALUES(?,?,?,?,?,?,?,?)""",
                    (order_id, *line),
                )
            AuditService.record(
                user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="sales", action="quotation_created", entity_type="sales_order",
                record_id=order_id, description=f"Quotation {quotation_number} created",
                after={"quotation_number": quotation_number, "total": total, "status": "DRAFT"},
                connection=self.conn,
            )
            return order_id

    def get_order(self, order_id: int, company_id: int | None = None):
        sql = "SELECT * FROM sales_orders WHERE id=?"
        params = [order_id]
        if company_id is not None:
            sql += " AND company_id=?"
            params.append(company_id)
        return self.conn.execute(sql, tuple(params)).fetchone()

    def get_items(self, order_id: int):
        return self.conn.execute(
            "SELECT * FROM sales_order_items WHERE sales_order_id=? ORDER BY id", (order_id,)
        ).fetchall()

    def send_quotation(self, order_id: int, created_by: int) -> bool | None:
        with transaction():
            order = self.get_order(order_id)
            if order is None:
                raise SalesOrderError("Quotation not found.")
            self._permission(created_by, int(order["company_id"]), "sales.create")
            if order["status"] != "DRAFT":
                raise SalesOrderError("Only draft quotations can be sent.")
            if order["expiry_date"] and str(order["expiry_date"]) < date.today().isoformat():
                self.conn.execute(
                    "UPDATE sales_orders SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (order_id,),
                )
                AuditService.record(user_id=created_by, company_id=int(order["company_id"]),
                    branch_id=int(order["branch_id"]), module="sales", action="quotation_expired",
                    entity_type="sales_order", record_id=order_id,
                    description=f"Quotation {order['quotation_number']} expired",
                    before={"status": order["status"]}, after={"status": "EXPIRED"}, connection=self.conn)
                return False
            self.conn.execute(
                "UPDATE sales_orders SET status='SENT',updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (order_id,),
            )
            AuditService.record(user_id=created_by, company_id=int(order["company_id"]),
                branch_id=int(order["branch_id"]), module="sales", action="quotation_sent",
                entity_type="sales_order", record_id=order_id,
                description=f"Quotation {order['quotation_number']} marked as sent",
                before={"status": "DRAFT"}, after={"status": "SENT"}, connection=self.conn)

    def confirm_order(self, order_id: int, created_by: int, order_number: str | None = None) -> str | bool:
        with transaction():
            order = self.get_order(order_id)
            if order is None:
                raise SalesOrderError("Quotation not found.")
            company_id, branch_id = int(order["company_id"]), int(order["branch_id"])
            self._permission(created_by, company_id, "sales.confirm")
            if order["status"] not in {"DRAFT", "SENT"}:
                raise SalesOrderError("Only draft or sent quotations can be confirmed.")
            if order["expiry_date"] and str(order["expiry_date"]) < date.today().isoformat():
                self.conn.execute(
                    "UPDATE sales_orders SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (order_id,),
                )
                AuditService.record(user_id=created_by, company_id=company_id,
                    branch_id=branch_id, module="sales", action="quotation_expired",
                    entity_type="sales_order", record_id=order_id,
                    description=f"Quotation {order['quotation_number']} expired",
                    before={"status": order["status"]}, after={"status": "EXPIRED"}, connection=self.conn)
                return False
            lines = self.get_items(order_id)
            requested: dict[tuple[int, int], float] = {}
            for line in lines:
                key = (int(line["product_id"]), int(line["warehouse_id"]))
                requested[key] = requested.get(key, 0.0) + float(line["quantity"])
            for (product_id, warehouse_id), qty in requested.items():
                if not self.inventory.check_stock(product_id, qty, warehouse_id):
                    raise SalesOrderError(f"Insufficient available stock for product {product_id}.")
            resolved_number = str(order_number or f"SO-{company_id}-{order_id:06d}").strip()
            if not resolved_number:
                raise SalesOrderError("Sales order number is required.")
            cur = self.conn.execute(
                """UPDATE sales_orders SET status='CONFIRMED',order_number=?,confirmed_by=?,
                   confirmed_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP
                   WHERE id=? AND status IN ('DRAFT','SENT')""",
                (resolved_number, created_by, order_id),
            )
            if cur.rowcount != 1:
                raise SalesOrderError("Quotation was changed by another operation; reload it.")
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="sales", action="sales_order_confirmed", entity_type="sales_order",
                record_id=order_id, description=f"Sales order {resolved_number} confirmed",
                before={"status": order['status']},
                after={"status": "CONFIRMED", "order_number": resolved_number}, connection=self.conn)
            return resolved_number

    def create_invoice_from_order(self, order_id: int, invoice_number: str,
                                  invoice_date: str, created_by: int,
                                  quantities: dict[int, float] | None = None,
                                  notes: str = "", invoice_accounts: dict | None = None) -> int:
        """Create a posted invoice for selected remaining quantities; multiple invoices are supported."""
        with transaction():
            order = self.get_order(order_id)
            if order is None:
                raise SalesOrderError("Sales order not found.")
            company_id, branch_id = int(order["company_id"]), int(order["branch_id"])
            self._permission(created_by, company_id, "sales.invoice_from_order")
            if order["status"] not in {"CONFIRMED", "PARTIALLY_INVOICED"}:
                raise SalesOrderError("Only confirmed sales orders with uninvoiced quantities can be invoiced.")
            try:
                date.fromisoformat(str(invoice_date))
            except ValueError as exc:
                raise SalesOrderError("Invalid invoice date.") from exc

            if quantities is not None:
                try:
                    quantities = {int(key): float(value) for key, value in quantities.items()}
                except (TypeError, ValueError) as exc:
                    raise SalesOrderError("Invoice quantities must be numeric and keyed by order line ID.") from exc
                valid_line_ids = {int(line["id"]) for line in self.get_items(order_id)}
                if set(quantities) - valid_line_ids:
                    raise SalesOrderError("Invoice request contains a line from another sales order.")

            selected = []
            for line in self.get_items(order_id):
                line_id = int(line["id"])
                ordered = float(line["quantity"])
                invoiced = float(line["invoiced_quantity"] or 0)
                remaining = round(ordered - invoiced, 6)
                if quantities is not None and line_id not in quantities:
                    continue
                requested = float(quantities[line_id]) if quantities is not None else remaining
                if not math.isfinite(requested) or requested <= 0 or requested > remaining + 0.000001:
                    raise SalesOrderError(f"Invalid invoice quantity for sales order line {line_id}.")
                cumulative_ratio = (invoiced + requested) / ordered
                prior_ratio = invoiced / ordered
                allocated_discount = round(float(line["discount"]) * cumulative_ratio, 2) - round(float(line["discount"]) * prior_ratio, 2)
                allocated_tax = round(float(line["tax"]) * cumulative_ratio, 2) - round(float(line["tax"]) * prior_ratio, 2)
                subtotal = round(requested * float(line["unit_price"]), 2)
                line_total = round(requested * float(line["unit_price"]) - allocated_discount + allocated_tax, 2)
                selected.append({
                    "sales_order_item_id": line_id,
                    "product_id": int(line["product_id"]),
                    "warehouse_id": int(line["warehouse_id"]),
                    "quantity": requested,
                    "unit_price": float(line["unit_price"]),
                    "discount": allocated_discount,
                    "tax": allocated_tax,
                    "total": line_total,
                    "new_invoiced_quantity": round(invoiced + requested, 6),
                })
            if not selected:
                raise SalesOrderError("There are no remaining quantities to invoice.")

            subtotal = round(sum(round(x["quantity"] * x["unit_price"], 2) for x in selected), 2)
            discount = round(sum(x["discount"] for x in selected), 2)
            tax = round(sum(x["tax"] for x in selected), 2)
            total = round(subtotal - discount + tax, 2)
            invoice_id = SalesService().create_invoice(
                company_id=company_id, branch_id=branch_id,
                customer_id=int(order["customer_id"]), invoice_number=invoice_number,
                invoice_date=str(invoice_date), items=selected, subtotal=subtotal,
                discount=discount, tax=tax, total=total, paid_amount=0,
                remaining_amount=total, notes=notes or f"From Sales Order {order['order_number']}",
                created_by=created_by,
                **({key: value for key, value in (invoice_accounts or {}).items()
                    if key in {"receivable_account", "sales_account", "inventory_account",
                               "cogs_account", "tax_account", "cash_account"}}),
            )
            self.conn.execute(
                "UPDATE sales_invoices SET sales_order_id=? WHERE id=?", (order_id, invoice_id)
            )
            invoice_lines = self.conn.execute(
                "SELECT id FROM sales_invoice_items WHERE invoice_id=? ORDER BY id", (invoice_id,)
            ).fetchall()
            for item, invoice_line in zip(selected, invoice_lines):
                self.conn.execute(
                    "UPDATE sales_invoice_items SET sales_order_item_id=? WHERE id=?",
                    (item["sales_order_item_id"], int(invoice_line["id"])),
                )
                self.conn.execute(
                    "UPDATE sales_order_items SET invoiced_quantity=? WHERE id=?",
                    (item["new_invoiced_quantity"], item["sales_order_item_id"]),
                )
            remaining_count = self.conn.execute(
                "SELECT COUNT(*) FROM sales_order_items WHERE sales_order_id=? AND quantity-invoiced_quantity>0.000001",
                (order_id,),
            ).fetchone()[0]
            new_status = "PARTIALLY_INVOICED" if remaining_count else "INVOICED"
            self.conn.execute(
                "UPDATE sales_orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (new_status, order_id),
            )
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="sales", action="sales_order_invoiced", entity_type="sales_order",
                record_id=order_id, description=f"Sales order {order['order_number']} invoiced",
                after={"invoice_id": invoice_id, "invoice_number": invoice_number,
                       "status": new_status, "total": total}, connection=self.conn)
            return invoice_id

    def cancel_order(self, order_id: int, created_by: int) -> None:
        with transaction():
            order = self.get_order(order_id)
            if order is None:
                raise SalesOrderError("Sales order not found.")
            self._permission(created_by, int(order["company_id"]), "sales.cancel")
            if order["status"] not in {"DRAFT", "SENT", "CONFIRMED", "PARTIALLY_INVOICED"}:
                raise SalesOrderError("This sales order cannot be cancelled.")
            cur = self.conn.execute(
                "UPDATE sales_orders SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status=?",
                (order_id, order["status"]),
            )
            if cur.rowcount != 1:
                raise SalesOrderError("Sales order was changed by another operation; reload it.")
            AuditService.record(user_id=created_by, company_id=int(order["company_id"]),
                branch_id=int(order["branch_id"]), module="sales", action="sales_order_cancelled",
                entity_type="sales_order", record_id=order_id,
                description=f"Sales order {order['order_number'] or order['quotation_number']} cancelled",
                before={"status": order["status"]}, after={"status": "CANCELLED"}, connection=self.conn)

    def list_for_company(self, company_id: int, keyword: str | None = None,
                         branch_id: int | None = None):
        sql = """SELECT so.*, c.name AS customer_name FROM sales_orders so
                 JOIN customers c ON c.id=so.customer_id WHERE so.company_id=?"""
        params: list = [company_id]
        if branch_id is not None:
            sql += " AND so.branch_id=?"
            params.append(branch_id)
        if keyword:
            sql += " AND (so.quotation_number LIKE ? OR so.order_number LIKE ? OR c.name LIKE ?)"
            like = f"%{keyword}%"
            params.extend((like, like, like))
        sql += " ORDER BY so.id DESC"
        return self.conn.execute(sql, tuple(params)).fetchall()
