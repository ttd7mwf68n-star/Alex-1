"""Profit and loss statement calculations."""
from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from alexerp.accounting import AccountingReadService

_CENT = Decimal("0.01")


def _money(value) -> Decimal:
    return Decimal(str(value or 0)).quantize(_CENT, rounding=ROUND_HALF_UP)


class ProfitLossService:
    def __init__(self, repository=None, read_service=None):
        self.repo = repository
        self.read_service = read_service or AccountingReadService()

    def get_report(self, company_id: int, date_from: str, date_to: str):
        if not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("A valid company_id is required.")
        try:
            start = date.fromisoformat(str(date_from))
            end = date.fromisoformat(str(date_to))
        except (TypeError, ValueError) as exc:
            raise ValueError("Report dates must be valid ISO dates (YYYY-MM-DD).") from exc
        if start > end:
            raise ValueError("Report start date cannot be after end date.")

        revenue_rows, expense_rows = [], []
        revenue_total = Decimal("0.00")
        expense_total = Decimal("0.00")
        rows = (self.repo.get_profit_and_loss(company_id, date_from, date_to) if self.repo
                else self.read_service.get_profit_loss_rows(company_id, date_from, date_to))
        for row in rows:
            debit, credit = _money(row["debit"]), _money(row["credit"])
            if row["account_type"] == "REVENUE":
                amount = credit - debit
                revenue_total += amount
                target = revenue_rows
            elif row["account_type"] == "EXPENSE":
                amount = debit - credit
                expense_total += amount
                target = expense_rows
            else:  # Defensive: repository must only return P&L account types.
                continue
            target.append({
                "code": row["code"],
                "name": row["name"],
                "debit": float(debit),
                "credit": float(credit),
                "amount": float(amount),
            })

        net_profit = revenue_total - expense_total
        return {
            "date_from": start.isoformat(),
            "date_to": end.isoformat(),
            "revenue": revenue_rows,
            "expenses": expense_rows,
            "total_revenue": float(revenue_total),
            "total_expenses": float(expense_total),
            "net_profit": float(net_profit),
            "is_profitable": net_profit >= 0,
        }
