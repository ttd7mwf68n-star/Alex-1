"""Safe, role-based field and record policies for purchasing records."""
from __future__ import annotations

import math
from typing import Any, Mapping

from alexerp.database.db import Database


class AdvancedAccessError(PermissionError):
    """Raised when a configured field or record policy denies access."""


class AdvancedAccessService:
    ENTITY_FIELDS = {
        "purchase_order": {
            "created_by", "status", "approval_status", "amount", "supplier_id",
        }
    }
    ENTITY_WRITABLE_FIELDS = {
        "purchase_order": {
            "unit_cost", "discount", "tax", "notes", "expected_date",
        }
    }
    ENTITY_POLICY_FIELDS = {
        "purchase_order": ENTITY_WRITABLE_FIELDS["purchase_order"] | {"amount"},
    }
    FIELD_ACCESS_LEVELS = {"READ_WRITE", "READ_ONLY", "HIDDEN"}
    RULE_EFFECTS = {"ALLOW", "DENY"}
    RULE_OPERATORS = {"EQ", "NE", "GT", "GTE", "LT", "LTE"}

    @staticmethod
    def role_id_for_user(user_id: int, company_id: int) -> int:
        row = Database.connect().execute(
            """SELECT u.role_id
               FROM users u JOIN roles r ON r.id=u.role_id AND r.is_active=1
                 AND (r.company_id IS NULL OR r.company_id=u.company_id)
               WHERE u.id=? AND u.company_id=? AND u.is_active=1""",
            (int(user_id), int(company_id)),
        ).fetchone()
        if row is None:
            raise AdvancedAccessError("An active user role is required for this company.")
        return int(row["role_id"])

    def field_access(self, user_id: int, company_id: int, entity_type: str, field_key: str) -> str:
        if field_key not in self.ENTITY_WRITABLE_FIELDS.get(entity_type, set()):
            raise ValueError(f"Unknown writable field: {entity_type}.{field_key}")
        role_id = self.role_id_for_user(user_id, company_id)
        row = Database.connect().execute(
            """SELECT access_level FROM role_field_policies
               WHERE role_id=? AND entity_type=? AND field_key=?""",
            (role_id, entity_type, field_key),
        ).fetchone()
        return str(row["access_level"]) if row else "READ_WRITE"

    def require_field_write(self, user_id: int, company_id: int, entity_type: str, field_key: str) -> None:
        if self.field_access(user_id, company_id, entity_type, field_key) != "READ_WRITE":
            raise AdvancedAccessError(f"Writing {entity_type}.{field_key} is not allowed for this role.")

    def hidden_fields(self, user_id: int, company_id: int, entity_type: str) -> set[str]:
        role_id = self.role_id_for_user(user_id, company_id)
        rows = Database.connect().execute(
            """SELECT field_key FROM role_field_policies
               WHERE role_id=? AND entity_type=? AND access_level='HIDDEN'""",
            (role_id, entity_type),
        ).fetchall()
        return {str(row["field_key"]) for row in rows}

    def filter_record_fields(
        self, user_id: int, company_id: int, entity_type: str, record: Mapping[str, Any]
    ) -> dict[str, Any]:
        hidden = self.hidden_fields(user_id, company_id, entity_type)
        display_keys = {
            "amount": "total_amount",
        }
        hidden_keys = hidden | {display_keys[key] for key in hidden if key in display_keys}
        return {key: value for key, value in record.items() if key not in hidden_keys}

    @staticmethod
    def _value_matches(rule, record: Mapping[str, Any], actor_id: int) -> bool:
        key = str(rule["field_key"])
        actual = record.get(key)
        expected = str(rule["value"])
        operator = str(rule["operator"])
        if key == "created_by" and expected == "current_user":
            actual_value: Any = int(actual) if actual is not None else None
            expected_value: Any = int(actor_id)
        elif key == "amount":
            if actual is None:
                return False
            try:
                actual_value = float(actual)
                expected_value = float(expected)
            except (TypeError, ValueError):
                return False
            if not math.isfinite(actual_value) or not math.isfinite(expected_value):
                return False
        else:
            actual_value = str(actual) if actual is not None else None
            expected_value = expected

        if operator == "EQ":
            return actual_value == expected_value
        if operator == "NE":
            return actual_value != expected_value
        if actual_value is None:
            return False
        if operator == "GT":
            return actual_value > expected_value
        if operator == "GTE":
            return actual_value >= expected_value
        if operator == "LT":
            return actual_value < expected_value
        if operator == "LTE":
            return actual_value <= expected_value
        return False

    def record_is_allowed(
        self, user_id: int, company_id: int, entity_type: str, record: Mapping[str, Any]
    ) -> bool:
        role_id = self.role_id_for_user(user_id, company_id)
        rules = Database.connect().execute(
            """SELECT effect,field_key,operator,value FROM role_record_rules
               WHERE role_id=? AND entity_type=? ORDER BY id""",
            (role_id, entity_type),
        ).fetchall()
        if not rules:
            return True
        deny_rules = [rule for rule in rules if rule["effect"] == "DENY"]
        if any(self._value_matches(rule, record, int(user_id)) for rule in deny_rules):
            return False
        allow_rules = [rule for rule in rules if rule["effect"] == "ALLOW"]
        return not allow_rules or any(
            self._value_matches(rule, record, int(user_id)) for rule in allow_rules
        )

    def require_record_access(
        self, user_id: int, company_id: int, entity_type: str, record: Mapping[str, Any]
    ) -> None:
        if not self.record_is_allowed(user_id, company_id, entity_type, record):
            raise AdvancedAccessError(f"Access to this {entity_type} record is not allowed.")
