"""Persistent, revocable user sessions and security audit events."""
from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from alexerp.database.db import Database
from alexerp.services.audit_service import AuditService


class SessionService:
    TTL_HOURS = 8

    @staticmethod
    def _token_hash(token: str) -> str:
        return hashlib.sha256(str(token).encode("utf-8")).hexdigest()

    def create(self, user: dict, *, ip_address: str = "", device: str = "") -> str:
        token = secrets.token_urlsafe(32)
        expires = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(hours=self.TTL_HOURS)
        conn = Database.connect()
        try:
            conn.execute(
                "INSERT INTO user_sessions(user_id,session_token,login_time,expires_at,ip_address,device,is_active) "
                "VALUES(?,?,CURRENT_TIMESTAMP,?,?,?,1)",
                (int(user["id"]), self._token_hash(token), expires.strftime("%Y-%m-%d %H:%M:%S"),
                 str(ip_address or "")[:80], str(device or "")[:160]),
            )
            AuditService.record(user_id=int(user["id"]), company_id=user.get("company_id"),
                                branch_id=user.get("branch_id"), module="security", action="login",
                                entity_type="session", description="User session created",
                                ip_address=ip_address, connection=conn)
            conn.commit()
            return token
        except Exception:
            conn.rollback()
            raise

    def validate(self, token: str):
        if not token or len(token) > 256:
            return None
        conn = Database.connect()
        row = conn.execute(
            "SELECT u.id,u.username,u.full_name,u.role_id,u.company_id,u.branch_id,u.is_active, "
            "s.id AS session_id,s.expires_at "
            "FROM user_sessions s JOIN users u ON u.id=s.user_id "
            "WHERE s.session_token=? AND s.is_active=1 AND u.is_active=1",
            (self._token_hash(token),),
        ).fetchone()
        if row is None:
            return None
        try:
            expiry = datetime.fromisoformat(str(row["expires_at"])) if row["expires_at"] else None
        except ValueError:
            expiry = None
        if expiry is None:
            self.revoke(token, reason="invalid_expiry")
            return None
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
        if expiry <= datetime.now(timezone.utc):
            self.revoke(token, reason="expired")
            return None
        return {key: row[key] for key in ("id", "username", "full_name", "role_id", "company_id", "branch_id")}

    def revoke(self, token: str, *, user_id: int | None = None, reason: str = "logout") -> bool:
        if not token:
            return False
        conn = Database.connect()
        row = conn.execute(
            "SELECT s.id,s.user_id,u.company_id,u.branch_id FROM user_sessions s "
            "JOIN users u ON u.id=s.user_id WHERE s.session_token=? AND s.is_active=1",
            (self._token_hash(token),)).fetchone()
        if row is None:
            return False
        if user_id is not None and int(row["user_id"]) != int(user_id):
            return False
        try:
            conn.execute("UPDATE user_sessions SET is_active=0,logout_time=CURRENT_TIMESTAMP WHERE id=?", (row["id"],))
            AuditService.record(user_id=int(row["user_id"]), company_id=row["company_id"],
                                branch_id=row["branch_id"], module="security", action="session_revoked",
                                entity_type="session", record_id=int(row["id"]),
                                description=str(reason)[:200], connection=conn)
            conn.commit()
            return True
        except Exception:
            conn.rollback()
            raise

    def revoke_user_sessions(self, user_id: int, *, reason: str = "account_changed") -> int:
        conn = Database.connect()
        try:
            user = conn.execute("SELECT company_id,branch_id FROM users WHERE id=?", (int(user_id),)).fetchone()
            rows = conn.execute("SELECT id FROM user_sessions WHERE user_id=? AND is_active=1", (int(user_id),)).fetchall()
            if rows:
                conn.execute("UPDATE user_sessions SET is_active=0,logout_time=CURRENT_TIMESTAMP WHERE user_id=? AND is_active=1",
                             (int(user_id),))
                AuditService.record(user_id=int(user_id), company_id=user["company_id"] if user else None,
                                    branch_id=user["branch_id"] if user else None, module="security",
                                    action="all_sessions_revoked", entity_type="user", record_id=int(user_id),
                                    description=str(reason)[:200], connection=conn)
            conn.commit()
            return len(rows)
        except Exception:
            conn.rollback()
            raise

    def list_active(self, user_id: int, company_id: int):
        rows = Database.connect().execute(
            "SELECT s.id,s.login_time,s.expires_at,s.ip_address,s.device FROM user_sessions s "
            "JOIN users u ON u.id=s.user_id WHERE s.user_id=? AND u.company_id=? AND s.is_active=1 "
            "ORDER BY s.login_time DESC", (int(user_id), int(company_id))
        ).fetchall()
        return [dict(row) for row in rows]
