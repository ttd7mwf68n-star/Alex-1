"""
AlexERP — Business Management System
Transfer Service
"""

from __future__ import annotations

from alexerp.database.transaction import transaction

from alexerp.core.constants import (
    StockTransactionType,
    ReferenceType,
)

from alexerp.repositories.transfer_repository import TransferRepository
from alexerp.services.audit_service import AuditService
from alexerp.services.inventory_service import InventoryService
from alexerp.services.permission_service import PermissionService


class TransferError(Exception):
    pass


class TransferService:

    def __init__(self):

        self.repo = TransferRepository()
        self.inventory = InventoryService()

    # =====================================================
    # Create Transfer
    # =====================================================

    def create_transfer(

        self,

        company_id: int,
        branch_id: int,

        from_warehouse: int,
        to_warehouse: int,

        transfer_number: str,
        transfer_date: str,

        items: list,

        notes: str,

        created_by: int,

    ) -> int:

        try:
            PermissionService().require_for_company(created_by, company_id, "inventory.adjust")
        except PermissionError as exc:
            raise TransferError("User is not authorized to transfer inventory.") from exc
        if from_warehouse == to_warehouse:

            raise TransferError(
                "Source and destination warehouse cannot be the same."
            )

        if not items:

            raise TransferError(
                "Transfer contains no items."
            )

        from alexerp.core import tenancy
        tenancy.require_branch(company_id, branch_id)
        # Validate both warehouses and every product before creating the document.
        for item in items:
            product_id = int(item["product_id"])
            tenancy.require_item_scope(company_id, branch_id, product_id, from_warehouse)
            tenancy.require_item_scope(company_id, branch_id, product_id, to_warehouse)

        with transaction():

            transfer_id = self.repo.create_transfer(

                company_id=company_id,

                branch_id=branch_id,

                from_warehouse=from_warehouse,

                to_warehouse=to_warehouse,

                transfer_number=transfer_number,

                transfer_date=transfer_date,

                notes=notes,

                created_by=created_by,

            )

            for item in items:

                qty = float(item["quantity"])

                product_id = item["product_id"]

                unit_cost = float(item.get("unit_cost") or self.inventory.get_unit_cost(product_id, from_warehouse))

                if not self.inventory.check_stock(
                    product_id,
                    qty,
                    from_warehouse,
                ):
                    raise TransferError(
                        f"Insufficient stock for product {product_id}"
                    )

                self.repo.add_item(

                    transfer_id=transfer_id,

                    product_id=product_id,

                    quantity=qty,

                    unit_cost=unit_cost,

                )

                # إخراج من المخزن المصدر

                self.inventory.decrease_stock(
                    product_id, qty, from_warehouse,
                    company_id, branch_id, unit_cost,
                )

                self.inventory.add_stock_movement(

                    company_id=company_id,

                    branch_id=branch_id,

                    warehouse_id=from_warehouse,

                    product_id=product_id,

                    transaction_type=StockTransactionType.TRANSFER_OUT,

                    reference_type=ReferenceType.TRANSFER,

                    reference_id=transfer_id,

                    quantity_out=qty,

                    unit_cost=unit_cost,

                    balance_after=self.inventory.get_quantity(product_id, from_warehouse),

                    notes=f"Transfer #{transfer_number}",

                    created_by=created_by,

                )

                # إدخال للمخزن الوجهة

                self.inventory.increase_stock(
                    product_id, qty, to_warehouse,
                    company_id, branch_id, unit_cost,
                )

                self.inventory.add_stock_movement(

                    company_id=company_id,

                    branch_id=branch_id,

                    warehouse_id=to_warehouse,

                    product_id=product_id,

                    transaction_type=StockTransactionType.TRANSFER_IN,

                    reference_type=ReferenceType.TRANSFER,

                    reference_id=transfer_id,

                    quantity_in=qty,

                    unit_cost=unit_cost,

                    balance_after=self.inventory.get_quantity(product_id, to_warehouse),

                    notes=f"Transfer #{transfer_number}",

                    created_by=created_by,

                )

            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="inventory", action="warehouse_transfer_posted", entity_type="stock_transfer",
                record_id=transfer_id, description=f"Warehouse transfer {transfer_number} posted",
                after={"transfer_number": transfer_number, "from_warehouse": from_warehouse,
                       "to_warehouse": to_warehouse, "status": "POSTED",
                       "items": [{"product_id": int(x["product_id"]),
                                  "quantity": float(x["quantity"]),
                                  "unit_cost": float(x.get("unit_cost") or 0)} for x in items]})
            return transfer_id
