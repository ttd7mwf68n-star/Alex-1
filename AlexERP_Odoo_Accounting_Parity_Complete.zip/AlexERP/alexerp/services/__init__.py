from .customer_service import CustomerService
from .product_service import ProductService

customer_service = CustomerService()

product_service = ProductService()