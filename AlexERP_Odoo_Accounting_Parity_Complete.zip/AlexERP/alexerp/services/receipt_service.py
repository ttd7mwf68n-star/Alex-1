"""
AlexERP — Business Management System
Customer receipt service: allocates a receipt between cash and receivables
and posts a balanced journal entry atomically.
"""

from __future__ import annotations

import math

from alexerp.database.transaction import transaction
from alexerp.repositories.receipt_repository import ReceiptRepository
from alexerp.accounting import AccountingService
from alexerp.services.party_balance_service import PartyBalanceService
from alexerp.core import tenancy
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService, PermissionDenied
from alexerp.services.customer_service import CustomerService


class ReceiptService:

    def __init__(self):

        self.repo = ReceiptRepository()

        self.accounting = AccountingService()

        self.balances = PartyBalanceService()

    def create_receipt(

        self,

        company_id,

        branch_id,

        receipt_number,

        receipt_date,

        customer_id,

        cash_account,

        receivable_account,

        amount,

        created_by,

    ):
        try:
            amount = float(amount)
        except (TypeError, ValueError):
            raise ValueError("Receipt amount must be a valid number.")
        if not math.isfinite(amount) or amount <= 0:
            raise ValueError("Receipt amount must be finite and positive.")
        amount = round(amount, 2)

        tenancy.require_branch(company_id, branch_id)
        tenancy.require_customer(company_id, customer_id)
        try:
            PermissionService().require_for_company(created_by, company_id, "receipts.create")
        except PermissionDenied as exc:
            raise PermissionError("User is not authorized to create customer receipts.") from exc
        tenancy.require_account(company_id, receivable_account, "Accounts receivable account")
        receivable_account = CustomerService().ensure_customer_account(
            company_id, customer_id
        )
        tenancy.require_accounts(company_id, cash_account=cash_account,
            receivable_account=receivable_account)
        with transaction():
            receipt_id = self.repo.create(

                company_id,

                branch_id,

                receipt_number,

                receipt_date,

                customer_id,

                cash_account,

                amount,

                "",

                created_by,

            )

            details = [

                {

                    "account_id": cash_account,

                    "debit": amount,

                    "credit": 0,
                    "description": f"Receipt {receipt_number}"

                },

                {

                    "account_id": receivable_account,

                    "debit": 0,

                    "credit": amount,
                    "description": f"Receipt {receipt_number}"

                },

            ]

            self.accounting.create_entry(

                company_id=company_id,

                branch_id=branch_id,

                entry_number=f"RC-{receipt_number}",

                entry_date=receipt_date,

                description=f"Customer Receipt {receipt_number}",

                reference_type="RECEIPT",

                reference_id=receipt_id,

                created_by=created_by,

                details=details,

            )

            self.balances.refresh_customer(customer_id)
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="receipts", action="customer_receipt_posted", entity_type="customer_receipt",
                record_id=receipt_id, description=f"Customer receipt {receipt_number} posted",
                after={"receipt_number": receipt_number, "customer_id": customer_id,
                       "amount": amount, "status": "POSTED"})
            return receipt_id


    def cancel_receipt(self, receipt_id, created_by, cancel_date=None):
        from datetime import date
        with transaction():
            receipt = self.repo.get_for_actor(receipt_id, created_by)
            if receipt is None:
                raise ValueError("Customer receipt not found.")
            if receipt["source_sales_invoice_id"] is not None:
                raise ValueError("Invoice-time receipts must be reversed by cancelling their sales invoice.")
            try:
                PermissionService().require_for_company(
                    created_by, int(receipt["company_id"]), "receipts.cancel"
                )
            except PermissionDenied as exc:
                raise PermissionError("User is not authorized to cancel customer receipts.") from exc
            if str(receipt["status"]).upper() == "CANCELLED":
                raise ValueError("Customer receipt is already cancelled.")
            if str(receipt["status"]).upper() != "POSTED":
                raise ValueError("Only posted customer receipts can be cancelled.")
            from alexerp.services.invoice_settlement_service import InvoiceSettlementService
            InvoiceSettlementService().reverse_receipt_allocations(receipt_id)
            self.accounting.reverse_entry("RECEIPT", receipt_id, created_by,
                reversal_date=cancel_date or date.today().isoformat())
            self.repo.set_status(receipt_id, int(receipt["company_id"]), "CANCELLED")
            self.balances.refresh_customer(int(receipt["customer_id"]))
            before = {"receipt_number": receipt["receipt_number"], "customer_id": int(receipt["customer_id"]),
                      "amount": float(receipt["amount"]), "status": str(receipt["status"])}
            AuditService.record(user_id=created_by, company_id=int(receipt["company_id"]),
                branch_id=int(receipt["branch_id"]), module="receipts", action="customer_receipt_cancelled",
                entity_type="customer_receipt", record_id=receipt_id,
                description=f"Customer receipt {receipt['receipt_number']} cancelled",
                before=before, after={**before, "status": "CANCELLED"})
            return True
