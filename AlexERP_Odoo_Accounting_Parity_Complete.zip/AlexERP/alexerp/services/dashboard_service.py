"""Dashboard / analytics queries (read-only)."""
from __future__ import annotations

from datetime import date, timedelta

from alexerp.repositories.base_repository import BaseRepository

_ACTIVE_SALES = "COALESCE(status,'') NOT IN ('Cancelled','Canceled','Void','Draft')"
_ACTIVE_PURCHASES = "COALESCE(status,'') NOT IN ('Cancelled','Canceled','Void','Draft')"


class DashboardService(BaseRepository):
    table_name = "products"

    def _scalar(self, sql: str, params: tuple = ()):
        row = self.fetchone(sql, params)
        return row[0] if row and row[0] is not None else 0

    @staticmethod
    def _scope(alias: str, company_id: int | None, branch_id: int | None):
        clauses = []
        params = []
        if company_id is not None:
            clauses.append(f"{alias}.company_id=?")
            params.append(int(company_id))
        if branch_id is not None and alias not in {"customers", "suppliers"}:
            clauses.append(f"{alias}.branch_id=?")
            params.append(int(branch_id))
        return (" AND " + " AND ".join(clauses) if clauses else "", tuple(params))

    def summary(self, company_id: int | None = None,
                branch_id: int | None = None) -> dict:
        def value(sql: str, table: str, params: tuple = ()):
            clause, scope_params = self._scope(table, company_id, branch_id)
            return self._scalar(sql + clause, params + scope_params)

        return {
            "products": value("SELECT COUNT(*) FROM products WHERE is_active=1", "products"),
            "low_stock": value(
                "SELECT COUNT(*) FROM products WHERE is_active=1 AND quantity<=minimum_stock",
                "products",
            ),
            "stock_value": value(
                "SELECT SUM(quantity*purchase_price) FROM products WHERE is_active=1", "products"
            ),
            "customers": value("SELECT COUNT(*) FROM customers WHERE is_active=1", "customers"),
            "suppliers": value("SELECT COUNT(*) FROM suppliers WHERE is_active=1", "suppliers"),
            "sales_today": value(
                f"SELECT SUM(total) FROM sales_invoices WHERE invoice_date=date('now','localtime') AND {_ACTIVE_SALES}",
                "sales_invoices",
            ),
            "sales_month": value(
                f"SELECT SUM(total) FROM sales_invoices WHERE strftime('%Y-%m',invoice_date)=strftime('%Y-%m','now','localtime') AND {_ACTIVE_SALES}",
                "sales_invoices",
            ),
            "purchases_month": value(
                f"SELECT SUM(total) FROM purchase_invoices WHERE strftime('%Y-%m',invoice_date)=strftime('%Y-%m','now','localtime') AND {_ACTIVE_PURCHASES}",
                "purchase_invoices",
            ),
            "receivables": value(
                "SELECT SUM(current_balance) FROM customers WHERE current_balance>0", "customers"
            ),
            "payables": value(
                "SELECT SUM(current_balance) FROM suppliers WHERE current_balance>0", "suppliers"
            ),
        }

    def sales_trend(self, days: int = 14, company_id: int | None = None,
                    branch_id: int | None = None) -> list[dict]:
        days = max(1, min(int(days), 366))
        start = date.today() - timedelta(days=days - 1)
        scope, scope_params = self._scope("sales_invoices", company_id, branch_id)
        rows = self.fetchall(
            f"""SELECT invoice_date AS d, SUM(total) AS t
                FROM sales_invoices
                WHERE invoice_date>=? AND {_ACTIVE_SALES}{scope}
                GROUP BY invoice_date""",
            (start.isoformat(),) + scope_params,
        )
        by_day = {str(row["d"]): float(row["t"] or 0) for row in rows}
        return [
            {
                "date": (start + timedelta(days=i)).isoformat(),
                "label": (start + timedelta(days=i)).strftime("%d/%m"),
                "total": by_day.get((start + timedelta(days=i)).isoformat(), 0.0),
            }
            for i in range(days)
        ]

    def top_products(self, limit: int = 5, days: int = 30,
                     company_id: int | None = None,
                     branch_id: int | None = None) -> list[dict]:
        start = (date.today() - timedelta(days=max(1, min(int(days), 366)))).isoformat()
        scope, scope_params = self._scope("s", company_id, branch_id)
        rows = self.fetchall(
            f"""SELECT p.id, p.name, SUM(i.quantity) AS qty, SUM(i.total) AS revenue
                FROM sales_invoice_items i
                JOIN sales_invoices s ON s.id=i.invoice_id
                JOIN products p ON p.id=i.product_id
                WHERE s.invoice_date>=? AND {_ACTIVE_SALES.replace('status','s.status')}{scope}
                GROUP BY p.id, p.name
                ORDER BY revenue DESC
                LIMIT ?""",
            (start,) + scope_params + (max(1, int(limit)),),
        )
        return [dict(row) for row in rows]

    def top_debtors(self, limit: int = 5, company_id: int | None = None,
                    branch_id: int | None = None) -> list[dict]:
        scope, scope_params = self._scope("customers", company_id, branch_id)
        rows = self.fetchall(
            f"""SELECT id, name, phone, current_balance, credit_limit FROM customers
                WHERE current_balance>0{scope}
                ORDER BY current_balance DESC LIMIT ?""",
            scope_params + (max(1, int(limit)),),
        )
        return [dict(row) for row in rows]

    def low_stock_items(self, limit: int = 20, company_id: int | None = None,
                        branch_id: int | None = None) -> list[dict]:
        scope, scope_params = self._scope("products", company_id, branch_id)
        rows = self.fetchall(
            f"""SELECT id, code, name, quantity, minimum_stock FROM products
                WHERE is_active=1 AND quantity<=minimum_stock{scope}
                ORDER BY (quantity-minimum_stock) ASC, name LIMIT ?""",
            scope_params + (max(1, int(limit)),),
        )
        return [dict(row) for row in rows]

    # ------------------------------------------------------------------
    # Read-only helpers used by the Desktop dashboard charts (Phase 9 UI).
    # ------------------------------------------------------------------

    def purchases_trend(self, days: int = 14, company_id: int | None = None,
                        branch_id: int | None = None) -> list[dict]:
        days = max(1, min(int(days), 366))
        start = date.today() - timedelta(days=days - 1)
        scope, scope_params = self._scope("purchase_invoices", company_id, branch_id)
        rows = self.fetchall(
            f"""SELECT invoice_date AS d, SUM(total) AS t
                FROM purchase_invoices
                WHERE invoice_date>=? AND {_ACTIVE_PURCHASES}{scope}
                GROUP BY invoice_date""",
            (start.isoformat(),) + scope_params,
        )
        by_day = {str(row["d"]): float(row["t"] or 0) for row in rows}
        return [
            {
                "date": (start + timedelta(days=i)).isoformat(),
                "label": (start + timedelta(days=i)).strftime("%d/%m"),
                "total": by_day.get((start + timedelta(days=i)).isoformat(), 0.0),
            }
            for i in range(days)
        ]

    def stock_health(self, company_id: int | None = None,
                     branch_id: int | None = None) -> dict:
        """Counts of active products that are healthy / low / out of stock."""
        scope, scope_params = self._scope("products", company_id, branch_id)
        row = self.fetchone(
            f"""SELECT
                    SUM(CASE WHEN quantity<=0 THEN 1 ELSE 0 END) AS out_of_stock,
                    SUM(CASE WHEN quantity>0 AND quantity<=minimum_stock THEN 1 ELSE 0 END) AS low,
                    SUM(CASE WHEN quantity>minimum_stock THEN 1 ELSE 0 END) AS healthy
                FROM products WHERE is_active=1{scope}""",
            scope_params,
        )
        return {
            "healthy": int((row["healthy"] if row else 0) or 0),
            "low": int((row["low"] if row else 0) or 0),
            "out_of_stock": int((row["out_of_stock"] if row else 0) or 0),
        }
