"""Atomic supplier payment posting and cancellation."""
from __future__ import annotations
import math
from datetime import date
from alexerp.database.transaction import transaction
from alexerp.core import tenancy
from alexerp.repositories.payment_repository import PaymentRepository
from alexerp.accounting import AccountingService
from alexerp.services.party_balance_service import PartyBalanceService
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService, PermissionDenied


class PaymentError(Exception):
    pass


class PaymentService:
    def __init__(self):
        self.repo = PaymentRepository()
        self.accounting = AccountingService()
        self.balances = PartyBalanceService()

    def create_payment(self, company_id, branch_id, payment_number, payment_date,
                       supplier_id, cash_account, payable_account, amount,
                       created_by, notes=""):
        try:
            amount = float(amount)
        except (TypeError, ValueError):
            raise PaymentError("Payment amount must be a valid number.")
        if not math.isfinite(amount) or amount <= 0:
            raise PaymentError("Payment amount must be finite and positive.")
        tenancy.require_branch(company_id, branch_id)
        tenancy.require_supplier(company_id, supplier_id)
        tenancy.require_accounts(company_id, cash_account=cash_account,
                                 payable_account=payable_account)
        try:
            PermissionService().require_for_company(created_by, company_id, "payments.create")
        except PermissionDenied as exc:
            raise PaymentError("User is not authorized to create supplier payments.") from exc
        with transaction():
            payment_id = self.repo.create(company_id, branch_id, payment_number,
                payment_date, supplier_id, cash_account, round(amount, 2), notes, created_by)
            self.accounting.create_entry(
                company_id=company_id, branch_id=branch_id,
                entry_number=f"SP-{payment_number}", entry_date=payment_date,
                description=f"Supplier Payment {payment_number}",
                reference_type="SUPPLIER_PAYMENT", reference_id=payment_id,
                created_by=created_by,
                details=[
                    {"account_id": payable_account, "debit": round(amount, 2),
                     "credit": 0, "description": f"Supplier payment {payment_number}"},
                    {"account_id": cash_account, "debit": 0,
                     "credit": round(amount, 2), "description": f"Supplier payment {payment_number}"},
                ])
            self.balances.refresh_supplier(supplier_id)
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="payments", action="supplier_payment_posted", entity_type="supplier_payment",
                record_id=payment_id, description=f"Supplier payment {payment_number} posted",
                after={"payment_number": payment_number, "supplier_id": supplier_id,
                       "amount": round(amount, 2), "status": "POSTED"})
            return payment_id

    def cancel_payment(self, payment_id, created_by, cancel_date=None):
        with transaction():
            payment = self.repo.get_for_actor(payment_id, created_by)
            if payment is None:
                raise PaymentError("Supplier payment not found.")
            try:
                PermissionService().require_for_company(
                    created_by, int(payment["company_id"]), "payments.cancel"
                )
            except PermissionDenied as exc:
                raise PaymentError("User is not authorized to cancel supplier payments.") from exc
            if str(payment["status"]).upper() == "CANCELLED":
                raise PaymentError("Supplier payment is already cancelled.")
            if str(payment["status"]).upper() != "POSTED":
                raise PaymentError("Only posted supplier payments can be cancelled.")
            from alexerp.services.invoice_settlement_service import InvoiceSettlementService
            InvoiceSettlementService().reverse_payment_allocations(payment_id)
            self.accounting.reverse_entry("SUPPLIER_PAYMENT", payment_id, created_by,
                reversal_date=cancel_date or date.today().isoformat())
            self.repo.set_status(payment_id, int(payment["company_id"]), "CANCELLED")
            self.balances.refresh_supplier(int(payment["supplier_id"]))
            before = {"payment_number": payment["payment_number"], "supplier_id": int(payment["supplier_id"]),
                      "amount": float(payment["amount"]), "status": str(payment["status"])}
            AuditService.record(user_id=created_by, company_id=int(payment["company_id"]),
                branch_id=int(payment["branch_id"]), module="payments", action="supplier_payment_cancelled",
                entity_type="supplier_payment", record_id=payment_id,
                description=f"Supplier payment {payment['payment_number']} cancelled",
                before=before, after={**before, "status": "CANCELLED"})
            return True
