"""
AlexERP — Business Management System
Inventory Adjustment Service
"""

from __future__ import annotations

import math

from alexerp.database.transaction import transaction

from alexerp.core.constants import (
    StockTransactionType,
    ReferenceType,
)

from alexerp.repositories.adjustment_repository import AdjustmentRepository
from alexerp.services.audit_service import AuditService
from alexerp.services.inventory_service import InventoryService
from alexerp.services.permission_service import PermissionService


class AdjustmentService:

    def __init__(self):

        self.repo = AdjustmentRepository()
        self.inventory = InventoryService()

    # =====================================================
    # Create Adjustment
    # =====================================================

    def create_adjustment(

        self,

        company_id,
        branch_id,
        warehouse_id,

        adjustment_number,
        adjustment_date,

        adjustment_type,

        items,

        notes,

        created_by,

    ):

        PermissionService().require_for_company(created_by, company_id, "inventory.adjust")
        from alexerp.core import tenancy
        tenancy.require_branch(company_id, branch_id)
        if not items:
            raise ValueError("Adjustment contains no items.")
        for item in items:
            tenancy.require_item_scope(company_id, branch_id, int(item["product_id"]), warehouse_id)
            system_qty = float(item["system_quantity"])
            actual_qty = float(item["actual_quantity"])
            supplied_difference = float(item["difference"])
            if not all(math.isfinite(value) for value in (system_qty, actual_qty, supplied_difference)):
                raise ValueError("Adjustment quantities must be finite numbers.")
            if system_qty < 0 or actual_qty < 0 or abs((actual_qty - system_qty) - supplied_difference) > 1e-9:
                raise ValueError("Adjustment difference must equal actual quantity minus system quantity.")

        with transaction():

            adjustment_id = self.repo.create_adjustment(

                company_id,

                branch_id,

                warehouse_id,

                adjustment_number,

                adjustment_date,

                adjustment_type,

                notes,

                created_by,

            )

            for item in items:

                difference = float(item["difference"])

                product_id = item["product_id"]

                cost = float(item["unit_cost"])

                self.repo.add_item(

                    adjustment_id,

                    product_id,

                    item["system_quantity"],

                    item["actual_quantity"],

                    difference,

                    cost,

                )

                if difference > 0:

                    self.inventory.increase_stock(
                        product_id, difference, warehouse_id,
                        company_id, branch_id, cost,
                    )

                    self.inventory.add_stock_movement(

                        company_id=company_id,

                        branch_id=branch_id,

                        warehouse_id=warehouse_id,

                        product_id=product_id,

                        transaction_type=StockTransactionType.ADJUSTMENT,

                        reference_type=ReferenceType.ADJUSTMENT,

                        reference_id=adjustment_id,

                        quantity_in=difference,

                        unit_cost=cost,

                        notes="Inventory Adjustment",

                        created_by=created_by,

                    )

                elif difference < 0:

                    self.inventory.decrease_stock(
                        product_id, abs(difference), warehouse_id,
                        company_id, branch_id, cost,
                    )

                    self.inventory.add_stock_movement(

                        company_id=company_id,

                        branch_id=branch_id,

                        warehouse_id=warehouse_id,

                        product_id=product_id,

                        transaction_type=StockTransactionType.ADJUSTMENT,

                        reference_type=ReferenceType.ADJUSTMENT,

                        reference_id=adjustment_id,

                        quantity_out=abs(difference),

                        unit_cost=cost,

                        notes="Inventory Adjustment",

                        created_by=created_by,

                    )

            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="inventory", action="inventory_adjustment_posted", entity_type="inventory_adjustment",
                record_id=adjustment_id, description=f"Inventory adjustment {adjustment_number} posted",
                after={"adjustment_number": adjustment_number, "warehouse_id": warehouse_id,
                       "adjustment_type": adjustment_type, "items": [
                           {"product_id": int(x["product_id"]),
                            "system_quantity": float(x["system_quantity"]),
                            "actual_quantity": float(x["actual_quantity"]),
                            "difference": float(x["difference"]),
                            "unit_cost": float(x["unit_cost"])} for x in items]})
            return adjustment_id
