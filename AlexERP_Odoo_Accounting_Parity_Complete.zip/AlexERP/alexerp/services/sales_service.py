"""Sales invoice posting with atomic inventory and accounting effects."""
from __future__ import annotations
import math
from datetime import date, timedelta
from alexerp.database.transaction import transaction
from alexerp.core.constants import StockTransactionType, ReferenceType, InvoiceStatus
from alexerp.repositories.sales_repository import SalesRepository
from alexerp.services.inventory_service import InventoryService
from alexerp.accounting import AccountingReadService, AccountingService
from alexerp.services.party_balance_service import PartyBalanceService
from alexerp.core import tenancy
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService, PermissionDenied
from alexerp.services.sales_settings_service import SalesSettingsError, SalesSettingsService
from alexerp.services.customer_service import CustomerService

class SalesError(Exception):
    pass

class SalesService:
    def __init__(self):
        self.sales = SalesRepository()
        self.inventory = InventoryService()
        self.accounting = AccountingService()
        self.accounting_reads = AccountingReadService()
        self.balances = PartyBalanceService()

    def create_invoice(self, company_id: int, branch_id: int, customer_id: int,
        invoice_number: str, invoice_date: str, items: list, subtotal: float,
        discount: float, tax: float, total: float, paid_amount: float,
        remaining_amount: float, notes: str, created_by: int,
        receivable_account: int | None = None, sales_account: int | None = None,
        inventory_account: int | None = None, cogs_account: int | None = None,
        tax_account: int | None = None,
        cash_account: int | None = None, payment_terms_days: int | None = None,
        due_date: str | None = None, override_credit_limit: bool = False) -> int:
        if not items:
            raise SalesError("Invoice contains no items.")
        vals = [float(subtotal), float(discount), float(tax), float(total),
                float(paid_amount), float(remaining_amount)]
        if any(not math.isfinite(x) or x < 0 for x in vals):
            raise SalesError("Invoice amounts must be finite and non-negative.")
        if round(vals[0] - vals[1] + vals[2], 2) != round(vals[3], 2):
            raise SalesError("Invoice total must equal subtotal minus discount plus tax.")
        if round(vals[4] + vals[5], 2) != round(vals[3], 2):
            raise SalesError("Paid amount plus remaining amount must equal invoice total.")
        # Validate every line independently before any stock/accounting write.
        # Header totals alone are insufficient: a caller could otherwise submit
        # a balanced header while hiding negative discounts/taxes or an
        # inconsistent line total inside the document.
        line_total_sum = 0.0
        for index, item in enumerate(items, start=1):
            try:
                quantity = float(item["quantity"])
                unit_price = float(item["unit_price"])
                line_discount = float(item.get("discount", 0) or 0)
                line_tax = float(item.get("tax", 0) or 0)
                line_total = float(item["total"])
            except (KeyError, TypeError, ValueError) as exc:
                raise SalesError(f"Invalid values in sales invoice line {index}.") from exc
            line_values = (quantity, unit_price, line_discount, line_tax, line_total)
            if any(not math.isfinite(value) for value in line_values):
                raise SalesError(f"Sales invoice line {index} contains a non-finite amount.")
            if quantity <= 0 or unit_price < 0 or line_discount < 0 or line_tax < 0 or line_total < 0:
                raise SalesError(f"Sales invoice line {index} contains a negative amount or invalid quantity.")
            expected_line_total = quantity * unit_price - line_discount + line_tax
            if expected_line_total < -0.005 or round(expected_line_total, 2) != round(line_total, 2):
                raise SalesError(
                    f"Sales invoice line {index} total must equal quantity × unit price - discount + tax."
                )
            line_total_sum += line_total
        if round(line_total_sum, 2) != round(vals[3], 2):
            raise SalesError("Invoice total does not equal the sum of its item totals.")
        tenancy.require_branch(company_id, branch_id)
        tenancy.require_customer(company_id, customer_id)
        try:
            PermissionService().require_for_company(created_by, company_id, "sales.create")
        except PermissionDenied as exc:
            raise SalesError("User is not authorized to create sales invoices.") from exc
        tenancy.require_account(company_id, receivable_account, "Accounts receivable account")
        customer_receivable_account = CustomerService().ensure_customer_account(
            company_id, customer_id
        )
        try:
            settings = SalesSettingsService().get_settings(company_id)
        except SalesSettingsError as exc:
            raise SalesError(str(exc)) from exc
        receivable_account = customer_receivable_account
        sales_account = sales_account or settings["sales_account_id"]
        inventory_account = inventory_account or settings["inventory_account_id"]
        cogs_account = cogs_account or settings["cogs_account_id"]
        tax_account = tax_account or settings["tax_account_id"]
        cash_account = cash_account or settings["cash_account_id"]
        inventory_policy = settings["inventory_policy"]
        if inventory_policy not in SalesSettingsService.POLICIES:
            raise SalesError("Sales inventory policy is invalid; update company sales settings.")
        if not all((receivable_account, sales_account, inventory_account, cogs_account)):
            raise SalesError("اضبط الحسابات الافتراضية للمبيعات أو اختر الحسابات في الفاتورة.")
        if vals[4] > 0 and not cash_account:
            raise SalesError("حساب النقدية/البنك مطلوب عند تسجيل دفعة مع الفاتورة.")
        terms_row = self.sales.execute(
            "SELECT payment_terms_days FROM customers WHERE id=? AND company_id=?",
            (customer_id, company_id),
        ).fetchone()
        terms_days = int(payment_terms_days if payment_terms_days is not None else (terms_row[0] if terms_row else 0))
        if terms_days < 0 or terms_days > 3650:
            raise SalesError("Payment terms must be between 0 and 3650 days.")
        try:
            parsed_invoice_date = date.fromisoformat(str(invoice_date))
            resolved_due_date = date.fromisoformat(str(due_date)).isoformat() if due_date else (parsed_invoice_date + timedelta(days=terms_days)).isoformat()
        except ValueError as exc:
            raise SalesError("Invalid invoice or due date.") from exc
        if resolved_due_date < parsed_invoice_date.isoformat():
            raise SalesError("Due date cannot be earlier than invoice date.")
        tenancy.require_accounts(company_id, receivable_account=receivable_account,
            sales_account=sales_account, inventory_account=inventory_account,
            cogs_account=cogs_account, tax_account=tax_account, cash_account=cash_account)
        for item in items:
            tenancy.require_item_scope(company_id, branch_id, item["product_id"], item["warehouse_id"])
        with transaction():
            credit_status = self.credit_limit_status(
                company_id, customer_id, remaining_amount, created_by
            )
            if credit_status["exceeded"]:
                if not credit_status["can_override"]:
                    raise SalesError(
                        f"تجاوز حد ائتمان العميل ({credit_status['limit']:.2f}). "
                        f"الرصيد المتوقع {credit_status['projected_balance']:.2f}."
                    )
                if override_credit_limit is not True:
                    raise SalesError(
                        f"سيؤدي ترحيل الفاتورة إلى تجاوز حد الائتمان. "
                        f"الرصيد المتوقع {credit_status['projected_balance']:.2f} "
                        f"والحد {credit_status['limit']:.2f}. يلزم تأكيد التجاوز."
                    )
                AuditService.record(
                    user_id=created_by, company_id=company_id, branch_id=branch_id,
                    module="sales", action="customer_credit_limit_overridden",
                    entity_type="customer", record_id=customer_id,
                    description=f"Credit limit override for invoice {invoice_number}",
                    after={
                        "invoice_number": invoice_number,
                        "credit_limit": credit_status["limit"],
                        "balance_before": credit_status["balance"],
                        "invoice_remaining": round(float(remaining_amount), 2),
                        "projected_balance": credit_status["projected_balance"],
                    },
                )
            # Validate aggregate demand per product/warehouse, not each line in
            # isolation. Otherwise duplicate lines can each pass against the
            # same opening balance and collectively oversell that warehouse.
            requested_stock: dict[tuple[int, int], float] = {}
            for item in items:
                qty, price = float(item["quantity"]), float(item["unit_price"])
                if not math.isfinite(qty) or qty <= 0 or not math.isfinite(price) or price < 0:
                    raise SalesError("Invalid item quantity or price.")
                key = (int(item["product_id"]), int(item["warehouse_id"]))
                requested_stock[key] = requested_stock.get(key, 0.0) + qty
            for (product_id, warehouse_id), requested_qty in requested_stock.items():
                if not self.inventory.check_stock(product_id, requested_qty, warehouse_id):
                    raise SalesError(f"Insufficient stock for product {product_id}.")
            invoice_id = self.sales.create_invoice(
                company_id, branch_id, customer_id, invoice_number, invoice_date,
                subtotal, discount, tax, total, paid_amount, remaining_amount,
                notes, created_by, terms_days, resolved_due_date)
            self.sales.execute(
                """UPDATE sales_invoices
                   SET inventory_policy=?,inventory_account_id=?,cogs_account_id=?
                   WHERE id=?""",
                (inventory_policy, inventory_account, cogs_account, invoice_id),
            )
            total_cost = 0.0
            reservation_totals: dict[tuple[int, int], dict[str, float]] = {}
            for item in items:
                qty = float(item["quantity"])
                supplied_cost = item.get("unit_cost")
                cost = float(supplied_cost) if supplied_cost not in (None, "") and float(supplied_cost) > 0 else self.inventory.get_unit_cost(item["product_id"], item["warehouse_id"])
                if not math.isfinite(cost) or cost < 0:
                    raise SalesError("Invalid item cost.")
                self.sales.add_item(invoice_id, item["product_id"], item["warehouse_id"],
                    qty, item["unit_price"], item.get("discount", 0),
                    item.get("tax", 0), item["total"], unit_cost=cost)
                total_cost += qty * cost
                key = (int(item["product_id"]), int(item["warehouse_id"]))
                totals = reservation_totals.setdefault(key, {"quantity": 0.0, "cost": 0.0})
                totals["quantity"] += qty
                totals["cost"] += qty * cost
                if inventory_policy == "DEDUCT_ON_POST":
                    self.inventory.decrease_stock(item["product_id"], qty, item["warehouse_id"],
                        company_id, branch_id, cost)
                    self.inventory.add_stock_movement(
                        company_id=company_id, branch_id=branch_id,
                        warehouse_id=item["warehouse_id"], product_id=item["product_id"],
                        transaction_type=StockTransactionType.SALE,
                        reference_type=ReferenceType.SALE, reference_id=invoice_id,
                        quantity_out=qty, unit_cost=cost,
                        balance_after=self.inventory.get_quantity(item["product_id"], item["warehouse_id"]),
                        notes=f"Sales Invoice {invoice_number}", created_by=created_by)
            if inventory_policy == "RESERVE_UNTIL_DELIVERY":
                for (product_id, warehouse_id), values in reservation_totals.items():
                    self.inventory.reserve_stock(
                        product_id, values["quantity"], warehouse_id, company_id,
                        branch_id, ReferenceType.SALE, invoice_id, created_by,
                        values["cost"] / values["quantity"],
                    )
            journal = [
                {"account_id": receivable_account, "debit": remaining_amount, "credit": 0,
                 "description": f"Customer receivable {invoice_number}"},
                {"account_id": sales_account, "debit": 0, "credit": subtotal-discount,
                 "description": f"Net sales {invoice_number}"},
            ]
            if paid_amount:
                journal.append({"account_id": cash_account, "debit": paid_amount, "credit": 0,
                                "description": f"Cash received on {invoice_number}"})
            if tax:
                if not tax_account:
                    raise SalesError("Tax account is required when invoice tax is non-zero.")
                journal.append({"account_id": tax_account, "debit": 0, "credit": tax,
                                "description": "Sales tax"})
            if total_cost and inventory_policy == "DEDUCT_ON_POST":
                journal += [
                    {"account_id": cogs_account, "debit": total_cost, "credit": 0, "description": "Cost of goods sold"},
                    {"account_id": inventory_account, "debit": 0, "credit": total_cost, "description": "Inventory issued"},
                ]
            self.accounting.create_entry(company_id, branch_id, invoice_date,
                f"Sales Invoice {invoice_number}", ReferenceType.SALE, invoice_id,
                created_by, journal, entry_number=f"JV-S-{company_id}-{invoice_number}")
            if paid_amount:
                self._record_invoice_receipt(
                    company_id, branch_id, customer_id, invoice_id, invoice_number,
                    invoice_date, paid_amount, cash_account, created_by,
                )
            self.sales.execute("UPDATE sales_invoices SET status=? WHERE id=?",
                               (InvoiceStatus.POSTED, invoice_id))
            self.balances.refresh_customer(customer_id)
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="sales", action="invoice_posted", entity_type="sales_invoice",
                record_id=invoice_id, description=f"Sales invoice {invoice_number} posted",
                after={"invoice_number": invoice_number, "customer_id": customer_id,
                       "total": total, "paid_amount": paid_amount,
                       "remaining_amount": remaining_amount, "status": str(InvoiceStatus.POSTED)})
            return invoice_id

    def credit_limit_status(self, company_id: int, customer_id: int,
                            new_receivable: float, actor_id: int | None = None) -> dict:
        customer = self.sales.execute(
            """SELECT credit_limit FROM customers
               WHERE id=? AND company_id=? AND COALESCE(is_active,1)=1""",
            (customer_id, company_id),
        ).fetchone()
        if customer is None:
            raise SalesError("العميل غير موجود أو غير نشط في الشركة المحددة.")
        try:
            amount = float(new_receivable)
        except (TypeError, ValueError) as exc:
            raise SalesError("مبلغ المديونية الجديدة غير صالح.") from exc
        if not math.isfinite(amount) or amount < 0:
            raise SalesError("مبلغ المديونية الجديدة غير صالح.")
        balance = round(self.balances.customer_balance(customer_id), 2)
        limit = round(float(customer["credit_limit"] or 0), 2)
        projected = round(balance + amount, 2)
        exceeded = limit > 0 and projected > limit
        can_override = bool(
            exceeded and actor_id is not None
            and PermissionService().has_permission_for_company(
                actor_id, company_id, "customers.credit_limit.override"
            )
        )
        return {
            "limit": limit,
            "balance": balance,
            "projected_balance": projected,
            "exceeded": exceeded,
            "can_override": can_override,
        }

    def _record_invoice_receipt(self, company_id: int, branch_id: int, customer_id: int,
                                invoice_id: int, invoice_number: str, receipt_date: str,
                                amount: float, cash_account: int, created_by: int) -> int:
        conn = self.sales.connection
        receipt_number = f"RC-S-{company_id}-{invoice_number}"
        cursor = conn.execute(
            """INSERT INTO receipts(
                   company_id,branch_id,receipt_number,receipt_date,customer_id,
                   cash_box_id,amount,notes,created_by,status,source_sales_invoice_id,source_type)
               VALUES(?,?,?,?,?,?,?,?,?,'POSTED',?,'SALES_INVOICE')""",
            (company_id, branch_id, receipt_number, receipt_date, customer_id,
             cash_account, amount, f"تحصيل عند ترحيل فاتورة البيع {invoice_number}",
             created_by, invoice_id),
        )
        if cursor.lastrowid is None:
            raise SalesError("تعذر تسجيل سند القبض المرتبط بفاتورة البيع.")
        receipt_id = int(cursor.lastrowid)
        conn.execute(
            """INSERT INTO receipt_allocations(
                   company_id,branch_id,receipt_id,sales_invoice_id,amount,created_by)
               VALUES(?,?,?,?,?,?)""",
            (company_id, branch_id, receipt_id, invoice_id, amount, created_by),
        )
        AuditService.record(
            user_id=created_by, company_id=company_id, branch_id=branch_id,
            module="receipts", action="invoice_receipt_recorded",
            entity_type="customer_receipt", record_id=receipt_id,
            description=f"Receipt recorded from sales invoice {invoice_number}",
            after={"receipt_number": receipt_number, "invoice_id": invoice_id, "amount": amount},
            connection=conn,
        )
        return receipt_id

    def cancel_invoice(self, invoice_id: int, created_by: int, cancel_date: str | None = None):
        from datetime import date
        with transaction():
            invoice = self.sales.get_invoice(invoice_id)
            if invoice is None:
                raise SalesError("Invoice not found.")
            if str(invoice["status"]).upper() == "CANCELLED":
                raise SalesError("Invoice is already cancelled.")
            if str(invoice["status"]).upper() != "POSTED":
                raise SalesError("Only posted invoices can be cancelled.")
            active_notes = self.sales.connection.execute(
                """SELECT COUNT(*) FROM customer_financial_notes
                   WHERE sales_invoice_id=? AND UPPER(COALESCE(status,''))='POSTED'""",
                (invoice_id,),
            ).fetchone()[0]
            if active_notes:
                raise SalesError(
                    "Cancel the linked customer financial notes before cancelling this invoice."
                )
            try:
                PermissionService().require_for_company(
                    created_by, int(invoice["company_id"]), "sales.cancel"
                )
            except PermissionDenied as exc:
                raise SalesError("User is not authorized to cancel sales invoices.") from exc
            manual_allocations = self.sales.connection.execute(
                """SELECT COUNT(*) FROM receipt_allocations a
                   JOIN receipts r ON r.id=a.receipt_id
                   WHERE a.sales_invoice_id=? AND a.status='ACTIVE'
                     AND COALESCE(r.source_sales_invoice_id,0)<>?""",
                (invoice_id, invoice_id),
            ).fetchone()[0]
            if manual_allocations:
                raise SalesError("Cannot cancel an invoice with active receipt allocations. Reverse/cancel the receipts first.")
            auto_receipts = self.sales.connection.execute(
                """SELECT DISTINCT r.id,r.receipt_number,r.amount,r.company_id,r.branch_id
                   FROM receipts r JOIN receipt_allocations a ON a.receipt_id=r.id
                   WHERE r.source_sales_invoice_id=? AND a.sales_invoice_id=?
                     AND a.status='ACTIVE' AND UPPER(COALESCE(r.status,'POSTED'))='POSTED'""",
                (invoice_id, invoice_id),
            ).fetchall()
            if auto_receipts:
                from alexerp.services.invoice_settlement_service import InvoiceSettlementService
                settlements = InvoiceSettlementService()
                for receipt in auto_receipts:
                    settlements.reverse_receipt_allocations(int(receipt["id"]))
                    self.sales.connection.execute(
                        "UPDATE receipts SET status='CANCELLED' WHERE id=?",
                        (int(receipt["id"]),),
                    )
                    AuditService.record(
                        user_id=created_by, company_id=int(receipt["company_id"]),
                        branch_id=int(receipt["branch_id"]) if receipt["branch_id"] is not None else None,
                        module="receipts", action="invoice_receipt_cancelled",
                        entity_type="customer_receipt", record_id=int(receipt["id"]),
                        description=f"Receipt {receipt['receipt_number']} cancelled with its sales invoice",
                        before={"amount": float(receipt["amount"]), "status": "POSTED"},
                        after={"amount": float(receipt["amount"]), "status": "CANCELLED"},
                    )
            delivered_docs = self.sales.connection.execute(
                "SELECT COUNT(*) FROM sales_deliveries WHERE sales_invoice_id=? AND status='POSTED'",
                (invoice_id,),
            ).fetchone()[0]
            if delivered_docs:
                raise SalesError("An invoice with posted delivery documents cannot be cancelled. Create a sales return instead.")
            returned = self.sales.connection.execute(
                "SELECT COUNT(*) FROM sales_returns WHERE sales_invoice_id=? AND UPPER(COALESCE(status,'POSTED'))='POSTED'",
                (invoice_id,),
            ).fetchone()[0]
            if returned:
                raise SalesError("An invoice with posted returns cannot be cancelled. Reverse the return documents first.")
            was_stock_issued = (
                str(invoice["inventory_policy"] or "DEDUCT_ON_POST") == "DEDUCT_ON_POST"
                or str(invoice["delivery_status"] or "").upper() == "DELIVERED"
            )
            if was_stock_issued:
                for item in self.sales.get_items(invoice_id):
                    qty = float(item["quantity"])
                    cost = float(item["unit_cost"] or 0)
                    self.inventory.increase_stock(item["product_id"], qty, item["warehouse_id"],
                        invoice["company_id"], invoice["branch_id"], cost)
                    self.inventory.add_stock_movement(
                        company_id=invoice["company_id"], branch_id=invoice["branch_id"],
                        warehouse_id=item["warehouse_id"], product_id=item["product_id"],
                        transaction_type=StockTransactionType.SALE_RETURN,
                        reference_type="SALE_CANCEL", reference_id=invoice_id,
                        quantity_in=qty, unit_cost=cost,
                        balance_after=self.inventory.get_quantity(item["product_id"], item["warehouse_id"]),
                        notes=f"Cancel Sales Invoice {invoice['invoice_number']}", created_by=created_by)
            else:
                self.inventory.release_stock_reservations(ReferenceType.SALE, invoice_id)
            self.accounting.reverse_entry(ReferenceType.SALE, invoice_id, created_by,
                reversal_date=cancel_date or date.today().isoformat())
            if was_stock_issued and str(invoice["inventory_policy"] or "") == "RESERVE_UNTIL_DELIVERY":
                has_delivery_entry = self.accounting_reads.journal_exists_by_reference(
                    "SALE_DELIVERY", invoice_id, company_id=int(invoice["company_id"]),
                    connection=self.sales.connection,
                )
                if has_delivery_entry:
                    self.accounting.reverse_entry(
                        "SALE_DELIVERY", invoice_id, created_by,
                        reversal_date=cancel_date or date.today().isoformat(),
                    )
            self.sales.execute(
                "UPDATE sales_invoices SET status=?,delivery_status='CANCELLED' WHERE id=?",
                (InvoiceStatus.CANCELLED, invoice_id),
            )
            # If this invoice originated from a sales order, release its invoiced
            # quantities atomically so the cancelled quantities can be invoiced again.
            sales_order_id = invoice["sales_order_id"] if "sales_order_id" in invoice.keys() else None
            if sales_order_id:
                linked_lines = self.sales.connection.execute(
                    "SELECT sales_order_item_id,quantity FROM sales_invoice_items "
                    "WHERE invoice_id=? AND sales_order_item_id IS NOT NULL ORDER BY id",
                    (invoice_id,),
                ).fetchall()
                for linked_line in linked_lines:
                    self.sales.connection.execute(
                        "UPDATE sales_order_items SET invoiced_quantity=CASE "
                        "WHEN invoiced_quantity>=? THEN invoiced_quantity-? ELSE 0 END "
                        "WHERE id=? AND sales_order_id=?",
                        (float(linked_line["quantity"]), float(linked_line["quantity"]),
                         int(linked_line["sales_order_item_id"]), int(sales_order_id)),
                    )
                order_row = self.sales.connection.execute(
                    "SELECT status FROM sales_orders WHERE id=? AND company_id=?",
                    (int(sales_order_id), int(invoice["company_id"])),
                ).fetchone()
                if order_row is not None and str(order_row["status"]) != "CANCELLED":
                    invoiced_total = float(self.sales.connection.execute(
                        "SELECT COALESCE(SUM(invoiced_quantity),0) FROM sales_order_items "
                        "WHERE sales_order_id=?", (int(sales_order_id),),
                    ).fetchone()[0] or 0)
                    next_status = "PARTIALLY_INVOICED" if invoiced_total > 0.000001 else "CONFIRMED"
                    self.sales.connection.execute(
                        "UPDATE sales_orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                        (next_status, int(sales_order_id)),
                    )
            self.balances.refresh_customer(invoice["customer_id"])
            before = {"invoice_number": invoice["invoice_number"], "status": str(invoice["status"]),
                      "total": float(invoice["total"] or 0), "customer_id": int(invoice["customer_id"])}
            AuditService.record(user_id=created_by, company_id=int(invoice["company_id"]),
                branch_id=int(invoice["branch_id"]), module="sales", action="invoice_cancelled",
                entity_type="sales_invoice", record_id=invoice_id,
                description=f"Sales invoice {invoice['invoice_number']} cancelled",
                before=before, after={**before, "status": str(InvoiceStatus.CANCELLED)})
            return True

    def update_delivery_status(self, invoice_id: int, status: str, created_by: int) -> None:
        target = str(status or "").upper()
        if target not in {"SHIPPED", "DELIVERED"}:
            raise SalesError("Delivery status must be SHIPPED or DELIVERED.")
        with transaction():
            invoice = self.sales.get_invoice(invoice_id)
            if invoice is None:
                raise SalesError("Invoice not found.")
            if str(invoice["status"]).upper() != "POSTED":
                raise SalesError("Only posted invoices can be updated for delivery.")
            try:
                PermissionService().require_for_company(
                    created_by, int(invoice["company_id"]), "sales.delivery.update"
                )
            except PermissionDenied as exc:
                raise SalesError("User is not authorized to update sales delivery.") from exc
            linked_delivery_count = self.sales.connection.execute(
                "SELECT COUNT(*) FROM sales_deliveries WHERE sales_invoice_id=? AND status='POSTED'",
                (invoice_id,),
            ).fetchone()[0]
            if linked_delivery_count:
                raise SalesError("This invoice uses delivery documents. Update shipment quantities through the delivery workflow.")
            current = str(invoice["delivery_status"] or "PREPARING").upper()
            if current == "CANCELLED":
                raise SalesError("Cancelled invoices cannot be updated for delivery.")
            if current == "DELIVERED" or (current == "SHIPPED" and target == "SHIPPED"):
                raise SalesError("The invoice already has this or a later delivery status.")
            if current not in {"PREPARING", "SHIPPED"}:
                raise SalesError("The invoice has an invalid delivery status.")
            if current == "SHIPPED" and target != "DELIVERED":
                raise SalesError("Delivery status cannot move backwards.")
            reserved_policy = str(invoice["inventory_policy"] or "").upper() == "RESERVE_UNTIL_DELIVERY"
            if target == "DELIVERED" and reserved_policy:
                expected = sum(float(item["quantity"]) for item in self.sales.get_items(invoice_id))
                reserved = self.sales.connection.execute(
                    """SELECT COALESCE(SUM(quantity),0) FROM stock_reservations
                       WHERE reference_type=? AND reference_id=? AND status='ACTIVE'""",
                    (ReferenceType.SALE, invoice_id),
                ).fetchone()[0]
                if abs(float(reserved or 0) - expected) > 0.000001:
                    raise SalesError("Active stock reservations do not match this invoice.")
                self.inventory.fulfill_stock_reservations(
                    ReferenceType.SALE, invoice_id, created_by,
                    f"Delivery of Sales Invoice {invoice['invoice_number']}",
                )
                items = self.sales.get_items(invoice_id)
                total_cost = sum(
                    float(item["quantity"]) * float(item["unit_cost"] or 0)
                    for item in items
                )
                if total_cost:
                    if not invoice["inventory_account_id"] or not invoice["cogs_account_id"]:
                        raise SalesError("Inventory/COGS accounts are missing from the invoice snapshot.")
                    self.accounting.create_entry(
                        int(invoice["company_id"]), int(invoice["branch_id"]),
                        date.today().isoformat(),
                        f"Sales Delivery {invoice['invoice_number']}",
                        "SALE_DELIVERY", invoice_id, created_by,
                        [
                            {"account_id": int(invoice["cogs_account_id"]),
                             "debit": total_cost, "credit": 0,
                             "description": "Cost of goods delivered"},
                            {"account_id": int(invoice["inventory_account_id"]),
                             "debit": 0, "credit": total_cost,
                             "description": "Inventory delivered"},
                        ],
                        entry_number=f"JV-SD-{invoice['company_id']}-{invoice['invoice_number']}",
                    )
            self.sales.execute(
                """UPDATE sales_invoices
                   SET delivery_status=?,delivery_updated_by=?,delivery_updated_at=CURRENT_TIMESTAMP,
                       delivered_at=CASE WHEN ?='DELIVERED' THEN CURRENT_TIMESTAMP ELSE delivered_at END
                   WHERE id=?""",
                (target, created_by, target, invoice_id),
            )
            AuditService.record(
                user_id=created_by, company_id=int(invoice["company_id"]),
                branch_id=int(invoice["branch_id"]), module="sales",
                action="delivery_status_updated", entity_type="sales_invoice",
                record_id=invoice_id,
                description=f"Sales invoice {invoice['invoice_number']} delivery status updated",
                before={"delivery_status": current},
                after={"delivery_status": target},
            )

    def delete_invoice(self, invoice_id: int, created_by: int):
        raise SalesError("Invoices are audit records and cannot be deleted. Use cancel_invoice() or a sales return.")
    def get_invoice(self, invoice_id: int): return self.sales.get_invoice(invoice_id)
    def get_items(self, invoice_id: int): return self.sales.get_items(invoice_id)
    def list(self): return self.sales.get_all()
    def list_for_company(self, company_id: int, keyword: str | None = None):
        return self.sales.list_for_company(company_id, keyword)
    def get_product_name(self, product_id: int, company_id: int):
        return self.sales.get_product_name(product_id, company_id)
    def search(self, keyword: str): return self.sales.search(keyword)
    def exists(self, invoice_id: int) -> bool: return self.sales.get_invoice(invoice_id) is not None
