"""Trial balance calculations with opening, period and closing balances."""
from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from alexerp.accounting import AccountingReadService


_CENT = Decimal("0.01")


def _money(value) -> Decimal:
    return Decimal(str(value or 0)).quantize(_CENT, rounding=ROUND_HALF_UP)


def _validate_period(date_from: str, date_to: str) -> None:
    try:
        start = date.fromisoformat(str(date_from))
        end = date.fromisoformat(str(date_to))
    except (TypeError, ValueError) as exc:
        raise ValueError("Report dates must be valid ISO dates (YYYY-MM-DD).") from exc
    if start > end:
        raise ValueError("Report start date cannot be after end date.")


class TrialBalanceService:
    def __init__(self, repository=None, read_service=None):
        self.repo = repository
        self.read_service = read_service or AccountingReadService()

    def get_report(self, company_id, date_from, date_to):
        if not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("A valid company_id is required.")
        _validate_period(date_from, date_to)
        rows = (self.repo.get_trial_balance(company_id, date_from, date_to)
                if self.repo else self.read_service.get_trial_balance_rows(
                    company_id, date_from, date_to))
        report = []
        opening_debit_total = Decimal("0.00")
        opening_credit_total = Decimal("0.00")
        period_debit_total = Decimal("0.00")
        period_credit_total = Decimal("0.00")
        closing_debit_total = Decimal("0.00")
        closing_credit_total = Decimal("0.00")

        for row in rows:
            opening_debit = _money(row["opening_debit"])
            opening_credit = _money(row["opening_credit"])
            period_debit = _money(row["period_debit"])
            period_credit = _money(row["period_credit"])
            closing_net = opening_debit - opening_credit + period_debit - period_credit
            closing_debit = max(closing_net, Decimal("0.00"))
            closing_credit = max(-closing_net, Decimal("0.00"))

            opening_debit_total += opening_debit
            opening_credit_total += opening_credit
            period_debit_total += period_debit
            period_credit_total += period_credit
            closing_debit_total += closing_debit
            closing_credit_total += closing_credit

            report.append({
                "code": row["code"],
                "name": row["name"],
                "account_type": row["account_type"],
                "opening_debit": float(opening_debit),
                "opening_credit": float(opening_credit),
                "period_debit": float(period_debit),
                "period_credit": float(period_credit),
                "closing_debit": float(closing_debit),
                "closing_credit": float(closing_credit),
            })

        return {
            "rows": report,
            "opening_debit": float(opening_debit_total),
            "opening_credit": float(opening_credit_total),
            "period_debit": float(period_debit_total),
            "period_credit": float(period_credit_total),
            "closing_debit": float(closing_debit_total),
            "closing_credit": float(closing_credit_total),
            # Backward-compatible aliases now represent closing trial-balance totals.
            "total_debit": float(closing_debit_total),
            "total_credit": float(closing_credit_total),
            "balanced": closing_debit_total == closing_credit_total,
        }
