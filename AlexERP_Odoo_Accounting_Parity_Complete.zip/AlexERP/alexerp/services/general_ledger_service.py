"""General ledger service with company isolation and opening balance."""
from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from alexerp.accounting import AccountingReadService

_CENT = Decimal("0.01")


def _money(value) -> Decimal:
    return Decimal(str(value or 0)).quantize(_CENT, rounding=ROUND_HALF_UP)


class GeneralLedgerService:
    def __init__(self, repository=None, read_service=None):
        self.repo = repository
        self.read_service = read_service or AccountingReadService()

    def get_report(self, company_id, account_id, date_from, date_to):
        if not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("A valid company_id is required.")
        if not isinstance(account_id, int) or account_id <= 0:
            raise ValueError("A valid account_id is required.")
        try:
            start, end = date.fromisoformat(str(date_from)), date.fromisoformat(str(date_to))
        except (TypeError, ValueError) as exc:
            raise ValueError("Ledger dates must be valid ISO dates (YYYY-MM-DD).") from exc
        if start > end:
            raise ValueError("Ledger start date cannot be after end date.")

        opening = (self.repo.get_opening_balance(company_id, account_id, date_from)
                   if self.repo else self.read_service.get_opening_balance(company_id, account_id, date_from))
        opening_balance = _money(opening["debit"]) - _money(opening["credit"])
        rows = (self.repo.get_ledger(company_id, account_id, date_from, date_to)
                if self.repo else self.read_service.get_account_ledger(
                    company_id, account_id, date_from, date_to))
        balance = opening_balance
        result = []
        for row in rows:
            debit, credit = _money(row["debit"]), _money(row["credit"])
            balance += debit - credit
            result.append({
                "entry_number": row["entry_number"],
                "entry_date": row["entry_date"],
                "description": row["description"],
                "line_description": row["line_description"],
                "debit": float(debit),
                "credit": float(credit),
                "balance": float(balance),
            })
        return {"opening_balance": float(opening_balance), "rows": result,
                "closing_balance": float(balance)}

    def get_ledger(self, company_id, account_id, date_from, date_to):
        """Backward-compatible row-only accessor; row balances include opening balance."""
        return self.get_report(company_id, account_id, date_from, date_to)["rows"]
