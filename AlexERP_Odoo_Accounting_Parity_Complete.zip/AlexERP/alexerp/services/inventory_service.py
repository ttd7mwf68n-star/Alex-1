"""
AlexERP — Business Management System
Inventory Service backed by per-warehouse stock balances.

Legacy product.quantity is maintained as the sum of warehouse balances plus
any unresolved legacy balance, for compatibility with older screens.
"""
from __future__ import annotations

import math

from alexerp.repositories.product_repository import ProductRepository
from alexerp.repositories.stock_movement_repository import StockMovementRepository


class InventoryError(Exception):
    pass


class InventoryService:
    def __init__(self):
        self.products = ProductRepository()
        self.stock = StockMovementRepository()

    def _warehouse(self, product_id: int, company_id: int, branch_id: int,
                   warehouse_id: int):
        conn = self.products.connection
        product = conn.execute(
            "SELECT * FROM products WHERE id=? AND company_id=?",
            (product_id, company_id),
        ).fetchone()
        warehouse = conn.execute(
            "SELECT * FROM warehouses WHERE id=? AND company_id=? AND is_active=1",
            (warehouse_id, company_id),
        ).fetchone()
        if product is None:
            raise InventoryError("Product not found.")
        if warehouse is None:
            raise InventoryError("Warehouse not found or inactive.")
        if int(product["company_id"]) != int(company_id) or int(warehouse["company_id"] or 0) != int(company_id):
            raise InventoryError("Product or warehouse belongs to a different company.")
        if product["branch_id"] is not None and int(product["branch_id"]) != int(branch_id):
            raise InventoryError("Product belongs to a different branch.")
        if warehouse["branch_id"] is not None and int(warehouse["branch_id"]) != int(branch_id):
            raise InventoryError("Warehouse belongs to a different branch.")
        pending = conn.execute(
            "SELECT quantity FROM legacy_stock_unallocated WHERE product_id=? AND resolved_at IS NULL",
            (product_id,),
        ).fetchone()
        if pending and float(pending["quantity"] or 0) != 0:
            raise InventoryError(
                "Legacy stock for this product is not assigned to a warehouse. "
                "Allocate it before posting stock movements."
            )
        return product

    def _product_for_read(self, product_id: int):
        product = self.products.connection.execute(
            "SELECT id, company_id, branch_id, allow_negative_stock, purchase_price "
            "FROM products WHERE id=?",
            (product_id,),
        ).fetchone()
        if product is None:
            raise InventoryError("Product not found.")
        return product

    def _read_warehouse_scope(self, product, warehouse_id: int):
        warehouse = self.products.connection.execute(
            "SELECT id, company_id, branch_id, is_active FROM warehouses "
            "WHERE id=? AND company_id=? AND is_active=1",
            (warehouse_id, product["company_id"]),
        ).fetchone()
        if warehouse is None:
            raise InventoryError("Warehouse not found or inactive for this company.")
        if (product["branch_id"] is not None and warehouse["branch_id"] is not None
                and int(product["branch_id"]) != int(warehouse["branch_id"])):
            raise InventoryError("Product and warehouse belong to different branches.")
        return warehouse

    def check_stock(self, product_id: int, quantity: float,
                    warehouse_id: int | None = None) -> bool:
        qty = float(quantity)
        if not math.isfinite(qty) or qty <= 0:
            raise InventoryError("Quantity must be a positive finite number.")
        conn = self.products.connection
        product = self._product_for_read(product_id)
        if warehouse_id is None:
            available = conn.execute(
                """SELECT
                     COALESCE((SELECT SUM(quantity) FROM product_stock
                               WHERE product_id=? AND company_id=?),0)
                   - COALESCE((SELECT SUM(quantity) FROM stock_reservations
                               WHERE product_id=? AND company_id=? AND status='ACTIVE'),0)""",
                (product_id, product["company_id"], product_id, product["company_id"]),
            ).fetchone()[0]
        else:
            self._read_warehouse_scope(product, warehouse_id)
            available = conn.execute(
                """SELECT
                     COALESCE((SELECT quantity FROM product_stock
                               WHERE product_id=? AND warehouse_id=? AND company_id=?),0)
                   - COALESCE((SELECT SUM(quantity) FROM stock_reservations
                               WHERE product_id=? AND warehouse_id=? AND company_id=?
                                 AND status='ACTIVE'),0)""",
                (product_id, warehouse_id, product["company_id"],
                 product_id, warehouse_id, product["company_id"]),
            ).fetchone()[0]
        if bool(product["allow_negative_stock"]):
            active_reserved = conn.execute(
                """SELECT COALESCE(SUM(quantity),0) FROM stock_reservations
                   WHERE product_id=? AND company_id=? AND status='ACTIVE'
                     AND (? IS NULL OR warehouse_id=?)""",
                (product_id, product["company_id"], warehouse_id, warehouse_id),
            ).fetchone()[0]
            return float(active_reserved or 0) <= 0 or float(available or 0) >= qty
        return float(available or 0) >= qty

    def available_quantity(self, product_id: int, warehouse_id: int) -> float:
        conn = self.products.connection
        product = self._product_for_read(product_id)
        if bool(product["allow_negative_stock"]):
            return float("inf")
        self._read_warehouse_scope(product, warehouse_id)
        row = conn.execute(
            """SELECT
                 COALESCE((SELECT quantity FROM product_stock
                           WHERE product_id=? AND warehouse_id=? AND company_id=?),0)
               - COALESCE((SELECT SUM(quantity) FROM stock_reservations
                           WHERE product_id=? AND warehouse_id=? AND company_id=?
                             AND status='ACTIVE'),0)""",
            (product_id, warehouse_id, product["company_id"],
             product_id, warehouse_id, product["company_id"]),
        ).fetchone()
        return float(row[0] or 0)

    def get_quantity(self, product_id: int, warehouse_id: int | None = None) -> float:
        conn = self.products.connection
        product = self._product_for_read(product_id)
        company_id = int(product["company_id"])
        if warehouse_id is None:
            row = conn.execute(
                "SELECT COALESCE(SUM(quantity),0) AS quantity FROM product_stock "
                "WHERE product_id=? AND company_id=?",
                (product_id, company_id),
            ).fetchone()
            pending = conn.execute(
                "SELECT COALESCE(SUM(quantity),0) AS quantity FROM legacy_stock_unallocated "
                "WHERE product_id=? AND resolved_at IS NULL", (product_id,),
            ).fetchone()
            return float(row["quantity"] or 0) + float(pending["quantity"] or 0)
        self._read_warehouse_scope(product, warehouse_id)
        row = conn.execute(
            "SELECT COALESCE(quantity,0) AS quantity FROM product_stock "
            "WHERE product_id=? AND warehouse_id=? AND company_id=?",
            (product_id, warehouse_id, company_id),
        ).fetchone()
        return float(row["quantity"] or 0)

    def get_unit_cost(self, product_id: int, warehouse_id: int) -> float:
        conn = self.products.connection
        product = self._product_for_read(product_id)
        self._read_warehouse_scope(product, warehouse_id)
        row = conn.execute(
            "SELECT average_cost FROM product_stock "
            "WHERE product_id=? AND warehouse_id=? AND company_id=?",
            (product_id, warehouse_id, product["company_id"]),
        ).fetchone()
        if row and float(row["average_cost"] or 0) > 0:
            return float(row["average_cost"])
        return float(product["purchase_price"] or 0)

    def _change(self, direction: str, product_id: int, quantity: float,
                warehouse_id: int, company_id: int, branch_id: int,
                unit_cost: float = 0) -> float:
        qty = float(quantity)
        cost = float(unit_cost or 0)
        if not math.isfinite(qty) or qty <= 0:
            raise InventoryError("Quantity must be a positive finite number.")
        if not math.isfinite(cost) or cost < 0:
            raise InventoryError("Unit cost must be non-negative.")
        conn = self.products.connection
        product = self._warehouse(product_id, company_id, branch_id, warehouse_id)
        row = conn.execute(
            "SELECT quantity, average_cost FROM product_stock "
            "WHERE product_id=? AND warehouse_id=? AND company_id=?",
            (product_id, warehouse_id, company_id),
        ).fetchone()
        current = float(row["quantity"]) if row else 0.0
        if direction == "OUT":
            reserved = float(conn.execute(
                """SELECT COALESCE(SUM(quantity),0) FROM stock_reservations
                   WHERE product_id=? AND warehouse_id=? AND company_id=? AND status='ACTIVE'""",
                (product_id, warehouse_id, company_id),
            ).fetchone()[0] or 0)
            if reserved and current - qty < reserved:
                raise InventoryError("Stock issue would consume quantity reserved for sales.")
            if not bool(product["allow_negative_stock"]) and current < qty:
                raise InventoryError("Insufficient stock in the selected warehouse.")
            new_balance = current - qty
            average_cost = float(row["average_cost"] or 0) if row else cost
        else:
            new_balance = current + qty
            old_cost = float(row["average_cost"] or 0) if row else 0.0
            average_cost = ((current * old_cost + qty * cost) / new_balance
                            if new_balance > 0 else cost)

        conn.execute("""
            INSERT INTO product_stock
                (company_id, branch_id, warehouse_id, product_id,
                 quantity, average_cost, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(warehouse_id, product_id) DO UPDATE SET
                quantity=excluded.quantity,
                average_cost=excluded.average_cost,
                updated_at=CURRENT_TIMESTAMP
        """, (company_id, branch_id, warehouse_id, product_id, new_balance, average_cost))
        assigned = conn.execute(
            "SELECT COALESCE(SUM(quantity),0) AS total FROM product_stock "
            "WHERE product_id=? AND company_id=?",
            (product_id, company_id),
        ).fetchone()["total"]
        pending = conn.execute(
            "SELECT COALESCE(SUM(quantity),0) AS total FROM legacy_stock_unallocated "
            "WHERE product_id=? AND resolved_at IS NULL", (product_id,),
        ).fetchone()["total"]
        conn.execute(
            "UPDATE products SET quantity=?, updated_at=CURRENT_TIMESTAMP "
            "WHERE id=? AND company_id=?",
            (float(assigned or 0) + float(pending or 0), product_id, company_id),
        )
        return new_balance

    def increase_stock(self, product_id: int, quantity: float,
                       warehouse_id: int, company_id: int, branch_id: int,
                       unit_cost: float = 0) -> float:
        return self._change("IN", product_id, quantity, warehouse_id,
                            company_id, branch_id, unit_cost)

    def decrease_stock(self, product_id: int, quantity: float,
                       warehouse_id: int, company_id: int, branch_id: int,
                       unit_cost: float = 0) -> float:
        return self._change("OUT", product_id, quantity, warehouse_id,
                            company_id, branch_id, unit_cost)

    def reserve_stock(self, product_id: int, quantity: float, warehouse_id: int,
                      company_id: int, branch_id: int, reference_type: str,
                      reference_id: int, created_by: int, unit_cost: float = 0) -> int:
        qty = float(quantity)
        if not math.isfinite(qty) or qty <= 0:
            raise InventoryError("Quantity must be a positive finite number.")
        if not self.check_stock(product_id, qty, warehouse_id):
            raise InventoryError("Insufficient unreserved stock in the selected warehouse.")
        self._warehouse(product_id, company_id, branch_id, warehouse_id)
        cursor = self.products.connection.execute(
            """INSERT INTO stock_reservations(
                   company_id,branch_id,warehouse_id,product_id,reference_type,
                   reference_id,quantity,unit_cost,created_by)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (company_id, branch_id, warehouse_id, product_id, reference_type,
             reference_id, qty, float(unit_cost), created_by),
        )
        if cursor.lastrowid is None:
            raise InventoryError("Stock reservation could not be recorded.")
        return int(cursor.lastrowid)

    def fulfill_stock_reservations(self, reference_type: str, reference_id: int,
                                   created_by: int, notes: str) -> None:
        conn = self.products.connection
        rows = conn.execute(
            """SELECT * FROM stock_reservations
               WHERE reference_type=? AND reference_id=? AND status='ACTIVE'
               ORDER BY id""",
            (reference_type, reference_id),
        ).fetchall()
        for row in rows:
            conn.execute(
                "UPDATE stock_reservations SET status='FULFILLED',updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (int(row["id"]),),
            )
            self.decrease_stock(
                int(row["product_id"]), float(row["quantity"]),
                int(row["warehouse_id"]), int(row["company_id"]),
                int(row["branch_id"]), float(row["unit_cost"] or 0),
            )
            self.add_stock_movement(
                company_id=int(row["company_id"]), branch_id=int(row["branch_id"]),
                warehouse_id=int(row["warehouse_id"]), product_id=int(row["product_id"]),
                transaction_type="SALE", reference_type=reference_type,
                reference_id=reference_id, quantity_out=float(row["quantity"]),
                unit_cost=float(row["unit_cost"] or 0),
                balance_after=self.get_quantity(int(row["product_id"]), int(row["warehouse_id"])),
                notes=notes, created_by=created_by,
            )

    def fulfill_stock_reservations_partial(self, reference_type: str, reference_id: int,
                                           quantities: dict[tuple[int, int], float],
                                           created_by: int, notes: str) -> None:
        """Fulfil only the requested product/warehouse quantities of a reservation."""
        conn = self.products.connection
        cleaned = {}
        for key, value in quantities.items():
            qty = float(value)
            if not math.isfinite(qty) or qty <= 0:
                raise InventoryError("Partial reservation quantity must be positive and finite.")
            cleaned[(int(key[0]), int(key[1]))] = cleaned.get((int(key[0]), int(key[1])), 0.0) + qty
        for (product_id, warehouse_id), requested in cleaned.items():
            rows = conn.execute(
                "SELECT * FROM stock_reservations WHERE reference_type=? AND reference_id=? "
                "AND product_id=? AND warehouse_id=? AND status='ACTIVE' ORDER BY id",
                (reference_type, reference_id, product_id, warehouse_id),
            ).fetchall()
            available_reserved = sum(float(row["quantity"]) for row in rows)
            if available_reserved + 0.000001 < requested:
                raise InventoryError("Active reservations do not cover the delivery quantity.")
            remaining = requested
            for row in rows:
                if remaining <= 0.000001:
                    break
                reserved_qty = float(row["quantity"])
                fulfilled = min(reserved_qty, remaining)
                residual = reserved_qty - fulfilled
                if residual <= 0.000001:
                    conn.execute("UPDATE stock_reservations SET status='FULFILLED',updated_at=CURRENT_TIMESTAMP WHERE id=?", (int(row["id"]),))
                else:
                    conn.execute("UPDATE stock_reservations SET quantity=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (residual, int(row["id"])))
                cost = float(row["unit_cost"] or 0)
                self.decrease_stock(product_id, fulfilled, warehouse_id, int(row["company_id"]), int(row["branch_id"]), cost)
                self.add_stock_movement(
                    company_id=int(row["company_id"]), branch_id=int(row["branch_id"]),
                    warehouse_id=warehouse_id, product_id=product_id, transaction_type="SALE",
                    reference_type=reference_type, reference_id=reference_id, quantity_out=fulfilled,
                    unit_cost=cost, balance_after=self.get_quantity(product_id, warehouse_id),
                    notes=notes, created_by=created_by,
                )
                remaining -= fulfilled

    def release_stock_reservations(self, reference_type: str, reference_id: int) -> None:
        self.products.connection.execute(
            """UPDATE stock_reservations SET status='RELEASED',updated_at=CURRENT_TIMESTAMP
               WHERE reference_type=? AND reference_id=? AND status='ACTIVE'""",
            (reference_type, reference_id),
        )

    def add_stock_movement(self, **kwargs):
        # Callers already wrap invoice/transfer operations in one DB transaction.
        return self.stock.add_movement(commit=False, **kwargs)

    def opening_balance(self, company_id: int, branch_id: int, warehouse_id: int,
                        product_id: int, quantity: float, unit_cost: float,
                        created_by: int):
        from alexerp.services.permission_service import PermissionService
        PermissionService().require_for_company(created_by, company_id, "inventory.adjust")
        self.increase_stock(product_id, quantity, warehouse_id, company_id,
                            branch_id, unit_cost)
        return self.add_stock_movement(
            company_id=company_id, branch_id=branch_id, warehouse_id=warehouse_id,
            product_id=product_id, transaction_type="OPENING",
            reference_type="OPENING", reference_id=0, quantity_in=quantity,
            unit_cost=unit_cost, balance_after=self.get_quantity(product_id, warehouse_id),
            notes="Opening Balance", created_by=created_by,
        )

    def adjust_stock(self, company_id: int, branch_id: int, warehouse_id: int,
                     product_id: int, new_quantity: float, unit_cost: float,
                     created_by: int):
        from alexerp.services.permission_service import PermissionService
        PermissionService().require_for_company(created_by, company_id, "inventory.adjust")
        current = self.get_quantity(product_id, warehouse_id)
        reserved = self.products.connection.execute(
            """SELECT COALESCE(SUM(quantity),0) FROM stock_reservations
               WHERE company_id=? AND warehouse_id=? AND product_id=? AND status='ACTIVE'""",
            (company_id, warehouse_id, product_id),
        ).fetchone()[0]
        if float(new_quantity) < float(reserved or 0):
            raise InventoryError("Stock cannot be adjusted below the quantity reserved for sales.")
        difference = float(new_quantity) - current
        if difference > 0:
            self.increase_stock(product_id, difference, warehouse_id,
                                company_id, branch_id, unit_cost)
            return self.add_stock_movement(
                company_id=company_id, branch_id=branch_id, warehouse_id=warehouse_id,
                product_id=product_id, transaction_type="ADJUSTMENT",
                reference_type="ADJUSTMENT", reference_id=0,
                quantity_in=difference, unit_cost=unit_cost,
                balance_after=float(new_quantity), notes="Inventory Adjustment",
                created_by=created_by,
            )
        if difference < 0:
            self.decrease_stock(product_id, abs(difference), warehouse_id,
                                company_id, branch_id, unit_cost)
            return self.add_stock_movement(
                company_id=company_id, branch_id=branch_id, warehouse_id=warehouse_id,
                product_id=product_id, transaction_type="ADJUSTMENT",
                reference_type="ADJUSTMENT", reference_id=0,
                quantity_out=abs(difference), unit_cost=unit_cost,
                balance_after=float(new_quantity), notes="Inventory Adjustment",
                created_by=created_by,
            )
        return None
