"""Invoice-level allocation and aging for customer receipts and supplier payments.

All amounts are normalized to cents with Decimal. Allocations are append-only
records; reversal changes their status and restores the invoice open amount.
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from alexerp.database.db import Database
from alexerp.database.transaction import transaction
from alexerp.services.audit_service import AuditService

_CENT = Decimal("0.01")


def _money(value) -> Decimal:
    try:
        amount = Decimal(str(value)).quantize(_CENT, rounding=ROUND_HALF_UP)
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("قيمة التخصيص يجب أن تكون رقمًا صحيحًا.")
    if not amount.is_finite() or amount <= 0:
        raise ValueError("قيمة التخصيص يجب أن تكون أكبر من صفر.")
    return amount


def _as_of(value: str) -> date:
    try:
        return datetime.strptime(str(value), "%Y-%m-%d").date()
    except (TypeError, ValueError):
        raise ValueError("تاريخ التقرير يجب أن يكون بصيغة YYYY-MM-DD.")


class InvoiceSettlementService:
    """Allocate receipts/payments to invoices and produce aging schedules."""

    def __init__(self):
        self.conn = Database.connect()

    def allocate_receipt(self, receipt_id: int, sales_invoice_id: int,
                         amount, actor_user_id: int) -> int:
        value = _money(amount)
        with transaction() as conn:
            receipt = conn.execute(
                """SELECT r.* FROM receipts r JOIN users u
                   ON u.id=? AND u.company_id=r.company_id AND u.is_active=1
                   WHERE r.id=?""", (actor_user_id, receipt_id)
            ).fetchone()
            if receipt is None or str(receipt["status"]).upper() != "POSTED":
                raise ValueError("سند القبض غير موجود أو غير مرحّل أو خارج صلاحية المستخدم.")
            invoice = conn.execute(
                """SELECT * FROM sales_invoices
                   WHERE id=? AND company_id=? AND customer_id=?""",
                (sales_invoice_id, receipt["company_id"], receipt["customer_id"]),
            ).fetchone()
            if invoice is None or str(invoice["status"]).upper() != "POSTED":
                raise ValueError("فاتورة المبيعات غير موجودة أو لا تخص عميل سند القبض.")
            if str(invoice["invoice_date"]) > str(receipt["receipt_date"]):
                raise ValueError("لا يمكن تخصيص سند قبض بتاريخ يسبق تاريخ الفاتورة.")
            allocated = Decimal(str(conn.execute(
                "SELECT COALESCE(SUM(amount),0) FROM receipt_allocations WHERE receipt_id=? AND status='ACTIVE'",
                (receipt_id,),
            ).fetchone()[0] or 0))
            available = Decimal(str(receipt["amount"] or 0)).quantize(_CENT) - allocated
            remaining = Decimal(str(invoice["remaining_amount"] or 0)).quantize(_CENT)
            if value > available:
                raise ValueError("قيمة التخصيص تتجاوز رصيد سند القبض غير المخصص.")
            if value > remaining:
                raise ValueError("قيمة التخصيص تتجاوز المبلغ المتبقي على الفاتورة.")
            cur = conn.execute(
                """INSERT INTO receipt_allocations
                   (company_id,branch_id,receipt_id,sales_invoice_id,amount,created_by)
                   VALUES(?,?,?,?,?,?)""",
                (receipt["company_id"], receipt["branch_id"], receipt_id,
                 sales_invoice_id, str(value), actor_user_id),
            )
            conn.execute(
                """UPDATE sales_invoices SET paid_amount=?, remaining_amount=?, updated_at=CURRENT_TIMESTAMP
                   WHERE id=? AND company_id=?""",
                (str(Decimal(str(invoice["paid_amount"] or 0)).quantize(_CENT) + value),
                 str(remaining - value), sales_invoice_id, receipt["company_id"]),
            )
            self._refresh_party(conn, "customer", int(invoice["customer_id"]))
            AuditService.record(
                user_id=actor_user_id, company_id=int(receipt["company_id"]),
                branch_id=int(receipt["branch_id"]) if receipt["branch_id"] is not None else None,
                module="receipts", action="receipt_allocated_to_invoice",
                entity_type="receipt_allocation", record_id=cur.lastrowid,
                description=f"Allocated receipt {receipt['receipt_number']} to invoice {invoice['invoice_number']}",
                after={"receipt_id": receipt_id, "invoice_id": sales_invoice_id, "amount": str(value)},
            )
            return int(cur.lastrowid)

    def allocate_payment(self, payment_id: int, purchase_invoice_id: int,
                         amount, actor_user_id: int) -> int:
        value = _money(amount)
        with transaction() as conn:
            payment = conn.execute(
                """SELECT p.* FROM payments p JOIN users u
                   ON u.id=? AND u.company_id=p.company_id AND u.is_active=1
                   WHERE p.id=?""", (actor_user_id, payment_id)
            ).fetchone()
            if payment is None or str(payment["status"]).upper() != "POSTED":
                raise ValueError("سند الصرف غير موجود أو غير مرحّل أو خارج صلاحية المستخدم.")
            invoice = conn.execute(
                """SELECT * FROM purchase_invoices
                   WHERE id=? AND company_id=? AND supplier_id=?""",
                (purchase_invoice_id, payment["company_id"], payment["supplier_id"]),
            ).fetchone()
            if invoice is None or str(invoice["status"]).upper() != "POSTED":
                raise ValueError("فاتورة المشتريات غير موجودة أو لا تخص مورد سند الصرف.")
            if str(invoice["invoice_date"]) > str(payment["payment_date"]):
                raise ValueError("لا يمكن تخصيص سند صرف بتاريخ يسبق تاريخ الفاتورة.")
            allocated = Decimal(str(conn.execute(
                "SELECT COALESCE(SUM(amount),0) FROM payment_allocations WHERE payment_id=? AND status='ACTIVE'",
                (payment_id,),
            ).fetchone()[0] or 0))
            available = Decimal(str(payment["amount"] or 0)).quantize(_CENT) - allocated
            remaining = Decimal(str(invoice["remaining_amount"] or 0)).quantize(_CENT)
            if value > available:
                raise ValueError("قيمة التخصيص تتجاوز رصيد سند الصرف غير المخصص.")
            if value > remaining:
                raise ValueError("قيمة التخصيص تتجاوز المبلغ المتبقي على الفاتورة.")
            cur = conn.execute(
                """INSERT INTO payment_allocations
                   (company_id,branch_id,payment_id,purchase_invoice_id,amount,created_by)
                   VALUES(?,?,?,?,?,?)""",
                (payment["company_id"], payment["branch_id"], payment_id,
                 purchase_invoice_id, str(value), actor_user_id),
            )
            conn.execute(
                """UPDATE purchase_invoices SET paid_amount=?, remaining_amount=?, updated_at=CURRENT_TIMESTAMP
                   WHERE id=? AND company_id=?""",
                (str(Decimal(str(invoice["paid_amount"] or 0)).quantize(_CENT) + value),
                 str(remaining - value), purchase_invoice_id, payment["company_id"]),
            )
            self._refresh_party(conn, "supplier", int(invoice["supplier_id"]))
            AuditService.record(
                user_id=actor_user_id, company_id=int(payment["company_id"]),
                branch_id=int(payment["branch_id"]) if payment["branch_id"] is not None else None,
                module="payments", action="payment_allocated_to_invoice",
                entity_type="payment_allocation", record_id=cur.lastrowid,
                description=f"Allocated payment {payment['payment_number']} to invoice {invoice['invoice_number']}",
                after={"payment_id": payment_id, "invoice_id": purchase_invoice_id, "amount": str(value)},
            )
            return int(cur.lastrowid)

    def reverse_receipt_allocations(self, receipt_id: int) -> None:
        """Restore invoice balances when a posted receipt is cancelled."""
        conn = Database.connect()
        rows = conn.execute(
            """SELECT a.*, i.customer_id, i.paid_amount, i.remaining_amount
               FROM receipt_allocations a JOIN sales_invoices i ON i.id=a.sales_invoice_id
               WHERE a.receipt_id=? AND a.status='ACTIVE'""", (receipt_id,),
        ).fetchall()
        for row in rows:
            amount = Decimal(str(row["amount"])).quantize(_CENT)
            paid = Decimal(str(row["paid_amount"] or 0)).quantize(_CENT)
            remaining = Decimal(str(row["remaining_amount"] or 0)).quantize(_CENT)
            if amount > paid:
                raise ValueError("تعذر عكس التخصيص: رصيد المدفوع على الفاتورة غير متسق.")
            conn.execute(
                "UPDATE sales_invoices SET paid_amount=?, remaining_amount=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (str(paid - amount), str(remaining + amount), row["sales_invoice_id"]),
            )
            conn.execute(
                "UPDATE receipt_allocations SET status='REVERSED', reversed_at=CURRENT_TIMESTAMP WHERE id=?",
                (row["id"],),
            )
            self._refresh_party(conn, "customer", int(row["customer_id"]))

    def reverse_payment_allocations(self, payment_id: int) -> None:
        """Restore supplier invoice balances when a posted payment is cancelled."""
        conn = Database.connect()
        rows = conn.execute(
            """SELECT a.*, i.supplier_id, i.paid_amount, i.remaining_amount
               FROM payment_allocations a JOIN purchase_invoices i ON i.id=a.purchase_invoice_id
               WHERE a.payment_id=? AND a.status='ACTIVE'""", (payment_id,),
        ).fetchall()
        for row in rows:
            amount = Decimal(str(row["amount"])).quantize(_CENT)
            paid = Decimal(str(row["paid_amount"] or 0)).quantize(_CENT)
            remaining = Decimal(str(row["remaining_amount"] or 0)).quantize(_CENT)
            if amount > paid:
                raise ValueError("تعذر عكس التخصيص: رصيد المدفوع على الفاتورة غير متسق.")
            conn.execute(
                "UPDATE purchase_invoices SET paid_amount=?, remaining_amount=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (str(paid - amount), str(remaining + amount), row["purchase_invoice_id"]),
            )
            conn.execute(
                "UPDATE payment_allocations SET status='REVERSED', reversed_at=CURRENT_TIMESTAMP WHERE id=?",
                (row["id"],),
            )
            self._refresh_party(conn, "supplier", int(row["supplier_id"]))

    def customer_aging(self, company_id: int, as_of_date: str, branch_id: int | None = None) -> dict:
        return self._aging("customer", company_id, as_of_date, branch_id)

    def supplier_aging(self, company_id: int, as_of_date: str, branch_id: int | None = None) -> dict:
        return self._aging("supplier", company_id, as_of_date, branch_id)

    def _aging(self, party: str, company_id: int, as_of_date: str, branch_id: int | None) -> dict:
        cutoff = _as_of(as_of_date)
        if int(company_id or 0) <= 0:
            raise ValueError("معرّف الشركة غير صحيح.")
        if party == "customer":
            table, party_table, party_fk, party_name, date_col = (
                "sales_invoices", "customers", "customer_id", "customer_name", "invoice_date")
        else:
            table, party_table, party_fk, party_name, date_col = (
                "purchase_invoices", "suppliers", "supplier_id", "supplier_name", "invoice_date")
        due_expr = "COALESCE(i.due_date, i.invoice_date)"
        sql = f"""SELECT i.id AS invoice_id, i.invoice_number, i.invoice_date,
                         {due_expr} AS due_date, i.payment_terms_days,
                         i.{party_fk} AS party_id, p.name AS {party_name},
                         i.total, i.paid_amount, i.remaining_amount
                  FROM {table} i JOIN {party_table} p ON p.id=i.{party_fk}
                  WHERE i.company_id=? AND p.company_id=?
                    AND UPPER(COALESCE(i.status,''))='POSTED'
                    AND CAST(COALESCE(i.remaining_amount,0) AS REAL)>0
                    AND date(i.invoice_date)<=date(?)"""
        params: list = [company_id, company_id, cutoff.isoformat()]
        if branch_id is not None:
            sql += " AND i.branch_id=?"
            params.append(int(branch_id))
        sql += f" ORDER BY i.{date_col}, i.id"
        rows = []
        totals = {"current": Decimal("0.00"), "days_1_30": Decimal("0.00"),
                  "days_31_60": Decimal("0.00"), "days_61_90": Decimal("0.00"),
                  "over_90": Decimal("0.00")}
        for raw in self.conn.execute(sql, params).fetchall():
            invoice_day = _as_of(raw["invoice_date"])
            due_day = _as_of(raw["due_date"] or raw["invoice_date"])
            age = max((cutoff - due_day).days, 0)
            amount = Decimal(str(raw["remaining_amount"] or 0)).quantize(_CENT)
            if age == 0:
                bucket = "current"
            elif age <= 30:
                bucket = "days_1_30"
            elif age <= 60:
                bucket = "days_31_60"
            elif age <= 90:
                bucket = "days_61_90"
            else:
                bucket = "over_90"
            totals[bucket] += amount
            rows.append({
                "invoice_id": int(raw["invoice_id"]), "invoice_number": raw["invoice_number"],
                "invoice_date": str(raw["invoice_date"]), "due_date": str(raw["due_date"] or raw["invoice_date"]),
                "payment_terms_days": int(raw["payment_terms_days"] or 0),
                "party_id": int(raw["party_id"]), "party_name": raw[party_name], "age_days": age,
                "remaining_amount": float(amount), "bucket": bucket,
            })
        totals = {key: float(value.quantize(_CENT)) for key, value in totals.items()}
        totals["total"] = round(sum(totals.values()), 2)
        return {"party": party, "company_id": int(company_id), "as_of_date": cutoff.isoformat(),
                "basis": "due_date", "rows": rows, "totals": totals}

    def set_payment_terms(self, party: str, company_id: int, party_id: int,
                          payment_terms_days: int, actor_user_id: int) -> None:
        """Update a party's default terms; existing invoice snapshots are untouched."""
        from alexerp.services.permission_service import PermissionService

        if party not in {"customer", "supplier"}:
            raise ValueError("نوع الطرف غير صحيح.")
        try:
            days = int(payment_terms_days)
        except (TypeError, ValueError):
            raise ValueError("مدة السداد يجب أن تكون عدد أيام صحيحاً.")
        if days < 0 or days > 3650:
            raise ValueError("مدة السداد يجب أن تكون بين صفر و3650 يوماً.")
        PermissionService().require(int(actor_user_id), "parties.payment_terms.manage")
        table = "customers" if party == "customer" else "suppliers"
        with transaction() as conn:
            actor = conn.execute(
                "SELECT company_id,is_active FROM users WHERE id=?", (actor_user_id,)
            ).fetchone()
            row = conn.execute(
                f"SELECT payment_terms_days FROM {table} WHERE id=? AND company_id=?",
                (party_id, company_id),
            ).fetchone()
            if not actor or not actor["is_active"] or int(actor["company_id"] or 0) != int(company_id):
                raise ValueError("المستخدم غير نشط أو لا ينتمي إلى الشركة المحددة.")
            if row is None:
                raise ValueError("العميل أو المورد غير موجود ضمن الشركة.")
            before = int(row["payment_terms_days"] or 0)
            conn.execute(
                f"UPDATE {table} SET payment_terms_days=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND company_id=?",
                (days, party_id, company_id),
            )
            AuditService.record(
                user_id=actor_user_id, company_id=company_id, module="parties",
                action="payment_terms_updated", entity_type=party, record_id=party_id,
                description="Updated default payment terms",
                before={"payment_terms_days": before}, after={"payment_terms_days": days},
                connection=conn,
            )

    def customer_statement(self, company_id: int, customer_id: int,
                           date_from: str | None = None, date_to: str | None = None,
                           branch_id: int | None = None) -> dict:
        return self._statement("customer", company_id, customer_id, date_from, date_to, branch_id)

    def supplier_statement(self, company_id: int, supplier_id: int,
                           date_from: str | None = None, date_to: str | None = None,
                           branch_id: int | None = None) -> dict:
        return self._statement("supplier", company_id, supplier_id, date_from, date_to, branch_id)

    def _statement(self, party: str, company_id: int, party_id: int,
                   date_from: str | None, date_to: str | None,
                   branch_id: int | None) -> dict:
        """Build a document-based statement with a running debit-minus-credit balance."""
        if int(company_id or 0) <= 0 or int(party_id or 0) <= 0:
            raise ValueError("الشركة أو الطرف غير صحيح.")
        start = _as_of(date_from) if date_from else None
        end = _as_of(date_to) if date_to else date.today()
        if start and start > end:
            raise ValueError("تاريخ البداية يجب ألا يتجاوز تاريخ النهاية.")
        conn = self.conn
        events: list[dict] = []
        if party == "customer":
            party_row = conn.execute(
                "SELECT id,code,name,payment_terms_days FROM customers WHERE id=? AND company_id=?",
                (party_id, company_id),
            ).fetchone()
            if party_row is None:
                raise ValueError("العميل غير موجود ضمن الشركة.")
            invoices = conn.execute(
                """SELECT i.id,i.invoice_number,i.invoice_date,i.due_date,i.total,i.paid_amount,
                          COALESCE((SELECT SUM(a.amount) FROM receipt_allocations a
                                    WHERE a.sales_invoice_id=i.id AND a.status='ACTIVE'),0) AS allocated
                   FROM sales_invoices i WHERE i.company_id=? AND i.customer_id=?
                     AND UPPER(COALESCE(i.status,''))='POSTED'""",
                (company_id, party_id),
            ).fetchall()
            for r in invoices:
                total = Decimal(str(r["total"] or 0)).quantize(_CENT)
                active_allocated = Decimal(str(r["allocated"] or 0)).quantize(_CENT)
                initial_paid = max(Decimal(str(r["paid_amount"] or 0)).quantize(_CENT) - active_allocated, Decimal("0.00"))
                self._append_event(events, r["invoice_date"], "فاتورة مبيعات", r["invoice_number"],
                                   "إصدار فاتورة", total, Decimal("0"), r["due_date"] or r["invoice_date"], r["id"])
                if initial_paid:
                    self._append_event(events, r["invoice_date"], "تحصيل عند الفاتورة", r["invoice_number"],
                                       "دفعة مسجلة عند إصدار الفاتورة", Decimal("0"), initial_paid,
                                       r["due_date"] or r["invoice_date"], r["id"])
            receipts = conn.execute(
                """SELECT id,receipt_number,receipt_date,amount FROM receipts
                   WHERE company_id=? AND customer_id=? AND UPPER(COALESCE(status,'POSTED'))='POSTED'""",
                (company_id, party_id),
            ).fetchall()
            for r in receipts:
                self._append_event(events, r["receipt_date"], "سند قبض", r["receipt_number"],
                                   "تحصيل من العميل", Decimal("0"), Decimal(str(r["amount"] or 0)), "", r["id"])
            returns = conn.execute(
                """SELECT id,return_number,return_date,total FROM sales_returns
                   WHERE company_id=? AND customer_id=? AND UPPER(COALESCE(status,'POSTED'))='POSTED'""",
                (company_id, party_id),
            ).fetchall()
            for r in returns:
                self._append_event(events, r["return_date"], "مرتجع مبيعات", r["return_number"],
                                   "إشعار دائن للعميل", Decimal("0"), Decimal(str(r["total"] or 0)), "", r["id"])
            notes = conn.execute(
                """SELECT n.id,n.note_number,n.note_date,n.note_type,n.amount,
                          n.description,i.due_date
                   FROM customer_financial_notes n
                   JOIN sales_invoices i ON i.id=n.sales_invoice_id
                   WHERE n.company_id=? AND n.customer_id=?
                     AND UPPER(COALESCE(n.status,''))='POSTED'""",
                (company_id, party_id),
            ).fetchall()
            for r in notes:
                is_debit = str(r["note_type"]).upper() == "DEBIT"
                self._append_event(
                    events, r["note_date"],
                    "إشعار مدين للعميل" if is_debit else "إشعار دائن للعميل",
                    r["note_number"], r["description"],
                    Decimal(str(r["amount"] or 0)) if is_debit else Decimal("0"),
                    Decimal("0") if is_debit else Decimal(str(r["amount"] or 0)),
                    r["due_date"] or r["note_date"], r["id"],
                )
            debit_label, credit_label = "مدين", "دائن"
        else:
            party_row = conn.execute(
                "SELECT id,code,name,payment_terms_days FROM suppliers WHERE id=? AND company_id=?",
                (party_id, company_id),
            ).fetchone()
            if party_row is None:
                raise ValueError("المورد غير موجود ضمن الشركة.")
            invoices = conn.execute(
                """SELECT i.id,i.invoice_number,i.invoice_date,i.due_date,i.total,i.paid_amount,
                          COALESCE((SELECT SUM(a.amount) FROM payment_allocations a
                                    WHERE a.purchase_invoice_id=i.id AND a.status='ACTIVE'),0) AS allocated
                   FROM purchase_invoices i WHERE i.company_id=? AND i.supplier_id=?
                     AND UPPER(COALESCE(i.status,''))='POSTED'""",
                (company_id, party_id),
            ).fetchall()
            for r in invoices:
                total = Decimal(str(r["total"] or 0)).quantize(_CENT)
                active_allocated = Decimal(str(r["allocated"] or 0)).quantize(_CENT)
                initial_paid = max(Decimal(str(r["paid_amount"] or 0)).quantize(_CENT) - active_allocated, Decimal("0.00"))
                self._append_event(events, r["invoice_date"], "فاتورة مشتريات", r["invoice_number"],
                                   "إثبات مستحقات المورد", Decimal("0"), total, r["due_date"] or r["invoice_date"], r["id"])
                if initial_paid:
                    self._append_event(events, r["invoice_date"], "دفعة عند الفاتورة", r["invoice_number"],
                                       "دفعة مسجلة عند إصدار الفاتورة", initial_paid, Decimal("0"),
                                       r["due_date"] or r["invoice_date"], r["id"])
            payments = conn.execute(
                """SELECT id,payment_number,payment_date,amount FROM payments
                   WHERE company_id=? AND supplier_id=? AND UPPER(COALESCE(status,'POSTED'))='POSTED'""",
                (company_id, party_id),
            ).fetchall()
            for r in payments:
                self._append_event(events, r["payment_date"], "سند صرف", r["payment_number"],
                                   "سداد للمورد", Decimal(str(r["amount"] or 0)), Decimal("0"), "", r["id"])
            returns = conn.execute(
                """SELECT pr.id,pr.return_number,pr.return_date,pr.total
                   FROM purchase_returns pr JOIN purchase_invoices i ON i.id=pr.purchase_invoice_id
                   WHERE i.company_id=? AND pr.supplier_id=?""",
                (company_id, party_id),
            ).fetchall()
            for r in returns:
                self._append_event(events, r["return_date"], "مرتجع مشتريات", r["return_number"],
                                   "إشعار مدين للمورد", Decimal(str(r["total"] or 0)), Decimal("0"), "", r["id"])
            debit_label, credit_label = "مدين", "دائن"

        if branch_id is not None:
            # Branch filtering is applied to events that carry a branch. Legacy
            # purchase returns inherit the branch from their linked invoice.
            filtered = []
            for event in events:
                table = event.get("source_table")
                if table in {"sales_invoices", "purchase_invoices", "receipts", "payments",
                             "sales_returns", "customer_financial_notes"}:
                    branch = conn.execute(f"SELECT branch_id FROM {table} WHERE id=?", (event["source_id"],)).fetchone()
                elif table == "purchase_returns":
                    branch = conn.execute("SELECT branch_id FROM purchase_invoices WHERE id=(SELECT purchase_invoice_id FROM purchase_returns WHERE id=?)", (event["source_id"],)).fetchone()
                else:
                    branch = None
                if branch and branch[0] == branch_id:
                    filtered.append(event)
            events = filtered

        events.sort(key=lambda e: (e["date"], e["source_id"], e["type"]))
        opening = Decimal("0.00")
        selected = []
        running = Decimal("0.00")
        for event in events:
            day = _as_of(event["date"])
            delta = event["debit"] - event["credit"]
            if start and day < start:
                opening += delta
                continue
            if day <= end:
                running += delta
                selected.append({**event, "debit": float(event["debit"]), "credit": float(event["credit"]),
                                 "balance": float(running)})
        running += opening
        # Rebuild selected running balances from opening balance.
        balance = opening
        for row in selected:
            balance += Decimal(str(row["debit"])) - Decimal(str(row["credit"]))
            row["balance"] = float(balance.quantize(_CENT))
        return {
            "party": party, "company_id": int(company_id), "party_id": int(party_id),
            "party_code": party_row["code"], "party_name": party_row["name"],
            "payment_terms_days": int(party_row["payment_terms_days"] or 0),
            "date_from": start.isoformat() if start else None, "date_to": end.isoformat(),
            "opening_balance": float(opening.quantize(_CENT)),
            "closing_balance": float(balance.quantize(_CENT)),
            "rows": selected, "balance_convention": "debit_minus_credit",
        }

    @staticmethod
    def _append_event(events, day, doc_type, reference, description,
                      debit, credit, due_date="", source_id=None):
        if not day:
            return
        events.append({
            "date": str(day), "type": doc_type, "reference": str(reference or ""),
            "description": description, "due_date": str(due_date or ""),
            "debit": Decimal(str(debit or 0)).quantize(_CENT),
            "credit": Decimal(str(credit or 0)).quantize(_CENT),
            "source_id": int(source_id or 0),
            "source_table": {
                "فاتورة مبيعات": "sales_invoices", "فاتورة مشتريات": "purchase_invoices",
                "تحصيل عند الفاتورة": "sales_invoices", "دفعة عند الفاتورة": "purchase_invoices",
                "سند قبض": "receipts", "سند صرف": "payments",
                "مرتجع مبيعات": "sales_returns", "مرتجع مشتريات": "purchase_returns",
                "إشعار مدين للعميل": "customer_financial_notes",
                "إشعار دائن للعميل": "customer_financial_notes",
            }.get(doc_type),
        })

    @staticmethod
    def _refresh_party(conn, party: str, party_id: int) -> None:
        if party == "customer":
            balance = conn.execute(
                """SELECT COALESCE((SELECT SUM(remaining_amount) FROM sales_invoices
                                      WHERE customer_id=? AND UPPER(COALESCE(status,''))='POSTED'),0)
                   - COALESCE((SELECT SUM(r.amount - COALESCE(a.allocated,0)) FROM receipts r
                       LEFT JOIN (SELECT receipt_id,SUM(amount) AS allocated FROM receipt_allocations
                                  WHERE status='ACTIVE' GROUP BY receipt_id) a ON a.receipt_id=r.id
                       WHERE r.customer_id=? AND UPPER(COALESCE(r.status,'POSTED'))='POSTED'),0)""",
                (party_id, party_id),
            ).fetchone()[0]
            conn.execute("UPDATE customers SET current_balance=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                         (round(float(balance or 0), 2), party_id))
        else:
            balance = conn.execute(
                """SELECT COALESCE((SELECT SUM(remaining_amount) FROM purchase_invoices
                                      WHERE supplier_id=? AND UPPER(COALESCE(status,''))='POSTED'),0)
                   - COALESCE((SELECT SUM(p.amount - COALESCE(a.allocated,0)) FROM payments p
                       LEFT JOIN (SELECT payment_id,SUM(amount) AS allocated FROM payment_allocations
                                  WHERE status='ACTIVE' GROUP BY payment_id) a ON a.payment_id=p.id
                       WHERE p.supplier_id=? AND UPPER(COALESCE(p.status,'POSTED'))='POSTED'),0)""",
                (party_id, party_id),
            ).fetchone()[0]
            conn.execute("UPDATE suppliers SET current_balance=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                         (round(float(balance or 0), 2), party_id))
