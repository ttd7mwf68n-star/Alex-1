"""Company-scoped, read-only business intelligence queries.

The service deliberately reports only metrics supported by posted operational
records. It does not present cash-flow forecasts or stock-turnover estimates
when the source data is insufficient to calculate them reliably.
"""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP

from alexerp.repositories.base_repository import BaseRepository
from alexerp.accounting import AccountingReadService

_CENT = Decimal("0.01")
_EXCLUDED_STATUSES = ("Draft", "Cancelled", "Canceled", "Void", "CANCELLED", "CANCELED", "VOID")


def _amount(value) -> Decimal:
    return Decimal(str(value or 0)).quantize(_CENT, rounding=ROUND_HALF_UP)


def _month_start(value: date) -> date:
    return value.replace(day=1)


def _shift_month(value: date, offset: int) -> date:
    index = value.year * 12 + value.month - 1 + offset
    year, month0 = divmod(index, 12)
    return date(year, month0 + 1, 1)


class BusinessIntelligenceService(BaseRepository):
    """Read-only KPIs, period comparisons and rankings for one company."""

    table_name = "sales_invoices"

    def __init__(self, accounting_reads=None):
        self.accounting_reads = accounting_reads or AccountingReadService()

    @staticmethod
    def _validate_scope(company_id: int, branch_id: int | None = None) -> tuple[int, int | None]:
        if isinstance(company_id, bool) or not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("A valid company_id is required.")
        if branch_id is not None and (isinstance(branch_id, bool) or int(branch_id) <= 0):
            raise ValueError("branch_id must be a positive integer.")
        return int(company_id), int(branch_id) if branch_id is not None else None

    @staticmethod
    def _validate_dates(date_from: str, date_to: str) -> tuple[date, date]:
        try:
            start = date.fromisoformat(str(date_from))
            end = date.fromisoformat(str(date_to))
        except (TypeError, ValueError) as exc:
            raise ValueError("Dates must be valid ISO dates (YYYY-MM-DD).") from exc
        if start > end:
            raise ValueError("date_from cannot be after date_to.")
        if (end - start).days > 3660:
            raise ValueError("BI date range cannot exceed ten years.")
        return start, end

    @staticmethod
    def _invoice_scope(alias: str, company_id: int, branch_id: int | None) -> tuple[str, tuple]:
        sql = f"{alias}.company_id=?"
        params: tuple = (company_id,)
        if branch_id is not None:
            sql += f" AND {alias}.branch_id=?"
            params += (branch_id,)
        return sql, params

    def executive_summary(self, company_id: int, date_from: str, date_to: str,
                          branch_id: int | None = None) -> dict:
        company_id, branch_id = self._validate_scope(company_id, branch_id)
        start, end = self._validate_dates(date_from, date_to)
        sales_scope, sales_params = self._invoice_scope("s", company_id, branch_id)
        returns_scope, returns_params = self._invoice_scope("r", company_id, branch_id)
        purchase_scope, purchase_params = self._invoice_scope("p", company_id, branch_id)
        date_params = (start.isoformat(), end.isoformat())

        sales = self.fetchone(
            f"""SELECT COUNT(*) AS invoice_count, COALESCE(SUM(s.total),0) AS total
                FROM sales_invoices s
                WHERE {sales_scope} AND s.invoice_date BETWEEN ? AND ?
                  AND COALESCE(s.status,'') NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})""",
            sales_params + date_params + _EXCLUDED_STATUSES,
        )
        purchases = self.fetchone(
            f"""SELECT COUNT(*) AS invoice_count, COALESCE(SUM(p.total),0) AS total
                FROM purchase_invoices p
                WHERE {purchase_scope} AND p.invoice_date BETWEEN ? AND ?
                  AND COALESCE(p.status,'') NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})""",
            purchase_params + date_params + _EXCLUDED_STATUSES,
        )
        cogs = self.fetchone(
            f"""SELECT COALESCE(SUM(i.quantity * COALESCE(i.unit_cost,0)),0) AS amount
                FROM sales_invoice_items i
                JOIN sales_invoices s ON s.id=i.invoice_id
                WHERE {sales_scope}
                  AND ((COALESCE(s.inventory_policy,'DEDUCT_ON_POST')='DEDUCT_ON_POST'
                        AND s.invoice_date BETWEEN ? AND ?)
                    OR (s.inventory_policy='RESERVE_UNTIL_DELIVERY'
                        AND UPPER(COALESCE(s.delivery_status,''))='DELIVERED'
                        AND date(s.delivered_at) BETWEEN date(?) AND date(?)))
                  AND COALESCE(s.status,'') NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})""",
            sales_params + date_params + date_params + _EXCLUDED_STATUSES,
        )
        returns = self.fetchone(
            f"""SELECT COALESCE(SUM(r.total),0) AS amount
                FROM sales_returns r
                WHERE {returns_scope} AND r.return_date BETWEEN ? AND ?
                  AND UPPER(COALESCE(r.status,'POSTED')) NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})""",
            returns_params + date_params + tuple(value.upper() for value in _EXCLUDED_STATUSES),
        )
        returned_cost = self.fetchone(
            f"""SELECT COALESCE(SUM(i.quantity * COALESCE(i.unit_cost,0)),0) AS amount
                FROM sales_return_items i JOIN sales_returns r ON r.id=i.return_id
                WHERE {returns_scope} AND r.return_date BETWEEN ? AND ?
                  AND UPPER(COALESCE(r.status,'POSTED')) NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})""",
            returns_params + date_params + tuple(value.upper() for value in _EXCLUDED_STATUSES),
        )
        receipts = self._cash_total("receipts", "receipt_date", company_id, branch_id, start, end)
        payments = self._cash_total("payments", "payment_date", company_id, branch_id, start, end)
        receivables = self.fetchone(
            f"""SELECT COALESCE(SUM(remaining_amount),0) AS amount FROM sales_invoices s
                WHERE {sales_scope} AND COALESCE(s.status,'') NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})
                  AND COALESCE(s.remaining_amount,0)>0""",
            sales_params + _EXCLUDED_STATUSES,
        )
        payables = self.fetchone(
            f"""SELECT COALESCE(SUM(remaining_amount),0) AS amount FROM purchase_invoices p
                WHERE {purchase_scope} AND COALESCE(p.status,'') NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})
                  AND COALESCE(p.remaining_amount,0)>0""",
            purchase_params + _EXCLUDED_STATUSES,
        )
        ledger = self._ledger_profit_totals(company_id, branch_id, start, end)

        sales_total = _amount(sales["total"])
        cogs_total = _amount(cogs["amount"])
        sales_returns_total = _amount(returns["amount"])
        returned_cost_total = _amount(returned_cost["amount"])
        net_sales_total = sales_total - sales_returns_total
        net_cogs_total = cogs_total - returned_cost_total
        gross_profit = net_sales_total - net_cogs_total
        purchase_total = _amount(purchases["total"])
        receipt_total, payment_total = _amount(receipts), _amount(payments)
        margin = (gross_profit / net_sales_total * Decimal("100")) if net_sales_total else Decimal("0")
        return {
            "date_from": start.isoformat(), "date_to": end.isoformat(),
            "sales_total": float(net_sales_total), "gross_sales_total": float(sales_total),
            "sales_returns_total": float(sales_returns_total),
            "sales_invoice_count": int(sales["invoice_count"] or 0),
            "average_sale": float(net_sales_total / int(sales["invoice_count"])) if int(sales["invoice_count"] or 0) else 0.0,
            "purchase_total": float(purchase_total), "purchase_invoice_count": int(purchases["invoice_count"] or 0),
            "cost_of_goods_sold": float(net_cogs_total),
            "gross_cost_of_goods_sold": float(cogs_total),
            "returned_cost": float(returned_cost_total),
            "gross_profit": float(gross_profit),
            "gross_margin_percent": float(margin.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)),
            "receipts_total": float(receipt_total), "payments_total": float(payment_total),
            "net_cash_movement": float(receipt_total - payment_total),
            "receivables_open": float(_amount(receivables["amount"])),
            "payables_open": float(_amount(payables["amount"])),
            "ledger_revenue_total": float(ledger["revenue"]),
            "ledger_expenses_total": float(ledger["expenses"]),
            "net_income": float(ledger["revenue"] - ledger["expenses"]),
            "profit_basis": "net sales after posted returns less net stored unit cost; excludes operating expenses",
        }

    def _ledger_profit_totals(self, company_id: int, branch_id: int | None,
                              start: date, end: date) -> dict[str, Decimal]:
        row = self.accounting_reads.ledger_profit_totals(
            company_id, branch_id, start.isoformat(), end.isoformat()
        )
        return {
            "revenue": _amount(row["revenue"]),
            "expenses": _amount(row["expenses"]),
        }

    def _monthly_ledger_profit(self, company_id: int, branch_id: int | None,
                               start: date, end: date) -> dict[str, dict[str, Decimal]]:
        rows = self.accounting_reads.monthly_ledger_profit(
            company_id, branch_id, start.isoformat(), end.isoformat()
        )
        return {
            month: {
                "revenue": _amount(row["revenue"]),
                "expenses": _amount(row["expenses"]),
            }
            for month, row in rows.items()
        }

    def _cash_total(self, table: str, date_column: str, company_id: int,
                    branch_id: int | None, start: date, end: date) -> Decimal:
        # Table and date column are fixed internal literals, never user input.
        sql = f"SELECT COALESCE(SUM(amount),0) FROM {table} WHERE company_id=? AND {date_column} BETWEEN ? AND ?"
        params: tuple = (company_id, start.isoformat(), end.isoformat())
        if branch_id is not None:
            sql += " AND branch_id=?"
            params += (branch_id,)
        sql += " AND UPPER(COALESCE(status,'POSTED')) NOT IN ('CANCELLED','CANCELED','VOID','DRAFT')"
        row = self.fetchone(sql, params)
        return _amount(row[0] if row else 0)

    def period_comparison(self, company_id: int, date_from: str, date_to: str,
                          branch_id: int | None = None) -> dict:
        start, end = self._validate_dates(date_from, date_to)
        company_id, branch_id = self._validate_scope(company_id, branch_id)
        days = (end - start).days + 1
        previous_end = start - timedelta(days=1)
        previous_start = previous_end - timedelta(days=days - 1)
        current = self.executive_summary(company_id, start.isoformat(), end.isoformat(), branch_id)
        previous = self.executive_summary(company_id, previous_start.isoformat(), previous_end.isoformat(), branch_id)
        metrics = (
            "sales_total", "purchase_total", "gross_profit", "receipts_total",
            "payments_total", "ledger_expenses_total", "net_income",
        )
        comparison = {}
        for key in metrics:
            old, new = _amount(previous[key]), _amount(current[key])
            change = new - old
            comparison[key] = {
                "current": float(new), "previous": float(old), "change": float(change),
                "change_percent": float((change / old * 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)) if old else None,
            }
        return {"current_from": start.isoformat(), "current_to": end.isoformat(),
                "previous_from": previous_start.isoformat(), "previous_to": previous_end.isoformat(),
                "metrics": comparison}

    def monthly_performance(self, company_id: int, date_from: str, date_to: str,
                            branch_id: int | None = None) -> list[dict]:
        company_id, branch_id = self._validate_scope(company_id, branch_id)
        start, end = self._validate_dates(date_from, date_to)
        sales_scope, sales_params = self._invoice_scope("s", company_id, branch_id)
        returns_scope, returns_params = self._invoice_scope("r", company_id, branch_id)
        purchase_scope, purchase_params = self._invoice_scope("p", company_id, branch_id)
        excluded = ",".join("?" for _ in _EXCLUDED_STATUSES)
        sales_rows = self.fetchall(
            f"""SELECT substr(s.invoice_date,1,7) AS month, COALESCE(SUM(s.total),0) AS total
                FROM sales_invoices s WHERE {sales_scope} AND s.invoice_date BETWEEN ? AND ?
                AND COALESCE(s.status,'') NOT IN ({excluded})
                GROUP BY substr(CASE WHEN s.inventory_policy='RESERVE_UNTIL_DELIVERY'
                                     THEN s.delivered_at ELSE s.invoice_date END,1,7)""",
            sales_params + (start.isoformat(), end.isoformat()) + _EXCLUDED_STATUSES,
        )
        purchase_rows = self.fetchall(
            f"""SELECT substr(p.invoice_date,1,7) AS month, COALESCE(SUM(p.total),0) AS total
                FROM purchase_invoices p WHERE {purchase_scope} AND p.invoice_date BETWEEN ? AND ?
                AND COALESCE(p.status,'') NOT IN ({excluded}) GROUP BY substr(p.invoice_date,1,7)""",
            purchase_params + (start.isoformat(), end.isoformat()) + _EXCLUDED_STATUSES,
        )
        cogs_rows = self.fetchall(
            f"""SELECT substr(CASE WHEN s.inventory_policy='RESERVE_UNTIL_DELIVERY'
                                   THEN s.delivered_at ELSE s.invoice_date END,1,7) AS month,
                       COALESCE(SUM(i.quantity * COALESCE(i.unit_cost,0)),0) AS amount
                FROM sales_invoice_items i JOIN sales_invoices s ON s.id=i.invoice_id
                WHERE {sales_scope}
                AND ((COALESCE(s.inventory_policy,'DEDUCT_ON_POST')='DEDUCT_ON_POST'
                      AND s.invoice_date BETWEEN ? AND ?)
                  OR (s.inventory_policy='RESERVE_UNTIL_DELIVERY'
                      AND UPPER(COALESCE(s.delivery_status,''))='DELIVERED'
                      AND date(s.delivered_at) BETWEEN date(?) AND date(?)))
                AND COALESCE(s.status,'') NOT IN ({excluded}) GROUP BY substr(s.invoice_date,1,7)""",
            sales_params + (start.isoformat(), end.isoformat()) * 2 + _EXCLUDED_STATUSES,
        )
        returns_rows = self.fetchall(
            f"""SELECT substr(r.return_date,1,7) AS month, COALESCE(SUM(r.total),0) AS amount
                FROM sales_returns r WHERE {returns_scope} AND r.return_date BETWEEN ? AND ?
                  AND UPPER(COALESCE(r.status,'POSTED')) NOT IN ({excluded})
                GROUP BY substr(r.return_date,1,7)""",
            returns_params + (start.isoformat(), end.isoformat())
            + tuple(value.upper() for value in _EXCLUDED_STATUSES),
        )
        returned_cost_rows = self.fetchall(
            f"""SELECT substr(r.return_date,1,7) AS month,
                       COALESCE(SUM(i.quantity * COALESCE(i.unit_cost,0)),0) AS amount
                FROM sales_return_items i JOIN sales_returns r ON r.id=i.return_id
                WHERE {returns_scope} AND r.return_date BETWEEN ? AND ?
                  AND UPPER(COALESCE(r.status,'POSTED')) NOT IN ({excluded})
                GROUP BY substr(r.return_date,1,7)""",
            returns_params + (start.isoformat(), end.isoformat())
            + tuple(value.upper() for value in _EXCLUDED_STATUSES),
        )
        ledger_map = self._monthly_ledger_profit(company_id, branch_id, start, end)
        sales_map = {r["month"]: _amount(r["total"]) for r in sales_rows}
        purchase_map = {r["month"]: _amount(r["total"]) for r in purchase_rows}
        cogs_map = {r["month"]: _amount(r["amount"]) for r in cogs_rows}
        returns_map = {r["month"]: _amount(r["amount"]) for r in returns_rows}
        returned_cost_map = {r["month"]: _amount(r["amount"]) for r in returned_cost_rows}
        output = []
        cursor = _month_start(start)
        last = _month_start(end)
        while cursor <= last:
            key = cursor.strftime("%Y-%m")
            sales_value = sales_map.get(key, Decimal("0.00"))
            returns_value = returns_map.get(key, Decimal("0.00"))
            returned_cost = returned_cost_map.get(key, Decimal("0.00"))
            net_sales = sales_value - returns_value
            net_cogs = cogs_map.get(key, Decimal("0.00")) - returned_cost
            purchase_value = purchase_map.get(key, Decimal("0.00"))
            ledger = ledger_map.get(key, {"revenue": Decimal("0.00"), "expenses": Decimal("0.00")})
            output.append({"month": key, "label": f"{cursor.month:02d}/{cursor.year}",
                           "sales": float(net_sales), "invoice_sales": float(sales_value),
                           "sales_returns": float(returns_value),
                           "purchases": float(purchase_value),
                           "gross_profit": float(net_sales - net_cogs),
                           "ledger_expenses": float(ledger["expenses"]),
                           "net_income": float(ledger["revenue"] - ledger["expenses"])})
            cursor = _shift_month(cursor, 1)
        return output

    def top_customers(self, company_id: int, date_from: str, date_to: str,
                      branch_id: int | None = None, limit: int = 10) -> list[dict]:
        company_id, branch_id = self._validate_scope(company_id, branch_id)
        start, end = self._validate_dates(date_from, date_to)
        scope, params = self._invoice_scope("s", company_id, branch_id)
        returns_scope, returns_params = self._invoice_scope("r", company_id, branch_id)
        rows = self.fetchall(
            f"""SELECT c.id, c.name, COUNT(s.id) AS invoice_count,
                       COALESCE(SUM(s.total),0) AS sales_total,
                       COALESCE(SUM(s.remaining_amount),0) AS open_balance,
                       COALESCE(MAX(sr.sales_returns_total),0) AS sales_returns_total
                FROM sales_invoices s JOIN customers c ON c.id=s.customer_id AND c.company_id=s.company_id
                LEFT JOIN (
                    SELECT r.company_id,r.customer_id,SUM(r.total) AS sales_returns_total
                    FROM sales_returns r WHERE {returns_scope} AND r.return_date BETWEEN ? AND ?
                      AND UPPER(COALESCE(r.status,'POSTED')) NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})
                    GROUP BY r.company_id,r.customer_id
                ) sr ON sr.company_id=s.company_id AND sr.customer_id=c.id
                WHERE {scope} AND s.invoice_date BETWEEN ? AND ?
                  AND COALESCE(s.status,'') NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})
                GROUP BY c.id,c.name,sr.sales_returns_total
                ORDER BY sales_total-COALESCE(sr.sales_returns_total,0) DESC LIMIT ?""",
            returns_params + (start.isoformat(), end.isoformat())
            + tuple(value.upper() for value in _EXCLUDED_STATUSES)
            + params + (start.isoformat(), end.isoformat()) + _EXCLUDED_STATUSES
            + (max(1, min(int(limit), 100)),),
        )
        return [{"id": int(r["id"]), "name": r["name"], "invoice_count": int(r["invoice_count"] or 0),
                 "sales_total": float(_amount(r["sales_total"]) - _amount(r["sales_returns_total"])),
                 "gross_sales_total": float(_amount(r["sales_total"])),
                 "sales_returns_total": float(_amount(r["sales_returns_total"])),
                 "open_balance": float(_amount(r["open_balance"]))}
                for r in rows]

    def top_products(self, company_id: int, date_from: str, date_to: str,
                     branch_id: int | None = None, limit: int = 10) -> list[dict]:
        company_id, branch_id = self._validate_scope(company_id, branch_id)
        start, end = self._validate_dates(date_from, date_to)
        scope, params = self._invoice_scope("s", company_id, branch_id)
        returns_scope, returns_params = self._invoice_scope("r", company_id, branch_id)
        rows = self.fetchall(
            f"""SELECT p.id, p.name, COALESCE(SUM(i.quantity),0) AS quantity,
                       COALESCE(SUM(i.total),0) AS revenue,
                       COALESCE(MAX(sr.returned_quantity),0) AS returned_quantity,
                       COALESCE(MAX(sr.returned_revenue),0) AS returned_revenue,
                       COALESCE(MAX(sr.returned_cost),0) AS returned_cost
                FROM sales_invoice_items i JOIN sales_invoices s ON s.id=i.invoice_id
                JOIN products p ON p.id=i.product_id AND p.company_id=s.company_id
                LEFT JOIN (
                    SELECT r.company_id,ri.product_id,
                           SUM(ri.quantity) AS returned_quantity,
                           SUM(ri.total) AS returned_revenue,
                           SUM(ri.quantity * COALESCE(ri.unit_cost,0)) AS returned_cost
                    FROM sales_return_items ri JOIN sales_returns r ON r.id=ri.return_id
                    WHERE {returns_scope} AND r.return_date BETWEEN ? AND ?
                      AND UPPER(COALESCE(r.status,'POSTED')) NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})
                    GROUP BY r.company_id,ri.product_id
                ) sr ON sr.company_id=s.company_id AND sr.product_id=p.id
                WHERE {scope} AND s.invoice_date BETWEEN ? AND ?
                  AND COALESCE(s.status,'') NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})
                GROUP BY p.id,p.name,sr.returned_quantity,sr.returned_revenue,sr.returned_cost
                ORDER BY revenue-COALESCE(sr.returned_revenue,0) DESC LIMIT ?""",
            returns_params + (start.isoformat(), end.isoformat())
            + tuple(value.upper() for value in _EXCLUDED_STATUSES)
            + params + (start.isoformat(), end.isoformat()) + _EXCLUDED_STATUSES
            + (max(1, min(int(limit), 100)),),
        )
        cost_rows = self.fetchall(
            f"""SELECT i.product_id,
                       COALESCE(SUM(i.quantity * COALESCE(i.unit_cost,0)),0) AS amount
                FROM sales_invoice_items i JOIN sales_invoices s ON s.id=i.invoice_id
                WHERE {scope}
                  AND ((COALESCE(s.inventory_policy,'DEDUCT_ON_POST')='DEDUCT_ON_POST'
                        AND s.invoice_date BETWEEN ? AND ?)
                    OR (s.inventory_policy='RESERVE_UNTIL_DELIVERY'
                        AND UPPER(COALESCE(s.delivery_status,''))='DELIVERED'
                        AND date(s.delivered_at) BETWEEN date(?) AND date(?)))
                  AND COALESCE(s.status,'') NOT IN ({','.join('?' for _ in _EXCLUDED_STATUSES)})
                GROUP BY i.product_id""",
            params + (start.isoformat(), end.isoformat()) * 2 + _EXCLUDED_STATUSES,
        )
        cost_map = {int(row["product_id"]): _amount(row["amount"]) for row in cost_rows}
        result = []
        for r in rows:
            revenue = _amount(r["revenue"])
            cost = cost_map.get(int(r["id"]), Decimal("0.00"))
            returned_revenue = _amount(r["returned_revenue"])
            returned_cost = _amount(r["returned_cost"])
            result.append({
                "id": int(r["id"]), "name": r["name"],
                "quantity": float(r["quantity"] or 0) - float(r["returned_quantity"] or 0),
                "revenue": float(revenue - returned_revenue),
                "gross_revenue": float(revenue),
                "sales_returns_total": float(returned_revenue),
                "cost": float(cost - returned_cost),
                "gross_profit": float((revenue - returned_revenue) - (cost - returned_cost)),
            })
        return result
