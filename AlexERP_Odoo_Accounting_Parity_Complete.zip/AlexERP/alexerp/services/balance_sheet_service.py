"""Balance sheet using credit-normal liability/equity balances and current earnings."""
from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from alexerp.accounting import AccountingReadService

_CENT = Decimal("0.01")


def _money(value) -> Decimal:
    return Decimal(str(value or 0)).quantize(_CENT, rounding=ROUND_HALF_UP)


class BalanceSheetService:
    def __init__(self, repository=None, read_service=None):
        self.repo = repository
        self.read_service = read_service or AccountingReadService()

    def get_report(self, company_id, date_to):
        if not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("A valid company_id is required.")
        try:
            date.fromisoformat(str(date_to))
        except (TypeError, ValueError) as exc:
            raise ValueError("Report date must be a valid ISO date (YYYY-MM-DD).") from exc

        rows = (self.repo.get_balance_sheet(company_id, date_to) if self.repo
                else self.read_service.get_balance_sheet_rows(company_id, date_to))
        assets, liabilities, equity, unclassified = [], [], [], []
        total_assets = Decimal("0.00")
        total_liabilities = Decimal("0.00")
        total_equity = Decimal("0.00")

        for row in rows:
            debit, credit = _money(row["debit"]), _money(row["credit"])
            kind = row["account_type"]
            if kind == "ASSET":
                balance = debit - credit
                assets.append({"code": row["code"], "name": row["name"], "balance": float(balance)})
                total_assets += balance
            elif kind == "LIABILITY":
                balance = credit - debit
                liabilities.append({"code": row["code"], "name": row["name"], "balance": float(balance)})
                total_liabilities += balance
            elif kind == "EQUITY":
                balance = credit - debit
                equity.append({"code": row["code"], "name": row["name"], "balance": float(balance)})
                total_equity += balance
            elif kind in ("REVENUE", "EXPENSE"):
                # Income-statement accounts are included in current earnings below,
                # not displayed as balance-sheet assets/liabilities/equity.
                continue
            else:
                unclassified.append({
                    "code": row["code"], "name": row["name"],
                    "account_type": kind, "debit": float(debit), "credit": float(credit),
                })

        pnl_rows = (self.repo.get_profit_and_loss(company_id, date_to) if self.repo
                    else self.read_service.get_balance_sheet_income_totals(company_id, date_to))
        revenue = Decimal("0.00")
        expenses = Decimal("0.00")
        for row in pnl_rows:
            if row["account_type"] == "REVENUE":
                revenue += _money(row["credit"]) - _money(row["debit"])
            elif row["account_type"] == "EXPENSE":
                expenses += _money(row["debit"]) - _money(row["credit"])
        unclosed_profit = revenue - expenses
        equity_including_profit = total_equity + unclosed_profit
        difference = total_assets - total_liabilities - equity_including_profit

        return {
            "assets": assets,
            "liabilities": liabilities,
            "equity": equity,
            "unclassified": unclassified,
            "total_assets": float(total_assets),
            "total_liabilities": float(total_liabilities),
            "total_equity": float(total_equity),
            "revenue_to_date": float(revenue),
            "expenses_to_date": float(expenses),
            "unclosed_profit": float(unclosed_profit),
            "equity_including_unclosed_profit": float(equity_including_profit),
            "difference": float(difference),
            "balanced": not unclassified and difference == Decimal("0.00"),
        }
