"""Backward-compatible import path for the accounting-core service.

New application code should import from :mod:`alexerp.accounting`. This shim
keeps older extensions and stored scripts working while the service boundary is
migrated incrementally.
"""
from alexerp.accounting import AccountingError, AccountingService

__all__ = ["AccountingError", "AccountingService"]
