"""Customer / supplier running balances, derived from posted documents.

The stored `current_balance` is a cache of: posted invoices' unpaid amounts minus
settlements (receipts / payments) and returns. It is recomputed from the source
documents inside the same transaction as every posting, so it cannot drift, and
`refresh_all()` can rebuild it for existing data at any time.
"""
from __future__ import annotations

from alexerp.database.db import Database


class PartyBalanceService:
    def _conn(self):
        return Database.connect()

    def customer_balance(self, customer_id: int) -> float:
        row = self._conn().execute(
            """SELECT
                 COALESCE((SELECT SUM(remaining_amount) FROM sales_invoices
                           WHERE customer_id=? AND UPPER(COALESCE(status,''))='POSTED'),0)
               - COALESCE((SELECT SUM(r.amount - COALESCE(a.allocated,0)) FROM receipts r
                           LEFT JOIN (SELECT receipt_id,SUM(amount) AS allocated
                                      FROM receipt_allocations WHERE status='ACTIVE' GROUP BY receipt_id) a
                             ON a.receipt_id=r.id
                           WHERE r.customer_id=? AND UPPER(COALESCE(r.status,'POSTED'))='POSTED'),0)
               - COALESCE((SELECT SUM(total) FROM sales_returns
                           WHERE customer_id=? AND UPPER(COALESCE(status,'POSTED'))='POSTED'),0)""",
            (customer_id, customer_id, customer_id),
        ).fetchone()
        return round(float(row[0] or 0), 2)

    def supplier_balance(self, supplier_id: int) -> float:
        row = self._conn().execute(
            """SELECT
                 COALESCE((SELECT SUM(remaining_amount) FROM purchase_invoices
                           WHERE supplier_id=? AND UPPER(COALESCE(status,''))='POSTED'),0)
               - COALESCE((SELECT SUM(p.amount - COALESCE(a.allocated,0)) FROM payments p
                           LEFT JOIN (SELECT payment_id,SUM(amount) AS allocated
                                      FROM payment_allocations WHERE status='ACTIVE' GROUP BY payment_id) a
                             ON a.payment_id=p.id
                           WHERE p.supplier_id=? AND UPPER(COALESCE(p.status,'POSTED'))='POSTED'),0)""",
            (supplier_id, supplier_id),
        ).fetchone()
        return round(float(row[0] or 0), 2)

    def refresh_customer(self, customer_id: int) -> float:
        balance = self.customer_balance(customer_id)
        self._conn().execute(
            "UPDATE customers SET current_balance=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (balance, customer_id),
        )
        return balance

    def refresh_supplier(self, supplier_id: int) -> float:
        balance = self.supplier_balance(supplier_id)
        self._conn().execute(
            "UPDATE suppliers SET current_balance=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (balance, supplier_id),
        )
        return balance

    def refresh_all(self) -> None:
        conn = self._conn()
        conn.execute(
            """WITH invoice_totals AS (
                   SELECT customer_id, SUM(COALESCE(remaining_amount,0)) AS amount
                   FROM sales_invoices
                   WHERE UPPER(COALESCE(status,''))='POSTED'
                   GROUP BY customer_id
               ),
               allocation_totals AS (
                   SELECT receipt_id, SUM(amount) AS amount
                   FROM receipt_allocations WHERE status='ACTIVE'
                   GROUP BY receipt_id
               ),
               receipt_totals AS (
                   SELECT r.customer_id,
                          SUM(COALESCE(r.amount,0) - COALESCE(a.amount,0)) AS amount
                   FROM receipts r
                   LEFT JOIN allocation_totals a ON a.receipt_id=r.id
                   WHERE UPPER(COALESCE(r.status,'POSTED'))='POSTED'
                   GROUP BY r.customer_id
               ),
               return_totals AS (
                   SELECT customer_id, SUM(COALESCE(total,0)) AS amount
                   FROM sales_returns
                   WHERE UPPER(COALESCE(status,'POSTED'))='POSTED'
                   GROUP BY customer_id
               )
               UPDATE customers
               SET current_balance=ROUND(
                       COALESCE((SELECT amount FROM invoice_totals
                                 WHERE customer_id=customers.id),0)
                     - COALESCE((SELECT amount FROM receipt_totals
                                 WHERE customer_id=customers.id),0)
                     - COALESCE((SELECT amount FROM return_totals
                                 WHERE customer_id=customers.id),0), 2
                   ),
                   updated_at=CURRENT_TIMESTAMP"""
        )
        conn.execute(
            """WITH invoice_totals AS (
                   SELECT supplier_id, SUM(COALESCE(remaining_amount,0)) AS amount
                   FROM purchase_invoices
                   WHERE UPPER(COALESCE(status,''))='POSTED'
                   GROUP BY supplier_id
               ),
               allocation_totals AS (
                   SELECT payment_id, SUM(amount) AS amount
                   FROM payment_allocations WHERE status='ACTIVE'
                   GROUP BY payment_id
               ),
               payment_totals AS (
                   SELECT p.supplier_id,
                          SUM(COALESCE(p.amount,0) - COALESCE(a.amount,0)) AS amount
                   FROM payments p
                   LEFT JOIN allocation_totals a ON a.payment_id=p.id
                   WHERE UPPER(COALESCE(p.status,'POSTED'))='POSTED'
                   GROUP BY p.supplier_id
               )
               UPDATE suppliers
               SET current_balance=ROUND(
                       COALESCE((SELECT amount FROM invoice_totals
                                 WHERE supplier_id=suppliers.id),0)
                     - COALESCE((SELECT amount FROM payment_totals
                                 WHERE supplier_id=suppliers.id),0), 2
                   ),
                   updated_at=CURRENT_TIMESTAMP"""
        )
        conn.commit()
