"""Partial delivery lifecycle for posted sales-order invoices."""
from __future__ import annotations

import math
from datetime import date

from alexerp.database.db import Database
from alexerp.database.transaction import transaction
from alexerp.accounting import AccountingService
from alexerp.services.audit_service import AuditService
from alexerp.services.inventory_service import InventoryError, InventoryService
from alexerp.services.permission_service import PermissionDenied, PermissionService


class SalesDeliveryError(ValueError):
    pass


class SalesDeliveryService:
    def __init__(self):
        self.inventory = InventoryService()
        self.accounting = AccountingService()
        self.permissions = PermissionService()

    @property
    def conn(self):
        return Database.connect()

    def _permission(self, user_id: int, company_id: int, key: str):
        try:
            self.permissions.require_for_company(user_id, company_id, key)
        except PermissionDenied as exc:
            raise SalesDeliveryError(f"User is not authorized: {key}.") from exc

    def get_delivery(self, delivery_id: int):
        return self.conn.execute("SELECT * FROM sales_deliveries WHERE id=?", (delivery_id,)).fetchone()

    def get_items(self, delivery_id: int):
        return self.conn.execute(
            "SELECT * FROM sales_delivery_items WHERE delivery_id=? ORDER BY id", (delivery_id,)
        ).fetchall()

    def list_for_order(self, order_id: int, company_id: int):
        return self.conn.execute(
            "SELECT d.*, i.invoice_number FROM sales_deliveries d "
            "JOIN sales_invoices i ON i.id=d.sales_invoice_id "
            "WHERE d.sales_order_id=? AND d.company_id=? ORDER BY d.id DESC",
            (order_id, company_id),
        ).fetchall()

    def list_invoices_for_order(self, order_id: int, company_id: int):
        return self.conn.execute(
            "SELECT id,invoice_number,invoice_date,inventory_policy,delivery_status,status "
            "FROM sales_invoices WHERE sales_order_id=? AND company_id=? AND UPPER(status)='POSTED' "
            "ORDER BY id", (order_id, company_id),
        ).fetchall()

    def get_invoice_lines(self, invoice_id: int):
        return self.conn.execute(
            "SELECT ii.*, p.name AS product_name, w.name AS warehouse_name, "
            "COALESCE(ii.delivered_quantity,0) AS delivered_quantity "
            "FROM sales_invoice_items ii JOIN products p ON p.id=ii.product_id "
            "LEFT JOIN warehouses w ON w.id=ii.warehouse_id WHERE ii.invoice_id=? ORDER BY ii.id",
            (invoice_id,),
        ).fetchall()

    def create_and_post(self, *, order_id: int, invoice_id: int, delivery_number: str,
                        delivery_date: str, quantities: dict[int, float], created_by: int,
                        notes: str = "") -> int:
        delivery_number = str(delivery_number or "").strip()
        if not delivery_number or not quantities:
            raise SalesDeliveryError("Delivery number and at least one delivery line are required.")
        try:
            doc_date = date.fromisoformat(str(delivery_date)).isoformat()
        except (TypeError, ValueError) as exc:
            raise SalesDeliveryError("Invalid delivery date.") from exc

        with transaction():
            order = self.conn.execute(
                "SELECT * FROM sales_orders WHERE id=?", (order_id,)
            ).fetchone()
            invoice = self.conn.execute(
                "SELECT * FROM sales_invoices WHERE id=? AND sales_order_id=? AND company_id=? AND branch_id=?",
                (invoice_id, order_id, int(order["company_id"]) if order else -1,
                 int(order["branch_id"]) if order else -1),
            ).fetchone()
            if order is None or invoice is None:
                raise SalesDeliveryError("Sales order or linked invoice was not found.")
            if str(order["status"]).upper() in {"CANCELLED", "DRAFT", "SENT", "EXPIRED"}:
                raise SalesDeliveryError("Only confirmed sales orders can be delivered.")
            if str(invoice["status"]).upper() != "POSTED":
                raise SalesDeliveryError("Only posted invoices can be delivered.")
            company_id, branch_id = int(order["company_id"]), int(order["branch_id"])
            self._permission(created_by, company_id, "sales.delivery.create")
            self._permission(created_by, company_id, "sales.delivery.post")
            policy = str(invoice["inventory_policy"] or "DEDUCT_ON_POST").upper()
            if policy not in {"DEDUCT_ON_POST", "RESERVE_UNTIL_DELIVERY"}:
                raise SalesDeliveryError("Invoice has an unsupported inventory policy.")

            lines_by_id = {int(row["id"]): row for row in self.get_invoice_lines(invoice_id)}
            prepared = []
            reserve_totals: dict[tuple[int, int], float] = {}
            total_cost = 0.0
            for raw_id, raw_qty in quantities.items():
                try:
                    invoice_item_id = int(raw_id)
                    qty = float(raw_qty)
                except (TypeError, ValueError) as exc:
                    raise SalesDeliveryError("Invalid invoice line or delivery quantity.") from exc
                line = lines_by_id.get(invoice_item_id)
                if line is None:
                    raise SalesDeliveryError("A selected invoice line does not belong to this invoice.")
                if not math.isfinite(qty) or qty <= 0:
                    raise SalesDeliveryError("Delivery quantities must be positive finite numbers.")
                remaining = float(line["quantity"]) - float(line["delivered_quantity"] or 0)
                if qty - remaining > 0.000001:
                    raise SalesDeliveryError("Delivery quantity exceeds the invoice line's undelivered quantity.")
                order_item_id = line["sales_order_item_id"]
                if order_item_id is None:
                    raise SalesDeliveryError("Invoice line is not linked to a sales-order line.")
                order_line = self.conn.execute(
                    "SELECT * FROM sales_order_items WHERE id=? AND sales_order_id=?",
                    (int(order_item_id), order_id),
                ).fetchone()
                if order_line is None:
                    raise SalesDeliveryError("Invoice line points to an invalid sales-order line.")
                order_remaining = float(order_line["quantity"]) - float(order_line["delivered_quantity"] or 0)
                if qty - order_remaining > 0.000001:
                    raise SalesDeliveryError("Delivery quantity exceeds the sales-order line's remaining quantity.")
                product_id, warehouse_id = int(line["product_id"]), int(line["warehouse_id"])
                prepared.append((invoice_item_id, int(order_item_id), product_id, warehouse_id,
                                 qty, float(line["unit_cost"] or 0)))
                key = (product_id, warehouse_id)
                reserve_totals[key] = reserve_totals.get(key, 0.0) + qty
                total_cost += qty * float(line["unit_cost"] or 0)

            cur = self.conn.execute(
                "INSERT INTO sales_deliveries(company_id,branch_id,sales_order_id,sales_invoice_id,"
                "delivery_number,delivery_date,status,notes,created_by) "
                "VALUES(?,?,?,?,?,?,'DRAFT',?,?)",
                (company_id, branch_id, order_id, invoice_id, delivery_number, doc_date, notes, created_by),
            )
            delivery_id = int(cur.lastrowid)
            for invoice_item_id, order_item_id, product_id, warehouse_id, qty, cost in prepared:
                self.conn.execute(
                    "INSERT INTO sales_delivery_items(delivery_id,sales_order_item_id,sales_invoice_item_id,"
                    "product_id,warehouse_id,quantity,unit_cost) VALUES(?,?,?,?,?,?,?)",
                    (delivery_id, order_item_id, invoice_item_id, product_id, warehouse_id, qty, cost),
                )

            if policy == "RESERVE_UNTIL_DELIVERY":
                self.inventory.fulfill_stock_reservations_partial(
                    "SALE", invoice_id, reserve_totals, created_by,
                    f"Partial delivery {delivery_number}",
                )
                if total_cost > 0:
                    if not invoice["inventory_account_id"] or not invoice["cogs_account_id"]:
                        raise SalesDeliveryError("Inventory/COGS accounts are missing from the invoice snapshot.")
                    self.accounting.create_entry(
                        company_id, branch_id, doc_date, f"Sales Delivery {delivery_number}",
                        "SALE_DELIVERY", delivery_id, created_by,
                        [
                            {"account_id": int(invoice["cogs_account_id"]), "debit": round(total_cost, 2),
                             "credit": 0, "description": "Cost of goods delivered"},
                            {"account_id": int(invoice["inventory_account_id"]), "debit": 0,
                             "credit": round(total_cost, 2), "description": "Inventory delivered"},
                        ],
                        entry_number=f"JV-SD-{company_id}-{delivery_number}",
                    )

            for invoice_item_id, order_item_id, _product_id, _warehouse_id, qty, _cost in prepared:
                self.conn.execute(
                    "UPDATE sales_invoice_items SET delivered_quantity=COALESCE(delivered_quantity,0)+? WHERE id=?",
                    (qty, invoice_item_id),
                )
                self.conn.execute(
                    "UPDATE sales_order_items SET delivered_quantity=delivered_quantity+? WHERE id=? AND sales_order_id=?",
                    (qty, order_item_id, order_id),
                )
            self.conn.execute(
                "UPDATE sales_deliveries SET status='POSTED',posted_by=?,posted_at=CURRENT_TIMESTAMP WHERE id=?",
                (created_by, delivery_id),
            )
            remaining = self.conn.execute(
                "SELECT COALESCE(SUM(quantity-COALESCE(delivered_quantity,0)),0) FROM sales_invoice_items WHERE invoice_id=?",
                (invoice_id,),
            ).fetchone()[0]
            invoice_total = self.conn.execute(
                "SELECT COALESCE(SUM(quantity),0) FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
            ).fetchone()[0]
            new_status = "DELIVERED" if float(remaining or 0) <= 0.000001 else "SHIPPED"
            self.conn.execute(
                "UPDATE sales_invoices SET delivery_status=?,delivery_updated_by=?,delivery_updated_at=CURRENT_TIMESTAMP,"
                "delivered_at=CASE WHEN ?='DELIVERED' THEN CURRENT_TIMESTAMP ELSE delivered_at END WHERE id=?",
                (new_status, created_by, new_status, invoice_id),
            )
            AuditService.record(
                user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="sales", action="sales_delivery_posted", entity_type="sales_delivery",
                record_id=delivery_id, description=f"Delivery {delivery_number} posted",
                after={"order_id": order_id, "invoice_id": invoice_id, "status": "POSTED",
                       "total_quantity": sum(row[4] for row in prepared), "invoice_remaining": max(0, float(remaining or 0))},
                connection=self.conn,
            )
            return delivery_id

    def cancel_draft(self, delivery_id: int, created_by: int) -> None:
        with transaction():
            delivery = self.get_delivery(delivery_id)
            if delivery is None:
                raise SalesDeliveryError("Delivery document not found.")
            self._permission(created_by, int(delivery["company_id"]), "sales.delivery.create")
            if delivery["status"] != "DRAFT":
                raise SalesDeliveryError("Only draft deliveries can be cancelled. Posted deliveries require a return document.")
            self.conn.execute("UPDATE sales_deliveries SET status='CANCELLED' WHERE id=?", (delivery_id,))
            AuditService.record(
                user_id=created_by, company_id=int(delivery["company_id"]),
                branch_id=int(delivery["branch_id"]), module="sales", action="sales_delivery_cancelled",
                entity_type="sales_delivery", record_id=delivery_id,
                description=f"Draft delivery {delivery['delivery_number']} cancelled",
                before={"status": "DRAFT"}, after={"status": "CANCELLED"}, connection=self.conn,
            )
