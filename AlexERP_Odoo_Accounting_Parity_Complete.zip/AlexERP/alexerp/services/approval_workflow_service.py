"""Company-scoped, sequential approval workflows for purchase orders."""
from __future__ import annotations

import math
import sqlite3

from alexerp.database.db import Database
from alexerp.database.transaction import TransactionError, transaction
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionDenied, PermissionService


class ApprovalWorkflowError(ValueError):
    """Raised for invalid workflow configuration or approval-step access."""


class ApprovalWorkflowService:
    @staticmethod
    def _require_manage(actor_id: int, company_id: int) -> None:
        try:
            PermissionService().require_for_company(
                int(actor_id), int(company_id), "purchases.workflow.manage"
            )
        except (PermissionDenied, TypeError, ValueError) as exc:
            raise ApprovalWorkflowError("غير مصرح بإدارة تدفقات الاعتماد.") from exc

    def list_roles(self, company_id: int, actor_id: int):
        self._require_manage(actor_id, company_id)
        rows = Database.connect().execute(
            """SELECT id,code,name FROM roles
               WHERE is_active=1 AND (company_id IS NULL OR company_id=?)
                 AND EXISTS (
                     SELECT 1 FROM role_permissions rp
                     JOIN permissions p ON p.id=rp.permission_id
                     WHERE rp.role_id=roles.id AND p.permission_key='purchases.approve'
                 )
               ORDER BY is_system DESC,name""",
            (int(company_id),),
        ).fetchall()
        return [dict(row) for row in rows]

    def list_workflows(self, company_id: int, actor_id: int):
        self._require_manage(actor_id, company_id)
        conn = Database.connect()
        definitions = conn.execute(
            """SELECT id,name,min_amount,max_amount,is_active
               FROM approval_workflows
               WHERE company_id=? AND entity_type='purchase_order'
               ORDER BY min_amount,name""",
            (int(company_id),),
        ).fetchall()
        result = []
        for definition in definitions:
            item = dict(definition)
            item["steps"] = [dict(row) for row in conn.execute(
                """SELECT s.role_id,r.name role_name
                   FROM approval_workflow_steps s JOIN roles r ON r.id=s.role_id
                   WHERE s.workflow_id=? ORDER BY s.step_order""",
                (int(definition["id"]),),
            ).fetchall()]
            result.append(item)
        return result

    @staticmethod
    def _amount(value, label, allow_empty=False):
        if allow_empty and (value is None or str(value).strip() == ""):
            return None
        try:
            amount = float(value)
        except (TypeError, ValueError) as exc:
            raise ApprovalWorkflowError(f"{label} يجب أن يكون رقمًا.") from exc
        if not math.isfinite(amount) or amount < 0:
            raise ApprovalWorkflowError(f"{label} يجب أن يكون رقمًا موجبًا أو صفرًا.")
        return amount

    @staticmethod
    def _overlaps(min_a, max_a, min_b, max_b):
        return (max_a is None or min_b < max_a) and (max_b is None or min_a < max_b)

    def save_workflow(
        self, company_id: int, actor_id: int, name: str, min_amount, max_amount,
        role_ids, is_active: bool, workflow_id: int | None = None,
    ) -> int:
        self._require_manage(actor_id, company_id)
        name = str(name or "").strip()
        if not name or len(name) > 80:
            raise ApprovalWorkflowError("اسم تدفق الاعتماد مطلوب وبحد أقصى 80 حرفًا.")
        lower = self._amount(min_amount, "الحد الأدنى")
        if lower is None:
            raise ApprovalWorkflowError("الحد الأدنى مطلوب.")
        upper = self._amount(max_amount, "الحد الأعلى", allow_empty=True)
        if upper is not None and upper <= lower:
            raise ApprovalWorkflowError("الحد الأعلى يجب أن يكون أكبر من الحد الأدنى.")
        if not isinstance(role_ids, (list, tuple)) or not 1 <= len(role_ids) <= 10:
            raise ApprovalWorkflowError("يجب إعداد خطوة اعتماد واحدة على الأقل وبحد أقصى 10 خطوات.")
        normalized_roles = [int(role_id) for role_id in role_ids]
        if len(set(normalized_roles)) != len(normalized_roles):
            raise ApprovalWorkflowError("يجب أن يكون لكل خطوة اعتماد دور مختلف.")
        conn = Database.connect()
        allowed = {
            int(row["id"]) for row in conn.execute(
                """SELECT id FROM roles
                   WHERE is_active=1 AND (company_id IS NULL OR company_id=?)
                     AND EXISTS (
                         SELECT 1 FROM role_permissions rp
                         JOIN permissions p ON p.id=rp.permission_id
                         WHERE rp.role_id=roles.id AND p.permission_key='purchases.approve'
                     )""",
                (int(company_id),),
            ).fetchall()
        }
        if not set(normalized_roles).issubset(allowed):
            raise ApprovalWorkflowError("أحد أدوار الاعتماد غير نشط أو لا ينتمي إلى الشركة.")
        try:
            with transaction():
                existing = conn.execute(
                    """SELECT id,min_amount,max_amount FROM approval_workflows
                       WHERE company_id=? AND is_active=1 AND entity_type='purchase_order'
                         AND id<>?""",
                    (int(company_id), int(workflow_id or 0)),
                ).fetchall() if is_active else []
                for item in existing:
                    if self._overlaps(
                        lower, upper, float(item["min_amount"]),
                        float(item["max_amount"]) if item["max_amount"] is not None else None,
                    ):
                        raise ApprovalWorkflowError(
                            "نطاق المبالغ يتداخل مع تدفق اعتماد نشط آخر."
                        )
                if workflow_id is None:
                    cursor = conn.execute(
                        """INSERT INTO approval_workflows
                           (company_id,name,min_amount,max_amount,is_active,created_by)
                           VALUES(?,?,?,?,?,?)""",
                        (int(company_id), name, lower, upper, int(bool(is_active)), int(actor_id)),
                    )
                    if cursor.lastrowid is None:
                        raise ApprovalWorkflowError("تعذر إنشاء تدفق الاعتماد.")
                    saved_id = int(cursor.lastrowid)
                else:
                    existing = conn.execute(
                        "SELECT id FROM approval_workflows WHERE id=? AND company_id=?",
                        (int(workflow_id), int(company_id)),
                    ).fetchone()
                    if existing is None:
                        raise ApprovalWorkflowError("تدفق الاعتماد غير موجود داخل الشركة.")
                    saved_id = int(workflow_id)
                    conn.execute(
                        """UPDATE approval_workflows
                           SET name=?,min_amount=?,max_amount=?,is_active=?,updated_at=CURRENT_TIMESTAMP
                           WHERE id=? AND company_id=?""",
                        (name, lower, upper, int(bool(is_active)), saved_id, int(company_id)),
                    )
                    conn.execute(
                        "DELETE FROM approval_workflow_steps WHERE workflow_id=?", (saved_id,)
                    )
                conn.executemany(
                    """INSERT INTO approval_workflow_steps(workflow_id,step_order,role_id)
                       VALUES(?,?,?)""",
                    [(saved_id, index, role_id)
                     for index, role_id in enumerate(normalized_roles, start=1)],
                )
                AuditService.record(
                    user_id=int(actor_id), company_id=int(company_id), module="purchases",
                    action="approval_workflow_saved", entity_type="approval_workflow",
                    record_id=saved_id,
                    after={"name": name, "min_amount": lower, "max_amount": upper,
                           "is_active": int(bool(is_active)), "role_ids": normalized_roles},
                    connection=conn,
                )
                return saved_id
        except ApprovalWorkflowError:
            raise
        except TransactionError as exc:
            if isinstance(exc.__cause__, ApprovalWorkflowError):
                raise exc.__cause__ from exc
            if isinstance(exc.__cause__, sqlite3.IntegrityError):
                raise ApprovalWorkflowError(
                    "تعذر حفظ التدفق؛ تحقق من عدم تكرار اسمه داخل الشركة."
                ) from exc
            raise

    def snapshot_for_order(self, conn, company_id: int, order_id: int, amount: float) -> bool:
        workflows = conn.execute(
            """SELECT id FROM approval_workflows
               WHERE company_id=? AND entity_type='purchase_order' AND is_active=1
                 AND min_amount<=? AND (max_amount IS NULL OR max_amount>?)
               ORDER BY min_amount DESC""",
            (int(company_id), float(amount), float(amount)),
        ).fetchall()
        if not workflows:
            return False
        if len(workflows) != 1:
            raise ApprovalWorkflowError("يوجد أكثر من تدفق اعتماد نشط مطابق لقيمة الأمر.")
        workflow_id = int(workflows[0]["id"])
        steps = conn.execute(
            """SELECT step_order,role_id FROM approval_workflow_steps
               WHERE workflow_id=? ORDER BY step_order""",
            (workflow_id,),
        ).fetchall()
        if not steps:
            raise ApprovalWorkflowError("تدفق الاعتماد المطابق لا يحتوي على خطوات.")
        conn.executemany(
            """INSERT INTO purchase_order_approval_steps(order_id,workflow_id,step_order,role_id)
               VALUES(?,?,?,?)""",
            [(int(order_id), workflow_id, int(step["step_order"]), int(step["role_id"]))
             for step in steps],
        )
        return True

    @staticmethod
    def current_step(conn, order_id: int):
        return conn.execute(
            """SELECT * FROM purchase_order_approval_steps
               WHERE order_id=? AND approval_status='PENDING'
               ORDER BY step_order LIMIT 1""",
            (int(order_id),),
        ).fetchone()

    @staticmethod
    def require_current_approver(conn, step, user_id: int, company_id: int) -> None:
        user = conn.execute(
            """SELECT u.role_id FROM users u
               JOIN roles r ON r.id=u.role_id AND r.is_active=1
                 AND (r.company_id IS NULL OR r.company_id=u.company_id)
               WHERE u.id=? AND u.company_id=? AND u.is_active=1""",
            (int(user_id), int(company_id)),
        ).fetchone()
        if user is None or int(user["role_id"]) != int(step["role_id"]):
            raise ApprovalWorkflowError("الدور الحالي للمستخدم غير مخول لهذه الخطوة.")
