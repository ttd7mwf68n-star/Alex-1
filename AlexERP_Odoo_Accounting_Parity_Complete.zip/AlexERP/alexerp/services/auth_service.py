"""
AlexERP — Business Management System
Authentication Service
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from alexerp.database.auth import PasswordManager
from alexerp.repositories.user_repository import UserRepository
from alexerp.services.session_service import SessionService
from alexerp.services.permission_service import PermissionService


class AuthenticationError(Exception):
    """Authentication failed."""
    pass


class AuthService:

    MAX_FAILED_ATTEMPTS = 5
    LOCKOUT_MINUTES = 15

    def __init__(self):

        self.users = UserRepository()

    # =====================================================
    # Login
    # =====================================================

    def login(
        self,
        username: str,
        password: str,
    ):

        user = self.users.find_by_username(username)

        if user is None:
            raise AuthenticationError("Invalid username or password.")

        if not user["is_active"]:
            raise AuthenticationError("User is inactive.")

        locked_until = user["locked_until"]
        if locked_until:
            try:
                lock_time = datetime.fromisoformat(str(locked_until))
            except ValueError:
                raise AuthenticationError("User account is locked.")
            if lock_time.tzinfo is not None:
                lock_time = lock_time.astimezone(timezone.utc).replace(tzinfo=None)
            now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
            if lock_time > now_utc:
                raise AuthenticationError("User account is locked.")
            self.users.lock_user(user["id"], None)

        if not PasswordManager.verify_password(
            password,
            user["password_hash"],
        ):

            self.users.increase_failed_login(user["id"])
            refreshed_user = self.users.find_by_username(username)
            if int(refreshed_user["failed_login_attempts"] or 0) >= self.MAX_FAILED_ATTEMPTS:
                lock_time = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(
                    minutes=self.LOCKOUT_MINUTES
                )
                self.users.lock_user(user["id"], lock_time.isoformat(timespec="seconds"))
            self.users.commit()

            raise AuthenticationError("Invalid username or password.")

        # Upgrade old 120k-round hashes after a successful login, without
        # forcing a password reset or changing the user's credential.
        if PasswordManager.needs_rehash(user["password_hash"]):
            self.users.update_password(user["id"], PasswordManager.hash_password(password))
        self.users.update_last_login(user["id"])
        self.users.commit()

        return {
            key: user[key]
            for key in (
                "id", "username", "full_name", "role_id", "company_id",
                "branch_id", "email", "phone", "is_active",
            )
        }

    # =====================================================
    # Change Password
    # =====================================================

    def change_password(
        self,
        user_id: int,
        new_password: str,
        *,
        actor_id: int,
    ):
        target = self.users.find_by_id(user_id)
        if target is None:
            raise AuthenticationError("User not found.")
        if int(actor_id) != int(user_id):
            PermissionService().require_for_company(
                actor_id, int(target["company_id"]), "security.users.manage"
            )

        PasswordManager.validate_password(new_password)
        password_hash = PasswordManager.hash_password(new_password)

        self.users.update_password(
            user_id,
            password_hash,
        )

        self.users.commit()
        SessionService().revoke_user_sessions(user_id, reason="password_changed")

    # =====================================================
    # Create User
    # =====================================================

    def create_user(
        self,
        username: str,
        password: str,
        full_name: str,
        role_id: int,
        company_id: int,
        branch_id: int,
        *,
        actor_id: int,
    ) -> int:
        PermissionService().require_for_company(actor_id, company_id, "security.users.manage")

        PasswordManager.validate_password(password)
        password_hash = PasswordManager.hash_password(password)

        user_id = self.users.add(
            username=username,
            password_hash=password_hash,
            full_name=full_name,
            role_id=role_id,
            company_id=company_id,
            branch_id=branch_id,
        )

        self.users.commit()

        return user_id

    # =====================================================
    # Activate User
    # =====================================================

    def activate_user(
        self,
        user_id: int,
        *,
        actor_id: int,
    ):
        target = self.users.find_by_id(user_id)
        if target is None:
            raise AuthenticationError("User not found.")
        PermissionService().require_for_company(
            actor_id, int(target["company_id"]), "security.users.manage"
        )

        self.users.set_active(user_id, True)
        self.users.commit()

    # =====================================================
    # Deactivate User
    # =====================================================

    def deactivate_user(
        self,
        user_id: int,
        *,
        actor_id: int,
    ):
        target = self.users.find_by_id(user_id)
        if target is None:
            raise AuthenticationError("User not found.")
        PermissionService().require_for_company(
            actor_id, int(target["company_id"]), "security.users.manage"
        )

        self.users.set_active(user_id, False)
        self.users.commit()
        SessionService().revoke_user_sessions(user_id, reason="user_deactivated")
