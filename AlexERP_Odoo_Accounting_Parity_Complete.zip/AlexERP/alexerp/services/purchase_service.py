"""Purchase invoice posting with atomic receipt, stock and accounting."""
from __future__ import annotations
import math
from datetime import date, timedelta
from alexerp.database.transaction import transaction
from alexerp.core.constants import StockTransactionType, ReferenceType, InvoiceStatus
from alexerp.repositories.purchase_repository import PurchaseRepository
from alexerp.services.inventory_service import InventoryService
from alexerp.accounting import AccountingService
from alexerp.services.party_balance_service import PartyBalanceService
from alexerp.core import tenancy
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService, PermissionDenied

class PurchaseError(Exception): pass

class PurchaseService:
    def __init__(self):
        self.purchase = PurchaseRepository()
        self.inventory = InventoryService()
        self.accounting = AccountingService()
        self.balances = PartyBalanceService()

    def create_invoice(self, company_id: int, branch_id: int, supplier_id: int,
        invoice_number: str, supplier_invoice_number: str, invoice_date: str,
        items: list, subtotal: float, discount: float, tax: float, total: float,
        paid_amount: float, remaining_amount: float, notes: str, created_by: int,
        supplier_account: int, inventory_account: int, tax_account: int | None = None,
        cash_account: int | None = None, payment_terms_days: int | None = None,
        due_date: str | None = None) -> int:
        if not items: raise PurchaseError("Invoice contains no items.")
        vals = [float(subtotal), float(discount), float(tax), float(total),
                float(paid_amount), float(remaining_amount)]
        if any(not math.isfinite(x) or x < 0 for x in vals):
            raise PurchaseError("Invoice amounts must be finite and non-negative.")
        if round(vals[0]-vals[1]+vals[2], 2) != round(vals[3], 2):
            raise PurchaseError("Invoice total must equal subtotal minus discount plus tax.")
        if round(vals[4]+vals[5], 2) != round(vals[3], 2):
            raise PurchaseError("Paid amount plus remaining amount must equal invoice total.")
        if vals[4] > 0 and not cash_account:
            raise PurchaseError("Cash/bank account is required when any amount is paid at invoice time.")
        if round(sum(float(item["total"]) for item in items), 2) != round(vals[3], 2):
            raise PurchaseError("Invoice total does not equal the sum of its item totals.")
        tenancy.require_branch(company_id, branch_id)
        tenancy.require_supplier(company_id, supplier_id)
        terms_row = self.purchase.execute(
            "SELECT payment_terms_days FROM suppliers WHERE id=? AND company_id=?",
            (supplier_id, company_id),
        ).fetchone()
        terms_days = int(payment_terms_days if payment_terms_days is not None else (terms_row[0] if terms_row else 0))
        if terms_days < 0 or terms_days > 3650:
            raise PurchaseError("Payment terms must be between 0 and 3650 days.")
        try:
            parsed_invoice_date = date.fromisoformat(str(invoice_date))
            resolved_due_date = date.fromisoformat(str(due_date)).isoformat() if due_date else (parsed_invoice_date + timedelta(days=terms_days)).isoformat()
        except ValueError as exc:
            raise PurchaseError("Invalid invoice or due date.") from exc
        if resolved_due_date < parsed_invoice_date.isoformat():
            raise PurchaseError("Due date cannot be earlier than invoice date.")
        tenancy.require_accounts(company_id, supplier_account=supplier_account,
            inventory_account=inventory_account, tax_account=tax_account, cash_account=cash_account)
        for item in items:
            tenancy.require_item_scope(company_id, branch_id, item["product_id"], item["warehouse_id"])
        try:
            PermissionService().require_for_company(created_by, company_id, "purchases.create")
        except PermissionDenied as exc:
            raise PurchaseError("User is not authorized to create purchase invoices.") from exc
        with transaction():
            invoice_id = self.purchase.create_invoice(company_id, branch_id, supplier_id,
                invoice_number, supplier_invoice_number, invoice_date, subtotal, discount,
                tax, total, paid_amount, remaining_amount, notes, created_by,
                terms_days, resolved_due_date)
            inventory_total = 0.0
            for item in items:
                qty, cost = float(item["quantity"]), float(item["unit_cost"])
                if not math.isfinite(qty) or qty <= 0 or not math.isfinite(cost) or cost < 0:
                    raise PurchaseError("Invalid item quantity or cost.")
                self.purchase.add_item(invoice_id, item["product_id"], item["warehouse_id"],
                    qty, cost, item.get("discount", 0), item.get("tax", 0), item["total"])
                inventory_total += qty * cost
                self.inventory.increase_stock(item["product_id"], qty, item["warehouse_id"],
                    company_id, branch_id, cost)
                self.inventory.add_stock_movement(
                    company_id=company_id, branch_id=branch_id,
                    warehouse_id=item["warehouse_id"], product_id=item["product_id"],
                    transaction_type=StockTransactionType.PURCHASE,
                    reference_type=ReferenceType.PURCHASE, reference_id=invoice_id,
                    quantity_in=qty, unit_cost=cost,
                    balance_after=self.inventory.get_quantity(item["product_id"], item["warehouse_id"]),
                    notes=f"Purchase Invoice {invoice_number}", created_by=created_by)
            # Cost line total must agree with the net inventory value posted to the ledger.
            if round(inventory_total, 2) != round(subtotal-discount, 2):
                raise PurchaseError("Purchase item costs do not equal subtotal minus discount; correct item values before posting.")
            journal = [
                {"account_id": inventory_account, "debit": subtotal-discount, "credit": 0, "description": f"Inventory received {invoice_number}"},
                {"account_id": supplier_account, "debit": 0, "credit": remaining_amount, "description": f"Supplier payable {invoice_number}"},
            ]
            if paid_amount:
                journal.append({"account_id": cash_account, "debit": 0, "credit": paid_amount,
                                "description": f"Cash paid on {invoice_number}"})
            if tax:
                if not tax_account: raise PurchaseError("Input tax account is required when invoice tax is non-zero.")
                journal.append({"account_id": tax_account, "debit": tax, "credit": 0, "description": "Input tax"})
            self.accounting.create_entry(company_id, branch_id, invoice_date,
                f"Purchase Invoice {invoice_number}", ReferenceType.PURCHASE,
                invoice_id, created_by, journal, entry_number=f"JV-P-{company_id}-{invoice_number}")
            self.purchase.execute("UPDATE purchase_invoices SET status=? WHERE id=?",
                                  (InvoiceStatus.POSTED, invoice_id))
            self.balances.refresh_supplier(supplier_id)
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="purchases", action="invoice_posted", entity_type="purchase_invoice",
                record_id=invoice_id, description=f"Purchase invoice {invoice_number} posted",
                after={"invoice_number": invoice_number, "supplier_id": supplier_id,
                       "total": total, "paid_amount": paid_amount,
                       "remaining_amount": remaining_amount, "status": str(InvoiceStatus.POSTED)})
            return invoice_id

    def cancel_invoice(self, invoice_id: int, created_by: int, cancel_date: str | None = None):
        from datetime import date
        with transaction():
            invoice = self.purchase.get_invoice(invoice_id)
            if invoice is None:
                raise PurchaseError("Purchase invoice not found.")
            if str(invoice["status"]).upper() == "CANCELLED":
                raise PurchaseError("Purchase invoice is already cancelled.")
            if str(invoice["status"]).upper() != "POSTED":
                raise PurchaseError("Only posted purchase invoices can be cancelled.")
            try:
                PermissionService().require_for_company(
                    created_by, int(invoice["company_id"]), "purchases.cancel"
                )
            except PermissionDenied as exc:
                raise PurchaseError("User is not authorized to cancel purchase invoices.") from exc
            allocations = self.purchase.connection.execute(
                "SELECT COUNT(*) FROM payment_allocations WHERE purchase_invoice_id=? AND status='ACTIVE'",
                (invoice_id,),
            ).fetchone()[0]
            if allocations:
                raise PurchaseError("Cannot cancel an invoice with active payment allocations. Reverse/cancel the payments first.")
            for item in self.purchase.get_items(invoice_id):
                qty = float(item["quantity"])
                cost = float(item["unit_cost"] or 0)
                if not self.inventory.check_stock(item["product_id"], qty, item["warehouse_id"]):
                    raise PurchaseError(f"Cannot cancel: insufficient remaining stock for product {item['product_id']}.")
                self.inventory.decrease_stock(item["product_id"], qty, item["warehouse_id"],
                    invoice["company_id"], invoice["branch_id"], cost)
                self.inventory.add_stock_movement(
                    company_id=invoice["company_id"], branch_id=invoice["branch_id"],
                    warehouse_id=item["warehouse_id"], product_id=item["product_id"],
                    transaction_type=StockTransactionType.PURCHASE_RETURN,
                    reference_type="PURCHASE_CANCEL", reference_id=invoice_id,
                    quantity_out=qty, unit_cost=cost,
                    balance_after=self.inventory.get_quantity(item["product_id"], item["warehouse_id"]),
                    notes=f"Cancel Purchase Invoice {invoice['invoice_number']}", created_by=created_by)
            self.accounting.reverse_entry(ReferenceType.PURCHASE, invoice_id, created_by,
                reversal_date=cancel_date or date.today().isoformat())
            self.purchase.execute("UPDATE purchase_invoices SET status=? WHERE id=?",
                                  (InvoiceStatus.CANCELLED, invoice_id))
            self.balances.refresh_supplier(invoice["supplier_id"])
            before = {"invoice_number": invoice["invoice_number"], "status": str(invoice["status"]),
                      "total": float(invoice["total"] or 0), "supplier_id": int(invoice["supplier_id"])}
            AuditService.record(user_id=created_by, company_id=int(invoice["company_id"]),
                branch_id=int(invoice["branch_id"]), module="purchases", action="invoice_cancelled",
                entity_type="purchase_invoice", record_id=invoice_id,
                description=f"Purchase invoice {invoice['invoice_number']} cancelled",
                before=before, after={**before, "status": str(InvoiceStatus.CANCELLED)})
            return True

    def delete_invoice(self, invoice_id: int, created_by: int):
        raise PurchaseError("Invoices are audit records and cannot be deleted. Use cancel_invoice() or a purchase return.")
    def get_invoice(self, invoice_id: int): return self.purchase.get_invoice(invoice_id)
    def get_items(self, invoice_id: int): return self.purchase.get_items(invoice_id)
    def list(self): return self.purchase.get_all()
    def search(self, keyword: str): return self.purchase.search(keyword)
    def exists(self, invoice_id: int) -> bool: return self.purchase.get_invoice(invoice_id) is not None
