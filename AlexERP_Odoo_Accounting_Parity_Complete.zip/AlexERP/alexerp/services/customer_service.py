"""
AlexERP — Business Management System
Customer Service
"""

from __future__ import annotations

import math

from alexerp.database.transaction import transaction
from alexerp.repositories.customer_repository import CustomerRepository
from alexerp.services.permission_service import PermissionService


class CustomerService:

    def __init__(self):

        self.repo = CustomerRepository()

    # =====================================================
    # Create Customer
    # =====================================================

    def create_customer(
        self,
        company_id: int,
        code: str,
        name: str,
        tax_number: str = "",
        phone: str = "",
        mobile: str = "",
        email: str = "",
        address: str = "",
        city: str = "",
        credit_limit: float = 0,
        account_id: int | None = None,
        *,
        actor_id: int,
    ) -> int:
        PermissionService().require_for_company(actor_id, company_id, "customers.create")
        credit_limit = self._validated_credit_limit(credit_limit)
        with transaction() as conn:
            if self.repo.find_by_code(company_id, code):
                raise ValueError("Customer code already exists.")
            customer_id = self.repo.add(
                company_id=company_id,
                code=code,
                name=name,
                tax_number=tax_number,
                phone=phone,
                mobile=mobile,
                email=email,
                address=address,
                city=city,
                credit_limit=credit_limit,
                account_id=None,
            )
            account_id = self._ensure_receivable_account(
                conn, company_id, customer_id, code, name, account_id
            )
            conn.execute(
                "UPDATE customers SET account_id=? WHERE id=? AND company_id=?",
                (account_id, customer_id, company_id),
            )
            return customer_id

    # =====================================================
    # Update Customer
    # =====================================================

    def update_customer(
        self,
        customer_id: int,
        code: str,
        name: str,
        tax_number: str,
        phone: str,
        mobile: str,
        email: str,
        address: str,
        city: str,
        credit_limit: float,
        account_id: int | None,
        *,
        actor_id: int,
    ):
        customer = self.repo.find_by_id(customer_id)
        if customer is None:
            raise ValueError("Customer not found.")
        PermissionService().require_for_company(
            actor_id, int(customer["company_id"]), "customers.update"
        )
        credit_limit = self._validated_credit_limit(credit_limit)
        company_id = int(customer["company_id"])
        with transaction() as conn:
            duplicate = self.repo.find_by_code(company_id, code)
            if duplicate is not None and int(duplicate["id"]) != int(customer_id):
                raise ValueError("Customer code already exists.")
            resolved_account_id = self._ensure_receivable_account(
                conn, company_id, customer_id, code, name,
                account_id if account_id is not None else customer["account_id"],
            )
            self.repo.update(
                customer_id,
                code,
                name,
                tax_number,
                phone,
                mobile,
                email,
                address,
                city,
                credit_limit,
                resolved_account_id,
            )

    # =====================================================
    # Get Customer
    # =====================================================

    def get_customer(self, customer_id: int):

        return self.repo.find_by_id(customer_id)

    # =====================================================
    # Get All Customers
    # =====================================================

    def get_all(self, company_id: int | None = None):
        if company_id is None:
            return self.repo.find_all()
        return self.repo.find_all_by_company(company_id)

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        return self.repo.search(keyword)

    # =====================================================
    # Update Balance
    # =====================================================

    def update_balance(self, customer_id: int, balance: float):
        raise ValueError(
            "Customer balances are derived from posted documents; "
            "manual balance updates are disabled."
        )

    # =====================================================
    # Delete Customer
    # =====================================================

    def delete(self, customer_id: int, *, actor_id: int):
        customer = self.repo.find_by_id(customer_id)
        if customer is None:
            raise ValueError("Customer not found.")
        PermissionService().require_for_company(
            actor_id, int(customer["company_id"]), "customers.delete"
        )

        self.repo.delete(customer_id)

        self.repo.commit()

    def ensure_customer_accounts(self) -> None:
        """Backfill dedicated receivable subaccounts for existing customers."""
        with transaction() as conn:
            rows = conn.execute(
                """SELECT id,company_id,code,name,account_id
                   FROM customers ORDER BY company_id,id"""
            ).fetchall()
            for row in rows:
                account_id = self._ensure_receivable_account(
                    conn, int(row["company_id"]), int(row["id"]),
                    str(row["code"]), str(row["name"]), row["account_id"],
                )
                if row["account_id"] is None or int(row["account_id"]) != account_id:
                    conn.execute(
                        "UPDATE customers SET account_id=? WHERE id=?",
                        (account_id, row["id"]),
                    )

    def ensure_customer_account(self, company_id: int, customer_id: int) -> int:
        with transaction() as conn:
            row = conn.execute(
                """SELECT code,name,account_id FROM customers
                   WHERE id=? AND company_id=?""",
                (customer_id, company_id),
            ).fetchone()
            if row is None:
                raise ValueError("Customer not found in the selected company.")
            account_id = self._ensure_receivable_account(
                conn, company_id, customer_id, str(row["code"]),
                str(row["name"]), row["account_id"],
            )
            if row["account_id"] is None or int(row["account_id"]) != account_id:
                conn.execute(
                    "UPDATE customers SET account_id=? WHERE id=? AND company_id=?",
                    (account_id, customer_id, company_id),
                )
            return account_id

    @staticmethod
    def _validated_credit_limit(value: float) -> float:
        try:
            limit = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError("Credit limit must be a valid non-negative amount.") from exc
        if not math.isfinite(limit) or limit < 0:
            raise ValueError("Credit limit must be a valid non-negative amount.")
        return round(limit, 2)

    @staticmethod
    def _ensure_receivable_account(conn, company_id: int, customer_id: int,
                                   customer_code: str, customer_name: str,
                                   current_account_id: int | None) -> int:
        parent = conn.execute(
            """SELECT coa.id,coa.account_code,coa.account_type_id
               FROM company_sales_settings s
               JOIN chart_of_accounts coa ON coa.id=s.receivable_account_id
               JOIN account_types at ON at.id=coa.account_type_id
               WHERE s.company_id=? AND coa.company_id=? AND at.code='ASSET'
                 AND COALESCE(coa.is_active,1)=1
                 AND COALESCE(coa.allow_posting,1)=1 AND COALESCE(coa.is_header,0)=0""",
            (company_id, company_id),
        ).fetchone()
        if parent is None:
            parent = conn.execute(
                """SELECT coa.id,coa.account_code,coa.account_type_id
                   FROM chart_of_accounts coa
                   JOIN account_types at ON at.id=coa.account_type_id
                   WHERE coa.company_id=? AND coa.account_code='1201'
                     AND at.code='ASSET' AND COALESCE(coa.is_active,1)=1
                     AND COALESCE(coa.allow_posting,1)=1 AND COALESCE(coa.is_header,0)=0
                   LIMIT 1""",
                (company_id,),
            ).fetchone()
        if parent is None:
            raise ValueError(
                "Configure an active Accounts Receivable asset account before creating customer accounts."
            )

        if current_account_id is not None:
            account = conn.execute(
                """SELECT coa.id,coa.account_code,at.code AS type_code,
                          coa.is_active,coa.allow_posting,coa.is_header
                   FROM chart_of_accounts coa
                   JOIN account_types at ON at.id=coa.account_type_id
                   WHERE coa.id=? AND coa.company_id=?""",
                (current_account_id, company_id),
            ).fetchone()
            linked_count = conn.execute(
                "SELECT COUNT(*) FROM customers WHERE company_id=? AND account_id=? AND id<>?",
                (company_id, current_account_id, customer_id),
            ).fetchone()[0]
            if (account is not None and account["type_code"] == "ASSET"
                    and int(account["is_active"] or 0)
                    and int(account["allow_posting"] if account["allow_posting"] is not None else 1)
                    and not int(account["is_header"] or 0)
                    and int(account["id"]) != int(parent["id"])
                    and int(linked_count) == 0):
                return int(account["id"])

        account_code = f"{parent['account_code']}-{customer_id:06d}"
        collision = conn.execute(
            "SELECT id FROM chart_of_accounts WHERE company_id=? AND account_code=?",
            (company_id, account_code),
        ).fetchone()
        suffix = 1
        base_code = account_code
        while collision is not None:
            account_code = f"{base_code}-{suffix:02d}"
            collision = conn.execute(
                "SELECT id FROM chart_of_accounts WHERE company_id=? AND account_code=?",
                (company_id, account_code),
            ).fetchone()
            suffix += 1
        cursor = conn.execute(
            """INSERT INTO chart_of_accounts(
                   company_id,parent_id,account_type_id,account_code,account_name,
                   account_level,is_header,allow_posting,is_active)
               VALUES(?,?,?,?,?,?,0,1,1)""",
            (company_id, parent["id"], parent["account_type_id"], account_code,
             f"ذمم العميل {customer_code} - {customer_name}",
             int(conn.execute(
                 "SELECT COALESCE(account_level,1) FROM chart_of_accounts WHERE id=?",
                 (parent["id"],),
             ).fetchone()[0]) + 1),
        )
        if cursor.lastrowid is None:
            raise ValueError("Failed to create a dedicated customer receivable account.")
        return int(cursor.lastrowid)
