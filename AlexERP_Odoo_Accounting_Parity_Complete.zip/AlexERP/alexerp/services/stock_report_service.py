"""
AlexERP — Business Management System
Stock Report Service
"""

from __future__ import annotations

from alexerp.repositories.stock_report_repository import StockReportRepository


class StockReportService:
    def __init__(self):
        self.repo = StockReportRepository()

    # =====================================================

    def stock_card(
        self,
        product_id,
        warehouse_id=None,
        date_from=None,
        date_to=None,
    ):
        return self.repo.stock_card(
            product_id,
            warehouse_id,
            date_from,
            date_to,
        )

    # =====================================================

    def current_stock(self, warehouse_id=None):
        return self.repo.current_stock(warehouse_id)

    # =====================================================

    def low_stock(self):
        return self.repo.low_stock()
