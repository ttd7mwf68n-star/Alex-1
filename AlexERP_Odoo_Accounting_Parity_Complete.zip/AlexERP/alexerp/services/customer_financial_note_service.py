"""Financial customer debit and credit notes linked to posted sales invoices."""
from __future__ import annotations

from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from alexerp.core import tenancy
from alexerp.core.constants import ReferenceType
from alexerp.database.db import Database
from alexerp.database.transaction import transaction
from alexerp.accounting import AccountingService
from alexerp.services.audit_service import AuditService
from alexerp.services.customer_service import CustomerService
from alexerp.services.party_balance_service import PartyBalanceService
from alexerp.services.permission_service import PermissionService
from alexerp.services.sales_service import SalesService

_CENT = Decimal("0.01")


class CustomerFinancialNoteError(ValueError):
    pass


def _amount(value) -> Decimal:
    try:
        amount = Decimal(str(value)).quantize(_CENT, rounding=ROUND_HALF_UP)
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise CustomerFinancialNoteError("قيمة الإشعار غير صالحة.") from exc
    if not amount.is_finite() or amount <= 0:
        raise CustomerFinancialNoteError("قيمة الإشعار يجب أن تكون أكبر من صفر.")
    return amount


class CustomerFinancialNoteService:
    def __init__(self):
        self.conn = Database.connect()
        self.accounting = AccountingService()
        self.balances = PartyBalanceService()

    def create_note(
        self,
        company_id: int,
        branch_id: int,
        customer_id: int,
        sales_invoice_id: int,
        note_number: str,
        note_type: str,
        note_date: str,
        amount,
        counter_account_id: int,
        description: str,
        created_by: int,
        override_credit_limit: bool = False,
    ) -> int:
        kind = str(note_type or "").upper()
        if kind not in {"DEBIT", "CREDIT"}:
            raise CustomerFinancialNoteError("نوع الإشعار غير صالح.")
        note_number = str(note_number or "").strip()
        description = str(description or "").strip()
        if not note_number or not description:
            raise CustomerFinancialNoteError("رقم الإشعار والبيان مطلوبان.")
        value = _amount(amount)
        try:
            parsed_date = date.fromisoformat(str(note_date))
        except (TypeError, ValueError) as exc:
            raise CustomerFinancialNoteError("تاريخ الإشعار غير صالح.") from exc

        tenancy.require_branch(company_id, branch_id)
        tenancy.require_customer(company_id, customer_id)
        tenancy.require_accounts(company_id, counter_account=counter_account_id)
        PermissionService().require_for_company(
            created_by, company_id, "customers.notes.create"
        )
        customer_account_id = CustomerService().ensure_customer_account(
            company_id, customer_id
        )
        control_account = self.conn.execute(
            """SELECT receivable_account_id FROM company_sales_settings
               WHERE company_id=?""",
            (company_id,),
        ).fetchone()
        customer_link = self.conn.execute(
            """SELECT 1 FROM customers WHERE company_id=? AND account_id=? LIMIT 1""",
            (company_id, counter_account_id),
        ).fetchone()
        counter_account = self.conn.execute(
            """SELECT account_code FROM chart_of_accounts
               WHERE id=? AND company_id=?""",
            (counter_account_id, company_id),
        ).fetchone()
        if (int(counter_account_id) == customer_account_id or customer_link is not None
                or (counter_account is not None and counter_account["account_code"] == "1201")
                or (control_account is not None
                    and int(control_account["receivable_account_id"] or 0) == int(counter_account_id))):
            raise CustomerFinancialNoteError(
                "اختر حساب دخل أو مصروف، وليس حساب ذمم عميل."
            )

        with transaction() as conn:
            invoice = conn.execute(
                """SELECT id,invoice_number,invoice_date,due_date,remaining_amount,status
                   FROM sales_invoices
                   WHERE id=? AND company_id=? AND branch_id=? AND customer_id=?""",
                (sales_invoice_id, company_id, branch_id, customer_id),
            ).fetchone()
            if invoice is None or str(invoice["status"]).upper() != "POSTED":
                raise CustomerFinancialNoteError(
                    "اختر فاتورة مبيعات مرحلة تخص العميل والفرع المحددين."
                )
            if parsed_date < date.fromisoformat(str(invoice["invoice_date"])):
                raise CustomerFinancialNoteError(
                    "لا يمكن أن يسبق تاريخ الإشعار تاريخ الفاتورة."
                )
            if kind == "CREDIT":
                returned = Decimal(str(conn.execute(
                    """SELECT COALESCE(SUM(total),0) FROM sales_returns
                       WHERE sales_invoice_id=? AND UPPER(COALESCE(status,'POSTED'))='POSTED'""",
                    (sales_invoice_id,),
                ).fetchone()[0] or 0)).quantize(_CENT)
                available = max(
                    Decimal(str(invoice["remaining_amount"] or 0)).quantize(_CENT) - returned,
                    Decimal("0.00"),
                )
                if value > available:
                    raise CustomerFinancialNoteError(
                        f"قيمة الإشعار الدائن تتجاوز المديونية المتاحة على الفاتورة "
                        f"({available:.2f})."
                    )
            else:
                status = SalesService().credit_limit_status(
                    company_id, customer_id, float(value), created_by
                )
                if status["exceeded"] and not status["can_override"]:
                    raise CustomerFinancialNoteError(
                        f"سيؤدي الإشعار إلى تجاوز حد الائتمان "
                        f"({status['projected_balance']:.2f} من {status['limit']:.2f})."
                    )
                if status["exceeded"] and override_credit_limit is not True:
                    raise CustomerFinancialNoteError(
                        "يلزم تأكيد تجاوز حد الائتمان قبل ترحيل الإشعار."
                    )
                if status["exceeded"]:
                    AuditService.record(
                        user_id=created_by, company_id=company_id, branch_id=branch_id,
                        module="sales", action="customer_credit_limit_overridden",
                        entity_type="customer", record_id=customer_id,
                        description=f"Credit limit override for debit note {note_number}",
                        after={
                            "note_number": note_number,
                            "credit_limit": status["limit"],
                            "balance_before": status["balance"],
                            "debit_note_amount": float(value),
                            "projected_balance": status["projected_balance"],
                        },
                    )

            existing = conn.execute(
                """SELECT 1 FROM customer_financial_notes
                   WHERE company_id=? AND note_number=?""",
                (company_id, note_number),
            ).fetchone()
            if existing is not None:
                raise CustomerFinancialNoteError("رقم الإشعار مستخدم بالفعل.")
            cursor = conn.execute(
                """INSERT INTO customer_financial_notes(
                       company_id,branch_id,customer_id,sales_invoice_id,note_number,
                       note_type,note_date,amount,counter_account_id,description,created_by)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (company_id, branch_id, customer_id, sales_invoice_id, note_number,
                 kind, parsed_date.isoformat(), str(value), counter_account_id,
                 description, created_by),
            )
            if cursor.lastrowid is None:
                raise CustomerFinancialNoteError("تعذر حفظ الإشعار المالي.")
            note_id = int(cursor.lastrowid)
            delta = value if kind == "DEBIT" else -value
            conn.execute(
                """UPDATE sales_invoices
                   SET remaining_amount=CAST(COALESCE(remaining_amount,0) AS REAL)+?,
                       updated_at=CURRENT_TIMESTAMP
                   WHERE id=? AND company_id=?""",
                (float(delta), sales_invoice_id, company_id),
            )
            if kind == "DEBIT":
                details = [
                    {"account_id": customer_account_id, "debit": float(value), "credit": 0,
                     "description": f"Customer debit note {note_number}"},
                    {"account_id": counter_account_id, "debit": 0, "credit": float(value),
                     "description": description},
                ]
            else:
                details = [
                    {"account_id": counter_account_id, "debit": float(value), "credit": 0,
                     "description": description},
                    {"account_id": customer_account_id, "debit": 0, "credit": float(value),
                     "description": f"Customer credit note {note_number}"},
                ]
            self.accounting.create_entry(
                company_id=company_id,
                branch_id=branch_id,
                entry_date=parsed_date.isoformat(),
                description=f"Customer {'debit' if kind == 'DEBIT' else 'credit'} note {note_number}",
                reference_type=ReferenceType.CUSTOMER_NOTE,
                reference_id=note_id,
                created_by=created_by,
                details=details,
                entry_number=f"JV-CN-{company_id}-{note_number}",
            )
            self.balances.refresh_customer(customer_id)
            AuditService.record(
                user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="sales", action=f"customer_{kind.lower()}_note_posted",
                entity_type="customer_financial_note", record_id=note_id,
                description=f"Customer {kind.lower()} note {note_number} posted",
                after={
                    "note_number": note_number, "note_type": kind,
                    "customer_id": customer_id, "sales_invoice_id": sales_invoice_id,
                    "amount": float(value), "status": "POSTED",
                },
            )
            return note_id

    def cancel_note(self, note_id: int, actor_id: int,
                    cancel_date: str | None = None) -> bool:
        cancellation_date = cancel_date or date.today().isoformat()
        try:
            date.fromisoformat(cancellation_date)
        except (TypeError, ValueError) as exc:
            raise CustomerFinancialNoteError("تاريخ إلغاء الإشعار غير صالح.") from exc
        with transaction() as conn:
            note = conn.execute(
                """SELECT * FROM customer_financial_notes
                   WHERE id=?""",
                (note_id,),
            ).fetchone()
            if note is None:
                raise CustomerFinancialNoteError("الإشعار المالي غير موجود.")
            PermissionService().require_for_company(
                actor_id, int(note["company_id"]), "customers.notes.cancel"
            )
            if str(note["status"]).upper() != "POSTED":
                raise CustomerFinancialNoteError("يمكن إلغاء الإشعارات المرحلة فقط.")
            invoice = conn.execute(
                """SELECT remaining_amount FROM sales_invoices
                   WHERE id=? AND company_id=?""",
                (note["sales_invoice_id"], note["company_id"]),
            ).fetchone()
            amount = Decimal(str(note["amount"])).quantize(_CENT)
            if str(note["note_type"]).upper() == "DEBIT":
                remaining = Decimal(str(invoice["remaining_amount"] or 0)).quantize(_CENT)
                if remaining < amount:
                    raise CustomerFinancialNoteError(
                        "لا يمكن إلغاء الإشعار بعد تخصيص التحصيل له؛ اعكس تخصيص التحصيل أولاً."
                    )
                delta = -amount
            else:
                delta = amount
            self.accounting.reverse_entry(
                ReferenceType.CUSTOMER_NOTE, note_id, actor_id,
                reversal_date=cancellation_date,
            )
            conn.execute(
                """UPDATE sales_invoices
                   SET remaining_amount=CAST(COALESCE(remaining_amount,0) AS REAL)+?,
                       updated_at=CURRENT_TIMESTAMP
                   WHERE id=? AND company_id=?""",
                (float(delta), note["sales_invoice_id"], note["company_id"]),
            )
            conn.execute(
                """UPDATE customer_financial_notes
                   SET status='CANCELLED',cancelled_at=CURRENT_TIMESTAMP
                   WHERE id=? AND company_id=?""",
                (note_id, note["company_id"]),
            )
            self.balances.refresh_customer(int(note["customer_id"]))
            AuditService.record(
                user_id=actor_id, company_id=int(note["company_id"]),
                branch_id=int(note["branch_id"]), module="sales",
                action=f"customer_{str(note['note_type']).lower()}_note_cancelled",
                entity_type="customer_financial_note", record_id=note_id,
                description=f"Customer financial note {note['note_number']} cancelled",
                before={"status": "POSTED", "amount": float(amount)},
                after={"status": "CANCELLED", "amount": float(amount)},
            )
            return True

    def list_notes(self, company_id: int, actor_id: int,
                   customer_id: int | None = None) -> list[dict]:
        PermissionService().require_for_company(
            actor_id, company_id, "customers.notes.view"
        )
        sql = """SELECT n.*,c.code AS customer_code,c.name AS customer_name,
                        i.invoice_number,i.due_date
                 FROM customer_financial_notes n
                 JOIN customers c ON c.id=n.customer_id
                 JOIN sales_invoices i ON i.id=n.sales_invoice_id
                 WHERE n.company_id=? AND c.company_id=?"""
        params: list = [company_id, company_id]
        if customer_id is not None:
            sql += " AND n.customer_id=?"
            params.append(customer_id)
        sql += " ORDER BY n.note_date DESC,n.id DESC"
        return [dict(row) for row in self.conn.execute(sql, params).fetchall()]
