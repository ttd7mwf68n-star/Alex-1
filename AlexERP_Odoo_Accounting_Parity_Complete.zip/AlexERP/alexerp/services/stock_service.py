"""
AlexERP — Business Management System
Warehouse-aware stock service.

product_stock is the operational source of truth. products.quantity remains
a compatibility aggregate for older screens and reports.
"""
from __future__ import annotations

import math

from alexerp.database.transaction import transaction
from alexerp.repositories.product_repository import ProductRepository
from alexerp.repositories.stock_movement_repository import StockMovementRepository
from alexerp.core.constants import StockTransactionType


class StockError(Exception):
    """Raised when a stock operation cannot be completed."""


class StockService:
    def __init__(self):
        self.products = ProductRepository()
        self.movements = StockMovementRepository()

    @staticmethod
    def _validate_quantity(quantity: float) -> float:
        value = float(quantity)
        if not math.isfinite(value) or value <= 0:
            raise StockError("Quantity must be a positive finite number.")
        return value

    def get_balance(self, product_id: int, warehouse_id: int | None = None) -> float:
        product = self.products.get_by_id(product_id)
        if product is None:
            raise StockError("Product not found.")
        conn = self.products.connection
        company_id = int(product["company_id"])
        if warehouse_id is None:
            row = conn.execute(
                "SELECT COALESCE(SUM(quantity), 0) AS quantity FROM product_stock "
                "WHERE product_id=? AND company_id=?",
                (product_id, company_id),
            ).fetchone()
            pending = conn.execute(
                "SELECT COALESCE(quantity, 0) AS quantity FROM legacy_stock_unallocated "
                "WHERE product_id=? AND resolved_at IS NULL", (product_id,),
            ).fetchone()
            return float(row["quantity"] or 0) + (float(pending["quantity"]) if pending else 0)
        warehouse = conn.execute(
            "SELECT company_id, branch_id, is_active FROM warehouses "
            "WHERE id=? AND company_id=? AND is_active=1",
            (warehouse_id, company_id),
        ).fetchone()
        if warehouse is None or (product["branch_id"] is not None
                and warehouse["branch_id"] is not None
                and int(product["branch_id"]) != int(warehouse["branch_id"])):
            raise StockError("Warehouse is not available in the product company/branch.")
        row = conn.execute(
            "SELECT quantity FROM product_stock "
            "WHERE product_id=? AND warehouse_id=? AND company_id=?",
            (product_id, warehouse_id, company_id),
        ).fetchone()
        return float(row["quantity"]) if row else 0.0

    def check_stock(self, product_id: int, quantity: float,
                    warehouse_id: int | None = None) -> bool:
        return self.get_balance(product_id, warehouse_id) >= self._validate_quantity(quantity)

    def _validate_warehouse(self, product, company_id: int, branch_id: int,
                            warehouse_id: int) -> None:
        row = self.products.connection.execute(
            "SELECT company_id, branch_id, is_active FROM warehouses "
            "WHERE id=? AND company_id=? AND (branch_id IS NULL OR branch_id=?)",
            (warehouse_id, company_id, branch_id),
        ).fetchone()
        if row is None or not row["is_active"]:
            raise StockError("Warehouse not found or inactive.")
        if int(row["company_id"] or 0) != int(company_id):
            raise StockError("Warehouse belongs to a different company.")
        if row["branch_id"] is not None and int(row["branch_id"]) != int(branch_id):
            raise StockError("Warehouse belongs to a different branch.")
        if int(product["company_id"]) != int(company_id):
            raise StockError("Product belongs to a different company.")
        if product["branch_id"] is not None and int(product["branch_id"]) != int(branch_id):
            raise StockError("Product belongs to a different branch.")

    def _apply(self, direction: str, company_id: int, branch_id: int,
               warehouse_id: int, product_id: int, quantity: float,
               unit_cost: float = 0,
               transaction_type: str = StockTransactionType.PURCHASE,
               reference_type: str | None = None,
               reference_id: int | None = None,
               location_id: int | None = None, notes: str = "",
               created_by: int | None = None) -> float:
        qty = self._validate_quantity(quantity)
        cost = float(unit_cost or 0)
        if not math.isfinite(cost) or cost < 0:
            raise StockError("Unit cost must be a non-negative finite number.")

        with transaction() as conn:
            product = conn.execute(
                "SELECT * FROM products WHERE id=? AND company_id=? "
                "AND (branch_id IS NULL OR branch_id=?)",
                (product_id, company_id, branch_id),
            ).fetchone()
            if product is None:
                raise StockError("Product not found.")
            self._validate_warehouse(product, company_id, branch_id, warehouse_id)

            pending = conn.execute(
                "SELECT quantity FROM legacy_stock_unallocated "
                "WHERE product_id=? AND resolved_at IS NULL", (product_id,),
            ).fetchone()
            if pending and float(pending["quantity"] or 0) != 0:
                raise StockError(
                    "Legacy stock for this product is not assigned to a warehouse. "
                    "Allocate it before posting stock movements."
                )

            row = conn.execute(
                "SELECT quantity, average_cost FROM product_stock "
                "WHERE product_id=? AND warehouse_id=? AND company_id=?",
                (product_id, warehouse_id, company_id),
            ).fetchone()
            current = float(row["quantity"]) if row else 0.0
            if direction == "OUT":
                if not bool(product["allow_negative_stock"]) and current < qty:
                    raise StockError("Insufficient stock in the selected warehouse.")
                new_balance = current - qty
                average_cost = float(row["average_cost"] or 0) if row else cost
                qty_in, qty_out = 0.0, qty
            else:
                new_balance = current + qty
                old_cost = float(row["average_cost"] or 0) if row else 0.0
                average_cost = ((current * old_cost + qty * cost) / new_balance
                                if new_balance > 0 else cost)
                qty_in, qty_out = qty, 0.0

            conn.execute("""
                INSERT INTO product_stock
                    (company_id, branch_id, warehouse_id, product_id,
                     quantity, average_cost, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(warehouse_id, product_id) DO UPDATE SET
                    quantity=excluded.quantity,
                    average_cost=excluded.average_cost,
                    updated_at=CURRENT_TIMESTAMP
            """, (company_id, branch_id, warehouse_id, product_id, new_balance, average_cost))

            assigned_total = conn.execute(
                "SELECT COALESCE(SUM(quantity),0) AS total FROM product_stock "
                "WHERE product_id=? AND company_id=?",
                (product_id, company_id),
            ).fetchone()["total"]
            pending_total = conn.execute(
                "SELECT COALESCE(SUM(quantity),0) AS total FROM legacy_stock_unallocated "
                "WHERE product_id=? AND resolved_at IS NULL", (product_id,),
            ).fetchone()["total"]
            conn.execute(
                "UPDATE products SET quantity=?, updated_at=CURRENT_TIMESTAMP "
                "WHERE id=? AND company_id=?",
                (float(assigned_total or 0) + float(pending_total or 0), product_id, company_id),
            )

            self.movements.add_movement(
                company_id=company_id, branch_id=branch_id, warehouse_id=warehouse_id,
                location_id=location_id, product_id=product_id,
                transaction_type=transaction_type,
                reference_type=reference_type or transaction_type,
                reference_id=reference_id, quantity_in=qty_in, quantity_out=qty_out,
                unit_cost=cost, balance_after=new_balance, notes=notes,
                created_by=created_by, commit=False,
            )
            return new_balance

    def increase(self, company_id: int, branch_id: int, warehouse_id: int,
                 product_id: int, quantity: float, unit_cost: float = 0,
                 transaction_type: str = StockTransactionType.PURCHASE,
                 reference_type: str | None = None, reference_id: int | None = None,
                 location_id: int | None = None, notes: str = "",
                 created_by: int | None = None) -> float:
        return self._apply("IN", company_id, branch_id, warehouse_id, product_id,
                           quantity, unit_cost, transaction_type, reference_type,
                           reference_id, location_id, notes, created_by)

    def decrease(self, company_id: int, branch_id: int, warehouse_id: int,
                 product_id: int, quantity: float, unit_cost: float = 0,
                 transaction_type: str = StockTransactionType.SALE,
                 reference_type: str | None = None, reference_id: int | None = None,
                 location_id: int | None = None, notes: str = "",
                 created_by: int | None = None) -> float:
        return self._apply("OUT", company_id, branch_id, warehouse_id, product_id,
                           quantity, unit_cost, transaction_type, reference_type,
                           reference_id, location_id, notes, created_by)

    def cardex(self, product_id: int):
        return self.movements.cardex(product_id)

    def warehouse_movements(self, warehouse_id: int):
        return self.movements.get_warehouse_movements(warehouse_id)

    def product_movements(self, product_id: int):
        return self.movements.get_product_movements(product_id)

    def delete_reference(self, reference_type: str, reference_id: int):
        return self.movements.delete_reference(reference_type, reference_id)
