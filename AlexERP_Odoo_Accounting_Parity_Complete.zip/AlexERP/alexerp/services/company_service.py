"""
AlexERP — Business Management System
Company Service
"""

from __future__ import annotations

from alexerp.repositories.company_repository import CompanyRepository
from alexerp.services.permission_service import PermissionService


class CompanyService:

    def __init__(self):

        self.repo = CompanyRepository()

    # =====================================================
    # Create Company
    # =====================================================

    def create_company(
        self,
        code: str,
        name: str,
        commercial_name: str = "",
        tax_number: str = "",
        phone: str = "",
        mobile: str = "",
        email: str = "",
        website: str = "",
        address: str = "",
        city: str = "",
        country: str = "",
        *,
        actor_id: int,
    ) -> int:
        PermissionService().require(actor_id, "companies.manage")

        if self.repo.find_by_code(code):
            raise ValueError("Company code already exists.")

        company_id = self.repo.add(
            code=code,
            name=name,
            commercial_name=commercial_name,
            tax_number=tax_number,
            phone=phone,
            mobile=mobile,
            email=email,
            website=website,
            address=address,
            city=city,
            country=country,
        )

        self.repo.commit()

        return company_id

    # =====================================================
    # Update Company
    # =====================================================

    def update_company(
        self,
        company_id: int,
        code: str,
        name: str,
        commercial_name: str,
        tax_number: str,
        phone: str,
        mobile: str,
        email: str,
        website: str,
        address: str,
        city: str,
        country: str,
        *,
        actor_id: int,
    ):
        PermissionService().require(actor_id, "companies.manage")

        self.repo.update(
            company_id,
            code,
            name,
            commercial_name,
            tax_number,
            phone,
            mobile,
            email,
            website,
            address,
            city,
            country,
        )

        self.repo.commit()

    # =====================================================
    # Get Company
    # =====================================================

    def get_company(self, company_id: int):

        return self.repo.find_by_id(company_id)

    # =====================================================
    # Get All Companies
    # =====================================================

    def get_all(self):

        return self.repo.find_all()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        return self.repo.search(keyword)

    # =====================================================
    # Delete
    # =====================================================

    def delete(self, company_id: int, *, actor_id: int):
        PermissionService().require(actor_id, "companies.manage")

        self.repo.delete(company_id)
        self.repo.commit()