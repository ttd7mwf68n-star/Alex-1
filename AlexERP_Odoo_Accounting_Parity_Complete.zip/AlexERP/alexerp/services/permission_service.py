"""Role-based permission checks shared by application entry points."""
from __future__ import annotations

from alexerp.database.db import Database


class PermissionDenied(PermissionError):
    """Raised when a user does not hold a required permission."""


class PermissionService:
    def has_permission(self, user_id: int, permission_key: str) -> bool:
        if not isinstance(user_id, int) or user_id <= 0 or not permission_key:
            return False
        row = Database.connect().execute(
            """SELECT 1
               FROM users u
               JOIN roles r ON r.id = u.role_id AND r.is_active = 1
                 AND (r.company_id IS NULL OR r.company_id = u.company_id)
               JOIN role_permissions rp ON rp.role_id = r.id
               JOIN permissions p ON p.id = rp.permission_id
               WHERE u.id = ? AND u.is_active = 1 AND p.permission_key = ?
               LIMIT 1""",
            (user_id, permission_key),
        ).fetchone()
        return row is not None

    def has_permission_for_company(self, user_id: int, company_id: int, permission_key: str) -> bool:
        if (not isinstance(user_id, int) or user_id <= 0
                or not isinstance(company_id, int) or company_id <= 0
                or not permission_key):
            return False
        row = Database.connect().execute(
            """SELECT 1
               FROM users u
               JOIN roles r ON r.id = u.role_id AND r.is_active = 1
                 AND (r.company_id IS NULL OR r.company_id = u.company_id)
               JOIN role_permissions rp ON rp.role_id = r.id
               JOIN permissions p ON p.id = rp.permission_id
               WHERE u.id = ? AND u.company_id = ? AND u.is_active = 1
                 AND p.permission_key = ?
               LIMIT 1""",
            (user_id, company_id, permission_key),
        ).fetchone()
        return row is not None

    def require(self, user_id: int, permission_key: str) -> None:
        if not self.has_permission(user_id, permission_key):
            raise PermissionDenied(f"Permission required: {permission_key}")

    def require_for_company(self, user_id: int, company_id: int, permission_key: str) -> None:
        if not self.has_permission_for_company(user_id, company_id, permission_key):
            raise PermissionDenied(f"Permission required for company: {permission_key}")
