"""Company/branch-scoped requisitions, purchase orders, receipts and supplier quotes."""
from __future__ import annotations

import math
from datetime import date

from alexerp.core import tenancy
from alexerp.database.db import Database
from alexerp.database.transaction import transaction
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService, PermissionDenied
from alexerp.services.advanced_access_service import AdvancedAccessError, AdvancedAccessService
from alexerp.services.approval_workflow_service import (
    ApprovalWorkflowError, ApprovalWorkflowService,
)


class PurchasingWorkflowError(ValueError):
    pass


class PurchasingWorkflowService:
    def __init__(self):
        self.access = AdvancedAccessService()
        self.approval_workflows = ApprovalWorkflowService()

    @staticmethod
    def _require_permission(user_id, company_id, permission_key):
        try:
            PermissionService().require_for_company(int(user_id), int(company_id), permission_key)
        except (PermissionDenied, TypeError, ValueError) as exc:
            raise PurchasingWorkflowError(
                f"User is not authorized for this purchasing action ({permission_key})."
            ) from exc

    def _date(self, value, label):
        try:
            return date.fromisoformat(str(value)).isoformat()
        except (TypeError, ValueError) as exc:
            raise PurchasingWorkflowError(f"Invalid {label}.") from exc

    def _require_field_write(self, user_id, company_id, field_key):
        try:
            self.access.require_field_write(user_id, company_id, "purchase_order", field_key)
        except AdvancedAccessError as exc:
            raise PurchasingWorkflowError(str(exc)) from exc

    def _require_order_access(self, conn, user_id, company_id, order):
        record = dict(order)
        record["amount"] = float(conn.execute(
            """SELECT COALESCE(SUM(ordered_quantity*unit_cost-discount+tax),0)
               FROM purchase_order_items WHERE order_id=?""",
            (int(order["id"]),),
        ).fetchone()[0] or 0)
        try:
            self.access.require_record_access(user_id, company_id, "purchase_order", record)
        except AdvancedAccessError as exc:
            raise PurchasingWorkflowError(str(exc)) from exc

    def _require_financial_read(self, user_id, company_id):
        hidden = self.access.hidden_fields(user_id, company_id, "purchase_order")
        restricted = hidden.intersection({"unit_cost", "discount", "tax", "amount"})
        if restricted:
            raise PurchasingWorkflowError(
                "سياسة الحقول تمنع عرض بيانات التكلفة المطلوبة لهذه العملية."
            )

    def _items(self, company_id, branch_id, items, price_required=False, user_id=None):
        if not items:
            raise PurchasingWorkflowError("At least one item is required.")
        normalized = []
        for item in items:
            product_id, warehouse_id = int(item["product_id"]), int(item["warehouse_id"])
            tenancy.require_item_scope(company_id, branch_id, product_id, warehouse_id)
            qty = float(item["quantity"])
            if not math.isfinite(qty) or qty <= 0:
                raise PurchasingWorkflowError("Item quantity must be finite and greater than zero.")
            row = {"product_id": product_id, "warehouse_id": warehouse_id, "quantity": qty,
                   "notes": str(item.get("notes") or "")}
            if price_required:
                if user_id is not None:
                    self._require_field_write(user_id, company_id, "unit_cost")
                    if "discount" in item:
                        self._require_field_write(user_id, company_id, "discount")
                    if "tax" in item:
                        self._require_field_write(user_id, company_id, "tax")
                cost = float(item["unit_cost"])
                if not math.isfinite(cost) or cost < 0:
                    raise PurchasingWorkflowError("Unit cost must be finite and non-negative.")
                row["unit_cost"] = cost
                row["discount"] = float(item.get("discount", 0) or 0)
                row["tax"] = float(item.get("tax", 0) or 0)
                if any(not math.isfinite(row[k]) or row[k] < 0 for k in ("discount", "tax")):
                    raise PurchasingWorkflowError("Discount and tax must be finite and non-negative.")
            normalized.append(row)
        return normalized

    def create_requisition(self, company_id, branch_id, requisition_number, request_date,
                           requested_by, items, notes=""):
        self._require_permission(requested_by, company_id, "purchases.create")
        tenancy.require_branch(company_id, branch_id)
        request_date = self._date(request_date, "request date")
        rows = self._items(company_id, branch_id, items)
        with transaction():
            cur = Database.connect().execute(
                "INSERT INTO purchase_requisitions(company_id,branch_id,requisition_number,request_date,requested_by,notes) VALUES(?,?,?,?,?,?)",
                (company_id, branch_id, str(requisition_number).strip(), request_date, requested_by, notes))
            rid = cur.lastrowid
            Database.connect().executemany(
                "INSERT INTO purchase_requisition_items(requisition_id,product_id,warehouse_id,quantity,notes) VALUES(?,?,?,?,?)",
                [(rid, r["product_id"], r["warehouse_id"], r["quantity"], r["notes"]) for r in rows])
            AuditService.record(user_id=requested_by, company_id=company_id, branch_id=branch_id,
                module="purchases", action="requisition_created", entity_type="purchase_requisition",
                record_id=rid, description=f"Purchase requisition {requisition_number} created")
            return rid

    def create_order(self, company_id, branch_id, supplier_id, order_number, order_date,
                     expected_date, created_by, items, requisition_id=None, notes="", require_approval=False):
        self._require_permission(created_by, company_id, "purchases.create")
        tenancy.require_branch(company_id, branch_id)
        tenancy.require_supplier(company_id, supplier_id)
        order_date = self._date(order_date, "order date")
        expected_date = self._date(expected_date, "expected delivery date") if expected_date else None
        if expected_date and expected_date < order_date:
            raise PurchasingWorkflowError("Expected delivery date cannot precede order date.")
        rows = self._items(company_id, branch_id, items, price_required=True, user_id=created_by)
        if expected_date:
            self._require_field_write(created_by, company_id, "expected_date")
        if notes:
            self._require_field_write(created_by, company_id, "notes")
        if requisition_id:
            req = Database.connect().execute(
                "SELECT company_id,branch_id,status FROM purchase_requisitions WHERE id=?", (requisition_id,)).fetchone()
            if not req or int(req[0]) != int(company_id) or (req[1] is not None and branch_id is not None and int(req[1]) != int(branch_id)):
                raise PurchasingWorkflowError("Requisition is outside the selected company/branch.")
            if req[2] != "OPEN":
                raise PurchasingWorkflowError("Only open requisitions can be converted to an order.")
            requested = Database.connect().execute(
                "SELECT product_id,warehouse_id,SUM(quantity) quantity FROM purchase_requisition_items WHERE requisition_id=? GROUP BY product_id,warehouse_id",
                (requisition_id,)).fetchall()
            ordered = {}
            for row in rows:
                key = (row["product_id"], row["warehouse_id"])
                ordered[key] = ordered.get(key, 0.0) + row["quantity"]
            requested_map = {(int(r["product_id"]), int(r["warehouse_id"])): float(r["quantity"]) for r in requested}
            if ordered != requested_map:
                raise PurchasingWorkflowError("Order lines must exactly cover the linked requisition quantities and items.")
        with transaction():
            approval_status = "PENDING" if require_approval else "APPROVED"
            cur = Database.connect().execute(
                "INSERT INTO purchase_orders(company_id,branch_id,supplier_id,requisition_id,order_number,order_date,expected_date,created_by,notes,approval_status,approved_by,approved_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (company_id, branch_id, supplier_id, requisition_id, str(order_number).strip(), order_date, expected_date, created_by, notes, approval_status, None if require_approval else created_by, None if require_approval else __import__("datetime").datetime.now().isoformat(sep=" ")))
            if cur.lastrowid is None:
                raise PurchasingWorkflowError("Could not create the purchase order.")
            oid = cur.lastrowid
            Database.connect().executemany(
                "INSERT INTO purchase_order_items(order_id,product_id,warehouse_id,ordered_quantity,unit_cost,discount,tax) VALUES(?,?,?,?,?,?,?)",
                [(oid,r["product_id"],r["warehouse_id"],r["quantity"],r["unit_cost"],r["discount"],r["tax"]) for r in rows])
            if require_approval:
                amount = sum(
                    row["quantity"] * row["unit_cost"] - row["discount"] + row["tax"]
                    for row in rows
                )
                try:
                    self.approval_workflows.snapshot_for_order(
                        Database.connect(), company_id, oid, amount
                    )
                except ApprovalWorkflowError as exc:
                    raise PurchasingWorkflowError(str(exc)) from exc
            if requisition_id:
                Database.connect().execute("UPDATE purchase_requisitions SET status='ORDERED' WHERE id=?", (requisition_id,))
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="purchases", action="purchase_order_created", entity_type="purchase_order",
                record_id=oid, description=f"Purchase order {order_number} created")
            return oid

    def record_receipt(self, company_id, branch_id, order_id, receipt_number, receipt_date,
                       received_by, items, notes=""):
        self._require_permission(received_by, company_id, "purchases.receive")
        receipt_date = self._date(receipt_date, "receipt date")
        rows = items or []
        if not rows:
            raise PurchasingWorkflowError("At least one received line is required.")
        conn = Database.connect()
        with transaction():
            order = conn.execute("SELECT * FROM purchase_orders WHERE id=? AND company_id=? AND (branch_id IS ? OR branch_id=?)",
                                 (order_id, company_id, branch_id, branch_id)).fetchone()
            if not order or order["status"] in ("CANCELLED", "CLOSED"):
                raise PurchasingWorkflowError("Purchase order not found or not receivable.")
            self._require_order_access(conn, received_by, company_id, order)
            if order["approval_status"] != "APPROVED":
                raise PurchasingWorkflowError("Purchase order must be approved before receiving goods.")
            cur = conn.execute("INSERT INTO purchase_receipts(company_id,branch_id,order_id,receipt_number,receipt_date,received_by,notes) VALUES(?,?,?,?,?,?,?)",
                               (company_id, branch_id, order_id, str(receipt_number).strip(), receipt_date, received_by, notes))
            receipt_id = cur.lastrowid
            seen = set()
            for item in rows:
                line_id, qty = int(item["order_item_id"]), float(item["quantity"])
                if line_id in seen or not math.isfinite(qty) or qty <= 0:
                    raise PurchasingWorkflowError("Receipt lines must be unique and have positive finite quantities.")
                seen.add(line_id)
                line = conn.execute("SELECT * FROM purchase_order_items WHERE id=? AND order_id=?", (line_id, order_id)).fetchone()
                if not line or float(line["received_quantity"]) + qty > float(line["ordered_quantity"]) + 1e-9:
                    raise PurchasingWorkflowError("Received quantity exceeds the ordered quantity or line is invalid.")
                conn.execute("INSERT INTO purchase_receipt_items(receipt_id,order_item_id,quantity) VALUES(?,?,?)", (receipt_id,line_id,qty))
                conn.execute("UPDATE purchase_order_items SET received_quantity=received_quantity+? WHERE id=?", (qty,line_id))
            outstanding = conn.execute("SELECT COUNT(*) FROM purchase_order_items WHERE order_id=? AND received_quantity < ordered_quantity", (order_id,)).fetchone()[0]
            conn.execute("UPDATE purchase_orders SET status=? WHERE id=?", ("PARTIALLY_RECEIVED" if outstanding else "RECEIVED", order_id))
            AuditService.record(user_id=received_by, company_id=company_id, branch_id=branch_id,
                module="purchases", action="goods_receipt_recorded", entity_type="purchase_receipt",
                record_id=receipt_id, description=f"Goods receipt {receipt_number} recorded")
            return receipt_id

    def approve_order(self, company_id, branch_id, order_id, approved_by, notes=""):
        """Approve a pending order; approval is immutable once goods are received."""
        self._require_permission(approved_by, company_id, "purchases.approve")
        conn = Database.connect()
        with transaction():
            order = conn.execute("SELECT * FROM purchase_orders WHERE id=? AND company_id=? AND (branch_id IS ? OR branch_id=?)",
                                 (order_id, company_id, branch_id, branch_id)).fetchone()
            if not order:
                raise PurchasingWorkflowError("Purchase order not found in the selected scope.")
            self._require_order_access(conn, approved_by, company_id, order)
            if order["approval_status"] != "PENDING" or order["status"] != "OPEN":
                raise PurchasingWorkflowError("Only pending, open orders can be approved.")
            has_workflow = conn.execute(
                "SELECT 1 FROM purchase_order_approval_steps WHERE order_id=? LIMIT 1",
                (int(order_id),),
            ).fetchone() is not None
            if has_workflow:
                step = self.approval_workflows.current_step(conn, order_id)
                if step is None:
                    raise PurchasingWorkflowError("لا توجد خطوة اعتماد معلقة لهذا الأمر.")
                try:
                    self.approval_workflows.require_current_approver(
                        conn, step, approved_by, company_id
                    )
                except ApprovalWorkflowError as exc:
                    raise PurchasingWorkflowError(str(exc)) from exc
                conn.execute(
                    """UPDATE purchase_order_approval_steps
                       SET approval_status='APPROVED',acted_by=?,acted_at=CURRENT_TIMESTAMP,notes=?
                       WHERE id=? AND approval_status='PENDING'""",
                    (int(approved_by), str(notes or ""), int(step["id"])),
                )
                pending = self.approval_workflows.current_step(conn, order_id)
                if pending is None:
                    conn.execute(
                        """UPDATE purchase_orders SET approval_status='APPROVED',approved_by=?,
                           approved_at=CURRENT_TIMESTAMP,approval_notes=? WHERE id=?""",
                        (approved_by, str(notes or ""), order_id),
                    )
                else:
                    conn.execute(
                        "UPDATE purchase_orders SET approval_notes=? WHERE id=?",
                        (str(notes or ""), order_id),
                    )
                action = "purchase_order_step_approved"
                description = (
                    f"Purchase order {order['order_number']} approval step "
                    f"{step['step_order']} approved"
                )
            else:
                conn.execute("UPDATE purchase_orders SET approval_status='APPROVED',approved_by=?,approved_at=CURRENT_TIMESTAMP,approval_notes=? WHERE id=?",
                             (approved_by, str(notes or ""), order_id))
                action = "purchase_order_approved"
                description = f"Purchase order {order['order_number']} approved"
            AuditService.record(user_id=approved_by, company_id=company_id, branch_id=branch_id,
                module="purchases", action=action, entity_type="purchase_order",
                record_id=order_id, description=description)
            return True

    def reject_order(self, company_id, branch_id, order_id, rejected_by, reason):
        reason = str(reason or "").strip()
        if not reason:
            raise PurchasingWorkflowError("A rejection reason is required.")
        self._require_permission(rejected_by, company_id, "purchases.approve")
        conn = Database.connect()
        with transaction():
            order = conn.execute("SELECT * FROM purchase_orders WHERE id=? AND company_id=? AND (branch_id IS ? OR branch_id=?)",
                                 (order_id, company_id, branch_id, branch_id)).fetchone()
            if not order or order["approval_status"] != "PENDING" or order["status"] != "OPEN":
                raise PurchasingWorkflowError("Only pending, open orders can be rejected.")
            self._require_order_access(conn, rejected_by, company_id, order)
            has_workflow = conn.execute(
                "SELECT 1 FROM purchase_order_approval_steps WHERE order_id=? LIMIT 1",
                (int(order_id),),
            ).fetchone() is not None
            if has_workflow:
                step = self.approval_workflows.current_step(conn, order_id)
                if step is None:
                    raise PurchasingWorkflowError("لا توجد خطوة اعتماد معلقة لهذا الأمر.")
                try:
                    self.approval_workflows.require_current_approver(
                        conn, step, rejected_by, company_id
                    )
                except ApprovalWorkflowError as exc:
                    raise PurchasingWorkflowError(str(exc)) from exc
                conn.execute(
                    """UPDATE purchase_order_approval_steps
                       SET approval_status='REJECTED',acted_by=?,acted_at=CURRENT_TIMESTAMP,notes=?
                       WHERE id=? AND approval_status='PENDING'""",
                    (int(rejected_by), reason, int(step["id"])),
                )
            conn.execute("UPDATE purchase_orders SET approval_status='REJECTED',approval_notes=? WHERE id=?", (reason, order_id))
            AuditService.record(user_id=rejected_by, company_id=company_id, branch_id=branch_id,
                module="purchases", action="purchase_order_rejected", entity_type="purchase_order",
                record_id=order_id, description=f"Purchase order {order['order_number']} rejected: {reason}")
            return True

    def order_invoice_payload(self, company_id, branch_id, order_id, user_id):
        """Return received, not-yet-invoiced lines with their stable PO line IDs."""
        conn = Database.connect()
        order = conn.execute("SELECT * FROM purchase_orders WHERE id=? AND company_id=? AND (branch_id IS ? OR branch_id=?)",
                             (order_id, company_id, branch_id, branch_id)).fetchone()
        if not order:
            raise PurchasingWorkflowError("Purchase order not found in the selected scope.")
        self._require_order_access(conn, user_id, company_id, order)
        self._require_financial_read(user_id, company_id)
        if order["approval_status"] != "APPROVED":
            raise PurchasingWorkflowError("Purchase order must be approved before invoicing.")
        rows = conn.execute("""SELECT oi.id order_item_id,oi.product_id,oi.warehouse_id,
            (oi.received_quantity-COALESCE((SELECT SUM(l.matched_quantity) FROM purchase_order_invoice_links l
             JOIN purchase_invoices pi ON pi.id=l.invoice_id
             WHERE l.order_item_id=oi.id AND l.company_id=? AND pi.status<>'CANCELLED'),0)) AS quantity,
            oi.unit_cost,oi.discount,oi.tax
            FROM purchase_order_items oi WHERE oi.order_id=? ORDER BY oi.id""", (company_id, order_id)).fetchall()
        items = [{"order_item_id":r["order_item_id"],"product_id":r["product_id"],"warehouse_id":r["warehouse_id"],
                  "quantity":float(r["quantity"]),"unit_cost":float(r["unit_cost"]),"discount":float(r["discount"] or 0),
                  "tax":float(r["tax"] or 0),"total":round(float(r["quantity"])*float(r["unit_cost"])-float(r["discount"] or 0)+float(r["tax"] or 0),2)}
                 for r in rows if float(r["quantity"]) > 1e-9]
        subtotal = round(sum(i["quantity"] * i["unit_cost"] for i in items), 2)
        discount = round(sum(i["discount"] for i in items), 2)
        tax = round(sum(i["tax"] for i in items), 2)
        total = round(sum(i["total"] for i in items), 2)
        return {"order_id": order_id, "supplier_id":order["supplier_id"],"items":items,"subtotal":subtotal,
                "discount":discount,"tax":tax,"total":total,"notes":order["notes"] or ""}

    def link_invoice(self, company_id, branch_id, order_id, invoice_id, created_by, line_matches):
        """Persist PO-line to posted-invoice-line matching; never rely on notes text."""
        if not line_matches:
            raise PurchasingWorkflowError("At least one invoice line match is required.")
        self._require_permission(created_by, company_id, "purchases.match")
        conn = Database.connect()
        with transaction():
            order = conn.execute("SELECT * FROM purchase_orders WHERE id=? AND company_id=? AND (branch_id IS ? OR branch_id=?)",
                                 (order_id, company_id, branch_id, branch_id)).fetchone()
            invoice = conn.execute("SELECT * FROM purchase_invoices WHERE id=? AND company_id=? AND branch_id=?",
                                   (invoice_id, company_id, branch_id)).fetchone()
            if not order or not invoice or int(order["supplier_id"]) != int(invoice["supplier_id"]):
                raise PurchasingWorkflowError("Order and invoice must belong to the same company, branch and supplier.")
            self._require_order_access(conn, created_by, company_id, order)
            if invoice["status"] != "POSTED":
                raise PurchasingWorkflowError("Only posted purchase invoices can be matched.")
            seen = set()
            for match in line_matches:
                po_line_id, invoice_line_id = int(match["order_item_id"]), int(match["invoice_item_id"])
                qty = float(match["quantity"])
                if po_line_id in seen or not math.isfinite(qty) or qty <= 0:
                    raise PurchasingWorkflowError("Invoice matches must be unique and have positive finite quantities.")
                seen.add(po_line_id)
                po_line = conn.execute("SELECT * FROM purchase_order_items WHERE id=? AND order_id=?", (po_line_id, order_id)).fetchone()
                inv_line = conn.execute("SELECT * FROM purchase_invoice_items WHERE id=? AND invoice_id=?", (invoice_line_id, invoice_id)).fetchone()
                if not po_line or not inv_line or int(po_line["product_id"]) != int(inv_line["product_id"]) or int(po_line["warehouse_id"]) != int(inv_line["warehouse_id"]):
                    raise PurchasingWorkflowError("Matched invoice and order lines must reference the same product and warehouse.")
                already_po = conn.execute("""SELECT COALESCE(SUM(l.matched_quantity),0)
                    FROM purchase_order_invoice_links l JOIN purchase_invoices p ON p.id=l.invoice_id
                    WHERE l.order_item_id=? AND p.status<>'CANCELLED'""", (po_line_id,)).fetchone()[0]
                already_invoice = conn.execute("""SELECT COALESCE(SUM(l.matched_quantity),0)
                    FROM purchase_order_invoice_links l JOIN purchase_invoices p ON p.id=l.invoice_id
                    WHERE l.invoice_item_id=? AND p.status<>'CANCELLED'""", (invoice_line_id,)).fetchone()[0]
                if (float(already_po or 0) + qty > float(po_line["received_quantity"]) + 1e-9
                        or float(already_invoice or 0) + qty > float(inv_line["quantity"]) + 1e-9):
                    raise PurchasingWorkflowError("Matched quantity exceeds the remaining received or invoiced quantity.")
                conn.execute("INSERT INTO purchase_order_invoice_links(company_id,branch_id,order_id,order_item_id,invoice_id,invoice_item_id,matched_quantity) VALUES(?,?,?,?,?,?,?)",
                             (company_id, branch_id, order_id, po_line_id, invoice_id, invoice_line_id, qty))
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="purchases", action="purchase_invoice_matched", entity_type="purchase_invoice",
                record_id=invoice_id, description=f"Purchase invoice {invoice['invoice_number']} matched to order {order['order_number']}")
            return True

    def invoice_match_audit(self, company_id, branch_id, user_id, order_id=None, tolerance=0.01, limit=500):
        """Audit matched PO/invoice lines for price, discount and tax variances.

        Amount comparisons are prorated to the matched quantity. This is an
        exception report only; it never silently changes or posts accounting data.
        """
        try:
            tolerance = float(tolerance)
            limit = max(1, min(int(limit), 2000))
        except (TypeError, ValueError) as exc:
            raise PurchasingWorkflowError("Invalid audit tolerance or limit.") from exc
        if not math.isfinite(tolerance) or tolerance < 0:
            raise PurchasingWorkflowError("Audit tolerance must be finite and non-negative.")
        self._require_financial_read(user_id, company_id)
        clauses = ["l.company_id=?", "pi.status='POSTED'"]
        params = [company_id]
        if branch_id is not None:
            clauses.append("l.branch_id=?")
            params.append(branch_id)
        if order_id is not None:
            clauses.append("l.order_id=?")
            params.append(order_id)
        sql = f"""SELECT l.id link_id,l.order_id,po.order_number,po.created_by,po.status po_status,
            po.approval_status,po.supplier_id,
            (SELECT COALESCE(SUM(ordered_quantity*unit_cost-discount+tax),0)
             FROM purchase_order_items WHERE order_id=po.id) total_amount,
            l.invoice_id,pi.invoice_number,
            l.order_item_id,l.invoice_item_id,l.matched_quantity,
            poi.unit_cost po_unit_cost,poi.ordered_quantity po_ordered_quantity,
            poi.discount po_discount,poi.tax po_tax,
            ii.unit_cost invoice_unit_cost,ii.quantity invoice_quantity,
            ii.discount invoice_discount,ii.tax invoice_tax,
            s.name supplier_name
            FROM purchase_order_invoice_links l
            JOIN purchase_orders po ON po.id=l.order_id
            JOIN purchase_invoices pi ON pi.id=l.invoice_id
            JOIN purchase_order_items poi ON poi.id=l.order_item_id
            JOIN purchase_invoice_items ii ON ii.id=l.invoice_item_id
            JOIN suppliers s ON s.id=po.supplier_id
            WHERE {' AND '.join(clauses)} ORDER BY l.id DESC LIMIT ?"""
        params.append(limit)
        results = []
        for row in Database.connect().execute(sql, params).fetchall():
            r = dict(row)
            if not self.access.record_is_allowed(
                user_id, company_id, "purchase_order",
                {"created_by": r["created_by"], "status": r["po_status"],
                 "approval_status": r["approval_status"], "supplier_id": r["supplier_id"],
                 "amount": float(r["total_amount"] or 0)},
            ):
                continue
            qty = float(r["matched_quantity"])
            po_gross = qty * float(r["po_unit_cost"])
            invoice_gross = qty * float(r["invoice_unit_cost"])
            po_discount = (float(r["po_discount"] or 0) / float(r["po_ordered_quantity"])) * qty
            invoice_discount = (float(r["invoice_discount"] or 0) / float(r["invoice_quantity"])) * qty
            po_tax = (float(r["po_tax"] or 0) / float(r["po_ordered_quantity"])) * qty
            invoice_tax = (float(r["invoice_tax"] or 0) / float(r["invoice_quantity"])) * qty
            r.update({
                "matched_quantity": qty,
                "price_variance": round(invoice_gross - po_gross, 2),
                "discount_variance": round(invoice_discount - po_discount, 2),
                "tax_variance": round(invoice_tax - po_tax, 2),
                "net_variance": round((invoice_gross-invoice_discount+invoice_tax) - (po_gross-po_discount+po_tax), 2),
            })
            r["has_variance"] = any(abs(r[k]) > tolerance for k in
                                     ("price_variance", "discount_variance", "tax_variance"))
            r["review_status"] = "REVIEW_REQUIRED" if r["has_variance"] else "MATCHED"
            results.append(r)
        return results

    def add_supplier_quote(self, company_id, branch_id, supplier_id, quote_number, quote_date,
                           valid_until, items, created_by, notes=""):
        self._require_permission(created_by, company_id, "purchases.create")
        tenancy.require_branch(company_id, branch_id)
        tenancy.require_supplier(company_id, supplier_id)
        quote_date = self._date(quote_date, "quote date")
        valid_until = self._date(valid_until, "quote validity date") if valid_until else None
        if valid_until and valid_until < quote_date:
            raise PurchasingWorkflowError("Quote validity cannot precede quote date.")
        rows = self._items(company_id, branch_id, items, price_required=True)
        with transaction():
            cur = Database.connect().execute("INSERT INTO supplier_quotes(company_id,branch_id,supplier_id,quote_number,quote_date,valid_until,notes) VALUES(?,?,?,?,?,?,?)",
                (company_id,branch_id,supplier_id,str(quote_number).strip(),quote_date,valid_until,notes))
            qid = cur.lastrowid
            Database.connect().executemany("INSERT INTO supplier_quote_items(quote_id,product_id,quantity,unit_cost,delivery_days) VALUES(?,?,?,?,?)",
                [(qid,r["product_id"],r["quantity"],r["unit_cost"],int(next((x.get("delivery_days",0) for x in items if int(x["product_id"])==r["product_id"]),0))) for r in rows])
            return qid

    def compare_quotes(self, company_id, product_id, branch_id=None):
        sql = """SELECT q.id quote_id,q.quote_number,q.supplier_id,s.name supplier_name,q.quote_date,q.valid_until,
                 qi.quantity,qi.unit_cost,qi.delivery_days
                 FROM supplier_quotes q JOIN supplier_quote_items qi ON qi.quote_id=q.id
                 JOIN suppliers s ON s.id=q.supplier_id
                 WHERE q.company_id=? AND qi.product_id=? AND (q.branch_id IS NULL OR q.branch_id IS ?) 
                 AND (q.valid_until IS NULL OR q.valid_until>=date('now'))
                 ORDER BY qi.unit_cost,qi.delivery_days,q.quote_date DESC"""
        return [dict(r) for r in Database.connect().execute(sql,(company_id,product_id,branch_id)).fetchall()]

    def supplier_performance(self, company_id, branch_id, user_id):
        conn = Database.connect()
        orders = conn.execute(
            """SELECT po.*,s.id supplier_id,s.name supplier_name,
                 (SELECT MAX(pr.receipt_date) FROM purchase_receipts pr WHERE pr.order_id=po.id) last_receipt
               FROM purchase_orders po JOIN suppliers s ON s.id=po.supplier_id
               WHERE po.company_id=? AND (? IS NULL OR po.branch_id=?)
               ORDER BY s.name,po.id""",
            (company_id, branch_id, branch_id),
        ).fetchall()
        totals = {}
        for order in orders:
            if not self.access.record_is_allowed(
                user_id, company_id, "purchase_order",
                {**dict(order), "amount": float(conn.execute(
                    """SELECT COALESCE(SUM(ordered_quantity*unit_cost-discount+tax),0)
                       FROM purchase_order_items WHERE order_id=?""",
                    (int(order["id"]),),
                ).fetchone()[0] or 0)},
            ):
                continue
            summary = totals.setdefault(int(order["supplier_id"]), {
                "supplier_id": int(order["supplier_id"]),
                "supplier_name": order["supplier_name"],
                "order_count": 0,
                "completed_orders": 0,
                "on_time": [],
                "days_vs_expected": [],
            })
            summary["order_count"] += 1
            if order["status"] == "RECEIVED":
                summary["completed_orders"] += 1
                if order["expected_date"] and order["last_receipt"]:
                    summary["on_time"].append(
                        1.0 if order["last_receipt"] <= order["expected_date"] else 0.0
                    )
                    delta = conn.execute(
                        "SELECT julianday(?) - julianday(?)",
                        (order["last_receipt"], order["expected_date"]),
                    ).fetchone()[0]
                    if delta is not None:
                        summary["days_vs_expected"].append(float(delta))
        supplier_rows = conn.execute(
            "SELECT id supplier_id,name supplier_name FROM suppliers WHERE company_id=? ORDER BY name",
            (int(company_id),),
        ).fetchall()
        results = []
        for supplier in supplier_rows:
            result = totals.get(int(supplier["supplier_id"]), {
                "supplier_id": int(supplier["supplier_id"]),
                "supplier_name": supplier["supplier_name"],
                "order_count": 0,
                "completed_orders": 0,
                "on_time": [],
                "days_vs_expected": [],
            })
            on_time = result.pop("on_time")
            days = result.pop("days_vs_expected")
            result["on_time_rate"] = sum(on_time) / len(on_time) if on_time else None
            result["avg_days_vs_expected"] = sum(days) / len(days) if days else None
            results.append(result)
        return results

    def order_tracking(self, company_id, branch_id, user_id, limit=200):
        limit = max(1, min(int(limit), 500))
        rows = Database.connect().execute("""SELECT po.id,po.created_by,po.supplier_id,po.order_number,po.order_date,po.expected_date,po.status,po.approval_status,
            s.name supplier_name,COALESCE(SUM(oi.ordered_quantity),0) ordered_quantity,
            COALESCE(SUM(oi.received_quantity),0) received_quantity,
            COALESCE(SUM(oi.ordered_quantity*oi.unit_cost-oi.discount+oi.tax),0) total_amount,
            CASE WHEN po.expected_date<date('now') AND po.status NOT IN ('RECEIVED','CLOSED','CANCELLED') THEN 1 ELSE 0 END is_late
            FROM purchase_orders po JOIN suppliers s ON s.id=po.supplier_id
            LEFT JOIN purchase_order_items oi ON oi.order_id=po.id
            WHERE po.company_id=? AND (? IS NULL OR po.branch_id=?)
            GROUP BY po.id ORDER BY po.order_date DESC,po.id DESC LIMIT ?""",
            (company_id,branch_id,branch_id,limit)).fetchall()
        results = []
        for row in rows:
            record = dict(row)
            record["amount"] = float(record["total_amount"] or 0)
            if self.access.record_is_allowed(user_id, company_id, "purchase_order", record):
                results.append(self.access.filter_record_fields(
                    user_id, company_id, "purchase_order", record
                ))
        return results

    def cancel_order(self, company_id, branch_id, order_id, cancelled_by):
        self._require_permission(cancelled_by, company_id, "purchases.cancel")
        conn = Database.connect()
        with transaction():
            order = conn.execute("SELECT * FROM purchase_orders WHERE id=? AND company_id=? AND (branch_id IS ? OR branch_id=?)",
                                  (order_id,company_id,branch_id,branch_id)).fetchone()
            if not order:
                raise PurchasingWorkflowError("Purchase order not found in the selected scope.")
            self._require_order_access(conn, cancelled_by, company_id, order)
            received = conn.execute("SELECT COALESCE(SUM(received_quantity),0) FROM purchase_order_items WHERE order_id=?",(order_id,)).fetchone()[0]
            if float(received or 0) > 0 or order["status"] in ("RECEIVED","CANCELLED"):
                raise PurchasingWorkflowError("An order with received goods cannot be cancelled here.")
            conn.execute("UPDATE purchase_orders SET status='CANCELLED' WHERE id=?",(order_id,))
            AuditService.record(user_id=cancelled_by, company_id=company_id, branch_id=branch_id,
                module="purchases", action="purchase_order_cancelled", entity_type="purchase_order",
                record_id=order_id, description=f"Purchase order {order['order_number']} cancelled")
            return True

    def supplier_price_history(self, company_id, product_id, branch_id=None, limit=200):
        """Historical unit costs from posted purchase invoices only."""
        limit = max(1, min(int(limit), 500))
        sql = """SELECT pi.invoice_date,pi.invoice_number,s.id supplier_id,s.name supplier_name,
                 pii.quantity,pii.unit_cost,pii.discount,pii.tax,
                 (pii.quantity*pii.unit_cost) gross_line_cost
                 FROM purchase_invoice_items pii
                 JOIN purchase_invoices pi ON pi.id=pii.invoice_id
                 JOIN suppliers s ON s.id=pi.supplier_id
                 WHERE pi.company_id=? AND pii.product_id=? AND pi.status='POSTED'
                 AND (? IS NULL OR pi.branch_id=?)
                 ORDER BY pi.invoice_date DESC,pi.id DESC LIMIT ?"""
        rows = Database.connect().execute(sql,(company_id,product_id,branch_id,branch_id,limit)).fetchall()
        return [dict(r) for r in rows]
