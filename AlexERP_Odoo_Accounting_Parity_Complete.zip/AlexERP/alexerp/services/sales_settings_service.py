"""Company-scoped defaults for sales accounting and inventory fulfillment."""
from __future__ import annotations

from alexerp.database.db import Database
from alexerp.database.transaction import transaction
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService


class SalesSettingsError(ValueError):
    pass


class SalesSettingsService:
    DEFAULT_ACCOUNT_CODES = {
        "receivable_account_id": "1201",
        "sales_account_id": "4101",
        "inventory_account_id": "1301",
        "cogs_account_id": "5101",
        "tax_account_id": "2201",
        "cash_account_id": "1101",
    }
    REQUIRED_ACCOUNTS = (
        "receivable_account_id",
        "sales_account_id",
        "inventory_account_id",
        "cogs_account_id",
        "cash_account_id",
    )
    POLICIES = {"DEDUCT_ON_POST", "RESERVE_UNTIL_DELIVERY"}

    def get_settings(self, company_id: int) -> dict:
        company_id = int(company_id)
        if company_id <= 0:
            raise SalesSettingsError("معرّف الشركة غير صحيح.")
        conn = Database.connect()
        row = conn.execute(
            "SELECT * FROM company_sales_settings WHERE company_id=?",
            (company_id,),
        ).fetchone()
        if row is not None:
            return dict(row)

        defaults = {
            "company_id": company_id,
            "inventory_policy": "DEDUCT_ON_POST",
        }
        for field, code in self.DEFAULT_ACCOUNT_CODES.items():
            account = conn.execute(
                """SELECT id FROM chart_of_accounts
                   WHERE company_id=? AND account_code=? AND is_header=0 AND allow_posting=1 AND is_active=1
                   ORDER BY id LIMIT 1""",
                (company_id, code),
            ).fetchone()
            defaults[field] = int(account["id"]) if account else None
        return defaults

    def save_settings(
        self,
        *,
        company_id: int,
        actor_id: int,
        inventory_policy: str,
        receivable_account_id: int,
        sales_account_id: int,
        inventory_account_id: int,
        cogs_account_id: int,
        cash_account_id: int,
        tax_account_id: int | None = None,
    ) -> None:
        company_id = int(company_id)
        actor_id = int(actor_id)
        if company_id <= 0 or actor_id <= 0:
            raise SalesSettingsError("الشركة أو المستخدم غير صحيح.")
        if inventory_policy not in self.POLICIES:
            raise SalesSettingsError("سياسة المخزون غير معروفة.")
        PermissionService().require_for_company(actor_id, company_id, "companies.manage")

        accounts = {
            "receivable_account_id": receivable_account_id,
            "sales_account_id": sales_account_id,
            "inventory_account_id": inventory_account_id,
            "cogs_account_id": cogs_account_id,
            "cash_account_id": cash_account_id,
            "tax_account_id": tax_account_id,
        }
        conn = Database.connect()
        for field in self.REQUIRED_ACCOUNTS:
            if accounts[field] is None:
                raise SalesSettingsError(f"يجب تحديد الحساب: {field}.")
        for field, account_id in accounts.items():
            if account_id is None:
                continue
            row = conn.execute(
                """SELECT 1 FROM chart_of_accounts
                   WHERE id=? AND company_id=? AND is_header=0 AND allow_posting=1 AND is_active=1""",
                (int(account_id), company_id),
            ).fetchone()
            if row is None:
                raise SalesSettingsError("يجب اختيار حساب ترحيل نشط تابع للشركة.")
            accounts[field] = int(account_id)

        with transaction() as conn:
            before_row = conn.execute(
                "SELECT * FROM company_sales_settings WHERE company_id=?",
                (company_id,),
            ).fetchone()
            before = dict(before_row) if before_row else None
            conn.execute(
                """INSERT INTO company_sales_settings(
                       company_id,inventory_policy,receivable_account_id,sales_account_id,
                       inventory_account_id,cogs_account_id,tax_account_id,cash_account_id,
                       updated_by,updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                   ON CONFLICT(company_id) DO UPDATE SET
                       inventory_policy=excluded.inventory_policy,
                       receivable_account_id=excluded.receivable_account_id,
                       sales_account_id=excluded.sales_account_id,
                       inventory_account_id=excluded.inventory_account_id,
                       cogs_account_id=excluded.cogs_account_id,
                       tax_account_id=excluded.tax_account_id,
                       cash_account_id=excluded.cash_account_id,
                       updated_by=excluded.updated_by,
                       updated_at=CURRENT_TIMESTAMP""",
                (
                    company_id,
                    inventory_policy,
                    accounts["receivable_account_id"],
                    accounts["sales_account_id"],
                    accounts["inventory_account_id"],
                    accounts["cogs_account_id"],
                    accounts["tax_account_id"],
                    accounts["cash_account_id"],
                    actor_id,
                ),
            )
            AuditService.record(
                user_id=actor_id,
                company_id=company_id,
                module="sales",
                action="sales_settings_updated",
                entity_type="company_sales_settings",
                record_id=company_id,
                description="Updated company sales settings",
                before=before,
                after={
                    "inventory_policy": inventory_policy,
                    **accounts,
                },
                connection=conn,
            )
