"""Sales returns limited to the quantities originally sold and not yet returned."""
from __future__ import annotations
import math
from alexerp.database.transaction import transaction
from alexerp.core.constants import StockTransactionType, ReferenceType
from alexerp.repositories.sales_return_repository import SalesReturnRepository
from alexerp.repositories.sales_repository import SalesRepository
from alexerp.services.inventory_service import InventoryService
from alexerp.accounting import AccountingService
from alexerp.services.party_balance_service import PartyBalanceService
from alexerp.core import tenancy
from alexerp.services.audit_service import AuditService
from alexerp.services.permission_service import PermissionService, PermissionDenied
from alexerp.services.customer_service import CustomerService

class SalesReturnError(Exception): pass

class SalesReturnService:
    def __init__(self):
        self.repo = SalesReturnRepository()
        self.sales = SalesRepository()
        self.inventory = InventoryService()
        self.accounting = AccountingService()
        self.balances = PartyBalanceService()

    def list_returnable_deliveries(
        self, order_id: int, company_id: int, branch_id: int, user_id: int
    ):
        tenancy.require_branch(company_id, branch_id)
        try:
            PermissionService().require_for_company(user_id, company_id, "sales.return")
        except PermissionDenied as exc:
            raise SalesReturnError("User is not authorized to create sales returns.") from exc
        rows = self.sales.connection.execute(
            "SELECT d.id,d.delivery_number,d.delivery_date,d.sales_invoice_id,"
            "i.invoice_number,COALESCE(SUM(di.quantity-COALESCE(di.returned_quantity,0)),0) "
            "AS remaining_quantity FROM sales_deliveries d "
            "JOIN sales_invoices i ON i.id=d.sales_invoice_id "
            "JOIN sales_delivery_items di ON di.delivery_id=d.id "
            "WHERE d.sales_order_id=? AND d.company_id=? AND d.branch_id=? "
            "AND UPPER(d.status)='POSTED' AND UPPER(i.status)='POSTED' "
            "GROUP BY d.id HAVING SUM(di.quantity-COALESCE(di.returned_quantity,0))>0.000001 "
            "ORDER BY d.delivery_date DESC,d.id DESC",
            (int(order_id), int(company_id), int(branch_id)),
        ).fetchall()
        result = []
        for row in rows:
            available = sum(
                float(item["available_quantity"] or 0)
                for item in self.get_delivery_return_items(
                    int(row["id"]), company_id, branch_id, user_id
                )
            )
            if available > 0.000001:
                delivery = dict(row)
                delivery["remaining_quantity"] = available
                result.append(delivery)
        return result

    def get_delivery_return_items(
        self, delivery_id: int, company_id: int, branch_id: int, user_id: int
    ):
        tenancy.require_branch(company_id, branch_id)
        try:
            PermissionService().require_for_company(user_id, company_id, "sales.return")
        except PermissionDenied as exc:
            raise SalesReturnError("User is not authorized to create sales returns.") from exc
        rows = self.sales.connection.execute(
            "SELECT di.id AS delivery_item_id,di.sales_order_item_id,di.sales_invoice_item_id,"
            "i.id AS sales_invoice_id,"
            "di.product_id,di.warehouse_id,di.quantity AS delivered_quantity,"
            "COALESCE(di.returned_quantity,0) AS returned_quantity,"
            "CASE WHEN di.quantity-COALESCE(di.returned_quantity,0)>0 "
            "THEN di.quantity-COALESCE(di.returned_quantity,0) ELSE 0 END AS available_quantity,"
            "di.unit_cost,ii.quantity AS invoiced_quantity,ii.total AS invoice_line_total,"
            "ii.tax AS invoice_line_tax,p.name AS product_name "
            "FROM sales_delivery_items di JOIN sales_deliveries d ON d.id=di.delivery_id "
            "JOIN sales_invoices i ON i.id=d.sales_invoice_id "
            "JOIN sales_invoice_items ii ON ii.id=di.sales_invoice_item_id "
            "JOIN products p ON p.id=di.product_id "
            "WHERE di.delivery_id=? AND d.company_id=? AND d.branch_id=? "
            "AND UPPER(d.status)='POSTED' AND UPPER(i.status)='POSTED' "
            "ORDER BY di.id",
            (int(delivery_id), int(company_id), int(branch_id)),
        ).fetchall()
        if not rows:
            return []

        invoice_id = int(rows[0]["sales_invoice_id"])
        returned_by_product = self.repo.get_returned_quantities(invoice_id)
        availability = {}
        for key, total_returned in returned_by_product.items():
            linked_returned = self.sales.connection.execute(
                "SELECT COALESCE(SUM(ri.quantity),0) FROM sales_return_items ri "
                "JOIN sales_returns r ON r.id=ri.return_id "
                "WHERE r.sales_invoice_id=? AND UPPER(COALESCE(r.status,'POSTED'))='POSTED' "
                "AND ri.product_id=? AND ri.warehouse_id=? AND ri.sales_delivery_item_id IS NOT NULL",
                (invoice_id, key[0], key[1]),
            ).fetchone()[0]
            legacy_remaining = max(0.0, float(total_returned) - float(linked_returned or 0))
            candidates = self.sales.connection.execute(
                "SELECT di.id,di.quantity,COALESCE(di.returned_quantity,0) AS returned_quantity "
                "FROM sales_delivery_items di JOIN sales_deliveries d ON d.id=di.delivery_id "
                "WHERE d.sales_invoice_id=? AND UPPER(d.status)='POSTED' "
                "AND di.product_id=? AND di.warehouse_id=? "
                "ORDER BY d.delivery_date,d.id,di.id",
                (invoice_id, key[0], key[1]),
            ).fetchall()
            for candidate in candidates:
                line_remaining = max(
                    0.0,
                    float(candidate["quantity"]) - float(candidate["returned_quantity"] or 0),
                )
                allocated_legacy = min(line_remaining, legacy_remaining)
                availability[int(candidate["id"])] = line_remaining - allocated_legacy
                legacy_remaining -= allocated_legacy

        return [
            dict(row, available_quantity=availability.get(
                int(row["delivery_item_id"]), float(row["available_quantity"] or 0)
            ))
            for row in rows
        ]

    def create_return_from_delivery(
        self, *, company_id: int, branch_id: int, sales_delivery_id: int,
        return_number: str, return_date: str, items: list, notes: str,
        created_by: int, sales_account: int, receivable_account: int,
        inventory_account: int, cogs_account: int, tax_account: int | None = None,
    ) -> int:
        if not items:
            raise SalesReturnError("Return contains no items.")
        tenancy.require_branch(company_id, branch_id)
        with transaction():
            delivery = self.sales.connection.execute(
                "SELECT d.*,i.customer_id,i.status AS invoice_status,o.status AS order_status "
                "FROM sales_deliveries d JOIN sales_invoices i ON i.id=d.sales_invoice_id "
                "JOIN sales_orders o ON o.id=d.sales_order_id "
                "WHERE d.id=? AND d.company_id=? AND d.branch_id=?",
                (int(sales_delivery_id), int(company_id), int(branch_id)),
            ).fetchone()
            if delivery is None:
                raise SalesReturnError("Delivery document was not found in this company and branch.")
            if str(delivery["status"]).upper() != "POSTED":
                raise SalesReturnError("Only posted delivery documents can be returned.")
            if str(delivery["invoice_status"]).upper() != "POSTED":
                raise SalesReturnError("Only deliveries from posted invoices can be returned.")

            lines_by_id = {
                int(row["delivery_item_id"]): row
                for row in self.get_delivery_return_items(
                    sales_delivery_id, company_id, branch_id, created_by
                )
            }
            prepared, computed_total, seen = [], 0.0, set()
            for item in items:
                try:
                    delivery_item_id = int(item["delivery_item_id"])
                    qty = float(item["quantity"])
                except (KeyError, TypeError, ValueError) as exc:
                    raise SalesReturnError("Invalid delivery line or return quantity.") from exc
                line = lines_by_id.get(delivery_item_id)
                if line is None or delivery_item_id in seen:
                    raise SalesReturnError("A selected line does not belong to this posted delivery.")
                if not math.isfinite(qty) or qty <= 0:
                    raise SalesReturnError("Return quantities must be positive finite numbers.")
                available = float(line["available_quantity"] or 0)
                if qty - available > 0.000001:
                    raise SalesReturnError("Return quantity exceeds the unreturned delivery quantity.")
                invoiced_qty = float(line["invoiced_quantity"] or 0)
                if invoiced_qty <= 0:
                    raise SalesReturnError("The source invoice line has no valid quantity.")
                line_total = round(float(line["invoice_line_total"] or 0) * qty / invoiced_qty, 2)
                prepared.append({
                    "delivery_item_id": delivery_item_id,
                    "invoice_item_id": int(line["sales_invoice_item_id"]),
                    "order_item_id": int(line["sales_order_item_id"]),
                    "product_id": int(line["product_id"]),
                    "warehouse_id": int(line["warehouse_id"]),
                    "quantity": qty,
                    "total": line_total,
                })
                computed_total += line_total
                seen.add(delivery_item_id)

            return self.create_return(
                company_id=company_id, branch_id=branch_id,
                sales_invoice_id=int(delivery["sales_invoice_id"]),
                customer_id=int(delivery["customer_id"]), return_number=return_number,
                return_date=return_date, items=prepared, total=round(computed_total, 2),
                notes=notes, created_by=created_by, sales_account=sales_account,
                receivable_account=receivable_account, inventory_account=inventory_account,
                cogs_account=cogs_account, tax_account=tax_account,
                sales_delivery_id=int(sales_delivery_id),
            )

    def create_return(self, company_id: int, branch_id: int, sales_invoice_id: int,
        customer_id: int, return_number: str, return_date: str, items: list,
        total: float, notes: str, created_by: int, sales_account: int,
        receivable_account: int, inventory_account: int, cogs_account: int,
        tax_account: int | None = None, sales_delivery_id: int | None = None) -> int:
        if not items: raise SalesReturnError("Return contains no items.")
        total = float(total)
        if not math.isfinite(total) or total <= 0: raise SalesReturnError("Return total must be positive.")
        tenancy.require_branch(company_id, branch_id)
        tenancy.require_customer(company_id, customer_id)
        try:
            PermissionService().require_for_company(created_by, company_id, "sales.return")
        except PermissionDenied as exc:
            raise SalesReturnError("User is not authorized to create sales returns.") from exc
        tenancy.require_account(company_id, receivable_account, "Accounts receivable account")
        receivable_account = CustomerService().ensure_customer_account(
            company_id, customer_id
        )
        tenancy.require_accounts(company_id, sales_account=sales_account,
            receivable_account=receivable_account, inventory_account=inventory_account,
            cogs_account=cogs_account, tax_account=tax_account)
        with transaction():
            invoice = self.sales.get_invoice(sales_invoice_id)
            if invoice is None: raise SalesReturnError("Original sales invoice not found.")
            if int(invoice["company_id"]) != int(company_id) or int(invoice["branch_id"]) != int(branch_id) or int(invoice["customer_id"]) != int(customer_id):
                raise SalesReturnError("Return customer/company/branch does not match the original invoice.")
            if str(invoice["status"]).upper() != "POSTED":
                raise SalesReturnError("Only posted sales invoices can be returned.")
            delivery = None
            delivery_lines_by_id = {}
            if sales_delivery_id is not None:
                delivery = self.sales.connection.execute(
                    "SELECT * FROM sales_deliveries WHERE id=? AND sales_invoice_id=? "
                    "AND company_id=? AND branch_id=?",
                    (int(sales_delivery_id), int(sales_invoice_id), int(company_id), int(branch_id)),
                ).fetchone()
                if delivery is None or str(delivery["status"]).upper() != "POSTED":
                    raise SalesReturnError("A posted delivery linked to this invoice is required.")
                delivery_lines_by_id = {
                    int(row["id"]): row for row in self.sales.connection.execute(
                        "SELECT * FROM sales_delivery_items WHERE delivery_id=? ORDER BY id",
                        (int(sales_delivery_id),),
                    ).fetchall()
                }
            if (
                sales_delivery_id is None
                and
                str(invoice["inventory_policy"] or "DEDUCT_ON_POST") == "RESERVE_UNTIL_DELIVERY"
                and str(invoice["delivery_status"] or "").upper() != "DELIVERED"
            ):
                raise SalesReturnError("Reserved-stock invoices can only be returned after delivery.")
            original_items = self.sales.get_items(sales_invoice_id)
            prior = self.repo.get_returned_quantities(sales_invoice_id)
            header_tax = float(invoice["tax"] or 0)
            line_tax_sum = sum(float(x["tax"] or 0) for x in original_items)
            original_gross_sum = sum(float(x["total"] or 0) for x in original_items)
            normalized, return_refs = [], []
            computed_total, total_cost, computed_tax = 0.0, 0.0, 0.0
            for item in items:
                delivery_line = None
                delivery_item_id = item.get("delivery_item_id")
                if sales_delivery_id is not None:
                    try:
                        delivery_line = delivery_lines_by_id.get(int(delivery_item_id))
                    except (TypeError, ValueError):
                        delivery_line = None
                    if delivery_line is None:
                        raise SalesReturnError("A return line must reference a line from the selected delivery.")
                    pid, wid = int(delivery_line["product_id"]), int(delivery_line["warehouse_id"])
                else:
                    pid, wid = int(item["product_id"]), int(item["warehouse_id"])
                try:
                    qty = float(item["quantity"])
                except (KeyError, TypeError, ValueError) as exc:
                    raise SalesReturnError("Return quantity must be a positive finite number.") from exc
                if not math.isfinite(qty) or qty <= 0: raise SalesReturnError("Return quantity must be positive.")
                sold_qty = sum(float(x["quantity"]) for x in original_items if int(x["product_id"]) == pid and int(x["warehouse_id"] or 0) == wid)
                returned_qty = float(prior.get((pid, wid), 0.0))
                if sold_qty <= returned_qty or qty > sold_qty-returned_qty:
                    raise SalesReturnError(f"Return quantity exceeds the remaining sold quantity for product {pid}.")
                if delivery_line is not None:
                    delivery_remaining = float(delivery_line["quantity"]) - float(delivery_line["returned_quantity"] or 0)
                    if qty - delivery_remaining > 0.000001:
                        raise SalesReturnError("Return quantity exceeds the unreturned delivery quantity.")
                    delivered_group = self.sales.connection.execute(
                        "SELECT COALESCE(SUM(di.quantity),0) FROM sales_delivery_items di "
                        "JOIN sales_deliveries d ON d.id=di.delivery_id "
                        "WHERE d.sales_invoice_id=? AND UPPER(d.status)='POSTED' "
                        "AND di.product_id=? AND di.warehouse_id=?",
                        (int(sales_invoice_id), pid, wid),
                    ).fetchone()[0]
                    if qty - (float(delivered_group or 0) - returned_qty) > 0.000001:
                        raise SalesReturnError("Return quantity exceeds the total quantity delivered on this invoice.")
                matching = [x for x in original_items if int(x["product_id"]) == pid and int(x["warehouse_id"] or 0) == wid]
                sold_total_qty = sum(float(x["quantity"]) for x in matching)
                original_line_total = sum(float(x["total"] or 0) for x in matching)
                original_line_tax = sum(float(x["tax"] or 0) for x in matching)
                original_line_cost = sum(float(x["unit_cost"] or 0) * float(x["quantity"]) for x in matching)
                source_invoice_item = None
                if delivery_line is not None:
                    source_invoice_item = next(
                        (row for row in original_items if int(row["id"]) == int(delivery_line["sales_invoice_item_id"])),
                        None,
                    )
                    if source_invoice_item is None:
                        raise SalesReturnError("Delivery line does not map to an item on the selected invoice.")
                    source_qty = float(source_invoice_item["quantity"] or 0)
                    if source_qty <= 0 or int(source_invoice_item["product_id"]) != pid or int(source_invoice_item["warehouse_id"] or 0) != wid:
                        raise SalesReturnError("Delivery line does not match its source invoice item.")
                    original_line_total = float(source_invoice_item["total"] or 0)
                    sold_total_qty = source_qty
                    original_line_cost = float(delivery_line["unit_cost"] or 0) * source_qty
                product_cost = self.sales.connection.execute(
                    "SELECT purchase_price FROM products WHERE id=?", (pid,)
                ).fetchone()
                if original_line_cost <= 0 and product_cost and float(product_cost["purchase_price"] or 0) > 0:
                    raise SalesReturnError(
                        f"Original invoice line for product {pid} has no recorded issue cost. "
                        "A controlled cost review is required before returning this legacy invoice."
                    )
                expected_line_total = round((original_line_total / sold_total_qty) * qty, 2)
                unit_cost = (original_line_cost / sold_total_qty) if sold_total_qty else 0.0
                line_total = float(item["total"])
                if not math.isfinite(line_total) or line_total < 0: raise SalesReturnError("Invalid return line total.")
                if round(line_total, 2) != expected_line_total:
                    raise SalesReturnError(f"Return value for product {pid} must be {expected_line_total:.2f} based on the original invoice.")
                # Prefer recorded line-tax amounts when they reconcile to the
                # invoice header. For legacy lines with missing/inconsistent
                # tax values, allocate header tax by each group's gross value.
                if abs(line_tax_sum - header_tax) <= 0.01:
                    group_tax = original_line_tax
                else:
                    group_tax = (header_tax * original_line_total / original_gross_sum
                                 if original_gross_sum > 0 else 0.0)
                tax_before = round(group_tax * returned_qty / sold_total_qty, 2)
                tax_after = round(group_tax * (returned_qty + qty) / sold_total_qty, 2)
                line_return_tax = tax_after - tax_before
                if line_return_tax < 0 or line_return_tax > line_total + 0.01:
                    raise SalesReturnError("Original line tax data is invalid for this return.")
                normalized.append((pid, wid, qty, unit_cost, line_total))
                return_refs.append((
                    int(delivery_item_id) if delivery_line is not None else None,
                    int(source_invoice_item["id"]) if source_invoice_item is not None else None,
                    int(delivery_line["sales_order_item_id"]) if delivery_line is not None else None,
                ))
                computed_total += line_total
                total_cost += qty*unit_cost
                computed_tax += line_return_tax
                prior[(pid, wid)] = returned_qty+qty
            if round(computed_total,2) != round(total,2): raise SalesReturnError("Return total does not equal the sum of return lines.")
            return_id = self.repo.create_return(company_id=company_id, branch_id=branch_id,
                sales_invoice_id=sales_invoice_id, customer_id=customer_id,
                return_number=return_number, return_date=return_date, total=total,
                notes=notes, created_by=created_by,
                sales_order_id=int(delivery["sales_order_id"]) if delivery is not None else None,
                sales_delivery_id=int(delivery["id"]) if delivery is not None else None)
            for normalized_line, refs in zip(normalized, return_refs):
                pid, wid, qty, cost, line_total = normalized_line
                delivery_item_id, invoice_item_id, order_item_id = refs
                self.repo.add_item(
                    return_id, pid, wid, qty, cost, line_total,
                    sales_delivery_item_id=delivery_item_id,
                    sales_invoice_item_id=invoice_item_id,
                    sales_order_item_id=order_item_id,
                )
                if delivery_item_id is not None:
                    updated = self.sales.connection.execute(
                        "UPDATE sales_delivery_items SET returned_quantity=COALESCE(returned_quantity,0)+? "
                        "WHERE id=? AND quantity-COALESCE(returned_quantity,0)>=?-0.000001",
                        (qty, delivery_item_id, qty),
                    )
                    if updated.rowcount != 1:
                        raise SalesReturnError("Delivery line return quantity changed; refresh and try again.")
                self.inventory.increase_stock(pid, qty, wid, company_id, branch_id, cost)
                self.inventory.add_stock_movement(company_id=company_id, branch_id=branch_id,
                    warehouse_id=wid, product_id=pid, transaction_type=StockTransactionType.SALE_RETURN,
                    reference_type=ReferenceType.SALE_RETURN, reference_id=return_id,
                    quantity_in=qty, unit_cost=cost,
                    balance_after=self.inventory.get_quantity(pid,wid),
                    notes=f"Sales Return {return_number}", created_by=created_by)
            returned_tax = round(computed_tax, 2)
            returned_net = round(total - returned_tax, 2)
            if returned_tax and not tax_account:
                raise SalesReturnError("Tax account is required to reverse tax on this return.")
            details = [
                {"account_id": sales_account, "debit": returned_net, "credit": 0, "description": "Sales return, net"},
                {"account_id": receivable_account, "debit": 0, "credit": total, "description": "Customer credit"},
            ]
            if returned_tax:
                details.append({"account_id": tax_account, "debit": returned_tax, "credit": 0, "description": "Reverse output tax"})
            if total_cost:
                details += [
                    {"account_id": inventory_account, "debit": total_cost, "credit": 0, "description": "Returned inventory"},
                    {"account_id": cogs_account, "debit": 0, "credit": total_cost, "description": "Reverse cost of goods sold"},
                ]
            self.accounting.create_entry(company_id, branch_id, return_date,
                f"Sales Return {return_number}", ReferenceType.SALE_RETURN,
                return_id, created_by, details, entry_number=f"JV-SR-{company_id}-{return_number}")
            self.balances.refresh_customer(customer_id)
            AuditService.record(user_id=created_by, company_id=company_id, branch_id=branch_id,
                module="sales", action="sales_return_posted", entity_type="sales_return",
                record_id=return_id, description=f"Sales return {return_number} posted",
                after={"return_number": return_number, "sales_invoice_id": sales_invoice_id,
                       "customer_id": customer_id, "sales_order_id": int(delivery["sales_order_id"]) if delivery is not None else None,
                       "sales_delivery_id": int(delivery["id"]) if delivery is not None else None,
                       "total": round(total, 2),
                       "status": "POSTED", "items": [
                           {"product_id": pid, "warehouse_id": wid, "quantity": qty,
                            "unit_cost": cost, "line_total": line_total}
                           for pid, wid, qty, cost, line_total in normalized]})
            return return_id
