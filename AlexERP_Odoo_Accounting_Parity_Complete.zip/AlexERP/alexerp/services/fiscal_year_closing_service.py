"""Controlled, company-scoped fiscal-year closing workflow."""
from __future__ import annotations

from datetime import date, datetime, timezone, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from alexerp.database.transaction import transaction
from alexerp.accounting import AccountingReadService, FiscalPeriodService


class FiscalYearClosingError(ValueError):
    """Raised when a fiscal year cannot be safely closed."""


_CENT = Decimal("0.01")


def _money(value) -> Decimal:
    try:
        amount = Decimal(str(value if value is not None else 0))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FiscalYearClosingError("A financial balance contains an invalid number.") from exc
    if not amount.is_finite():
        raise FiscalYearClosingError("A financial balance must be finite.")
    return amount.quantize(_CENT, rounding=ROUND_HALF_UP)


def _date(value: str, label: str) -> date:
    try:
        parsed = date.fromisoformat(str(value))
    except (TypeError, ValueError) as exc:
        raise FiscalYearClosingError(f"{label} must be a valid YYYY-MM-DD date.") from exc
    if parsed.isoformat() != str(value):
        raise FiscalYearClosingError(f"{label} must use YYYY-MM-DD format.")
    return parsed


class FiscalYearClosingService:
    """Close P&L accounts to retained earnings and close covered periods atomically.

    The ledger is cumulative in this application. Therefore permanent-account
    balances are carried forward by their existing ledger history; this service
    deliberately does not insert duplicate opening-balance journals.
    """

    permission_key = "accounting.fiscal_year.close"

    def __init__(self, accounting_reads=None, period_service=None):
        self.accounting_reads = accounting_reads or AccountingReadService()
        self.period_service = period_service or FiscalPeriodService(self.accounting_reads)

    def close_year(
        self,
        *,
        company_id: int,
        year_name: str,
        start_date: str,
        end_date: str,
        retained_earnings_account_id: int,
        closed_by: int,
    ) -> dict:
        if not isinstance(company_id, int) or company_id <= 0:
            raise FiscalYearClosingError("A valid company_id is required.")
        if not isinstance(closed_by, int) or closed_by <= 0:
            raise FiscalYearClosingError("A valid closed_by user ID is required.")
        if not isinstance(retained_earnings_account_id, int) or retained_earnings_account_id <= 0:
            raise FiscalYearClosingError("A valid retained-earnings account is required.")
        name = str(year_name or "").strip()
        if not name:
            raise FiscalYearClosingError("Fiscal year name is required.")
        start = _date(start_date, "start_date")
        end = _date(end_date, "end_date")
        if start > end:
            raise FiscalYearClosingError("Fiscal year start must not be after its end.")

        with transaction() as conn:
            self._require_permission(conn, closed_by, company_id)
            existing = conn.execute(
                "SELECT id FROM fiscal_year_closings WHERE company_id=? AND start_date=? AND end_date=?",
                (company_id, start.isoformat(), end.isoformat()),
            ).fetchone()
            if existing:
                raise FiscalYearClosingError("This fiscal year has already been closed.")

            overlap = conn.execute(
                """SELECT year_name FROM fiscal_year_closings
                   WHERE company_id=? AND NOT(end_date<? OR start_date>?) LIMIT 1""",
                (company_id, start.isoformat(), end.isoformat()),
            ).fetchone()
            if overlap:
                raise FiscalYearClosingError(
                    f"Fiscal year overlaps already closed year '{overlap['year_name']}'."
                )

            company = conn.execute("SELECT id FROM companies WHERE id=?", (company_id,)).fetchone()
            if company is None:
                raise FiscalYearClosingError("Company does not exist.")

            retained = self.accounting_reads.get_account_for_closing(
                company_id, retained_earnings_account_id, connection=conn,
            )
            if (retained is None or retained["account_type"] != "EQUITY"
                    or not int(retained["is_active"] if retained["is_active"] is not None else 1)
                    or not int(retained["allow_posting"] if retained["allow_posting"] is not None else 1)):
                raise FiscalYearClosingError(
                    "Retained-earnings account must be an active, postable equity account in this company."
                )

            periods = self.period_service.periods_overlapping(
                company_id, start.isoformat(), end.isoformat(), connection=conn,
            )
            if not periods:
                raise FiscalYearClosingError("No accounting periods cover this fiscal year.")
            for period in periods:
                period_start = _date(period["start_date"], "period start")
                period_end = _date(period["end_date"], "period end")
                if period_start < start or period_end > end:
                    raise FiscalYearClosingError(
                        "Every accounting period included in a fiscal-year close must be fully inside that fiscal year."
                    )
            self._require_contiguous_coverage(periods, start, end)

            invalid = self.accounting_reads.find_unbalanced_journal(
                company_id, start.isoformat(), end.isoformat(), connection=conn,
            )
            if invalid:
                raise FiscalYearClosingError(
                    f"Journal {invalid['entry_number'] or invalid['id']} is empty or unbalanced."
                )
            pending = self.accounting_reads.find_unposted_journal(
                company_id, start.isoformat(), end.isoformat(), connection=conn,
            )
            if pending:
                raise FiscalYearClosingError(
                    f"Unposted journal '{pending['entry_number']}' prevents fiscal-year closing."
                )

            balances = self.accounting_reads.get_profit_loss_account_balances(
                company_id, start.isoformat(), end.isoformat(), connection=conn,
            )

            lines: list[dict] = []
            revenue_total = Decimal("0.00")
            expense_total = Decimal("0.00")
            for row in balances:
                debit = _money(row["debit_total"])
                credit = _money(row["credit_total"])
                if debit == 0 and credit == 0:
                    continue
                account_state = self.accounting_reads.get_account_posting_state(
                    company_id, int(row["id"]), connection=conn,
                )
                if (account_state is None
                        or not int(account_state["is_active"] if account_state["is_active"] is not None else 1)
                        or not int(account_state["allow_posting"] if account_state["allow_posting"] is not None else 1)):
                    raise FiscalYearClosingError(
                        f"P&L account '{row['account_code']}' has a balance but is inactive or not postable."
                    )
                if row["account_type"] == "REVENUE":
                    net = credit - debit
                    revenue_total += net
                    # Reverse the account's net credit balance.
                    if net > 0:
                        lines.append({"account_id": int(row["id"]), "debit": str(net), "credit": "0.00",
                                      "description": f"Fiscal year closing — {row['account_name']}"})
                    elif net < 0:
                        lines.append({"account_id": int(row["id"]), "debit": "0.00", "credit": str(-net),
                                      "description": f"Fiscal year closing — {row['account_name']}"})
                else:
                    net = debit - credit
                    expense_total += net
                    # Reverse the account's net debit balance.
                    if net > 0:
                        lines.append({"account_id": int(row["id"]), "debit": "0.00", "credit": str(net),
                                      "description": f"Fiscal year closing — {row['account_name']}"})
                    elif net < 0:
                        lines.append({"account_id": int(row["id"]), "debit": str(-net), "credit": "0.00",
                                      "description": f"Fiscal year closing — {row['account_name']}"})

            net_income = (revenue_total - expense_total).quantize(_CENT, rounding=ROUND_HALF_UP)
            closing_entry_id = None
            if lines:
                if net_income > 0:
                    lines.append({"account_id": retained_earnings_account_id, "debit": "0.00",
                                  "credit": str(net_income), "description": "Transfer of fiscal-year net profit"})
                elif net_income < 0:
                    lines.append({"account_id": retained_earnings_account_id, "debit": str(-net_income),
                                  "credit": "0.00", "description": "Transfer of fiscal-year net loss"})

                year_end_period = next(
                    (period for period in periods
                     if _date(period["start_date"], "period start") <= end
                     <= _date(period["end_date"], "period end")), None
                )
                if year_end_period is None or int(year_end_period["is_closed"] or 0):
                    raise FiscalYearClosingError(
                        "The period containing the fiscal-year end must be open to post the closing journal."
                    )
                branch = conn.execute(
                    "SELECT id FROM branches WHERE company_id=? ORDER BY id LIMIT 1", (company_id,)
                ).fetchone()
                if branch is None:
                    raise FiscalYearClosingError("Company has no branch for the closing journal.")

            cur = conn.execute(
                """INSERT INTO fiscal_year_closings
                   (company_id, year_name, start_date, end_date, retained_earnings_account_id,
                    net_income, closed_by)
                   VALUES(?,?,?,?,?,?,?)""",
                (company_id, name, start.isoformat(), end.isoformat(), retained_earnings_account_id,
                 str(net_income), closed_by),
            )
            closing_id = int(cur.lastrowid)

            if lines:
                from alexerp.accounting import AccountingService
                closing_entry_id = AccountingService().create_entry(
                    company_id=company_id,
                    branch_id=int(branch["id"]),
                    entry_date=end.isoformat(),
                    description=f"Fiscal year closing — {name}",
                    reference_type="FISCAL_YEAR_CLOSE",
                    reference_id=closing_id,
                    created_by=closed_by,
                    details=lines,
                )
                conn.execute(
                    "UPDATE fiscal_year_closings SET closing_entry_id=? WHERE id=?",
                    (closing_entry_id, closing_id),
                )

            # Validate every affected period before closing any of them. Already
            # closed periods remain closed; the year-end period was checked above.
            for period in periods:
                if int(period["is_closed"] or 0):
                    continue
                bad = self.accounting_reads.find_unbalanced_journal(
                    company_id, period["start_date"], period["end_date"], connection=conn,
                )
                pending_period = self.accounting_reads.find_unposted_journal(
                    company_id, period["start_date"], period["end_date"], connection=conn,
                )
                if bad or pending_period:
                    raise FiscalYearClosingError(
                        f"Period '{period['name']}' contains invalid or unposted journals."
                    )

            closed_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
            self.period_service._close_periods_in_transaction(
                conn, company_id,
                [int(period["id"]) for period in periods if not int(period["is_closed"] or 0)],
                closed_by, closed_at,
            )

            from alexerp.services.audit_service import AuditService
            AuditService.record(
                user_id=closed_by, company_id=company_id, module="accounting",
                action="fiscal_year_closed", entity_type="fiscal_year_closing",
                record_id=closing_id,
                description=f"Closed fiscal year {name}; net income {net_income}",
                after={"year_name": name, "start_date": start.isoformat(),
                       "end_date": end.isoformat(), "net_income": str(net_income),
                       "closing_entry_id": closing_entry_id,
                       "retained_earnings_account_id": retained_earnings_account_id},
                connection=conn,
            )
            return {
                "closing_id": closing_id,
                "closing_entry_id": closing_entry_id,
                "net_income": str(net_income),
                "periods_closed": sum(1 for period in periods if not int(period["is_closed"] or 0)),
                "already_closed_periods": sum(1 for period in periods if int(period["is_closed"] or 0)),
            }

    @staticmethod
    def _require_contiguous_coverage(periods, start: date, end: date) -> None:
        next_day = start
        for period in periods:
            period_start = _date(period["start_date"], "period start")
            period_end = _date(period["end_date"], "period end")
            if period_start > next_day:
                raise FiscalYearClosingError(
                    f"Accounting periods have a gap beginning {next_day.isoformat()}."
                )
            if period_end >= next_day:
                next_day = period_end + timedelta(days=1)
            if next_day > end:
                return
        raise FiscalYearClosingError(
            f"Accounting periods do not cover the fiscal year through {end.isoformat()}."
        )

    @classmethod
    def _require_permission(cls, conn, user_id: int, company_id: int) -> None:
        allowed = conn.execute(
            """SELECT 1 FROM users u
               JOIN roles r ON r.id=u.role_id AND r.is_active=1
                 AND (r.company_id IS NULL OR r.company_id=u.company_id)
               JOIN role_permissions rp ON rp.role_id=r.id
               JOIN permissions p ON p.id=rp.permission_id
               WHERE u.id=? AND u.company_id=? AND u.is_active=1
                 AND p.permission_key=? LIMIT 1""",
            (user_id, company_id, cls.permission_key),
        ).fetchone()
        if allowed is None:
            raise FiscalYearClosingError("User is not authorized to close fiscal years for this company.")
