"""
AlexERP — Business Management System
Base Repository
"""

from __future__ import annotations

import sqlite3

from alexerp.database.db import Database


class BaseRepository:
    """Base repository for all repositories."""

    table_name: str = ""
    primary_key: str = "id"

    @property
    def connection(self) -> sqlite3.Connection:
        # Resolve lazily so a repository passed to a worker thread uses that
        # thread's connection rather than the creator's connection.
        return Database.connect()

    # =====================================================
    # Cursor
    # =====================================================

    @property
    def cursor(self) -> sqlite3.Cursor:
        return self.connection.cursor()

    # =====================================================
    # Execute
    # =====================================================

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        cursor = self.cursor
        cursor.execute(sql, params)
        return cursor

    # =====================================================
    # Commit
    # =====================================================

    def commit(self) -> None:
        self.connection.commit()

    # =====================================================
    # Rollback
    # =====================================================

    def rollback(self) -> None:
        self.connection.rollback()

    # =====================================================
    # Fetch One
    # =====================================================

    def fetchone(self, sql: str, params: tuple = ()):
        cursor = self.execute(sql, params)
        return cursor.fetchone()

    # =====================================================
    # Fetch All
    # =====================================================

    def fetchall(self, sql: str, params: tuple = ()):
        cursor = self.execute(sql, params)
        return cursor.fetchall()

    # =====================================================
    # Execute Many
    # =====================================================

    def executemany(self, sql: str, params: list[tuple] | list):
        cursor = self.cursor
        cursor.executemany(sql, params)
        return cursor

    # =====================================================
    # Find By ID
    # =====================================================

    def find_by_id(self, record_id: int):
        sql = f"""
        SELECT *
        FROM {self.table_name}
        WHERE {self.primary_key}=?
        """
        cursor = self.execute(sql, (record_id,))
        return cursor.fetchone()

    # =====================================================
    # Find All
    # =====================================================

    def find_all(self):
        sql = f"""
        SELECT *
        FROM {self.table_name}
        ORDER BY {self.primary_key}
        """
        cursor = self.execute(sql)
        return cursor.fetchall()

    # =====================================================
    # Delete
    # =====================================================

    def delete(self, record_id: int) -> None:
        sql = f"""
        DELETE
        FROM {self.table_name}
        WHERE {self.primary_key}=?
        """
        self.execute(sql, (record_id,))
        self.commit()

    # =====================================================
    # Count
    # =====================================================

    def count(self) -> int:
        sql = f"""
        SELECT COUNT(*)
        FROM {self.table_name}
        """
        cursor = self.execute(sql)
        return cursor.fetchone()[0]

    # =====================================================
    # Exists
    # =====================================================

    def exists(self, record_id: int) -> bool:
        return self.find_by_id(record_id) is not None

    # =====================================================
    # Close
    # =====================================================

    def close(self) -> None:
        Database.close_current()

