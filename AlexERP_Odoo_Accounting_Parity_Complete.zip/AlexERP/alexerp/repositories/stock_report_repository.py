"""
AlexERP — Business Management System
Stock Reports Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class StockReportRepository(BaseRepository):

    # =====================================================
    # Stock Card
    # =====================================================

    def stock_card(

        self,

        product_id: int,

        warehouse_id: int | None = None,

        date_from: str | None = None,

        date_to: str | None = None,

    ):

        sql = """

        SELECT

            transaction_date,

            transaction_type,

            reference_type,

            reference_id,

            quantity_in,

            quantity_out,

            unit_cost,

            balance_after,

            notes

        FROM stock_movements

        WHERE product_id=?

        """

        params = [product_id]

        if warehouse_id:

            sql += " AND warehouse_id=?"
            params.append(warehouse_id)

        if date_from:

            sql += " AND transaction_date>=?"
            params.append(date_from)

        if date_to:

            sql += " AND transaction_date<=?"
            params.append(date_to)

        sql += """

        ORDER BY

            transaction_date,

            id

        """

        cursor = self.execute(
            sql,
            tuple(params),
        )

        return cursor.fetchall()

    # =====================================================
    # Current Stock
    # =====================================================

    def current_stock(

        self,

        warehouse_id=None,

    ):

        sql = """

        SELECT

            p.code,

            p.barcode,

            p.name,

            ps.quantity,

            ps.average_cost,

            w.name AS warehouse

        FROM product_stock ps

        JOIN products p

            ON p.id=ps.product_id

        JOIN warehouses w

            ON w.id=ps.warehouse_id

        """

        params = []

        if warehouse_id:

            sql += """

            WHERE ps.warehouse_id=?

            """

            params.append(warehouse_id)

        sql += """

        ORDER BY

            p.name

        """

        cursor = self.execute(
            sql,
            tuple(params),
        )


    # =====================================================
    # Low Stock
    # =====================================================

    def low_stock(self, warehouse_id: int | None = None):
        sql = """
        SELECT p.id, p.code, p.name, p.minimum_stock,
               COALESCE(SUM(ps.quantity), 0) +
               COALESCE((SELECT SUM(lu.quantity) FROM legacy_stock_unallocated lu
                         WHERE lu.product_id=p.id AND lu.resolved_at IS NULL), 0) AS quantity
        FROM products p
        LEFT JOIN product_stock ps ON ps.product_id = p.id
        """
        params = []
        if warehouse_id is not None:
            sql += " WHERE ps.warehouse_id=?"
            params.append(warehouse_id)
        sql += """
        GROUP BY p.id, p.code, p.name, p.minimum_stock
        HAVING COALESCE(SUM(ps.quantity), 0) +
               COALESCE((SELECT SUM(lu.quantity) FROM legacy_stock_unallocated lu
                         WHERE lu.product_id=p.id AND lu.resolved_at IS NULL), 0)
               <= p.minimum_stock
        ORDER BY p.name
        """
        return self.fetchall(sql, tuple(params))
