"""
AlexERP — Business Management System
Product Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class ProductRepository(BaseRepository):

    table_name = "products"

    # =====================================================
    # Add Product
    # =====================================================

    def add(
        self,
        code: str,
        barcode: str,
        name: str,
        category_id: int | None = None,
        brand_id: int | None = None,
        unit_id: int | None = None,
        purchase_price: float = 0,
        sale_price: float = 0,
        minimum_stock: float = 0,
        maximum_stock: float = 0,
        description: str = "",
        company_id: int = 1,
        branch_id: int | None = 1,
    ) -> int:

        sql = """
        INSERT INTO products(
            company_id,
            branch_id,
            code,
            barcode,
            name,
            category_id,
            brand_id,
            unit_id,
            purchase_price,
            sale_price,
            minimum_stock,
            maximum_stock,
            description

        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                branch_id,
                code,
                barcode,
                name,
                category_id,
                brand_id,
                unit_id,
                purchase_price,
                sale_price,
                minimum_stock,
                maximum_stock,
                description,
            ),
        )

        self.commit()
        return cursor.lastrowid

    # =====================================================
    # Update Product
    # =====================================================

    def update(
        self,
        product_id: int,
        code: str,
        barcode: str,
        name: str,
        category_id: int | None,
        brand_id: int | None,
        unit_id: int | None,
        purchase_price: float,
        sale_price: float,
        minimum_stock: float,
        maximum_stock: float,
        description: str,
    ):

        sql = """
        UPDATE products
        SET

            code=?,
            barcode=?,
            name=?,
            category_id=?,
            brand_id=?,
            unit_id=?,
            purchase_price=?,
            sale_price=?,
            minimum_stock=?,
            maximum_stock=?,
            description=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                code,
                barcode,
                name,
                category_id,
                brand_id,
                unit_id,
                purchase_price,
                sale_price,
                minimum_stock,
                maximum_stock,
                description,
                product_id,
            ),
        )

    # =====================================================
    # Find By Barcode
    # =====================================================
        self.commit()

    def find_by_barcode(self, barcode: str):

        sql = """
        SELECT *
        FROM products
        WHERE barcode=?
        """

        cursor = self.execute(sql, (barcode,))

        return cursor.fetchone()

    # =====================================================
    # Find By Code
    # =====================================================

    def find_by_code(self, code: str):

        sql = """
        SELECT *
        FROM products
        WHERE code=?
        """

        cursor = self.execute(sql, (code,))

        return cursor.fetchone()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        sql = """
        SELECT *
        FROM products

        WHERE

            code LIKE ?
            OR
            barcode LIKE ?
            OR
            name LIKE ?

        ORDER BY name
        """

        cursor = self.execute(
            sql,
            (
                f"%{keyword}%",
                f"%{keyword}%",
                f"%{keyword}%",
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Low Stock
    # =====================================================

    def low_stock(self):

        sql = """
        SELECT *
        FROM products
        WHERE quantity <= minimum_stock
        ORDER BY name
        """

        cursor = self.execute(sql)

        return cursor.fetchall()

    # =====================================================
    # Update Quantity
    # =====================================================


    def update_quantity(
        self,
        product_id: int,
        quantity: float,
    ):

        sql = """
        UPDATE products
        SET

            quantity=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                quantity,
                product_id,
            ),
        )


 # =====================================================
# Get By ID

    # =====================================================
        self.commit()

    def get_by_id(
        self,
        product_id: int,
    ):

        sql = """
        SELECT *
        FROM products
        WHERE id=?
        """

        cursor = self.execute(
            sql,
            (
                product_id,
            ),
        )

        return cursor.fetchone()



    # =====================================================
    # Delete
    # =====================================================

    def delete(
        self,
        product_id: int,
    ):

        sql = """
        DELETE FROM products
        WHERE id=?
        """

        self.execute(
            sql,
            (
                product_id,
            ),
        )



    # =====================================================
    # Exists
    # =====================================================
        self.commit()

    def exists(
        self,
        product_id: int,
    ):

        sql = """
        SELECT 1
        FROM products
        WHERE id=?
        """

        cursor = self.execute(
            sql,
            (
                product_id,
            ),
        )

        return cursor.fetchone() is not None