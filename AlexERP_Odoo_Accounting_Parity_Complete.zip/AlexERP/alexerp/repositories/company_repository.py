"""
AlexERP — Business Management System
Company Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class CompanyRepository(BaseRepository):

    table_name = "companies"

    # =====================================================
    # Add
    # =====================================================

    def add(
        self,
        code: str,
        name: str,
        commercial_name: str = "",
        tax_number: str = "",
        phone: str = "",
        mobile: str = "",
        email: str = "",
        website: str = "",
        address: str = "",
        city: str = "",
        country: str = "",
    ) -> int:

        sql = """
        INSERT INTO companies(

            code,
            name,
            commercial_name,
            tax_number,
            phone,
            mobile,
            email,
            website,
            address,
            city,
            country

        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                code,
                name,
                commercial_name,
                tax_number,
                phone,
                mobile,
                email,
                website,
                address,
                city,
                country,
            ),
        )

        return cursor.lastrowid

    # =====================================================
    # Update
    # =====================================================

    def update(

        self,
        company_id: int,
        code: str,
        name: str,
        commercial_name: str,
        tax_number: str,
        phone: str,
        mobile: str,
        email: str,
        website: str,
        address: str,
        city: str,
        country: str,

    ):

        sql = """
        UPDATE companies
        SET

            code=?,
            name=?,
            commercial_name=?,
            tax_number=?,
            phone=?,
            mobile=?,
            email=?,
            website=?,
            address=?,
            city=?,
            country=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                code,
                name,
                commercial_name,
                tax_number,
                phone,
                mobile,
                email,
                website,
                address,
                city,
                country,
                company_id,
            ),
        )

    # =====================================================
    # Find By Code
    # =====================================================

    def find_by_code(self, code: str):

        sql = """
        SELECT *
        FROM companies
        WHERE code=?
        """

        cursor = self.execute(sql, (code,))

        return cursor.fetchone()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        sql = """
        SELECT *
        FROM companies
        WHERE

            code LIKE ?
            OR
            name LIKE ?

        ORDER BY name
        """

        cursor = self.execute(
            sql,
            (
                f"%{keyword}%",
                f"%{keyword}%",
            ),
        )

        return cursor.fetchall()