"""
AlexERP — Business Management System
Inventory Adjustment Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class AdjustmentRepository(BaseRepository):

    table_name = "stock_adjustments"

    # =====================================================
    # Create Adjustment
    # =====================================================

    def create_adjustment(
        self,
        company_id: int,
        branch_id: int,
        warehouse_id: int,
        adjustment_number: str,
        adjustment_date: str,
        adjustment_type: str,
        notes: str,
        created_by: int,
    ) -> int:

        sql = """
        INSERT INTO stock_adjustments(

            company_id,
            branch_id,
            warehouse_id,
            adjustment_number,
            adjustment_date,
            adjustment_type,
            notes,
            created_by

        )
        VALUES(?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                branch_id,
                warehouse_id,
                adjustment_number,
                adjustment_date,
                adjustment_type,
                notes,
                created_by,
            ),
        )

        return cursor.lastrowid

    # =====================================================
    # Add Item
    # =====================================================

    def add_item(
        self,
        adjustment_id: int,
        product_id: int,
        system_quantity: float,
        actual_quantity: float,
        difference: float,
        unit_cost: float,
    ):

        sql = """
        INSERT INTO stock_adjustment_items(

            adjustment_id,
            product_id,
            system_quantity,
            actual_quantity,
            difference,
            unit_cost

        )
        VALUES(?,?,?,?,?,?)
        """

        self.execute(
            sql,
            (
                adjustment_id,
                product_id,
                system_quantity,
                actual_quantity,
                difference,
                unit_cost,
            ),
        )

    # =====================================================
    # Get Adjustment
    # =====================================================

    def get_adjustment(self, adjustment_id: int):

        cursor = self.execute(
            """
            SELECT *
            FROM stock_adjustments
            WHERE id=?
            """,
            (adjustment_id,),
        )

        return cursor.fetchone()

    # =====================================================
    # Get Items
    # =====================================================

    def get_items(self, adjustment_id: int):

        cursor = self.execute(
            """
            SELECT *
            FROM stock_adjustment_items
            WHERE adjustment_id=?
            ORDER BY id
            """,
            (adjustment_id,),
        )

        return cursor.fetchall()