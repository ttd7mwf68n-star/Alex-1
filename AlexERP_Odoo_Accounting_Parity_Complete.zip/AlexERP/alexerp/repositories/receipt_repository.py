"""
AlexERP — Business Management System
Customer receipt repository.
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class ReceiptRepository(BaseRepository):

    table_name = "receipts"

    def create(

        self,

        company_id,

        branch_id,

        receipt_number,

        receipt_date,

        customer_id,

        cash_box_id,

        amount,

        notes,

        created_by,

    ):

        existing = self.fetchone(
            "SELECT id FROM receipts WHERE company_id=? AND branch_id=? AND receipt_number=? LIMIT 1",
            (company_id, branch_id, receipt_number),
        )
        if existing is not None:
            raise ValueError(f"Receipt number already exists: {receipt_number}")

        cursor = self.execute(

            """

            INSERT INTO receipts(

                company_id,

                branch_id,

                receipt_number,

                receipt_date,

                customer_id,

                cash_box_id,

                amount,

                notes,

                created_by

            )

            VALUES(?,?,?,?,?,?,?,?,?)

            """,

            (

                company_id,

                branch_id,

                receipt_number,

                receipt_date,

                customer_id,

                cash_box_id,

                amount,

                notes,

                created_by,

            ),

        )

        return cursor.lastrowid

    def get_for_actor(self, receipt_id, actor_user_id):
        """Return a receipt only when the active actor belongs to its company."""
        return self.fetchone(
            """SELECT r.* FROM receipts r
               JOIN users u ON u.id=? AND u.company_id=r.company_id AND u.is_active=1
               WHERE r.id=?""",
            (actor_user_id, receipt_id),
        )

    def set_status(self, receipt_id, company_id, status):
        cursor = self.execute(
            "UPDATE receipts SET status=? WHERE id=? AND company_id=?",
            (status, receipt_id, company_id),
        )
        if cursor.rowcount != 1:
            raise ValueError("Customer receipt is outside the actor company scope.")
