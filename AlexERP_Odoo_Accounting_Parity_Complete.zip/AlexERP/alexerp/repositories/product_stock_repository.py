from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class ProductStockRepository(BaseRepository):
    table_name = "product_stock"

    def get_stock(self, warehouse_id: int, product_id: int):
        return self.fetchone(
            "SELECT * FROM product_stock WHERE warehouse_id=? AND product_id=?",
            (warehouse_id, product_id),
        )

    def get_total_stock(self, product_id: int) -> float:
        row = self.fetchone(
            "SELECT COALESCE(SUM(quantity), 0) AS quantity "
            "FROM product_stock WHERE product_id=?",
            (product_id,),
        )
        return float(row["quantity"] or 0)

    def set_quantity(self, warehouse_id: int, product_id: int,
                     quantity: float, average_cost: float | None = None):
        warehouse = self.fetchone(
            "SELECT company_id, branch_id FROM warehouses WHERE id=?",
            (warehouse_id,),
        )
        if warehouse is None:
            raise ValueError("Warehouse not found.")
        product = self.fetchone(
            "SELECT company_id, branch_id FROM products WHERE id=?",
            (product_id,),
        )
        if product is None:
            raise ValueError("Product not found.")
        if int(product["company_id"]) != int(warehouse["company_id"]):
            raise ValueError("Product and warehouse must belong to the same company.")
        if (product["branch_id"] is not None and warehouse["branch_id"] is not None
                and int(product["branch_id"]) != int(warehouse["branch_id"])):
            raise ValueError("Product and warehouse must belong to the same branch.")
        existing = self.get_stock(warehouse_id, product_id)
        cost = (float(existing["average_cost"] or 0) if existing else 0.0)
        if average_cost is not None:
            cost = float(average_cost)
        self.execute("""
            INSERT INTO product_stock
                (company_id, branch_id, warehouse_id, product_id,
                 quantity, average_cost, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(warehouse_id, product_id) DO UPDATE SET
                quantity=excluded.quantity,
                average_cost=excluded.average_cost,
                updated_at=CURRENT_TIMESTAMP
        """, (warehouse["company_id"], warehouse["branch_id"], warehouse_id,
              product_id, float(quantity), cost))
        self.execute("""
            UPDATE products
            SET quantity=(
                SELECT COALESCE(SUM(ps.quantity),0)
                FROM product_stock ps WHERE ps.product_id=products.id
            ) + COALESCE((
                SELECT SUM(lu.quantity) FROM legacy_stock_unallocated lu
                WHERE lu.product_id=products.id AND lu.resolved_at IS NULL
            ),0),
            updated_at=CURRENT_TIMESTAMP
            WHERE id=?
        """, (product_id,))
