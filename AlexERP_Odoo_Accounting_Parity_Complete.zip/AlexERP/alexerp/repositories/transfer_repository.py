"""Repository for warehouse transfer headers and lines."""
from __future__ import annotations
from alexerp.repositories.base_repository import BaseRepository

class TransferRepository(BaseRepository):
    table_name = "stock_transfers"

    def create_transfer(self, company_id: int, branch_id: int,
        from_warehouse: int, to_warehouse: int, transfer_number: str,
        transfer_date: str, notes: str, created_by: int) -> int:
        cur = self.execute("""
            INSERT INTO stock_transfers(
                company_id, branch_id, transfer_number, from_warehouse_id,
                to_warehouse_id, transfer_date, notes, created_by, status
            ) VALUES(?,?,?,?,?,?,?,?, 'Posted')
        """, (company_id, branch_id, transfer_number, from_warehouse,
              to_warehouse, transfer_date, notes, created_by))
        return cur.lastrowid

    def add_item(self, transfer_id: int, product_id: int,
                 quantity: float, unit_cost: float) -> int:
        cur = self.execute("""
            INSERT INTO stock_transfer_items(transfer_id, product_id, quantity, unit_cost, total)
            VALUES(?,?,?,?,?)
        """, (transfer_id, product_id, quantity, unit_cost, quantity * unit_cost))
        return cur.lastrowid

    def get_transfer(self, transfer_id: int):
        return self.execute("SELECT * FROM stock_transfers WHERE id=?", (transfer_id,)).fetchone()

    def get_items(self, transfer_id: int):
        return self.execute("SELECT * FROM stock_transfer_items WHERE transfer_id=? ORDER BY id",
                            (transfer_id,)).fetchall()
