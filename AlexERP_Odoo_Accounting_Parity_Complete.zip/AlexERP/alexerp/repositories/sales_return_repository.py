"""AlexERP — Business Management System

Sales Return Repository

It provides DB operations used by services/sales_return_service.py.
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class SalesReturnRepository(BaseRepository):
    """Repository for sales return headers/items."""

    table_name = "sales_returns"
    primary_key = "id"

    # =====================================================
    # Headers
    # =====================================================

    def create_return(
        self,
        sales_invoice_id: int,
        customer_id: int,
        return_number: str,
        return_date: str,
        total: float,
        notes: str,
        company_id: int | None = None,
        branch_id: int | None = None,
        created_by: int | None = None,
        sales_order_id: int | None = None,
        sales_delivery_id: int | None = None,
    ) -> int:
        """Insert a new sales return header and return its id."""

        sql = """
        INSERT INTO sales_returns(
            company_id,
            branch_id,
            sales_invoice_id,
            customer_id,
            return_number,
            return_date,
            total,
            notes,
            created_by,
            sales_order_id,
            sales_delivery_id
        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                branch_id,
                sales_invoice_id,
                customer_id,
                return_number,
                return_date,
                total,
                notes,
                created_by,
                sales_order_id,
                sales_delivery_id,
            ),
        )
        return cursor.lastrowid

    def get_return(self, return_id: int):
        sql = """
        SELECT *
        FROM sales_returns
        WHERE id=?
        """
        cursor = self.execute(sql, (return_id,))
        return cursor.fetchone()

    # =====================================================
    # Items
    # =====================================================

    def add_item(
        self,
        return_id: int,
        product_id: int,
        warehouse_id: int,
        quantity: float,
        unit_cost: float,
        total: float,
        sales_delivery_item_id: int | None = None,
        sales_invoice_item_id: int | None = None,
        sales_order_item_id: int | None = None,
    ) -> None:
        sql = """
        INSERT INTO sales_return_items(
            return_id,
            product_id,
            warehouse_id,
            quantity,
            unit_cost,
            total,
            sales_delivery_item_id,
            sales_invoice_item_id,
            sales_order_item_id
        )
        VALUES(?,?,?,?,?,?,?,?,?)
        """

        self.execute(
            sql,
            (
                return_id,
                product_id,
                warehouse_id,
                quantity,
                unit_cost,
                total,
                sales_delivery_item_id,
                sales_invoice_item_id,
                sales_order_item_id,
            ),
        )

    def get_returned_quantities(self, sales_invoice_id: int) -> dict:
        cursor = self.execute("""
            SELECT i.product_id, i.warehouse_id, SUM(i.quantity) AS quantity
            FROM sales_return_items i
            JOIN sales_returns r ON r.id=i.return_id
            WHERE r.sales_invoice_id=? AND UPPER(COALESCE(r.status,'POSTED'))='POSTED'
            GROUP BY i.product_id, i.warehouse_id
        """, (sales_invoice_id,))
        return {(int(row["product_id"]), int(row["warehouse_id"])): float(row["quantity"] or 0)
                for row in cursor.fetchall()}

    def get_returned_amounts(self, sales_invoice_id: int) -> dict:
        cursor = self.execute("""
            SELECT i.product_id, i.warehouse_id, SUM(i.total) AS total
            FROM sales_return_items i
            JOIN sales_returns r ON r.id=i.return_id
            WHERE r.sales_invoice_id=? AND UPPER(COALESCE(r.status,'POSTED'))='POSTED'
            GROUP BY i.product_id, i.warehouse_id
        """, (sales_invoice_id,))
        return {(int(row["product_id"]), int(row["warehouse_id"])): float(row["total"] or 0)
                for row in cursor.fetchall()}

    def get_items(self, return_id: int):
        sql = """
        SELECT *
        FROM sales_return_items
        WHERE return_id=?
        ORDER BY id
        """
        cursor = self.execute(sql, (return_id,))
        return cursor.fetchall()
