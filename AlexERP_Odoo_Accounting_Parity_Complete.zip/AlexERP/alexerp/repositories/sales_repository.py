"""
AlexERP — Business Management System
Sales Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class SalesRepository(BaseRepository):

    table_name = "sales_invoices"

    # =====================================================
    # Create Invoice
    # =====================================================

    def create_invoice(
        self,
        company_id: int,
        branch_id: int,
        customer_id: int,
        invoice_number: str,
        invoice_date: str,
        subtotal: float,
        discount: float,
        tax: float,
        total: float,
        paid_amount: float,
        remaining_amount: float,
        notes: str,
        created_by: int,
        payment_terms_days: int = 0,
        due_date: str | None = None,
    ) -> int:

        sql = """
        INSERT INTO sales_invoices(

            company_id,
            branch_id,
            customer_id,
            invoice_number,
            invoice_date,
            subtotal,
            discount,
            tax,
            total,
            paid_amount,
            remaining_amount,
            notes,
            created_by,
            payment_terms_days,
            due_date

        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                branch_id,
                customer_id,
                invoice_number,
                invoice_date,
                subtotal,
                discount,
                tax,
                total,
                paid_amount,
                remaining_amount,
                notes,
                created_by,
                int(payment_terms_days),
                due_date,
            ),
        )

        return cursor.lastrowid

    # =====================================================
    # Add Item
    # =====================================================

    def add_item(
        self,
        invoice_id: int,
        product_id: int,
        warehouse_id: int,
        quantity: float,
        unit_price: float,
        discount: float,
        tax: float,
        total: float,
        unit_cost: float = 0,
    ):

        sql = """
        INSERT INTO sales_invoice_items(

            invoice_id,
            product_id,
            warehouse_id,
            quantity,
            unit_price,
            discount,
            tax,
            total,
            unit_cost

        )
        VALUES(?,?,?,?,?,?,?,?,?)
        """

        self.execute(
            sql,
            (
                invoice_id,
                product_id,
                warehouse_id,
                quantity,
                unit_price,
                discount,
                tax,
                total,
                unit_cost,
            ),
        )


    # =====================================================
    # Get Invoice
    # =====================================================

    def get_invoice(self, invoice_id: int):

        sql = """
        SELECT *
        FROM sales_invoices
        WHERE id=?
        """

        cursor = self.execute(sql, (invoice_id,))

        return cursor.fetchone()

    # =====================================================
    # Get Items
    # =====================================================

    def get_items(self, invoice_id: int):

        sql = """
        SELECT *
        FROM sales_invoice_items
        WHERE invoice_id=?
        ORDER BY id
        """

        cursor = self.execute(sql, (invoice_id,))

        return cursor.fetchall()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        sql = """
        SELECT *

        FROM sales_invoices

        WHERE

            invoice_number LIKE ?

        ORDER BY invoice_date DESC
        """

        cursor = self.execute(
            sql,
            (
                f"%{keyword}%",
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Get All
    # =====================================================

    def get_all(self):

        sql = """
        SELECT *

        FROM sales_invoices

        ORDER BY invoice_date DESC,id DESC
        """

        cursor = self.execute(sql)

        return cursor.fetchall()


    def list_for_company(self, company_id: int, keyword: str | None = None):
        """Return sales invoices joined to customer names within one company."""
        sql = (
            "SELECT s.*, COALESCE(c.name, '') AS customer_name "
            "FROM sales_invoices s "
            "LEFT JOIN customers c ON c.id=s.customer_id AND c.company_id=s.company_id "
            "WHERE s.company_id=?"
        )
        params: list[object] = [int(company_id)]
        term = str(keyword or '').strip()
        if term:
            sql += " AND (s.invoice_number LIKE ? OR c.name LIKE ?)"
            params.extend((f"%{term}%", f"%{term}%"))
        sql += " ORDER BY s.id DESC"
        return self.fetchall(sql, tuple(params))

    def get_product_name(self, product_id: int, company_id: int):
        row = self.fetchone(
            "SELECT name FROM products WHERE id=? AND company_id=?",
            (int(product_id), int(company_id)),
        )
        return row["name"] if row else None

    # =====================================================
    # Delete
    # =====================================================

    def delete_invoice(
        self,
        invoice_id: int,
    ):

        sql = """
        DELETE FROM sales_invoices
        WHERE id=?
        """

        self.execute(
            sql,
            (
                invoice_id,
            ),
        )


    # =====================================================
    # Last Invoice Number
    # =====================================================

    def get_last_invoice_number(self):

        sql = """
        SELECT invoice_number

        FROM sales_invoices

        ORDER BY id DESC

        LIMIT 1
        """

        cursor = self.execute(sql)

        row = cursor.fetchone()

        if row:
            return row["invoice_number"]

        return None
