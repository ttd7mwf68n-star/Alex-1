"""Compatibility export; accounting_core owns P&L read SQL."""
from alexerp.accounting.profit_loss_repository import ProfitLossRepository

__all__ = ["ProfitLossRepository"]
