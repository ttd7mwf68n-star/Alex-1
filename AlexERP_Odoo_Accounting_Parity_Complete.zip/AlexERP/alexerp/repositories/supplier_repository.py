"""
AlexERP — Business Management System
Supplier Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class SupplierRepository(BaseRepository):

    table_name = "suppliers"

    # =====================================================
    # Add Supplier
    # =====================================================

    def add(
        self,
        company_id: int,
        code: str,
        name: str,
        tax_number: str = "",
        phone: str = "",
        mobile: str = "",
        email: str = "",
        address: str = "",
        city: str = "",
        account_id: int | None = None,
    ) -> int:

        sql = """
        INSERT INTO suppliers(

            company_id,
            code,
            name,
            tax_number,
            phone,
            mobile,
            email,
            address,
            city,
            account_id

        )
        VALUES(?,?,?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                code,
                name,
                tax_number,
                phone,
                mobile,
                email,
                address,
                city,
                account_id,
            ),
        )

        return cursor.lastrowid

    # =====================================================
    # Update Supplier
    # =====================================================

    def update(
        self,
        supplier_id: int,
        code: str,
        name: str,
        tax_number: str,
        phone: str,
        mobile: str,
        email: str,
        address: str,
        city: str,
        account_id: int | None,
    ):

        sql = """
        UPDATE suppliers
        SET

            code=?,
            name=?,
            tax_number=?,
            phone=?,
            mobile=?,
            email=?,
            address=?,
            city=?,
            account_id=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                code,
                name,
                tax_number,
                phone,
                mobile,
                email,
                address,
                city,
                account_id,
                supplier_id,
            ),
        )

    # =====================================================
    # Find By Code
    # =====================================================

    def find_by_code(
        self,
        company_id: int,
        code: str,
    ):

        sql = """
        SELECT *
        FROM suppliers
        WHERE company_id=? AND code=?
        """

        cursor = self.execute(sql, (company_id, code))

        return cursor.fetchone()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        sql = """
        SELECT *
        FROM suppliers

        WHERE

            code LIKE ?
            OR
            name LIKE ?
            OR
            phone LIKE ?

        ORDER BY name
        """

        cursor = self.execute(
            sql,
            (
                f"%{keyword}%",
                f"%{keyword}%",
                f"%{keyword}%",
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Update Balance
    # =====================================================

    def update_balance(
        self,
        supplier_id: int,
        balance: float,
    ):

        sql = """
        UPDATE suppliers
        SET

            current_balance=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                balance,
                supplier_id,
            ),
        )