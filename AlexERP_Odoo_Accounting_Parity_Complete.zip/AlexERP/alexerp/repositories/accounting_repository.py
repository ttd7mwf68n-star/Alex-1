"""Backward-compatible import path for the accounting-core repository."""
from alexerp.accounting.repository import AccountingRepository

__all__ = ["AccountingRepository"]
