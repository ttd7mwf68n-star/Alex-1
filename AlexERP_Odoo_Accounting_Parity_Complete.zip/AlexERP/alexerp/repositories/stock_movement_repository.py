"""
AlexERP — Business Management System
Stock Movement Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class StockMovementRepository(BaseRepository):

    table_name = "stock_movements"

    # =====================================================
    # Add Movement
    # =====================================================

    def add_movement(
        self,
        company_id: int,
        branch_id: int,
        warehouse_id: int,
        product_id: int,
        transaction_type: str,
        reference_type: str | None,
        reference_id: int | None,
        quantity_in: float = 0,
        quantity_out: float = 0,
        unit_cost: float = 0,
        balance_after: float = 0,
        notes: str = "",
        created_by: int | None = None,
        location_id: int | None = None,
        commit: bool = True,
    ) -> int:

        sql = """
        INSERT INTO stock_movements(

            company_id,
            branch_id,
            warehouse_id,
            location_id,
            product_id,
            transaction_type,
            reference_type,
            reference_id,
            quantity_in,
            quantity_out,
            unit_cost,
            balance_after,
            notes,
            created_by

        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                branch_id,
                warehouse_id,
                location_id,
                product_id,
                transaction_type,
                reference_type,
                reference_id,
                quantity_in,
                quantity_out,
                unit_cost,
                balance_after,
                notes,
                created_by,
            ),
        )

        if commit:
            self.commit()

        return cursor.lastrowid

    # =====================================================
    # Product Movements
    # =====================================================

    def get_product_movements(
        self,
        product_id: int,
    ):

        sql = """
        SELECT *

        FROM stock_movements

        WHERE product_id=?

        ORDER BY transaction_date,id
        """

        cursor = self.execute(
            sql,
            (
                product_id,
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Warehouse Movements
    # =====================================================

    def get_warehouse_movements(
        self,
        warehouse_id: int,
    ):

        sql = """
        SELECT *

        FROM stock_movements

        WHERE warehouse_id=?

        ORDER BY transaction_date,id
        """

        cursor = self.execute(
            sql,
            (
                warehouse_id,
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Reference Movements
    # =====================================================

    def get_reference_movements(
        self,
        reference_type: str | None,
        reference_id: int | None,
    ):

        sql = """
        SELECT *

        FROM stock_movements

        WHERE

            reference_type=?
            AND
            reference_id=?

        ORDER BY id
        """

        cursor = self.execute(
            sql,
            (
                reference_type,
                reference_id,
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Delete Reference
    # =====================================================

    def delete_reference(
        self,
        reference_type: str | None,
        reference_id: int | None,
    ):

        sql = """
        DELETE

        FROM stock_movements

        WHERE

            reference_type=?
            AND
            reference_id=?
        """

        self.execute(
            sql,
            (
                reference_type,
                reference_id,
            ),
        )

        self.commit()

    # =====================================================
    # Last Balance
    # =====================================================

    def get_last_balance(
        self,
        product_id: int,
    ) -> float:

        sql = """
        SELECT balance_after

        FROM stock_movements

        WHERE product_id=?

        ORDER BY id DESC

        LIMIT 1
        """

        cursor = self.execute(
            sql,
            (
                product_id,
            ),
        )

        row = cursor.fetchone()

        if row:

            return float(row["balance_after"])

        return 0.0


    def add(self, **kwargs) -> int:
        """Backward-compatible alias used by older stock services."""
        return self.add_movement(**kwargs)

    def cardex(self, product_id: int):
        return self.get_product_movements(product_id)
