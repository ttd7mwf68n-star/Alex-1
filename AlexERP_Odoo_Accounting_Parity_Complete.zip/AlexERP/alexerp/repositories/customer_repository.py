"""
AlexERP — Business Management System
Customer Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class CustomerRepository(BaseRepository):

    table_name = "customers"

    # =====================================================
    # Add Customer
    # =====================================================

    def add(
        self,
        company_id: int,
        code: str,
        name: str,
        tax_number: str = "",
        phone: str = "",
        mobile: str = "",
        email: str = "",
        address: str = "",
        city: str = "",
        credit_limit: float = 0,
        account_id: int | None = None,
    ) -> int:

        sql = """
        INSERT INTO customers(

            company_id,
            code,
            name,
            tax_number,
            phone,
            mobile,
            email,
            address,
            city,
            credit_limit,
            account_id

        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                code,
                name,
                tax_number,
                phone,
                mobile,
                email,
                address,
                city,
                credit_limit,
                account_id,
            ),
        )

        return cursor.lastrowid

    # =====================================================
    # Update Customer
    # =====================================================

    def update(
        self,
        customer_id: int,
        code: str,
        name: str,
        tax_number: str,
        phone: str,
        mobile: str,
        email: str,
        address: str,
        city: str,
        credit_limit: float,
        account_id: int | None,
    ):

        sql = """
        UPDATE customers
        SET

            code=?,
            name=?,
            tax_number=?,
            phone=?,
            mobile=?,
            email=?,
            address=?,
            city=?,
            credit_limit=?,
            account_id=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                code,
                name,
                tax_number,
                phone,
                mobile,
                email,
                address,
                city,
                credit_limit,
                account_id,
                customer_id,
            ),
        )

    # =====================================================
    # Find By Code
    # =====================================================

    def find_by_code(self, company_id: int, code: str):

        sql = """
        SELECT *
        FROM customers
        WHERE company_id=? AND code=?
        """

        cursor = self.execute(sql, (company_id, code))

        return cursor.fetchone()

    def find_all_by_company(self, company_id: int):
        cursor = self.execute(
            """SELECT c.*,coa.account_code AS ledger_account_code
               FROM customers c
               LEFT JOIN chart_of_accounts coa ON coa.id=c.account_id
               WHERE c.company_id=?
               ORDER BY c.name,c.id""",
            (company_id,),
        )
        return cursor.fetchall()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        sql = """
        SELECT *
        FROM customers

        WHERE

            code LIKE ?
            OR
            name LIKE ?
            OR
            phone LIKE ?

        ORDER BY name
        """

        cursor = self.execute(
            sql,
            (
                f"%{keyword}%",
                f"%{keyword}%",
                f"%{keyword}%",
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Update Balance
    # =====================================================

    def update_balance(
        self,
        customer_id: int,
        balance: float,
    ):

        sql = """
        UPDATE customers
        SET

            current_balance=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                balance,
                customer_id,
            ),
        )