"""Compatibility export; accounting_core owns trial-balance read SQL."""
from alexerp.accounting.trial_balance_repository import TrialBalanceRepository

__all__ = ["TrialBalanceRepository"]
