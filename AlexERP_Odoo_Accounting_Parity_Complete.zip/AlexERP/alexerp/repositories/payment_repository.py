"""Supplier payment persistence."""
from __future__ import annotations
from alexerp.repositories.base_repository import BaseRepository


class PaymentRepository(BaseRepository):
    table_name = "payments"

    def create(self, company_id, branch_id, payment_number, payment_date,
               supplier_id, cash_box_id, amount, notes, created_by):
        existing = self.fetchone(
            "SELECT id FROM payments WHERE company_id=? AND branch_id=? AND payment_number=? LIMIT 1",
            (company_id, branch_id, payment_number),
        )
        if existing is not None:
            raise ValueError(f"Payment number already exists: {payment_number}")
        cur = self.execute(
            """INSERT INTO payments(company_id, branch_id, payment_number,
               payment_date, supplier_id, cash_box_id, amount, notes, created_by, status)
               VALUES(?,?,?,?,?,?,?,?,?,'POSTED')""",
            (company_id, branch_id, payment_number, payment_date, supplier_id,
             cash_box_id, amount, notes, created_by))
        return cur.lastrowid

    def get_for_actor(self, payment_id, actor_user_id):
        """Return a payment only when the active actor belongs to its company."""
        return self.fetchone(
            """SELECT p.* FROM payments p
               JOIN users u ON u.id=? AND u.company_id=p.company_id AND u.is_active=1
               WHERE p.id=?""",
            (actor_user_id, payment_id),
        )

    def set_status(self, payment_id, company_id, status):
        cursor = self.execute(
            "UPDATE payments SET status=? WHERE id=? AND company_id=?",
            (status, payment_id, company_id),
        )
        if cursor.rowcount != 1:
            raise ValueError("Supplier payment is outside the actor company scope.")
