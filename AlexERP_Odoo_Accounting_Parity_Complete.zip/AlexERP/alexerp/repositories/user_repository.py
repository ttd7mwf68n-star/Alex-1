"""
AlexERP — Business Management System
User Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class UserRepository(BaseRepository):

    table_name = "users"

    # =====================================================
    # Add User
    # =====================================================

    def add(
        self,
        username: str,
        password_hash: str,
        full_name: str,
        role_id: int | None = None,
        company_id: int | None = None,
        branch_id: int | None = None,
        email: str | None = None,
        phone: str = "",
    ) -> int:

        email = str(email or "").strip() or None

        sql = """
        INSERT INTO users(

            username,
            password_hash,
            full_name,
            role_id,
            company_id,
            branch_id,
            email,
            phone

        )
        VALUES(?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                username,
                password_hash,
                full_name,
                role_id,
                company_id,
                branch_id,
                email,
                phone,
            ),
        )

        return cursor.lastrowid

    # =====================================================
    # Find By Username
    # =====================================================

    def find_by_username(self, username: str):

        sql = """
        SELECT *
        FROM users
        WHERE username=?
        """

        cursor = self.execute(sql, (username,))

        return cursor.fetchone()

    # =====================================================
    # Update Password
    # =====================================================

    def update_password(
        self,
        user_id: int,
        password_hash: str,
    ):

        sql = """
        UPDATE users
        SET

            password_hash=?,
            password_changed_at=CURRENT_TIMESTAMP,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                password_hash,
                user_id,
            ),
        )

    # =====================================================
    # Update Last Login
    # =====================================================

    def update_last_login(
        self,
        user_id: int,
    ):

        sql = """
        UPDATE users
        SET

            last_login=CURRENT_TIMESTAMP,
            failed_login_attempts=0,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(sql, (user_id,))

    # =====================================================
    # Increase Failed Login Attempts
    # =====================================================

    def increase_failed_login(
        self,
        user_id: int,
    ):

        sql = """
        UPDATE users
        SET

            failed_login_attempts=failed_login_attempts+1,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(sql, (user_id,))

    # =====================================================
    # Lock User
    # =====================================================

    def lock_user(
        self,
        user_id: int,
        locked_until,
    ):

        sql = """
        UPDATE users
        SET

            locked_until=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                locked_until,
                user_id,
            ),
        )

    # =====================================================
    # Activate / Deactivate
    # =====================================================

    def set_active(
        self,
        user_id: int,
        active: bool,
    ):

        sql = """
        UPDATE users
        SET

            is_active=?,
            updated_at=CURRENT_TIMESTAMP

        WHERE id=?
        """

        self.execute(
            sql,
            (
                int(active),
                user_id,
            ),
        )

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        sql = """
        SELECT *
        FROM users

        WHERE

            username LIKE ?
            OR
            full_name LIKE ?

        ORDER BY full_name
        """

        cursor = self.execute(
            sql,
            (
                f"%{keyword}%",
                f"%{keyword}%",
            ),
        )

        return cursor.fetchall()
