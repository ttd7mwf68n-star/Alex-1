from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class InventoryCountRepository(BaseRepository):

    table_name = "inventory_counts"

    # -------------------------------------------------

    def create_count(
        self,
        company_id,
        branch_id,
        warehouse_id,
        count_number,
        count_date,
        notes,
        created_by,
    ):
        cursor = self.execute(
            """
            INSERT INTO inventory_counts(
                company_id,
                branch_id,
                warehouse_id,
                count_number,
                count_date,
                notes,
                created_by
            )
            VALUES(?,?,?,?,?,?,?)
            """,
            (
                company_id,
                branch_id,
                warehouse_id,
                count_number,
                count_date,
                notes,
                created_by,
            ),
        )
        return cursor.lastrowid

    # =====================================================
    # Add Item
    # =====================================================

    def add_item(
        self,
        inventory_count_id,
        product_id,
        system_quantity,
        counted_quantity,
        difference,
        unit_cost,
    ):
        self.execute(
            """
            INSERT INTO inventory_count_items(
                inventory_count_id,
                product_id,
                system_quantity,
                counted_quantity,
                difference,
                unit_cost
            )
            VALUES(?,?,?,?,?,?)
            """,
            (
                inventory_count_id,
                product_id,
                system_quantity,
                counted_quantity,
                difference,
                unit_cost,
            ),
        )

    # =====================================================
    # Get Count
    # =====================================================

    def get_count(self, count_id):
        cursor = self.execute(
            """
            SELECT *
            FROM inventory_counts
            WHERE id=?
            """,
            (count_id,),
        )
        return cursor.fetchone()

    # =====================================================
    # Get Items
    # =====================================================

    def get_items(self, count_id):
        cursor = self.execute(
            """
            SELECT *
            FROM inventory_count_items
            WHERE inventory_count_id=?
            ORDER BY id
            """,
            (count_id,),
        )
        return cursor.fetchall()

    # =====================================================
    # Close Count
    # =====================================================

    def close_count(self, count_id):
        self.execute(
            """
            UPDATE inventory_counts
            SET status='Posted'
            WHERE id=?
            """,
            (count_id,),
        )
