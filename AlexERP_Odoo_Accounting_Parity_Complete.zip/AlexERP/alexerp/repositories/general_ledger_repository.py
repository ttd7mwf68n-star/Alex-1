"""Compatibility export; accounting_core owns general-ledger read SQL."""
from alexerp.accounting.general_ledger_repository import GeneralLedgerRepository

__all__ = ["GeneralLedgerRepository"]
