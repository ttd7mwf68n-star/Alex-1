"""
AlexERP — Business Management System
Purchase Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class PurchaseRepository(BaseRepository):

    table_name = "purchase_invoices"

    # =====================================================
    # Create Purchase Invoice
    # =====================================================

    def create_invoice(
        self,
        company_id: int,
        branch_id: int,
        supplier_id: int,
        invoice_number: str,
        supplier_invoice_number: str,
        invoice_date: str,
        subtotal: float,
        discount: float,
        tax: float,
        total: float,
        paid_amount: float,
        remaining_amount: float,
        notes: str,
        created_by: int,
        payment_terms_days: int = 0,
        due_date: str | None = None,
    ) -> int:

        sql = """
        INSERT INTO purchase_invoices(

            company_id,
            branch_id,
            supplier_id,
            invoice_number,
            supplier_invoice_number,
            invoice_date,
            subtotal,
            discount,
            tax,
            total,
            paid_amount,
            remaining_amount,
            notes,
            created_by,
            payment_terms_days,
            due_date

        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                branch_id,
                supplier_id,
                invoice_number,
                supplier_invoice_number,
                invoice_date,
                subtotal,
                discount,
                tax,
                total,
                paid_amount,
                remaining_amount,
                notes,
                created_by,
                int(payment_terms_days),
                due_date,
            ),
        )

        return cursor.lastrowid

    # =====================================================
    # Add Invoice Item
    # =====================================================

    def add_item(
        self,
        invoice_id: int,
        product_id: int,
        warehouse_id: int,
        quantity: float,
        unit_cost: float,
        discount: float,
        tax: float,
        total: float,
    ):

        sql = """
        INSERT INTO purchase_invoice_items(

            invoice_id,
            product_id,
            warehouse_id,
            quantity,
            unit_cost,
            discount,
            tax,
            total

        )
        VALUES(?,?,?,?,?,?,?,?)
        """

        self.execute(
            sql,
            (
                invoice_id,
                product_id,
                warehouse_id,
                quantity,
                unit_cost,
                discount,
                tax,
                total,
            ),
        )

    # =====================================================
    # Get Invoice
    # =====================================================

    def get_invoice(self, invoice_id: int):

        sql = """
        SELECT *
        FROM purchase_invoices
        WHERE id=?
        """

        cursor = self.execute(sql, (invoice_id,))

        return cursor.fetchone()

    # =====================================================
    # Get Invoice Items
    # =====================================================

    def get_items(self, invoice_id: int):

        sql = """
        SELECT *
        FROM purchase_invoice_items
        WHERE invoice_id=?
        ORDER BY id
        """

        cursor = self.execute(sql, (invoice_id,))

        return cursor.fetchall()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        sql = """
        SELECT *
        FROM purchase_invoices

        WHERE

            invoice_number LIKE ?

        ORDER BY invoice_date DESC
        """

        cursor = self.execute(
            sql,
            (
                f"%{keyword}%",
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Delete Invoice
    # =====================================================

    def delete_invoice(self, invoice_id: int):

        sql = """
        DELETE FROM purchase_invoices
        WHERE id=?
        """

        self.execute(sql, (invoice_id,))

    # =====================================================
    # Get Last Invoice Number
    # =====================================================

    def get_last_invoice_number(self) -> str | None:

        sql = """
        SELECT invoice_number
        FROM purchase_invoices
        ORDER BY id DESC
        LIMIT 1
        """

        cursor = self.execute(sql)
        row = cursor.fetchone()

        if row:
            return row["invoice_number"]

        return None

    # =====================================================
    # Update Totals
    # =====================================================

    def update_totals(
        self,
        invoice_id: int,
        subtotal: float,
        discount: float,
        tax: float,
        total: float,
        paid_amount: float,
        remaining_amount: float,
    ):

        sql = """
        UPDATE purchase_invoices
        SET
            subtotal=?,
            discount=?,
            tax=?,
            total=?,
            paid_amount=?,
            remaining_amount=?
        WHERE id=?
        """

        self.execute(
            sql,
            (
                subtotal,
                discount,
                tax,
                total,
                paid_amount,
                remaining_amount,
                invoice_id,
            ),
        )

    def delete_items(self, invoice_id: int) -> None:
        self.execute("DELETE FROM purchase_invoice_items WHERE invoice_id=?", (invoice_id,))

    def get_all(self):
        cursor = self.execute(
            "SELECT * FROM purchase_invoices ORDER BY invoice_date DESC, id DESC"
        )
        return cursor.fetchall()

    def exists(self, invoice_id: int) -> bool:
        return self.get_invoice(invoice_id) is not None
