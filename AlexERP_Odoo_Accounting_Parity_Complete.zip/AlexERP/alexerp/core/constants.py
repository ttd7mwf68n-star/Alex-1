"""
AlexERP — Business Management System
Application Constants
"""

# ==========================================================
# Window
# ==========================================================

WINDOW_WIDTH = 1400
WINDOW_HEIGHT = 800
WINDOW_SIZE = f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}"

STATUSBAR_HEIGHT = 36

# ==========================================================
# Fonts
# ==========================================================

DEFAULT_FONT = "Segoe UI"

FONT_12 = (DEFAULT_FONT, 12)
FONT_14 = (DEFAULT_FONT, 14)

# ==========================================================
# Theme
# ==========================================================

DEFAULT_APPEARANCE = "System"
DEFAULT_THEME = "blue"

# ==========================================================
# Inventory
# ==========================================================

class StockTransactionType:
    PURCHASE = "PURCHASE"
    SALE = "SALE"
    SALE_RETURN = "SALE_RETURN"
    PURCHASE_RETURN = "PURCHASE_RETURN"
    TRANSFER_IN = "TRANSFER_IN"
    TRANSFER_OUT = "TRANSFER_OUT"
    ADJUSTMENT = "ADJUSTMENT"
    OPENING = "OPENING"
    INVENTORY_COUNT = "INVENTORY_COUNT"

# ==========================================================
# References
# ==========================================================

class ReferenceType:
    SALE = "SALE"
    SALES = "SALE"  # Backward-compatible alias
    PURCHASE = "PURCHASE"
    SALE_RETURN = "SALE_RETURN"
    RETURN = "SALE_RETURN"  # Backward-compatible alias
    CUSTOMER_NOTE = "CUSTOMER_NOTE"
    PURCHASE_RETURN = "PURCHASE_RETURN"
    TRANSFER = "TRANSFER"
    ADJUSTMENT = "ADJUSTMENT"
    OPENING = "OPENING"

# ==========================================================
# User Roles
# ==========================================================

class UserRole:
    ADMIN = "ADMIN"
    MANAGER = "MANAGER"
    ACCOUNTANT = "ACCOUNTANT"
    CASHIER = "CASHIER"
    STOREKEEPER = "STOREKEEPER"
    SALES = "SALES"

# ==========================================================
# Invoice Status
# ==========================================================

class InvoiceStatus:
    DRAFT = "DRAFT"
    POSTED = "POSTED"
    PAID = "PAID"
    PARTIAL = "PARTIAL"
    CANCELLED = "CANCELLED"

# ==========================================================
# Payment Method
# ==========================================================

class PaymentMethod:
    CASH = "CASH"
    BANK = "BANK"
    VISA = "VISA"
    MASTER = "MASTER"
    CHEQUE = "CHEQUE"
    TRANSFER = "TRANSFER"
