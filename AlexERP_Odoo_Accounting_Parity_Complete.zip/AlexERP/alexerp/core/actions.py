"""
AlexERP — Business Management System
Toolbar Action Manager
"""

from __future__ import annotations

from enum import Enum


class Action(str, Enum):
    NEW = "new"
    SAVE = "save"
    EDIT = "edit"
    DELETE = "delete"
    SEARCH = "search"
    PRINT = "print"
    EXPORT = "export"
    REFRESH = "refresh"



class ActionManager:

    def __init__(self):

        self.page = None

    # -----------------------------------------------------

    def bind(self, page):

        self.page = page

    # -----------------------------------------------------

    def _call(self, *methods):

        if self.page is None:
            return

        for method in methods:

            func = getattr(self.page, method, None)

            if callable(func):
                return func()

    # -----------------------------------------------------

    def new(self):
        return self._call(
            "new",
            "new_customer",
            "new_product",
            "new_invoice",
            "new_supplier",
        )

    # -----------------------------------------------------

    def save(self):
        return self._call(
            "save",
            "save_customer",
            "save_product",
            "save_invoice",
            "save_supplier",
        )

    # -----------------------------------------------------

    def edit(self):
        return self._call(
            "edit",
            "edit_customer",
            "edit_product",
            "edit_invoice",
        )

    # -----------------------------------------------------

    def delete(self):
        return self._call(
            "delete",
            "delete_customer",
            "delete_product",
            "delete_invoice",
        )

    # -----------------------------------------------------

    def search(self):
        return self._call(
            "search",
            "search_customer",
            "search_product",
            "search_invoice",
        )

    # -----------------------------------------------------

    def print(self):
        return self._call(
            "print",
            "print_customer_list",
            "print_products",
            "print_invoice",
        )

    # -----------------------------------------------------

    def export(self):
        return self._call(
            "export",
            "export_customer_list",
            "export_products",
            "export_invoice",
        )    