"""
AlexERP — Business Management System
Core Validators

جميع دوال التحقق الخاصة بالمشروع.
لا يتم عرض رسائل للمستخدم هنا، فقط يتم إرجاع
True / False أو رفع ValidationError.
"""

from __future__ import annotations

import re

from alexerp.core.error import ValidationError


# ==========================================================
# General
# ==========================================================

def required(value: str, field_name: str = "الحقل") -> str:
    """
    يتأكد أن القيمة ليست فارغة.
    """
    if value is None or str(value).strip() == "":
        raise ValidationError(f"{field_name} مطلوب.")
    return str(value).strip()


# ==========================================================
# Numbers
# ==========================================================

def positive_number(value, field_name="القيمة") -> float:
    """
    رقم أكبر من صفر.
    """

    try:
        number = float(value)
    except Exception:
        raise ValidationError(f"{field_name} غير صالح.")

    if number <= 0:
        raise ValidationError(f"{field_name} يجب أن يكون أكبر من صفر.")

    return number


def non_negative_number(value, field_name="القيمة") -> float:
    """
    رقم صفر أو أكبر.
    """

    try:
        number = float(value)
    except Exception:
        raise ValidationError(f"{field_name} غير صالح.")

    if number < 0:
        raise ValidationError(f"{field_name} لا يمكن أن يكون سالبًا.")

    return number


def positive_integer(value, field_name="القيمة") -> int:
    """
    عدد صحيح أكبر من صفر.
    """

    try:
        number = int(value)
    except Exception:
        raise ValidationError(f"{field_name} غير صالح.")

    if number <= 0:
        raise ValidationError(f"{field_name} يجب أن يكون أكبر من صفر.")

    return number


# ==========================================================
# Product
# ==========================================================

def product_name(name: str) -> str:
    """
    اسم المنتج.
    """

    name = required(name, "اسم المنتج")

    if len(name) < 2:
        raise ValidationError("اسم المنتج قصير جدًا.")

    return name


def product_quantity(quantity) -> int:
    """
    كمية المنتج.
    """

    return int(non_negative_number(quantity, "الكمية"))


def product_price(price) -> float:
    """
    سعر المنتج.
    """

    return positive_number(price, "السعر")


# ==========================================================
# Customer
# ==========================================================

def customer_name(name: str) -> str:
    """
    اسم العميل.
    """

    name = required(name, "اسم العميل")

    if len(name) < 2:
        raise ValidationError("اسم العميل قصير جدًا.")

    return name


# ==========================================================
# Supplier
# ==========================================================

def supplier_name(name: str) -> str:
    """
    اسم المورد.
    """

    name = required(name, "اسم المورد")

    if len(name) < 2:
        raise ValidationError("اسم المورد قصير جدًا.")

    return name


# ==========================================================
# Phone
# ==========================================================

_PHONE_REGEX = re.compile(r"^[0-9+\-\s()]{6,20}$")


def phone(phone_number: str) -> str:
    """
    التحقق من رقم الهاتف.
    """

    phone_number = str(phone_number).strip()

    if phone_number == "":
        return ""

    if not _PHONE_REGEX.fullmatch(phone_number):
        raise ValidationError("رقم الهاتف غير صحيح.")

    return phone_number


# ==========================================================
# Email
# ==========================================================

_EMAIL_REGEX = re.compile(
    r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
)


def email(address: str) -> str:
    """
    التحقق من البريد الإلكتروني.
    """

    address = str(address).strip()

    if address == "":
        return ""

    if not _EMAIL_REGEX.fullmatch(address):
        raise ValidationError("البريد الإلكتروني غير صحيح.")

    return address


# ==========================================================
# Barcode
# ==========================================================

def barcode(code: str) -> str:
    """
    باركود المنتج.
    """

    code = str(code).strip()

    if code == "":
        return ""

    if len(code) < 4:
        raise ValidationError("الباركود غير صحيح.")

    return code


# ==========================================================
# Code
# ==========================================================

def entity_code(code: str, field_name="الكود") -> str:
    """
    كود عام.
    """

    code = required(code, field_name)

    if len(code) < 2:
        raise ValidationError(f"{field_name} غير صالح.")

    return code