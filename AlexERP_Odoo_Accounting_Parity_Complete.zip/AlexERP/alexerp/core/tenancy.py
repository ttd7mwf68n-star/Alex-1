"""Tenant (company/branch) scope guards for the service layer.

Every document service must call these before posting, so that records from one
company can never be mixed into another company's documents, whichever front-end
(desktop, mobile API, AI assistant) calls the service.
"""
from __future__ import annotations

from alexerp.database.db import Database


class TenantScopeError(ValueError):
    """A referenced record does not belong to the document's company/branch."""


def _one(sql: str, params: tuple):
    return Database.connect().execute(sql, params).fetchone()


def require_branch(company_id: int, branch_id: int | None) -> None:
    if branch_id is None:
        return
    row = _one("SELECT company_id FROM branches WHERE id=?", (branch_id,))
    if row is None or int(row[0]) != int(company_id):
        raise TenantScopeError("Branch does not belong to this company.")


def _require_party(table: str, label: str, company_id: int, party_id: int) -> None:
    row = _one(f"SELECT company_id FROM {table} WHERE id=?", (party_id,))  # table is a fixed literal
    if row is None or row[0] is None or int(row[0]) != int(company_id):
        raise TenantScopeError(f"{label} does not belong to this company.")


def require_customer(company_id: int, customer_id: int) -> None:
    _require_party("customers", "Customer", company_id, customer_id)


def require_supplier(company_id: int, supplier_id: int) -> None:
    _require_party("suppliers", "Supplier", company_id, supplier_id)


def require_account(company_id: int, account_id: int | None, label: str = "Account") -> None:
    if account_id is None:
        return
    row = _one("SELECT company_id FROM chart_of_accounts WHERE id=?", (account_id,))
    if row is None or row[0] is None or int(row[0]) != int(company_id):
        raise TenantScopeError(f"{label} does not belong to this company.")


def require_accounts(company_id: int, **accounts: int | None) -> None:
    for label, account_id in accounts.items():
        require_account(company_id, account_id, label)


def require_item_scope(company_id: int, branch_id: int | None,
                       product_id: int, warehouse_id: int) -> None:
    product = _one("SELECT company_id, branch_id FROM products WHERE id=?", (product_id,))
    warehouse = _one("SELECT company_id, branch_id FROM warehouses WHERE id=?", (warehouse_id,))
    if product is None or product[0] is None or int(product[0]) != int(company_id):
        raise TenantScopeError(f"Product {product_id} does not belong to this company.")
    if warehouse is None or warehouse[0] is None or int(warehouse[0]) != int(company_id):
        raise TenantScopeError(f"Warehouse {warehouse_id} does not belong to this company.")
    if branch_id is not None:
        for name, row in (("Product", product), ("Warehouse", warehouse)):
            if row[1] is not None and int(row[1]) != int(branch_id):
                raise TenantScopeError(f"{name} does not belong to this branch.")
