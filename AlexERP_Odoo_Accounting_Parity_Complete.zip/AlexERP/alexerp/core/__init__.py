from .actions import ActionManager

actions = ActionManager()