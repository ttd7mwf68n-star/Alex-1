"""Validated registry for Alex ERP application and technical-module manifests.

The registry validates metadata and dependency relationships only. It does not
install, upgrade, import, or uninstall modules; runtime lifecycle management
remains deliberately separate until database migrations and rollback semantics
are defined.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

_MODULE_ID = re.compile(r"^[a-z][a-z0-9_]*$")
_PACKAGE_NAME = re.compile(r"^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)*$")
_PERMISSION_KEY = re.compile(r"^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+$")
_ENTRYPOINT = re.compile(r"^alexerp\.ui(?:\.[a-zA-Z_][a-zA-Z0-9_]*)+\.[A-Z][a-zA-Z0-9_]*$")
_REQUIRED_BASE = {"id", "name", "version", "category", "description", "state", "depends"}
_REQUIRED_APPLICATION = {"entrypoint", "page_file", "permissions", "icon", "navigation_section", "sequence"}
_ALLOWED_STATES = {"available", "planned", "disabled"}


@dataclass(frozen=True)
class ModuleManifest:
    id: str
    name: str
    version: str
    category: str
    description: str
    state: str
    application: bool
    entrypoint: str | None
    page_file: str | None
    icon: str | None
    navigation_section: str | None
    sequence: int
    permissions: tuple[str, ...]
    depends: tuple[str, ...]
    integrates_with: tuple[str, ...]
    python_package: str | None
    source: Path


class ModuleRegistryError(ValueError):
    """Raised when a module manifest is invalid or ambiguous."""


class ModuleRegistry:
    def __init__(self, manifest_dir: str | Path | None = None):
        self.manifest_dir = (
            Path(manifest_dir) if manifest_dir
            else Path(__file__).resolve().parents[1] / "modules" / "manifests"
        )

    def load(self) -> dict[str, ModuleManifest]:
        if not self.manifest_dir.exists():
            return {}
        manifests: dict[str, ModuleManifest] = {}
        for path in sorted(self.manifest_dir.glob("*.json")):
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise ModuleRegistryError(f"Invalid manifest {path.name}: {exc}") from exc
            if not isinstance(raw, dict) or not _REQUIRED_BASE.issubset(raw):
                missing = sorted(_REQUIRED_BASE - set(raw if isinstance(raw, dict) else {}))
                raise ModuleRegistryError(f"Manifest {path.name} missing fields: {', '.join(missing)}")

            module_id = raw["id"]
            if not isinstance(module_id, str) or not _MODULE_ID.fullmatch(module_id):
                raise ModuleRegistryError(f"Invalid module id in {path.name}")
            if module_id in manifests:
                raise ModuleRegistryError(f"Duplicate module id: {module_id}")
            if path.stem != module_id:
                raise ModuleRegistryError(f"Manifest filename must match id: {module_id}")
            if raw["state"] not in _ALLOWED_STATES:
                raise ModuleRegistryError(f"Invalid state for module {module_id}")
            application = raw.get("application", False)
            if not isinstance(application, bool):
                raise ModuleRegistryError(f"application must be a boolean: {module_id}")

            for field in ("depends", "integrates_with", "permissions"):
                value = raw.get(field, [])
                if not isinstance(value, list) or not all(isinstance(v, str) and v.strip() for v in value):
                    raise ModuleRegistryError(f"{field} must be a list of non-empty strings: {module_id}")
                if len(value) != len(set(value)):
                    raise ModuleRegistryError(f"Duplicate values in {field}: {module_id}")
            permissions = raw.get("permissions", [])
            depends = raw.get("depends", [])
            integrates_with = raw.get("integrates_with", [])
            python_package = raw.get("python_package")
            if not all(_PERMISSION_KEY.fullmatch(value) for value in permissions):
                raise ModuleRegistryError(f"Invalid permission key in module {module_id}")
            if not all(
                isinstance(raw[field], str) and raw[field].strip()
                for field in ("name", "version", "category", "description")
            ):
                raise ModuleRegistryError(f"Invalid text field in module {module_id}")
            if python_package is not None and (
                not isinstance(python_package, str) or not _PACKAGE_NAME.fullmatch(python_package)
            ):
                raise ModuleRegistryError(f"Invalid python_package in module {module_id}")

            entrypoint = raw.get("entrypoint")
            page_file_value = raw.get("page_file")
            icon = raw.get("icon")
            navigation_section = raw.get("navigation_section")
            sequence = raw.get("sequence", 10000)
            if type(sequence) is not int or sequence < 0:
                raise ModuleRegistryError(f"sequence must be a non-negative integer: {module_id}")

            if application:
                missing = sorted(_REQUIRED_APPLICATION - set(raw))
                if missing:
                    raise ModuleRegistryError(
                        f"Application manifest {module_id} missing fields: {', '.join(missing)}"
                    )
                if not permissions:
                    raise ModuleRegistryError(f"Application {module_id} must declare access permissions")
                if not isinstance(icon, str) or not icon.strip():
                    raise ModuleRegistryError(f"Application {module_id} must declare an icon")
                if not isinstance(navigation_section, str) or not navigation_section.strip():
                    raise ModuleRegistryError(f"Application {module_id} must declare a navigation section")
                if not isinstance(entrypoint, str) or not _ENTRYPOINT.fullmatch(entrypoint):
                    raise ModuleRegistryError(f"Invalid entrypoint in module {module_id}")
                if not isinstance(page_file_value, str) or not page_file_value.strip():
                    raise ModuleRegistryError(f"Invalid page_file in module {module_id}")
                page_file = Path(page_file_value)
                if page_file.is_absolute() or ".." in page_file.parts:
                    raise ModuleRegistryError(f"Unsafe page_file path in module {module_id}")
                expected_page = Path(*entrypoint.split(".")[:-1]).with_suffix(".py")
                if page_file != expected_page:
                    raise ModuleRegistryError(f"page_file does not match entrypoint in module {module_id}")
            else:
                if not python_package:
                    raise ModuleRegistryError(
                        f"Technical module {module_id} must declare its python_package"
                    )
                if entrypoint is not None and (not isinstance(entrypoint, str) or not _ENTRYPOINT.fullmatch(entrypoint)):
                    raise ModuleRegistryError(f"Invalid entrypoint in technical module {module_id}")
                if page_file_value is not None:
                    if not isinstance(page_file_value, str) or not page_file_value.strip():
                        raise ModuleRegistryError(f"Invalid page_file in technical module {module_id}")
                    page_file = Path(page_file_value)
                    if page_file.is_absolute() or ".." in page_file.parts:
                        raise ModuleRegistryError(f"Unsafe page_file path in module {module_id}")
                    if entrypoint is None or page_file != Path(*entrypoint.split(".")[:-1]).with_suffix(".py"):
                        raise ModuleRegistryError(f"page_file does not match entrypoint in module {module_id}")
                else:
                    page_file = None
                if icon is not None and (not isinstance(icon, str) or not icon.strip()):
                    raise ModuleRegistryError(f"Invalid icon in technical module {module_id}")
                if navigation_section is not None and (
                    not isinstance(navigation_section, str) or not navigation_section.strip()
                ):
                    raise ModuleRegistryError(f"Invalid navigation section in module {module_id}")

            manifests[module_id] = ModuleManifest(
                id=module_id,
                name=raw["name"],
                version=raw["version"],
                category=raw["category"],
                description=raw["description"],
                state=raw["state"],
                application=application,
                entrypoint=entrypoint,
                page_file=str(page_file) if page_file is not None else None,
                icon=icon,
                navigation_section=navigation_section,
                sequence=sequence,
                permissions=tuple(permissions),
                depends=tuple(depends),
                integrates_with=tuple(integrates_with),
                python_package=python_package,
                source=path,
            )
        self._validate_dependencies(manifests)
        return manifests

    def applications(self, states: set[str] | None = None) -> list[ModuleManifest]:
        """Return user-facing applications ordered by their declared sequence."""
        modules = self.load().values()
        return sorted(
            (module for module in modules if module.application and (states is None or module.state in states)),
            key=lambda module: (module.sequence, module.id),
        )

    @staticmethod
    def _validate_dependencies(manifests: dict[str, ModuleManifest]) -> None:
        for module in manifests.values():
            missing = sorted(set(module.depends) - manifests.keys())
            if missing:
                raise ModuleRegistryError(f"Module {module.id} has unknown dependencies: {', '.join(missing)}")
            if module.id in module.depends:
                raise ModuleRegistryError(f"Module {module.id} cannot depend on itself")
            missing_integrations = sorted(set(module.integrates_with) - manifests.keys())
            if missing_integrations:
                raise ModuleRegistryError(
                    f"Module {module.id} has unknown integrations: {', '.join(missing_integrations)}"
                )
            non_app_integrations = sorted(
                module_id for module_id in module.integrates_with
                if not manifests[module_id].application
            )
            if non_app_integrations:
                raise ModuleRegistryError(
                    f"Module {module.id} integrates with non-application modules: "
                    + ", ".join(non_app_integrations)
                )
            if module.id in module.integrates_with:
                raise ModuleRegistryError(f"Module {module.id} cannot integrate with itself")

    def topological_order(self) -> list[str]:
        """Return modules in dependency-first order without importing entrypoints."""
        manifests = self.load()
        pending = {module_id: set(module.depends) for module_id, module in manifests.items()}
        ordered: list[str] = []
        while pending:
            ready = sorted(module_id for module_id, deps in pending.items() if not deps)
            if not ready:
                cycle_nodes = sorted(pending)
                raise ModuleRegistryError(
                    "Cannot order modules because dependencies contain a cycle: "
                    + ", ".join(cycle_nodes)
                )
            for module_id in ready:
                ordered.append(module_id)
                pending.pop(module_id)
            for deps in pending.values():
                deps.difference_update(ready)
        return ordered

    def dependents_of(self, module_id: str, transitive: bool = True) -> list[str]:
        """Return direct or transitive modules that depend on module_id."""
        manifests = self.load()
        if module_id not in manifests:
            raise KeyError(module_id)
        found: set[str] = set()
        frontier = {module_id}
        while frontier:
            direct = {
                candidate for candidate, manifest in manifests.items()
                if candidate not in found and any(dep in frontier for dep in manifest.depends)
            }
            if not direct:
                break
            found.update(direct)
            if not transitive:
                break
            frontier = direct
        return sorted(found)

    def integrators_of(self, application_id: str, transitive: bool = True) -> list[str]:
        """Return applications that functionally integrate with an application."""
        manifests = self.load()
        if application_id not in manifests or not manifests[application_id].application:
            raise KeyError(application_id)
        found: set[str] = set()
        frontier = {application_id}
        while frontier:
            direct = {
                candidate for candidate, manifest in manifests.items()
                if manifest.application and candidate not in found
                and any(item in frontier for item in manifest.integrates_with)
            }
            if not direct:
                break
            found.update(direct)
            if not transitive:
                break
            frontier = direct
        return sorted(found)

    def dependency_graph_payload(self) -> dict:
        """Build the persisted dependency graph from manifests as the sole source."""
        manifests = self.load()
        return {
            "schema_version": 3,
            "source": "generated from manifests/*.json",
            "note": "modules are technical prerequisites; integrations are functional app links; neither is the full Python import graph.",
            "modules": {
                module_id: sorted(manifests[module_id].depends)
                for module_id in sorted(manifests)
            },
            "integrations": {
                module_id: sorted(manifests[module_id].integrates_with)
                for module_id in sorted(manifests)
                if manifests[module_id].application
            },
        }

    def audit(self, navigation_ids: Iterable[str] | None = None) -> dict[str, list[str]]:
        manifests = self.load()
        result = {
            "missing_manifests": [],
            "orphan_manifests": [],
            "missing_entrypoints": [],
            "missing_packages": [],
            "dependency_cycles": [],
        }
        application_ids = {
            module_id for module_id, module in manifests.items()
            if module.application and module.state == "available"
        }
        if navigation_ids is not None:
            nav = set(navigation_ids)
            result["missing_manifests"] = sorted(nav - application_ids)
            result["orphan_manifests"] = sorted(application_ids - nav)
        package_root = Path(__file__).resolve().parents[2]
        for module in manifests.values():
            if module.application and module.page_file and not (package_root / module.page_file).is_file():
                result["missing_entrypoints"].append(module.id)
            if module.python_package:
                package_path = package_root.joinpath(*module.python_package.split("."))
                if not (package_path / "__init__.py").is_file():
                    result["missing_packages"].append(module.id)
        result["dependency_cycles"] = self._find_cycles(manifests)
        return result

    @staticmethod
    def _find_cycles(manifests: dict[str, ModuleManifest]) -> list[str]:
        visiting: set[str] = set()
        visited: set[str] = set()
        cycles: set[str] = set()

        def visit(node: str, stack: list[str]) -> None:
            if node in visiting:
                cycles.update(stack[stack.index(node):])
                return
            if node in visited:
                return
            visiting.add(node)
            stack.append(node)
            for dependency in manifests[node].depends:
                visit(dependency, stack)
            stack.pop()
            visiting.remove(node)
            visited.add(node)

        for node in manifests:
            visit(node, [])
        return sorted(cycles)
