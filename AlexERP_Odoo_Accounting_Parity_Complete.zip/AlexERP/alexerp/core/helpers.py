from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any


# ==========================
# Date & Time
# ==========================

def today() -> str:
    """Return today's date as YYYY-MM-DD."""
    return datetime.now().strftime("%Y-%m-%d")


def now() -> datetime:
    """Return current datetime."""
    return datetime.now()


def current_time() -> str:
    """Return current time as HH:MM:SS."""
    return datetime.now().strftime("%H:%M:%S")


def format_date(value: datetime | None = None, fmt: str = "%Y-%m-%d") -> str:
    """Format datetime object."""
    return (value or datetime.now()).strftime(fmt)


# ==========================
# Safe Conversions
# ==========================

def safe_int(value: Any, default: int = 0) -> int:
    """Safely convert value to int."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_float(value: Any, default: float = 0.0) -> float:
    """Safely convert value to float."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def safe_decimal(value: Any, default: Decimal = Decimal("0")) -> Decimal:
    """Safely convert value to Decimal."""
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return default


def safe_str(value: Any) -> str:
    """Safely convert value to string."""
    if value is None:
        return ""
    return str(value).strip()


# ==========================
# Validation
# ==========================

def is_empty(value: Any) -> bool:
    """Check if value is empty."""
    return value is None or str(value).strip() == ""


def is_number(value: Any) -> bool:
    """Check if value can be converted to float."""
    try:
        float(value)
        return True
    except (TypeError, ValueError):
        return False


# ==========================
# Formatting
# ==========================

def money(value: Any, digits: int = 2) -> str:
    """Format money."""
    return f"{safe_float(value):,.{digits}f}"


def quantity(value: Any) -> str:
    """Format quantity."""
    return str(safe_int(value))


# ==========================
# Text
# ==========================

def normalize_text(text: Any) -> str:
    """Normalize text for searching."""
    return safe_str(text).lower()


def capitalize_words(text: Any) -> str:
    """Capitalize every word."""
    return safe_str(text).title()


# ==========================
# Boolean
# ==========================

def yes_no(value: bool) -> str:
    """Return Arabic Yes/No."""
    return "نعم" if value else "لا"


# ==========================
# Collections
# ==========================

def first(items, default=None):
    """Return first item or default."""
    try:
        return next(iter(items))
    except Exception:
        return default


def unique(items):
    """Remove duplicates while preserving order."""
    return list(dict.fromkeys(items))


def allocate_discount(bases: list[Any], discount: Any) -> list[float]:
    """Allocate a header discount across line bases in integer cents.

    The largest-remainder method keeps allocations proportional while ensuring
    the returned line discounts sum exactly to the requested currency amount.
    """
    from decimal import ROUND_HALF_UP

    try:
        base_cents = [
            int((Decimal(str(value)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            for value in bases
        ]
        discount_cents = int(
            (Decimal(str(discount)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        )
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError("Invoice bases and discount must be valid amounts.") from exc

    if any(value < 0 for value in base_cents) or discount_cents < 0:
        raise ValueError("Invoice bases and discount cannot be negative.")
    total_cents = sum(base_cents)
    if discount_cents > total_cents:
        raise ValueError("Discount cannot exceed the pre-tax line subtotal.")
    if not base_cents or total_cents == 0:
        if discount_cents:
            raise ValueError("Cannot allocate a discount when all line values are zero.")
        return [0.0 for _ in base_cents]

    floors = []
    remainders = []
    for base in base_cents:
        quotient, remainder = divmod(discount_cents * base, total_cents)
        floors.append(quotient)
        remainders.append(remainder)

    cents_left = discount_cents - sum(floors)
    for index in sorted(range(len(base_cents)), key=lambda i: (-remainders[i], i))[:cents_left]:
        floors[index] += 1

    return [value / 100 for value in floors]
