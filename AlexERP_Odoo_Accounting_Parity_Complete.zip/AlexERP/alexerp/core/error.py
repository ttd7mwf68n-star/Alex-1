class ERPError(Exception):
    """Base ERP exception."""


class ValidationError(ERPError):
    """Validation error."""


class DatabaseError(ERPError):
    """Database error."""


class NotFoundError(ERPError):
    """Entity not found."""