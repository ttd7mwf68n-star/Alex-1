"""
AlexERP — Business Management System
Runtime session context: the company/branch the signed-in user operates on.
UI pages and services read these defaults instead of hardcoding ids.
"""

from __future__ import annotations

_current_user = None


def set_current_user(user) -> None:
    """Call once after login; pass None on logout."""
    global _current_user
    _current_user = user


def get_current_user():
    return _current_user


def current_company_id() -> int:
    if _current_user is not None and _current_user["company_id"]:
        return int(_current_user["company_id"])
    return 1


def current_branch_id() -> int:
    if _current_user is not None and _current_user["branch_id"]:
        return int(_current_user["branch_id"])
    return 1


def current_user_id() -> int:
    if _current_user is not None and _current_user["id"]:
        return int(_current_user["id"])
    return 1
