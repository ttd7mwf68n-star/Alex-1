

try:
    import customtkinter as ctk
except Exception:
    import tkinter as _tk

    class _Stub:
        def __getattr__(self, name):
            return getattr(_tk, name)

    ctk = _Stub()

from alexerp.ui.components import get_theme_color


def refresh_theme_for_component(component):
    """Recursively refresh theme for a component and its children"""
    if isinstance(component, ctk.CTkLabel):
        component.configure(text_color=get_theme_color("text"))

    elif isinstance(component, ctk.CTkEntry):
        component.configure(
            fg_color=get_theme_color("background"),
            text_color=get_theme_color("text"),
            placeholder_text_color=get_theme_color("disabled_text"),
        )

    elif isinstance(component, ctk.CTkButton):
        component.configure(
            fg_color=get_theme_color("surface"),
            hover_color=get_theme_color("border"),
            text_color=get_theme_color("text"),
        )

    elif isinstance(component, ctk.CTkFrame):
        component.configure(
            fg_color=get_theme_color("background"),
        )

    elif isinstance(component, ctk.CTkComboBox):
        component.configure(
            fg_color=get_theme_color("background"),
            button_color=get_theme_color("surface"),
            text_color=get_theme_color("text"),
            dropdown_fg_color=get_theme_color("background"),
            dropdown_text_color=get_theme_color("text"),
        )

    if hasattr(component, "winfo_children"):
        for child in component.winfo_children():
            refresh_theme_for_component(child)


def refresh_theme_globally(app):
    """Refresh theme for all components in the application"""

    if hasattr(app, "login_frame") and app.login_frame:
        refresh_theme_for_component(app.login_frame)

    if hasattr(app, "layout_initialized") and app.layout_initialized:

        if hasattr(app, "sidebar") and app.sidebar:
            refresh_theme_for_component(app.sidebar)

        if hasattr(app, "topbar") and app.topbar:
            refresh_theme_for_component(app.topbar)

        if hasattr(app, "toolbar") and app.toolbar:
            refresh_theme_for_component(app.toolbar)

        if hasattr(app, "status_frame") and app.status_frame:
            refresh_theme_for_component(app.status_frame)

        if hasattr(app, "page_container") and app.page_container:
            refresh_theme_for_component(app.page_container)

        if hasattr(app, "current_page") and app.current_page:
            refresh_theme_for_component(app.current_page)