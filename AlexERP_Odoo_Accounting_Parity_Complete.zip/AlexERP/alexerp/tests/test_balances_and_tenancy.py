"""Regression tests: party balances must equal the ledger, and documents must
never mix records from different companies.

Run from the alexerp3 folder:
    PYTHONPATH=. python -m unittest discover -s alexerp/tests -v
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.core.tenancy import TenantScopeError
from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.transaction import TransactionError
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.accounting_service import AccountingService
from alexerp.services.party_balance_service import PartyBalanceService
from alexerp.services.purchase_service import PurchaseService
from alexerp.services.receipt_service import ReceiptService
from alexerp.services.payment_service import PaymentService, PaymentError
from alexerp.services.sales_return_service import SalesReturnService
from alexerp.services.sales_service import SalesService
from alexerp.services.inventory_service import InventoryService, InventoryError
from alexerp.services.stock_service import StockService, StockError


class BalancesAndTenancyTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_bt_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.c = Database.connect()
        self.acc = {}
        for code in ("AR", "AP", "SALES", "INV", "COGS", "CASH"):
            self.acc[code] = self._account(1, code)
        self.customer = self.c.execute(
            "INSERT INTO customers(company_id, code, name) VALUES(1,'C1','Cust1')").lastrowid
        self.supplier = self.c.execute(
            "INSERT INTO suppliers(company_id, code, name) VALUES(1,'S1','Sup1')").lastrowid
        self.product = self._product(1, "P1")
        # a second, unrelated company with its own records
        self.c.execute("INSERT INTO companies(id, code, name) VALUES(2,'B','Company B')")
        self.c.execute("INSERT INTO branches(id, company_id, code, name) VALUES(2,2,'B2','Branch B')")
        self.acc_b = self._account(2, "AR_B")
        self.customer_b = self.c.execute(
            "INSERT INTO customers(company_id, code, name) VALUES(2,'C1','CustB')").lastrowid
        self.supplier_b = self.c.execute(
            "INSERT INTO suppliers(company_id, code, name) VALUES(2,'S1','SupB')").lastrowid
        self.warehouse_b = self.c.execute(
            "INSERT INTO warehouses(company_id, branch_id, code, name) VALUES(2,2,'WB','WH B')").lastrowid
        self.product_b = self.c.execute(
            "INSERT INTO products(code,name,company_id,branch_id,purchase_price,sale_price,quantity) "
            "VALUES('PB','PB',2,2,5,20,50)").lastrowid
        self.c.commit()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    # ---- helpers ----
    def _account(self, company_id, code):
        return self.c.execute(
            "INSERT INTO chart_of_accounts(company_id, account_code, account_name) VALUES(?,?,?)",
            (company_id, code, code)).lastrowid

    def _product(self, company_id, code):
        pid = self.c.execute(
            "INSERT INTO products(code,name,company_id,branch_id,purchase_price,sale_price,quantity) "
            "VALUES(?,?,?,1,5,20,100)", (code, code, company_id)).lastrowid
        self.c.execute(
            "INSERT INTO product_stock(company_id,branch_id,warehouse_id,product_id,quantity,average_cost) "
            "VALUES(?,1,1,?,100,5)", (company_id, pid))
        self.c.commit()
        return pid

    def _gl(self, account_id):
        return round(float(self.c.execute(
            "SELECT COALESCE(SUM(debit),0)-COALESCE(SUM(credit),0) FROM journal_details WHERE account_id=?",
            (account_id,)).fetchone()[0]), 2)

    def _cust_bal(self):
        return round(float(self.c.execute(
            "SELECT current_balance FROM customers WHERE id=?", (self.customer,)).fetchone()[0]), 2)

    def _customer_ar_account(self):
        return int(self.c.execute(
            "SELECT account_id FROM customers WHERE id=?", (self.customer,)
        ).fetchone()[0])

    def _sup_bal(self):
        return round(float(self.c.execute(
            "SELECT current_balance FROM suppliers WHERE id=?", (self.supplier,)).fetchone()[0]), 2)

    def _sale(self, number, qty, price, paid=0.0, customer=None, **over):
        total = round(qty * price, 2)
        kw = dict(company_id=1, branch_id=1, customer_id=customer or self.customer,
                  invoice_number=number, invoice_date="2026-11-17",
                  items=[{"product_id": self.product, "warehouse_id": 1, "quantity": qty,
                          "unit_price": price, "discount": 0, "tax": 0, "total": total}],
                  subtotal=total, discount=0, tax=0, total=total, paid_amount=paid,
                  remaining_amount=round(total - paid, 2), notes="", created_by=1,
                  receivable_account=self.acc["AR"], sales_account=self.acc["SALES"],
                  inventory_account=self.acc["INV"], cogs_account=self.acc["COGS"],
                  cash_account=self.acc["CASH"] if paid else None)
        kw.update(over)
        return SalesService().create_invoice(**kw)

    def _purchase(self, number, qty, cost, paid=0.0, **over):
        total = round(qty * cost, 2)
        kw = dict(company_id=1, branch_id=1, supplier_id=self.supplier,
                  invoice_number=number, supplier_invoice_number="SUP-" + number,
                  invoice_date="2026-11-17",
                  items=[{"product_id": self.product, "warehouse_id": 1, "quantity": qty,
                          "unit_cost": cost, "discount": 0, "tax": 0, "total": total}],
                  subtotal=total, discount=0, tax=0, total=total, paid_amount=paid,
                  remaining_amount=round(total - paid, 2), notes="", created_by=1,
                  supplier_account=self.acc["AP"], inventory_account=self.acc["INV"],
                  cash_account=self.acc["CASH"] if paid else None)
        kw.update(over)
        return PurchaseService().create_invoice(**kw)

    def _receipt(self, number, amount, **over):
        kw = dict(company_id=1, branch_id=1, receipt_number=number, receipt_date="2026-11-17",
                  customer_id=self.customer, cash_account=self.acc["CASH"],
                  receivable_account=self.acc["AR"], amount=amount, created_by=1)
        kw.update(over)
        return ReceiptService().create_receipt(**kw)

    def _counts(self):
        return tuple(self.c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                     for t in ("sales_invoices", "purchase_invoices", "receipts", "journal_entries"))

    # ---- balances ----
    def test_customer_balance_follows_full_sales_cycle_and_matches_ledger(self):
        inv = self._sale("S1", 10, 20, paid=50)             # total 200, 150 on credit
        self.assertEqual(self._cust_bal(), 150.0)
        self.assertEqual(self._cust_bal(), self._gl(self._customer_ar_account()))
        self._receipt("R1", 60)
        self.assertEqual(self._cust_bal(), 90.0)
        SalesReturnService().create_return(
            company_id=1, branch_id=1, sales_invoice_id=inv, customer_id=self.customer,
            return_number="RT1", return_date="2026-11-17",
            items=[{"product_id": self.product, "warehouse_id": 1, "quantity": 2, "total": 40}],
            total=40, notes="", created_by=1, sales_account=self.acc["SALES"],
            receivable_account=self.acc["AR"], inventory_account=self.acc["INV"],
            cogs_account=self.acc["COGS"])
        self.assertEqual(self._cust_bal(), 50.0)
        self.assertEqual(self._cust_bal(), self._gl(self._customer_ar_account()))

    def test_cancelling_invoice_updates_customer_balance(self):
        inv = self._sale("S2", 5, 20)
        self._receipt("R2", 30)
        SalesService().cancel_invoice(inv, 1)
        self.assertEqual(self._cust_bal(), -30.0)           # receipt remains as customer credit
        self.assertEqual(self._cust_bal(), self._gl(self._customer_ar_account()))

    def test_supplier_balance_follows_purchase_and_cancel_and_matches_ledger(self):
        inv = self._purchase("P1", 4, 10, paid=15)           # total 40, 25 payable
        self.assertEqual(self._sup_bal(), 25.0)
        self.assertEqual(self._sup_bal(), -self._gl(self.acc["AP"]))
        PurchaseService().cancel_invoice(inv, 1)
        self.assertEqual(self._sup_bal(), 0.0)

    def test_refresh_all_repairs_stale_balances(self):
        self._sale("S3", 2, 20)
        self.c.execute("UPDATE customers SET current_balance=999 WHERE id=?", (self.customer,))
        self.c.execute("UPDATE suppliers SET current_balance=-5 WHERE id=?", (self.supplier,))
        self.c.commit()
        PartyBalanceService().refresh_all()
        self.assertEqual(self._cust_bal(), 40.0)
        self.assertEqual(self._sup_bal(), 0.0)

    def test_failed_posting_does_not_change_balance(self):
        self._sale("S4", 1, 20)
        before = self._cust_bal()
        with self.assertRaises(Exception):
            self._sale("S5", 1000, 20)                       # insufficient stock
        self.assertEqual(self._cust_bal(), before)

    def test_backup_restore_preserves_real_sales_purchases_receipts_and_ledger(self):
        """Acceptance test: restore a database after real service-posted transactions."""
        from alexerp.database.backup import BackupManager

        self._purchase("BK-P1", 20, 8, paid=40)
        invoice_id = self._sale("BK-S1", 5, 20, paid=25)
        self._receipt("BK-R1", 15)
        SalesReturnService().create_return(
            company_id=1, branch_id=1, sales_invoice_id=invoice_id, customer_id=self.customer,
            return_number="BK-RT1", return_date="2026-11-17",
            items=[{"product_id": self.product, "warehouse_id": 1, "quantity": 1, "total": 20}],
            total=20, notes="backup acceptance", created_by=1, sales_account=self.acc["SALES"],
            receivable_account=self.acc["AR"], inventory_account=self.acc["INV"],
            cogs_account=self.acc["COGS"])
        self.c.commit()

        def snapshot():
            return {
                "documents": tuple(self.c.execute(
                    "SELECT COUNT(*) FROM " + table
                ).fetchone()[0] for table in (
                    "sales_invoices", "purchase_invoices", "receipts", "sales_returns", "journal_entries"
                )),
                "customer_balance": self._cust_bal(),
                "supplier_balance": self._sup_bal(),
                "customer_ledger": self._gl(self._customer_ar_account()),
                "supplier_ledger": -self._gl(self.acc["AP"]),
                "stock": float(self.c.execute(
                    "SELECT quantity FROM products WHERE id=?", (self.product,)
                ).fetchone()[0]),
                "invoice_total": float(self.c.execute(
                    "SELECT total FROM sales_invoices WHERE id=?", (invoice_id,)
                ).fetchone()[0]),
                "journal_totals": tuple(round(float(row[0]), 2) for row in self.c.execute(
                    "SELECT COALESCE(SUM(debit),0) FROM journal_details GROUP BY journal_entry_id ORDER BY journal_entry_id"
                )),
            }

        before = snapshot()
        manager = BackupManager(Path(self.tempdir.name) / "backup_acceptance", db_module.DATABASE_FILE)
        backup = manager.create_backup(backup_type="acceptance-test")

        # Add a later posted transaction so restore must remove it and recover
        # all prior business state, not merely pass SQLite integrity_check.
        self._sale("BK-S2-AFTER-BACKUP", 2, 20)
        self.c.commit()
        self.assertNotEqual(snapshot()["documents"], before["documents"])

        manager.restore_backup(backup)
        self.c = Database.connect()
        self.assertEqual(snapshot(), before)
        self.assertEqual(manager.verify_backup(backup)["integrity"], "ok")

    # ---- tenancy ----
    def test_sales_rejects_other_company_customer_account_and_product(self):
        before = self._counts()
        for label, over in {
            "customer": dict(customer=self.customer_b),
            "account": dict(receivable_account=self.acc_b),
            "product": dict(items=[{"product_id": self.product_b, "warehouse_id": 1, "quantity": 1,
                                    "unit_price": 20, "discount": 0, "tax": 0, "total": 20}],
                            subtotal=20, total=20, remaining_amount=20),
            "warehouse": dict(items=[{"product_id": self.product, "warehouse_id": self.warehouse_b,
                                      "quantity": 1, "unit_price": 20, "discount": 0, "tax": 0, "total": 20}],
                              subtotal=20, total=20, remaining_amount=20),
        }.items():
            with self.subTest(label), self.assertRaises(TenantScopeError):
                self._sale("X-" + label, 1, 20, **over)
        self.assertEqual(self._counts(), before)

    def test_purchase_rejects_other_company_supplier_and_account(self):
        before = self._counts()
        with self.assertRaises(TenantScopeError):
            self._purchase("PX1", 1, 5, supplier_id=self.supplier_b)
        with self.assertRaises(TenantScopeError):
            self._purchase("PX2", 1, 5, supplier_account=self.acc_b)
        self.assertEqual(self._counts(), before)

    def test_receipt_rejects_other_company_customer_and_account(self):
        before = self._counts()
        with self.assertRaises(TenantScopeError):
            self._receipt("RX1", 5, customer_id=self.customer_b)
        with self.assertRaises(TenantScopeError):
            self._receipt("RX2", 5, receivable_account=self.acc_b)
        self.assertEqual(self._counts(), before)

    def test_branch_must_belong_to_company(self):
        with self.assertRaises(TenantScopeError):
            self._receipt("RX3", 5, branch_id=2)

    def test_journal_entry_rejects_invalid_date_and_non_posting_account(self):
        before = self.c.execute("SELECT COUNT(*) FROM journal_entries").fetchone()[0]
        with self.assertRaises(Exception):
            AccountingService().create_entry(
                1, 1, "2026-02-30", "bad date", "MANUAL", 7101, 1,
                [{"account_id": self.acc["CASH"], "debit": 10, "credit": 0},
                 {"account_id": self.acc["AR"], "debit": 0, "credit": 10}])

        header_account = self.c.execute(
            "INSERT INTO chart_of_accounts(company_id,account_code,account_name,allow_posting) "
            "VALUES(1,'HEADER','Header',0)"
        ).lastrowid
        with self.assertRaises(Exception):
            AccountingService().create_entry(
                1, 1, "2026-11-17", "header account", "MANUAL", 7102, 1,
                [{"account_id": header_account, "debit": 10, "credit": 0},
                 {"account_id": self.acc["AR"], "debit": 0, "credit": 10}])
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM journal_entries").fetchone()[0], before)

    def test_journal_entry_rejects_foreign_cost_center(self):
        foreign_center = self.c.execute(
            "INSERT INTO cost_centers(company_id,code,name) VALUES(2,'CC-B','Foreign center')"
        ).lastrowid
        with self.assertRaises(Exception):
            AccountingService().create_entry(
                1, 1, "2026-11-17", "foreign cost center", "MANUAL", 7103, 1,
                [{"account_id": self.acc["CASH"], "cost_center_id": foreign_center, "debit": 10, "credit": 0},
                 {"account_id": self.acc["AR"], "debit": 0, "credit": 10}])

    def test_journal_entry_rejects_foreign_account_for_any_caller(self):
        with self.assertRaises(Exception) as ctx:
            AccountingService().create_entry(
                1, 1, "2026-11-17", "direct", "MANUAL", 1, 1,
                [{"account_id": self.acc["CASH"], "debit": 5, "credit": 0},
                 {"account_id": self.acc_b, "debit": 0, "credit": 5}])
        self.assertIn("does not belong", str(ctx.exception))

    def test_supplier_payment_posts_balanced_entry_and_reduces_payable(self):
        self._purchase("P-PAY", 5, 10)
        payment_id = PaymentService().create_payment(
            company_id=1, branch_id=1, payment_number="PAY-1",
            payment_date="2026-11-17", supplier_id=self.supplier,
            cash_account=self.acc["CASH"], payable_account=self.acc["AP"],
            amount=20, created_by=1)
        self.assertGreater(payment_id, 0)
        self.assertEqual(self._sup_bal(), 30.0)
        self.assertEqual(self._sup_bal(), -self._gl(self.acc["AP"]))
        entry = self.c.execute(
            "SELECT id FROM journal_entries WHERE reference_type='SUPPLIER_PAYMENT' AND reference_id=?",
            (payment_id,)).fetchone()
        self.assertIsNotNone(entry)

    def test_supplier_payment_cancel_reverses_ledger_and_restores_balance(self):
        self._purchase("P-PAY-C", 5, 10)
        payment_id = PaymentService().create_payment(
            1, 1, "PAY-2", "2026-11-17", self.supplier, self.acc["CASH"],
            self.acc["AP"], 20, 1)
        self.assertEqual(self._sup_bal(), 30.0)
        PaymentService().cancel_payment(payment_id, 1, "2026-11-17")
        self.assertEqual(self._sup_bal(), 50.0)
        self.assertEqual(self._sup_bal(), -self._gl(self.acc["AP"]))
        self.assertEqual(self.c.execute("SELECT status FROM payments WHERE id=?",
                                        (payment_id,)).fetchone()[0], "CANCELLED")
        with self.assertRaises(TransactionError):
            PaymentService().cancel_payment(payment_id, 1, "2026-11-17")


    def test_receipt_rejects_infinite_amount_without_writes(self):
        before = self._counts()
        with self.assertRaises(ValueError):
            self._receipt("R-INF", float("inf"))
        self.assertEqual(self._counts(), before)

    def test_journal_rejects_non_finite_amounts(self):
        for invalid in (float("inf"), float("nan")):
            with self.subTest(invalid=invalid):
                with self.assertRaises(Exception):
                    AccountingService().create_entry(
                        1, 1, "2026-11-17", "invalid amount", "MANUAL", 900 + len(str(invalid)), 1,
                        [{"account_id": self.acc["CASH"], "debit": invalid, "credit": 0},
                         {"account_id": self.acc["AR"], "debit": 0, "credit": invalid}])

    def test_other_company_user_cannot_cancel_receipt_or_supplier_payment(self):
        receipt_id = self._receipt("R-CROSS-COMPANY", 10)
        payment_id = PaymentService().create_payment(
            1, 1, "PAY-CROSS-COMPANY", "2026-11-17", self.supplier,
            self.acc["CASH"], self.acc["AP"], 10, 1)
        foreign_actor = self.c.execute(
            "INSERT INTO users(username,password_hash,full_name,company_id,branch_id,is_active) "
            "VALUES('company_b_actor','test-hash','Company B Actor',2,2,1)"
        ).lastrowid
        self.c.commit()

        with self.assertRaises(TransactionError):
            ReceiptService().cancel_receipt(receipt_id, foreign_actor, "2026-11-17")
        with self.assertRaises(TransactionError):
            PaymentService().cancel_payment(payment_id, foreign_actor, "2026-11-17")

        self.assertEqual(self.c.execute(
            "SELECT status FROM receipts WHERE id=?", (receipt_id,)).fetchone()[0], "POSTED")
        self.assertEqual(self.c.execute(
            "SELECT status FROM payments WHERE id=?", (payment_id,)).fetchone()[0], "POSTED")

    def test_receipt_cancel_reverses_ledger_and_restores_customer_balance(self):
        self._sale("S-REC-C", 5, 20)
        receipt_id = self._receipt("R-CANCEL", 30)
        self.assertEqual(self._cust_bal(), 70.0)
        ReceiptService().cancel_receipt(receipt_id, 1, "2026-11-17")
        self.assertEqual(self._cust_bal(), 100.0)
        self.assertEqual(self._cust_bal(), self._gl(self._customer_ar_account()))
        self.assertEqual(self.c.execute("SELECT status FROM receipts WHERE id=?",
                                        (receipt_id,)).fetchone()[0], "CANCELLED")

    def test_payment_rejects_foreign_supplier_and_account_without_writes(self):
        before = self._counts()
        with self.assertRaises(TenantScopeError):
            PaymentService().create_payment(1, 1, "BAD-P1", "2026-11-17",
                self.supplier_b, self.acc["CASH"], self.acc["AP"], 5, 1)
        with self.assertRaises(TenantScopeError):
            PaymentService().create_payment(1, 1, "BAD-P2", "2026-11-17",
                self.supplier, self.acc["CASH"], self.acc_b, 5, 1)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM payments").fetchone()[0], 0)
        self.assertEqual(before, self._counts())

    def test_cancelled_receipts_are_excluded_from_balance_rebuild(self):
        self._sale("S-REC-R", 5, 20)
        receipt_id = self._receipt("R-REBUILD", 30)
        ReceiptService().cancel_receipt(receipt_id, 1, "2026-11-17")
        self.c.execute("UPDATE customers SET current_balance=999 WHERE id=?", (self.customer,))
        self.c.commit()
        PartyBalanceService().refresh_all()
        self.assertEqual(self._cust_bal(), 100.0)


    def test_inventory_reads_reject_cross_company_warehouse(self):
        inventory = InventoryService()
        self.c.execute(
            "INSERT INTO product_stock(company_id,branch_id,warehouse_id,product_id,quantity,average_cost) "
            "VALUES(2,2,?, ?,25,7)", (self.warehouse_b, self.product_b))
        self.c.commit()

        # A company-A product cannot be inspected through company-B's warehouse.
        with self.assertRaises(InventoryError):
            inventory.get_quantity(self.product, self.warehouse_b)
        with self.assertRaises(InventoryError):
            inventory.get_unit_cost(self.product, self.warehouse_b)
        with self.assertRaises(InventoryError):
            inventory.check_stock(self.product, 1, self.warehouse_b)

        # Company-B balances remain visible only through its own product scope.
        self.assertEqual(inventory.get_quantity(self.product_b, self.warehouse_b), 25.0)
        self.assertEqual(inventory.get_unit_cost(self.product_b, self.warehouse_b), 7.0)
        self.assertTrue(inventory.check_stock(self.product_b, 20, self.warehouse_b))
        stock = StockService()
        with self.assertRaises(StockError):
            stock.get_balance(self.product, self.warehouse_b)
        self.assertEqual(stock.get_balance(self.product_b, self.warehouse_b), 25.0)
        with self.assertRaises(TransactionError):
            stock.increase(1, 1, self.warehouse_b, self.product, 1, 7.0)


if __name__ == "__main__":
    unittest.main()
