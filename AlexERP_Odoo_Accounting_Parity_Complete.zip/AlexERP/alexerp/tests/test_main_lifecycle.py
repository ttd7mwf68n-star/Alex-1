from __future__ import annotations

import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

from alexerp import main as app_main
from alexerp.database import db as db_module
from alexerp.database.db import Database


class MainLifecycleTests(unittest.TestCase):
    def _fake_window_module(self, mainloop):
        module = types.ModuleType("alexerp.ui.main_window")

        class FakeWindow:
            def mainloop(self):
                mainloop()

        setattr(module, "MainWindow", FakeWindow)
        return module

    def test_database_initialization_failure_closes_database(self):
        with (
            mock.patch.object(app_main, "_load_main_window", return_value=mock.Mock()),
            mock.patch.object(app_main, "bootstrap_database", side_effect=RuntimeError("database failed")),
            mock.patch.object(Database, "close") as close_database,
            mock.patch("sys.stderr"),
        ):
            self.assertEqual(app_main.main(), 1)

        close_database.assert_called_once_with()

    def test_missing_gui_dependency_does_not_initialize_database(self):
        with (
            mock.patch.object(
                app_main,
                "_load_main_window",
                side_effect=ModuleNotFoundError(
                    "No module named 'customtkinter'", name="customtkinter"
                ),
            ),
            mock.patch.object(app_main, "bootstrap_database") as bootstrap,
            mock.patch.object(Database, "close") as close_database,
            mock.patch("sys.stderr"),
        ):
            self.assertEqual(app_main.main(), 1)

        bootstrap.assert_not_called()
        close_database.assert_called_once_with()

    def test_scheduler_stops_and_database_closes_when_mainloop_fails(self):
        def fail_mainloop():
            raise RuntimeError("window failed")

        scheduler = mock.Mock()
        scheduler_type = mock.Mock(return_value=scheduler)
        scheduler_module = types.ModuleType("alexerp.database.backup_scheduler")
        setattr(scheduler_module, "DailyBackupScheduler", scheduler_type)
        window_module = self._fake_window_module(fail_mainloop)
        patches = (
            mock.patch.object(app_main, "bootstrap_database"),
            mock.patch.dict(
                sys.modules,
                {
                    "alexerp.ui.main_window": window_module,
                    "alexerp.database.backup_scheduler": scheduler_module,
                },
            ),
            mock.patch("alexerp.config.AUTO_BACKUP_ENABLED", True),
        )
        with patches[0], patches[1], patches[2], mock.patch.object(
            Database, "close"
        ) as close_database:
            with self.assertRaisesRegex(RuntimeError, "window failed"):
                app_main.main()

        scheduler.start.assert_called_once_with()
        scheduler.stop.assert_called_once_with()
        close_database.assert_called_once_with()

    def test_database_closes_when_window_creation_fails(self):
        window_module = types.ModuleType("alexerp.ui.main_window")
        setattr(
            window_module,
            "MainWindow",
            mock.Mock(side_effect=RuntimeError("window creation failed")),
        )
        with (
            mock.patch.object(app_main, "bootstrap_database"),
            mock.patch.dict(sys.modules, {"alexerp.ui.main_window": window_module}),
            mock.patch("alexerp.config.AUTO_BACKUP_ENABLED", False),
            mock.patch.object(Database, "close") as close_database,
        ):
            with self.assertRaisesRegex(RuntimeError, "window creation failed"):
                app_main.main()

        close_database.assert_called_once_with()

    def test_normal_exit_returns_success_and_closes_database(self):
        window_module = self._fake_window_module(lambda: None)
        with (
            mock.patch.object(app_main, "bootstrap_database"),
            mock.patch.dict(sys.modules, {"alexerp.ui.main_window": window_module}),
            mock.patch("alexerp.config.AUTO_BACKUP_ENABLED", False),
            mock.patch.object(Database, "close") as close_database,
        ):
            self.assertEqual(app_main.main(), 0)

        close_database.assert_called_once_with()

    def test_bootstrap_backfills_customer_accounts_and_balances_idempotently(self):
        original_database_file = db_module.DATABASE_FILE
        Database.close()
        try:
            with tempfile.TemporaryDirectory(prefix="alexerp_bootstrap_") as temp_dir:
                db_module.DATABASE_FILE = Path(temp_dir) / "bootstrap.db"
                try:
                    with mock.patch.dict(
                        "os.environ",
                        {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"},
                    ):
                        app_main.bootstrap_database()
                        conn = Database.connect()
                        company_id = int(conn.execute(
                            "SELECT id FROM companies ORDER BY id LIMIT 1"
                        ).fetchone()[0])
                        branch_id = int(conn.execute(
                            "SELECT id FROM branches WHERE company_id=? ORDER BY id LIMIT 1",
                            (company_id,),
                        ).fetchone()[0])
                        admin_id = int(conn.execute(
                            "SELECT id FROM users WHERE username='admin'"
                        ).fetchone()[0])
                        customer_id = int(conn.execute(
                            "INSERT INTO customers(company_id,code,name) VALUES(?,?,?)",
                            (company_id, "BOOT-C1", "Bootstrap Customer"),
                        ).lastrowid)
                        conn.execute(
                            """INSERT INTO sales_invoices(
                                   company_id,branch_id,customer_id,invoice_number,invoice_date,
                                   total,paid_amount,remaining_amount,status,created_by)
                               VALUES(?,?,?,?,?,100,0,100,'POSTED',?)""",
                            (
                                company_id, branch_id, customer_id, "BOOT-SI-1",
                                "2026-01-01", admin_id,
                            ),
                        )
                        conn.commit()
                        Database.close()
                        app_main.bootstrap_database()

                        customer = Database.connect().execute(
                            "SELECT account_id,current_balance FROM customers WHERE id=?",
                            (customer_id,),
                        ).fetchone()
                        self.assertIsNotNone(customer["account_id"])
                        self.assertEqual(float(customer["current_balance"]), 100.0)
                        account_id = int(customer["account_id"])
                        app_main.bootstrap_database()
                        customer = Database.connect().execute(
                            "SELECT account_id,current_balance FROM customers WHERE id=?",
                            (customer_id,),
                        ).fetchone()
                        self.assertEqual(int(customer["account_id"]), account_id)
                        self.assertEqual(float(customer["current_balance"]), 100.0)
                finally:
                    Database.close()
        finally:
            db_module.DATABASE_FILE = original_database_file


if __name__ == "__main__":
    unittest.main()
