"""Tests for phase 15 purchasing workflow and tenant isolation."""
from __future__ import annotations
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from datetime import date, timedelta

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.database.transaction import TransactionError
from alexerp.services.purchasing_workflow_service import PurchasingWorkflowService, PurchasingWorkflowError
from alexerp.services.approval_workflow_service import ApprovalWorkflowService
from alexerp.services.security_admin_service import SecurityAdminError, SecurityAdminService


class PurchasingWorkflowTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tmp = tempfile.TemporaryDirectory(prefix="alexerp_po_")
        db_module.DATABASE_FILE = Path(self.tmp.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.user_id = self.conn.execute("SELECT id FROM users ORDER BY id LIMIT 1").fetchone()[0]
        self.company = self.conn.execute("INSERT INTO companies(code,name) VALUES('PO-C','PO Company')").lastrowid
        self.branch = self.conn.execute("INSERT INTO branches(company_id,code,name) VALUES(?, 'PO-B','PO Branch')", (self.company,)).lastrowid
        self.conn.execute("UPDATE users SET company_id=?, branch_id=? WHERE id=?",
                          (self.company, self.branch, self.user_id))
        self.warehouse = self.conn.execute("INSERT INTO warehouses(company_id,branch_id,code,name) VALUES(?,?,'PO-W','PO Warehouse')", (self.company,self.branch)).lastrowid
        self.product = self.conn.execute("INSERT INTO products(company_id,branch_id,code,name,quantity) VALUES(?,?,'PO-P','PO Product',0)", (self.company,self.branch)).lastrowid
        self.supplier = self.conn.execute("INSERT INTO suppliers(company_id,code,name) VALUES(?,'PO-S','PO Supplier')", (self.company,)).lastrowid
        self.svc = PurchasingWorkflowService()
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tmp.cleanup()

    def _item(self, qty=10, cost=5):
        return {"product_id":self.product,"warehouse_id":self.warehouse,"quantity":qty,"unit_cost":cost}

    def _create_role_user(self, code, permission_keys):
        role_id = self.conn.execute(
            "INSERT INTO roles(code,name,company_id,is_system,is_active) VALUES(?,?,?,0,1)",
            (code, code.replace("_", " ").title(), self.company),
        ).lastrowid
        for key in permission_keys:
            self.conn.execute(
                """INSERT INTO role_permissions(role_id,permission_id)
                   SELECT ?,id FROM permissions WHERE permission_key=?""",
                (role_id, key),
            )
        user_id = self.conn.execute(
            """INSERT INTO users(username,password_hash,full_name,role_id,company_id,branch_id,is_active)
               VALUES(?,?,?, ?,?,?,1)""",
            (code.lower(), "test-hash", code.replace("_", " ").title(),
             role_id, self.company, self.branch),
        ).lastrowid
        self.conn.commit()
        return int(role_id), int(user_id)

    def test_requisition_and_order_creation(self):
        req = self.svc.create_requisition(self.company,self.branch,"REQ-1",date.today().isoformat(),self.user_id,[self._item()])
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-1",date.today().isoformat(),
            (date.today()+timedelta(days=5)).isoformat(),self.user_id,[self._item()],req)
        self.assertEqual(self.conn.execute("SELECT status FROM purchase_requisitions WHERE id=?",(req,)).fetchone()[0],"ORDERED")
        self.assertEqual(self.conn.execute("SELECT status FROM purchase_orders WHERE id=?",(order,)).fetchone()[0],"OPEN")

    def test_partial_and_full_receipts_update_order_quantities(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-2",date.today().isoformat(),None,self.user_id,[self._item()])
        line = self.conn.execute("SELECT id FROM purchase_order_items WHERE order_id=?",(order,)).fetchone()[0]
        self.svc.record_receipt(self.company,self.branch,order,"GRN-1",date.today().isoformat(),self.user_id,[{"order_item_id":line,"quantity":4}])
        self.assertEqual(self.conn.execute("SELECT status FROM purchase_orders WHERE id=?",(order,)).fetchone()[0],"PARTIALLY_RECEIVED")
        self.svc.record_receipt(self.company,self.branch,order,"GRN-2",date.today().isoformat(),self.user_id,[{"order_item_id":line,"quantity":6}])
        row = self.conn.execute("SELECT received_quantity FROM purchase_order_items WHERE id=?",(line,)).fetchone()
        self.assertEqual(float(row[0]),10)
        self.assertEqual(self.conn.execute("SELECT status FROM purchase_orders WHERE id=?",(order,)).fetchone()[0],"RECEIVED")

    def test_over_receipt_is_rejected_and_transaction_rolls_back(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-3",date.today().isoformat(),None,self.user_id,[self._item()])
        line = self.conn.execute("SELECT id FROM purchase_order_items WHERE order_id=?",(order,)).fetchone()[0]
        with self.assertRaises(Exception):
            self.svc.record_receipt(self.company,self.branch,order,"GRN-X",date.today().isoformat(),self.user_id,[{"order_item_id":line,"quantity":11}])
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM purchase_receipts WHERE order_id=?",(order,)).fetchone()[0],0)
        self.assertEqual(float(self.conn.execute("SELECT received_quantity FROM purchase_order_items WHERE id=?",(line,)).fetchone()[0]),0)

    def test_company_scope_blocks_foreign_supplier_and_product(self):
        foreign_company = self.conn.execute("INSERT INTO companies(code,name) VALUES('PO-F','Foreign')").lastrowid
        foreign_supplier = self.conn.execute("INSERT INTO suppliers(company_id,code,name) VALUES(?,'PO-FS','Foreign supplier')",(foreign_company,)).lastrowid
        with self.assertRaises(Exception):
            self.svc.create_order(self.company,self.branch,foreign_supplier,"PO-F1",date.today().isoformat(),None,self.user_id,[self._item()])

    def test_invoice_match_audit_reports_price_discount_and_tax_variance(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-AUDIT",
            date.today().isoformat(),None,self.user_id,[{**self._item(10,5),"discount":2,"tax":3}])
        po_line = self.conn.execute("SELECT id FROM purchase_order_items WHERE order_id=?",(order,)).fetchone()[0]
        self.svc.record_receipt(self.company,self.branch,order,"GRN-AUDIT",date.today().isoformat(),
            self.user_id,[{"order_item_id":po_line,"quantity":4}])
        invoice_id = self.conn.execute("""INSERT INTO purchase_invoices
            (company_id,branch_id,supplier_id,invoice_number,invoice_date,status,total)
            VALUES(?,?,?,?,?,'POSTED',25)""",
            (self.company,self.branch,self.supplier,"INV-AUDIT",date.today().isoformat())).lastrowid
        invoice_line = self.conn.execute("""INSERT INTO purchase_invoice_items
            (invoice_id,product_id,warehouse_id,quantity,unit_cost,discount,tax,total)
            VALUES(?,?,?,?,?,?,?,?)""",
            (invoice_id,self.product,self.warehouse,4,6,1,4,27)).lastrowid
        self.svc.link_invoice(self.company,self.branch,order,invoice_id,self.user_id,
            [{"order_item_id":po_line,"invoice_item_id":invoice_line,"quantity":4}])
        audit = self.svc.invoice_match_audit(self.company,self.branch,self.user_id,order_id=order)
        self.assertEqual(len(audit),1)
        self.assertEqual(audit[0]["price_variance"],4.0)
        self.assertEqual(audit[0]["discount_variance"],0.2)
        self.assertEqual(audit[0]["tax_variance"],2.8)
        self.assertEqual(audit[0]["review_status"],"REVIEW_REQUIRED")

    def test_invoice_match_audit_is_company_scoped_and_validates_tolerance(self):
        self.assertEqual(self.svc.invoice_match_audit(self.company,self.branch,self.user_id),[])
        with self.assertRaises(PurchasingWorkflowError):
            self.svc.invoice_match_audit(self.company,self.branch,self.user_id,tolerance=-1)

    def test_quote_comparison_sorts_by_cost_then_delivery(self):
        supplier2 = self.conn.execute("INSERT INTO suppliers(company_id,code,name) VALUES(?,'PO-S2','Supplier Two')",(self.company,)).lastrowid
        self.svc.add_supplier_quote(self.company,self.branch,self.supplier,"Q-1",date.today().isoformat(),None,
            [{**self._item(3,8),"delivery_days":2}],self.user_id)
        self.svc.add_supplier_quote(self.company,self.branch,supplier2,"Q-2",date.today().isoformat(),None,
            [{**self._item(3,6),"delivery_days":4}],self.user_id)
        rows = self.svc.compare_quotes(self.company,self.product,self.branch)
        self.assertEqual(rows[0]["supplier_id"],supplier2)
        self.assertEqual(float(rows[0]["unit_cost"]),6)

    def test_company_scoped_permissions_reject_foreign_company_actor(self):
        foreign_company = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('PO-AUTH','Permission scope')"
        ).lastrowid
        foreign_branch = self.conn.execute(
            "INSERT INTO branches(company_id,code,name) VALUES(?, 'PO-AUTH-B','Permission scope')",
            (foreign_company,),
        ).lastrowid
        with self.assertRaises(PurchasingWorkflowError):
            self.svc.create_requisition(
                foreign_company, foreign_branch, "REQ-DENIED", date.today().isoformat(),
                self.user_id, [self._item()],
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM purchase_requisitions WHERE requisition_number='REQ-DENIED'"
        ).fetchone()[0], 0)

    def test_missing_action_permission_blocks_requisition(self):
        self.conn.execute(
            """DELETE FROM role_permissions
               WHERE role_id=(SELECT role_id FROM users WHERE id=?)
                 AND permission_id=(SELECT id FROM permissions WHERE permission_key='purchases.create')""",
            (self.user_id,),
        )
        self.conn.commit()
        with self.assertRaises(PurchasingWorkflowError):
            self.svc.create_requisition(
                self.company, self.branch, "REQ-DENIED", date.today().isoformat(),
                self.user_id, [self._item()],
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM purchase_requisitions WHERE requisition_number='REQ-DENIED'"
        ).fetchone()[0], 0)

    def test_late_delivery_and_supplier_performance(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-LATE",(date.today()-timedelta(days=10)).isoformat(),
            (date.today()-timedelta(days=2)).isoformat(),self.user_id,[self._item()])
        rows = self.svc.order_tracking(self.company,self.branch,self.user_id)
        row = next(r for r in rows if r["id"] == order)
        self.assertEqual(row["is_late"],1)
        perf = self.svc.supplier_performance(self.company,self.branch,self.user_id)
        self.assertEqual(perf[0]["order_count"],1)

    def test_invoice_payload_contains_only_received_quantities(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-PAYLOAD",date.today().isoformat(),None,self.user_id,[self._item(10,5)])
        line = self.conn.execute("SELECT id FROM purchase_order_items WHERE order_id=?",(order,)).fetchone()[0]
        self.svc.record_receipt(self.company,self.branch,order,"GRN-P",date.today().isoformat(),self.user_id,[{"order_item_id":line,"quantity":4}])
        payload = self.svc.order_invoice_payload(self.company,self.branch,order,self.user_id)
        self.assertEqual(payload["supplier_id"],self.supplier)
        self.assertEqual(payload["items"][0]["quantity"],4)
        self.assertEqual(payload["order_id"],order)
        self.assertEqual(payload["items"][0]["order_item_id"],line)
        self.assertEqual(payload["subtotal"],20)
        self.assertEqual(payload["total"],20)

    def test_requisition_cannot_be_partially_converted(self):
        req = self.svc.create_requisition(self.company,self.branch,"REQ-PART",date.today().isoformat(),self.user_id,[self._item(10)])
        with self.assertRaises(Exception):
            self.svc.create_order(self.company,self.branch,self.supplier,"PO-PART",date.today().isoformat(),None,
                self.user_id,[self._item(5)],req)
        self.assertEqual(self.conn.execute("SELECT status FROM purchase_requisitions WHERE id=?",(req,)).fetchone()[0],"OPEN")

    def test_pending_order_requires_approval_before_receipt(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-APPROVE",date.today().isoformat(),None,
            self.user_id,[self._item()],require_approval=True)
        line = self.conn.execute("SELECT id FROM purchase_order_items WHERE order_id=?",(order,)).fetchone()[0]
        with self.assertRaises(Exception):
            self.svc.record_receipt(self.company,self.branch,order,"GRN-PENDING",date.today().isoformat(),self.user_id,
                [{"order_item_id":line,"quantity":1}])
        self.svc.approve_order(self.company,self.branch,order,self.user_id,"Reviewed")
        self.svc.record_receipt(self.company,self.branch,order,"GRN-APPROVED",date.today().isoformat(),self.user_id,
            [{"order_item_id":line,"quantity":1}])
        row = self.conn.execute("SELECT approval_status,status FROM purchase_orders WHERE id=?",(order,)).fetchone()
        self.assertEqual(tuple(row),("APPROVED","PARTIALLY_RECEIVED"))

    def test_rejection_requires_reason(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-REJECT",date.today().isoformat(),None,
            self.user_id,[self._item()],require_approval=True)
        with self.assertRaises(Exception):
            self.svc.reject_order(self.company,self.branch,order,self.user_id,"")
        self.svc.reject_order(self.company,self.branch,order,self.user_id,"Budget exceeded")
        self.assertEqual(self.conn.execute("SELECT approval_status FROM purchase_orders WHERE id=?",(order,)).fetchone()[0],"REJECTED")

    def test_unreceived_order_can_be_cancelled(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-CANCEL",date.today().isoformat(),None,self.user_id,[self._item()])
        self.assertTrue(self.svc.cancel_order(self.company,self.branch,order,self.user_id))
        self.assertEqual(self.conn.execute("SELECT status FROM purchase_orders WHERE id=?",(order,)).fetchone()[0],"CANCELLED")

    def test_price_history_excludes_draft_and_foreign_company_invoices(self):
        # The history is intentionally sourced only from already-posted invoices.
        self.conn.execute("INSERT INTO purchase_invoices(company_id,branch_id,supplier_id,invoice_number,invoice_date,status) VALUES(?,?,?,?,?,'Draft')",
            (self.company,self.branch,self.supplier,"DRAFT-PRICE",date.today().isoformat()))
        self.conn.commit()
        self.assertEqual(self.svc.supplier_price_history(self.company,self.product,self.branch),[])

    def test_invoice_line_cannot_be_overmatched_across_multiple_po_links(self):
        order = self.svc.create_order(self.company,self.branch,self.supplier,"PO-MATCH-CAP",date.today().isoformat(),None,
            self.user_id,[self._item(10,5)])
        po_line = self.conn.execute("SELECT id FROM purchase_order_items WHERE order_id=?",(order,)).fetchone()[0]
        self.svc.record_receipt(self.company,self.branch,order,"GRN-MATCH-CAP",date.today().isoformat(),self.user_id,
            [{"order_item_id":po_line,"quantity":10}])
        invoice = self.conn.execute("INSERT INTO purchase_invoices(company_id,branch_id,supplier_id,invoice_number,invoice_date,status) VALUES(?,?,?,?,?,'POSTED')",
            (self.company,self.branch,self.supplier,"INV-MATCH-CAP",date.today().isoformat())).lastrowid
        inv_line = self.conn.execute("INSERT INTO purchase_invoice_items(invoice_id,product_id,warehouse_id,quantity,unit_cost,total) VALUES(?,?,?,?,?,?)",
            (invoice,self.product,self.warehouse,5,5,25)).lastrowid
        self.svc.link_invoice(self.company,self.branch,order,invoice,self.user_id,
            [{"order_item_id":po_line,"invoice_item_id":inv_line,"quantity":4}])
        with self.assertRaises(Exception):
            self.svc.link_invoice(self.company,self.branch,order,invoice,self.user_id,
                [{"order_item_id":po_line,"invoice_item_id":inv_line,"quantity":2}])
        matched = self.conn.execute("SELECT SUM(matched_quantity) FROM purchase_order_invoice_links WHERE invoice_item_id=?",(inv_line,)).fetchone()[0]
        self.assertEqual(float(matched),4.0)

    def test_multi_line_order_and_multi_line_receipt(self):
        product2 = self.conn.execute(
            "INSERT INTO products(company_id,branch_id,code,name,quantity) VALUES(?,?,'PO-P2','PO Product 2',0)",
            (self.company, self.branch)).lastrowid
        items = [self._item(8, 5), {"product_id": product2, "warehouse_id": self.warehouse,
                                  "quantity": 6, "unit_cost": 7}]
        order = self.svc.create_order(self.company, self.branch, self.supplier, "PO-MULTI",
            date.today().isoformat(), None, self.user_id, items, require_approval=True)
        lines = self.conn.execute(
            "SELECT id,ordered_quantity FROM purchase_order_items WHERE order_id=? ORDER BY id", (order,)).fetchall()
        self.assertEqual(len(lines), 2)
        self.svc.approve_order(self.company, self.branch, order, self.user_id, "Multi-line review")
        receipt_items = [{"order_item_id": int(lines[0][0]), "quantity": 3},
                         {"order_item_id": int(lines[1][0]), "quantity": 2}]
        receipt = self.svc.record_receipt(self.company, self.branch, order, "GRN-MULTI",
            date.today().isoformat(), self.user_id, receipt_items)
        self.assertGreater(receipt, 0)
        received = self.conn.execute(
            "SELECT SUM(quantity) FROM purchase_receipt_items WHERE receipt_id=?", (receipt,)).fetchone()[0]
        self.assertEqual(float(received), 5.0)
        self.assertEqual(self.conn.execute("SELECT status FROM purchase_orders WHERE id=?", (order,)).fetchone()[0],
                         "PARTIALLY_RECEIVED")

    def test_invalid_date_and_quantity_are_rejected(self):
        with self.assertRaises(Exception):
            self.svc.create_requisition(self.company,self.branch,"BAD","2026-02-30",self.user_id,[self._item()])
        with self.assertRaises(Exception):
            self.svc.create_requisition(self.company,self.branch,"BADQ",date.today().isoformat(),self.user_id,[self._item(0)])

    def test_role_record_and_field_policies_apply_in_service_layer(self):
        role_id, scoped_user = self._create_role_user(
            "BUYER_SCOPED", ["purchases.create", "purchases.cancel"]
        )
        admin = SecurityAdminService()
        admin.save_role_access_policies(
            self.company, role_id, [],
            [{"effect": "ALLOW", "field_key": "created_by",
              "operator": "EQ", "value": "current_user"}],
            actor_id=self.user_id,
        )
        own_order = self.svc.create_order(
            self.company, self.branch, self.supplier, "PO-OWN", date.today().isoformat(),
            None, scoped_user, [self._item()],
        )
        admin_order = self.svc.create_order(
            self.company, self.branch, self.supplier, "PO-OTHER", date.today().isoformat(),
            None, self.user_id, [self._item()],
        )
        rows = self.svc.order_tracking(self.company, self.branch, scoped_user)
        self.assertEqual([row["id"] for row in rows], [own_order])

        admin.save_role_access_policies(
            self.company, role_id,
            [{"field_key": "unit_cost", "access_level": "READ_ONLY"},
             {"field_key": "amount", "access_level": "HIDDEN"}],
            [{"effect": "ALLOW", "field_key": "created_by",
              "operator": "EQ", "value": "current_user"}],
            actor_id=self.user_id,
        )
        rows = self.svc.order_tracking(self.company, self.branch, scoped_user)
        self.assertNotIn("total_amount", rows[0])
        with self.assertRaises(PurchasingWorkflowError):
            self.svc.order_invoice_payload(self.company, self.branch, own_order, scoped_user)
        with self.assertRaises(PurchasingWorkflowError):
            self.svc.create_order(
                self.company, self.branch, self.supplier, "PO-PRICE-DENIED",
                date.today().isoformat(), None, scoped_user, [self._item()],
            )
        with self.assertRaises(TransactionError):
            self.svc.cancel_order(self.company, self.branch, admin_order, scoped_user)

    def test_custom_approval_workflow_requires_sequential_role_approvals(self):
        first_role, first_user = self._create_role_user(
            "APPROVER_FIRST", ["purchases.approve"]
        )
        second_role, second_user = self._create_role_user(
            "APPROVER_SECOND", ["purchases.approve"]
        )
        workflows = ApprovalWorkflowService()
        workflow_id = workflows.save_workflow(
            self.company, self.user_id, "Standard purchase", 0, 100,
            [first_role, second_role], True,
        )
        self.assertGreater(workflow_id, 0)
        workflows.save_workflow(
            self.company, self.user_id, "High value purchase", 100, None,
            [second_role], True,
        )
        with self.assertRaises(SecurityAdminError):
            SecurityAdminService().update_role(
                self.company, first_role, "Approver First", "", [], True,
                actor_id=self.user_id,
            )
        with self.assertRaises(ValueError):
            workflows.save_workflow(
                self.company, self.user_id, "Overlapping purchase", 99, 200,
                [first_role], True,
            )

        order = self.svc.create_order(
            self.company, self.branch, self.supplier, "PO-MULTI-APPROVAL",
            date.today().isoformat(), None, self.user_id, [self._item()], require_approval=True,
        )
        steps = self.conn.execute(
            """SELECT role_id,approval_status FROM purchase_order_approval_steps
               WHERE order_id=? ORDER BY step_order""",
            (order,),
        ).fetchall()
        self.assertEqual([int(step["role_id"]) for step in steps], [first_role, second_role])
        with self.assertRaises(TransactionError):
            self.svc.approve_order(self.company, self.branch, order, second_user)
        self.svc.approve_order(self.company, self.branch, order, first_user, "First review")
        self.assertEqual(
            self.conn.execute(
                "SELECT approval_status FROM purchase_orders WHERE id=?", (order,)
            ).fetchone()[0],
            "PENDING",
        )
        self.svc.approve_order(self.company, self.branch, order, second_user, "Final review")
        self.assertEqual(
            self.conn.execute(
                "SELECT approval_status FROM purchase_orders WHERE id=?", (order,)
            ).fetchone()[0],
            "APPROVED",
        )
        high_value_order = self.svc.create_order(
            self.company, self.branch, self.supplier, "PO-HIGH-APPROVAL",
            date.today().isoformat(), None, self.user_id, [self._item(qty=30, cost=5)],
            require_approval=True,
        )
        high_value_steps = self.conn.execute(
            """SELECT role_id FROM purchase_order_approval_steps
               WHERE order_id=? ORDER BY step_order""",
            (high_value_order,),
        ).fetchall()
        self.assertEqual([int(step["role_id"]) for step in high_value_steps], [second_role])


if __name__ == "__main__":
    unittest.main()
