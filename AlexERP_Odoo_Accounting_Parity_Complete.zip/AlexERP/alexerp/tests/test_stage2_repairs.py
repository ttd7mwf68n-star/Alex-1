from __future__ import annotations

import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.inventory_migrations import allocate_legacy_stock
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.repositories.base_repository import BaseRepository
from alexerp.repositories.product_stock_repository import ProductStockRepository
from alexerp.repositories.user_repository import UserRepository
from alexerp.services.auth_service import AuthService
from alexerp.services.inventory_count_service import InventoryCountService
from alexerp.services.purchase_service import PurchaseService
from alexerp.services.sales_service import SalesService
from alexerp.services.sales_return_service import SalesReturnService


class Stage2RepairTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_test_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.accounts = {}
        for index, code in enumerate(("AR", "SALES", "INV", "COGS", "TAX"), start=1):
            cur = self.conn.execute(
                "INSERT INTO chart_of_accounts(company_id, account_code, account_name) VALUES(1, ?, ?)",
                (code, code),
            )
            self.accounts[code] = cur.lastrowid
        cur = self.conn.execute(
            "INSERT INTO customers(company_id, code, name) VALUES(1, 'C1', 'Test Customer')"
        )
        self.customer_id = cur.lastrowid
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def add_product(self, code: str, name: str, purchase_price: float, qty: float, average_cost: float):
        cur = self.conn.execute(
            "INSERT INTO products(code, name, company_id, branch_id, purchase_price, sale_price, quantity) "
            "VALUES(?, ?, 1, 1, ?, 20, ?)",
            (code, name, purchase_price, qty),
        )
        product_id = cur.lastrowid
        self.conn.execute(
            "INSERT INTO product_stock(company_id, branch_id, warehouse_id, product_id, quantity, average_cost) "
            "VALUES(1, 1, 1, ?, ?, ?)",
            (product_id, qty, average_cost),
        )
        self.conn.commit()
        return product_id

    def post_sale(self, invoice_number: str, items: list, subtotal: float, tax: float, total: float):
        return SalesService().create_invoice(
            company_id=1, branch_id=1, customer_id=self.customer_id,
            invoice_number=invoice_number, invoice_date="2026-01-01", items=items,
            subtotal=subtotal, discount=0, tax=tax, total=total, paid_amount=0,
            remaining_amount=total, notes="test", created_by=1,
            receivable_account=self.accounts["AR"], sales_account=self.accounts["SALES"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"] if tax else None,
        )

    def test_duplicate_sales_lines_cannot_oversell_combined_warehouse_stock(self):
        product_id = self.add_product("P-DUP", "Duplicate line", 10, 5, 10)
        with self.assertRaises(Exception) as ctx:
            self.post_sale("S-DUP-OVER", [
                {"product_id": product_id, "warehouse_id": 1, "quantity": 3,
                 "unit_price": 10, "discount": 0, "tax": 0, "total": 30},
                {"product_id": product_id, "warehouse_id": 1, "quantity": 3,
                 "unit_price": 10, "discount": 0, "tax": 0, "total": 30},
            ], subtotal=60, tax=0, total=60)
        self.assertIn("Insufficient stock", str(ctx.exception))
        stock = self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()
        self.assertEqual(float(stock[0]), 5.0)
        invoice_count = self.conn.execute(
            "SELECT COUNT(*) FROM sales_invoices WHERE invoice_number='S-DUP-OVER'"
        ).fetchone()[0]
        self.assertEqual(invoice_count, 0)

    def test_sales_rejects_line_total_that_does_not_reconcile(self):
        product_id = self.add_product("P-LINE-TOTAL", "Line total", 10, 10, 10)
        with self.assertRaises(Exception) as ctx:
            self.post_sale("S-LINE-TOTAL", [{
                "product_id": product_id, "warehouse_id": 1, "quantity": 2,
                "unit_price": 10, "discount": 0, "tax": 0, "total": 19,
            }], subtotal=19, tax=0, total=19)
        self.assertIn("line 1 total", str(ctx.exception))
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM sales_invoices WHERE invoice_number='S-LINE-TOTAL'"
        ).fetchone())

    def test_sales_rejects_negative_line_discount_or_tax(self):
        product_id = self.add_product("P-LINE-NEG", "Negative line amount", 10, 10, 10)
        for invoice_number, discount, tax, total in (
            ("S-LINE-DISC", -1, 0, 21),
            ("S-LINE-TAX", 0, -1, 20),
        ):
            with self.subTest(invoice_number=invoice_number):
                with self.assertRaises(Exception) as ctx:
                    self.post_sale(invoice_number, [{
                        "product_id": product_id, "warehouse_id": 1, "quantity": 2,
                        "unit_price": 10, "discount": discount, "tax": tax, "total": total,
                    }], subtotal=total, tax=0, total=total)
                self.assertIn("line 1", str(ctx.exception))
                self.assertIsNone(self.conn.execute(
                    "SELECT 1 FROM sales_invoices WHERE invoice_number=?", (invoice_number,)
                ).fetchone())

    def test_purchase_list_works(self):
        self.assertEqual(PurchaseService().list(), [])

    def test_sales_issue_cost_is_saved_and_cancel_restores_average_cost(self):
        product_id = self.add_product("P1", "Costed", 10, 10, 10)
        invoice_id = self.post_sale("S-COST", [{
            "product_id": product_id, "warehouse_id": 1, "quantity": 2,
            "unit_price": 10, "discount": 0, "tax": 0, "total": 20,
        }], subtotal=20, tax=0, total=20)

        saved_cost = self.conn.execute(
            "SELECT unit_cost FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
        ).fetchone()[0]
        self.assertEqual(float(saved_cost), 10.0)

        SalesService().cancel_invoice(invoice_id, created_by=1, cancel_date="2026-01-02")
        stock = self.conn.execute(
            "SELECT quantity, average_cost FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()
        self.assertEqual(float(stock[0]), 10.0)
        self.assertEqual(float(stock[1]), 10.0)

    def test_return_tax_comes_from_returned_lines_not_invoice_average(self):
        exempt_id = self.add_product("P-EX", "Exempt", 5, 1, 5)
        taxed_id = self.add_product("P-TX", "Taxed", 8, 1, 8)
        invoice_id = self.post_sale("S-TAX", [
            {"product_id": exempt_id, "warehouse_id": 1, "quantity": 1,
             "unit_price": 50, "discount": 0, "tax": 0, "total": 50},
            {"product_id": taxed_id, "warehouse_id": 1, "quantity": 1,
             "unit_price": 50, "discount": 0, "tax": 10, "total": 60},
        ], subtotal=100, tax=10, total=110)

        return_id = SalesReturnService().create_return(
            company_id=1, branch_id=1, sales_invoice_id=invoice_id,
            customer_id=self.customer_id, return_number="R-EX", return_date="2026-01-03",
            items=[{"product_id": exempt_id, "warehouse_id": 1, "quantity": 1, "total": 50}],
            total=50, notes="exempt item only", created_by=1,
            sales_account=self.accounts["SALES"], receivable_account=self.accounts["AR"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"],
        )
        entry = self.conn.execute(
            "SELECT id FROM journal_entries WHERE reference_type='SALE_RETURN' AND reference_id=?",
            (return_id,),
        ).fetchone()
        lines = self.conn.execute(
            "SELECT account_id, debit, credit FROM journal_details WHERE journal_entry_id=?",
            (entry[0],),
        ).fetchall()
        tax_lines = [row for row in lines if row[0] == self.accounts["TAX"]]
        sales_line = next(row for row in lines if row[0] == self.accounts["SALES"])
        self.assertEqual(tax_lines, [])
        self.assertEqual(float(sales_line[1]), 50.0)

    def test_repository_created_in_ui_thread_resolves_worker_connection(self):
        repo = BaseRepository()
        main_connection = repo.connection
        worker_connections = []
        thread = threading.Thread(target=lambda: worker_connections.append(repo.connection))
        thread.start()
        thread.join(timeout=5)
        self.assertFalse(thread.is_alive())
        self.assertEqual(len(worker_connections), 1)
        self.assertIsNot(main_connection, worker_connections[0])

    def test_legacy_allocation_rolls_back_if_stock_movement_fails(self):
        product_id = self.add_product("P-LEG", "Legacy", 4, 0, 0)
        self.conn.execute(
            "INSERT INTO legacy_stock_unallocated(product_id, quantity, reason) VALUES(?, 3, 'test')",
            (product_id,),
        )
        self.conn.execute("""
            CREATE TRIGGER fail_legacy_movement BEFORE INSERT ON stock_movements
            WHEN NEW.reference_type='MIGRATION_ALLOCATION'
            BEGIN SELECT RAISE(ABORT, 'simulated movement failure'); END
        """)
        self.conn.commit()
        with self.assertRaises(sqlite3.DatabaseError):
            allocate_legacy_stock(self.conn, product_id, 1)
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM product_stock WHERE product_id=? AND quantity=3", (product_id,)
        ).fetchone())
        pending = self.conn.execute(
            "SELECT resolved_at FROM legacy_stock_unallocated WHERE product_id=?", (product_id,)
        ).fetchone()
        self.assertIsNone(pending[0])

    def test_login_result_never_exposes_password_hash(self):
        user = AuthService().login("admin", "test-admin-password")
        self.assertEqual(user["username"], "admin")
        self.assertNotIn("password_hash", user)

    def test_multiple_users_can_omit_email(self):
        users = UserRepository()
        first = users.add("blank-email-1", "hash-1", "First", 1, 1, 1)
        second = users.add("blank-email-2", "hash-2", "Second", 1, 1, 1)
        users.commit()
        emails = self.conn.execute(
            "SELECT email FROM users WHERE id IN (?, ?) ORDER BY id", (first, second)
        ).fetchall()
        self.assertEqual([row[0] for row in emails], [None, None])

    def test_stock_repository_rejects_cross_company_product_warehouse_pair(self):
        company_id = self.conn.execute(
            "INSERT INTO companies(code, name) VALUES('COMP002', 'Other Company')"
        ).lastrowid
        branch_id = self.conn.execute(
            "INSERT INTO branches(company_id, code, name) VALUES(?, 'BR2', 'Other Branch')",
            (company_id,),
        ).lastrowid
        product_id = self.conn.execute(
            "INSERT INTO products(code, name, company_id, branch_id) VALUES('P-OTHER', 'Other', ?, ?)",
            (company_id, branch_id),
        ).lastrowid
        self.conn.commit()

        with self.assertRaises(ValueError):
            ProductStockRepository().set_quantity(1, product_id, 5)
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM product_stock WHERE product_id=?", (product_id,)
        ).fetchone())

    def test_inventory_count_uses_derived_difference_and_rolls_back_bad_input(self):
        product_id = self.add_product("P-COUNT", "Counted", 5, 10, 5)
        service = InventoryCountService()
        count_id = service.create_count(
            1, 1, 1, "COUNT-OK", "2026-01-01",
            [{"product_id": product_id, "system_quantity": 10, "counted_quantity": 7,
              "difference": -3, "unit_cost": 5}], "test", 1,
        )
        stored = self.conn.execute(
            "SELECT difference FROM inventory_count_items WHERE inventory_count_id=?", (count_id,)
        ).fetchone()
        self.assertEqual(float(stored[0]), -3.0)
        from alexerp.services.audit_service import AuditService
        count_events = AuditService().list_events(company_id=1, entity_type="inventory_count")
        self.assertEqual(len(count_events), 1)
        self.assertEqual(count_events[0]["action"], "inventory_count_created")

        with self.assertRaises(Exception):
            service.create_count(
                1, 1, 1, "COUNT-BAD", "2026-01-01",
                [{"product_id": product_id, "system_quantity": 10, "counted_quantity": 7,
                  "difference": 4, "unit_cost": 5}], "bad mismatch", 1,
            )
        self.assertEqual(
            self.conn.execute(
                "SELECT COUNT(*) FROM inventory_counts WHERE count_number='COUNT-BAD'"
            ).fetchone()[0],
            0,
        )


if __name__ == "__main__":
    unittest.main()
