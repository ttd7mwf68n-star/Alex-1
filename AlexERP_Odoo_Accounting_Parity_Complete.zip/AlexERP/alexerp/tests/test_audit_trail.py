"""Audit trail schema, privacy, filtering, and admin mutation coverage."""
from __future__ import annotations
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.audit_service import AuditService
from alexerp.services.security_admin_service import SecurityAdminService


class AuditTrailTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tmp = tempfile.TemporaryDirectory(prefix="alex_audit_")
        db_module.DATABASE_FILE = Path(self.tmp.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        admin = dict(self.conn.execute("SELECT * FROM users WHERE username='admin'").fetchone())
        self.company_id = int(admin["company_id"])
        self.branch_id = int(admin["branch_id"])
        self.admin_id = int(admin["id"])
        self.audit = AuditService()
        self.admin = SecurityAdminService()

    def tearDown(self):
        Database.close()
        self.tmp.cleanup()

    def test_audit_schema_adds_metadata_without_losing_legacy_rows(self):
        self.conn.execute("DROP TABLE audit_logs")
        self.conn.execute("""CREATE TABLE audit_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, module TEXT NOT NULL,
            action TEXT NOT NULL, record_id INTEGER, description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        self.conn.execute("INSERT INTO audit_logs(user_id,module,action,description) VALUES(NULL,'sales','created','legacy')")
        self.conn.commit()
        from alexerp.database.schema.security import create_security_tables
        create_security_tables(self.conn.cursor())
        self.conn.commit()
        self.assertEqual(self.conn.execute("SELECT description FROM audit_logs WHERE id=1").fetchone()[0], "legacy")
        columns = {r[1] for r in self.conn.execute("PRAGMA table_info(audit_logs)")}
        self.assertTrue({"company_id", "before_json", "after_json", "entity_type"}.issubset(columns))

    def test_record_redacts_credentials_and_list_is_company_scoped(self):
        self.audit.record(user_id=self.admin_id, company_id=self.company_id, module="security", action="test",
                          entity_type="user", record_id=7,
                          before={"name": "A", "password_hash": "secret", "token": "abc"},
                          after={"name": "B", "password": "plain"})
        other = self.conn.execute("INSERT INTO companies(code,name) VALUES('AUD_OTHER','Other')").lastrowid
        self.audit.record(user_id=None, company_id=int(other), module="security", action="test")
        events = self.audit.list_events(company_id=self.company_id)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["before"], {"name": "A"})
        self.assertEqual(events[0]["after"], {"name": "B"})
        self.assertNotIn("password_hash", json.dumps(events, ensure_ascii=False, default=str))

    def test_admin_user_creation_and_update_are_audited_without_password(self):
        role_id = self.admin.create_role(self.company_id, "AUDIT_VIEW", "Audit viewer", "", ["dashboard.view"], actor_id=self.admin_id)
        user_id = self.admin.create_user(company_id=self.company_id, branch_id=self.branch_id,
            username="audit.user", full_name="Audit User", password="secure-password-123", role_id=role_id, actor_id=self.admin_id)
        self.admin.update_user(actor_id=self.admin_id, company_id=self.company_id, user_id=user_id,
            full_name="Audit User Updated", role_id=role_id, branch_id=self.branch_id, is_active=True)
        events = self.audit.list_events(company_id=self.company_id, entity_type="user")
        actions = {e["action"] for e in events}
        self.assertIn("user_created", actions)
        self.assertIn("user_updated", actions)
        self.assertTrue(all(e["user_id"] == self.admin_id for e in events))
        serialized = json.dumps(events, ensure_ascii=False, default=str)
        self.assertNotIn("password_hash", serialized)
        self.assertNotIn("secure-password-123", serialized)

    def test_audit_filters_by_date_range(self):
        self.audit.record(user_id=self.admin_id, company_id=self.company_id,
            module="sales", action="date_filter_test", description="in range")
        events = self.audit.list_events(company_id=self.company_id,
            date_from="2000-01-01", date_to="2999-12-31")
        self.assertTrue(any(e["action"] == "date_filter_test" for e in events))
        excluded = self.audit.list_events(company_id=self.company_id,
            date_from="2999-01-01", date_to="2999-12-31")
        self.assertFalse(any(e["action"] == "date_filter_test" for e in excluded))
        with self.assertRaises(ValueError):
            self.audit.list_events(company_id=self.company_id,
                date_from="2999-12-31", date_to="2999-01-01")
        with self.assertRaises(ValueError):
            self.audit.list_events(company_id=self.company_id, date_from="not-a-date")

    def test_nested_credentials_are_redacted_recursively(self):
        self.audit.record(user_id=self.admin_id, company_id=self.company_id,
            module="security", action="nested_redaction", before={
                "profile": {"name": "User", "access_token": "do-not-store", "passwordHash": "hash-secret",
                            "settings": [{"api_key": "also-secret", "theme": "dark"}]}
            })
        event = self.audit.list_events(company_id=self.company_id, action="nested_redaction")[0]
        self.assertEqual(event["before"], {"profile": {"name": "User", "settings": [{"theme": "dark"}]}})

    def test_role_create_and_update_are_audited(self):
        role_id = self.admin.create_role(self.company_id, "AUDIT_ROLE", "Audit role", "", ["dashboard.view"], actor_id=self.admin_id)
        self.admin.update_role(self.company_id, role_id, "Audit role v2", "changed", ["dashboard.view"], True, actor_id=self.admin_id)
        events = self.audit.list_events(company_id=self.company_id, entity_type="role")
        self.assertEqual({e["action"] for e in events}, {"role_created", "role_updated"})
        updated = next(e for e in events if e["action"] == "role_updated")
        self.assertEqual(updated["before"]["name"], "Audit role")
        self.assertEqual(updated["after"]["name"], "Audit role v2")


if __name__ == "__main__":
    unittest.main()
