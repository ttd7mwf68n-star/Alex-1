"""Persistent session lifecycle, revocation, and audit tests."""
from __future__ import annotations
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.auth_service import AuthService
from alexerp.services.session_service import SessionService


class SessionLifecycleTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tmp = tempfile.TemporaryDirectory(prefix="alex_sessions_")
        db_module.DATABASE_FILE = Path(self.tmp.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.user = dict(self.conn.execute("SELECT * FROM users WHERE username='admin'").fetchone())
        self.service = SessionService()

    def tearDown(self):
        Database.close()
        self.tmp.cleanup()

    def test_session_token_is_not_stored_in_plaintext_and_can_be_validated(self):
        token = self.service.create(self.user, ip_address="127.0.0.1", device="unit-test")
        row = self.conn.execute("SELECT session_token,expires_at FROM user_sessions WHERE user_id=?", (self.user["id"],)).fetchone()
        self.assertNotEqual(row["session_token"], token)
        self.assertIsNotNone(row["expires_at"])
        self.assertEqual(self.service.validate(token)["id"], self.user["id"])

    def test_logout_revokes_session_and_records_audit(self):
        token = self.service.create(self.user)
        self.assertTrue(self.service.revoke(token, user_id=self.user["id"]))
        self.assertIsNone(self.service.validate(token))
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM audit_logs WHERE action='session_revoked'").fetchone()[0], 1)

    def test_user_wide_revocation_ends_all_sessions(self):
        first = self.service.create(self.user)
        second = self.service.create(self.user)
        self.assertEqual(self.service.revoke_user_sessions(self.user["id"], reason="test"), 2)
        self.assertIsNone(self.service.validate(first))
        self.assertIsNone(self.service.validate(second))

    def test_inactive_user_cannot_reuse_existing_session(self):
        token = self.service.create(self.user)
        self.conn.execute("UPDATE users SET is_active=0 WHERE id=?", (self.user["id"],))
        self.conn.commit()
        self.assertIsNone(self.service.validate(token))


    def test_expired_session_is_revoked_and_rejected(self):
        token = self.service.create(self.user)
        self.conn.execute("UPDATE user_sessions SET expires_at='2000-01-01 00:00:00' WHERE user_id=?", (self.user["id"],))
        self.conn.commit()
        self.assertIsNone(self.service.validate(token))
        active = self.conn.execute("SELECT is_active FROM user_sessions WHERE user_id=?", (self.user["id"],)).fetchone()[0]
        self.assertEqual(active, 0)


    def test_successful_login_upgrades_legacy_password_hash(self):
        import hashlib
        salt = "old-salt"
        digest = hashlib.pbkdf2_hmac("sha256", b"legacy-password", salt.encode(), 120000).hex()
        self.conn.execute("UPDATE users SET password_hash=? WHERE id=?", (f"{salt}${digest}", self.user["id"]))
        self.conn.commit()
        AuthService().login("admin", "legacy-password")
        upgraded = self.conn.execute("SELECT password_hash FROM users WHERE id=?", (self.user["id"],)).fetchone()[0]
        self.assertTrue(upgraded.startswith("pbkdf2_sha256$310000$"))

    def test_password_change_revokes_existing_sessions(self):
        token = self.service.create(self.user)
        AuthService().change_password(
            self.user["id"], "new-secure-password-123", actor_id=self.user["id"]
        )
        self.assertIsNone(self.service.validate(token))


if __name__ == "__main__":
    unittest.main()
