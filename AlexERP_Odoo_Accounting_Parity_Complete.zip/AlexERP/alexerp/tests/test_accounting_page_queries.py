"""Company-scoped query coverage for the accounting workspace."""
from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

if importlib.util.find_spec("customtkinter") is None:
    raise unittest.SkipTest("customtkinter is not installed in this test environment")

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.accounting.read_service import AccountingReadService
from alexerp.ui.accounting_page import AccountingPage


class AccountingPageQueryTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_accounting_ui_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "accounting.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.customer_id = self.conn.execute(
            "INSERT INTO customers(company_id,code,name) VALUES(1,'ACCT-C1','Accounting Customer')"
        ).lastrowid
        self.account_id = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_code,account_name) "
            "VALUES(1,'ACCT-100','Accounting Test Account')"
        ).lastrowid
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def _page_stub(self, search="", status="المرحلة فقط"):
        captured = {}
        return SimpleNamespace(
            company_id=1,
            search=SimpleNamespace(get=lambda: search),
            status_filter=SimpleNamespace(get=lambda: status),
            accounting_reads=AccountingReadService(),
            _money=AccountingPage._money,
            _show_table=lambda columns, rows, summary: captured.update(
                columns=columns, rows=rows, summary=summary
            ),
            captured=captured,
        )

    def test_journal_items_show_invoice_partner_and_exclude_unposted_entries(self):
        invoice_id = self.conn.execute(
            """INSERT INTO sales_invoices(
                   company_id,branch_id,customer_id,invoice_number,invoice_date,total,status)
               VALUES(1,1,?,'ACCT-S-1','2026-02-10',100,'Posted')""",
            (self.customer_id,),
        ).lastrowid
        for number, posted in (("ACCT-J-POSTED", 1), ("ACCT-J-DRAFT", 0)):
            journal_id = self.conn.execute(
                """INSERT INTO journal_entries(
                       company_id,branch_id,entry_number,entry_date,description,
                       reference_type,reference_id,is_posted)
                   VALUES(1,1,?,'2026-02-10','Invoice posting','SALE',?,?)""",
                (number, invoice_id, posted),
            ).lastrowid
            self.conn.execute(
                """INSERT INTO journal_details(
                       journal_entry_id,account_id,debit,credit,description)
                   VALUES(?,?,100,0,'Customer receivable')""",
                (journal_id, self.account_id),
            )
        self.conn.commit()

        page = self._page_stub()
        AccountingPage._load_journal_items(page)

        rows = page.captured["rows"]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["entry_number"], "ACCT-J-POSTED")
        self.assertEqual(rows[0]["partner_name"], "Accounting Customer")
        self.assertEqual(rows[0]["account"], "ACCT-100 Accounting Test Account")
        self.assertEqual(rows[0]["matching_number"], "—")

    def test_journal_list_search_is_company_scoped(self):
        self.conn.execute(
            "INSERT INTO journal_entries(company_id,entry_number,entry_date,description,is_posted) "
            "VALUES(1,'OWN-READ-1','2026-02-10','owned read record',1)"
        )
        foreign_company = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('READ-FOREIGN','Foreign')"
        ).lastrowid
        self.conn.execute(
            "INSERT INTO journal_entries(company_id,entry_number,entry_date,description,is_posted) "
            "VALUES(?,'FOREIGN-READ-1','2026-02-10','owned read record',1)",
            (foreign_company,),
        )
        self.conn.commit()

        page = self._page_stub(search="owned read record")
        AccountingPage._load_journals(page)
        self.assertEqual([row["entry_number"] for row in page.captured["rows"]], ["OWN-READ-1"])

    def test_account_list_exposes_type_currency_and_company(self):
        page = self._page_stub(status="حسابات نشطة")
        AccountingPage._load_accounts(page)

        row = next(
            item for item in page.captured["rows"]
            if item["account_code"] == "ACCT-100"
        )
        self.assertEqual(row["company_name"], "AlexERP")
        self.assertEqual(row["currency_code"], "EGP")
        self.assertIn("account_type", row)
        self.assertIn("العملة", [column[1] for column in page.captured["columns"]])

    def test_dashboard_invoice_summary_distinguishes_drafts_and_overdue_balances(self):
        self.conn.execute(
            """INSERT INTO sales_invoices(
                   company_id,branch_id,customer_id,invoice_number,invoice_date,due_date,
                   total,remaining_amount,status)
               VALUES(1,1,?,'ACCT-S-DRAFT','2026-02-10','2026-02-10',50,50,'Draft')""",
            (self.customer_id,),
        )
        self.conn.execute(
            """INSERT INTO sales_invoices(
                   company_id,branch_id,customer_id,invoice_number,invoice_date,due_date,
                   total,remaining_amount,status)
               VALUES(1,1,?,'ACCT-S-OPEN','2026-02-10','2000-01-01',100,100,'Posted')""",
            (self.customer_id,),
        )
        self.conn.commit()

        summary = AccountingPage._overview_document(
            object(), "sales_invoices", "invoice_date", 1
        )
        self.assertEqual(summary["drafts"], 1)
        self.assertEqual(summary["open_count"], 1)
        self.assertEqual(float(summary["open_amount"]), 100.0)
        self.assertEqual(summary["overdue_count"], 1)


if __name__ == "__main__":
    unittest.main()
