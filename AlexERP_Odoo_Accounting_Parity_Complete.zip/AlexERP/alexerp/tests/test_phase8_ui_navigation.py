"""Regression checks for manifest-driven desktop navigation (no GUI runtime needed)."""
import ast
import unittest
from pathlib import Path

from alexerp.ui.applications_page import AppCatalogPage, ApplicationsPage
from alexerp.ui.accounting_page import AccountingPage
from alexerp.ui.inventory_page import InventoryPage
from alexerp.ui.main_window import MODULE_MANIFESTS, NAVIGATION


class Phase8NavigationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = Path(__file__).resolve().parents[1] / "ui" / "main_window.py"
        cls.tree = ast.parse(path.read_text(encoding="utf-8"))
        cls.source = path.read_text(encoding="utf-8")
        cls.navigation = {item[0]: item for item in NAVIGATION}

    def test_inventory_and_accounting_are_real_manifest_pages(self):
        inventory = self.navigation["inventory"]
        accounting = self.navigation["accounting"]
        self.assertIs(inventory[3], InventoryPage)
        self.assertEqual(inventory[2], MODULE_MANIFESTS["inventory"].icon)
        self.assertEqual(inventory[4], "المخزون")
        self.assertIs(accounting[3], AccountingPage)
        self.assertEqual(accounting[2], MODULE_MANIFESTS["accounting"].icon)
        self.assertEqual(accounting[4], "المالية")

    def test_business_navigation_entries_come_from_application_manifests(self):
        business_ids = set(self.navigation) - {"apps", "app_catalog"}
        manifests = {
            module_id for module_id, manifest in MODULE_MANIFESTS.items()
            if manifest.application and manifest.state == "available"
        }
        self.assertEqual(business_ids, manifests)
        for module_id in business_ids:
            manifest = MODULE_MANIFESTS[module_id]
            self.assertEqual(self.navigation[module_id][1], manifest.name)
            self.assertEqual(self.navigation[module_id][3].__name__, manifest.entrypoint.rsplit(".", 1)[-1])

    def test_application_launcher_and_catalog_remain_shell_routes(self):
        self.assertIs(self.navigation["apps"][3], ApplicationsPage)
        self.assertIs(self.navigation["app_catalog"][3], AppCatalogPage)
        self.assertIn('self.navigate("apps" if "apps" in allowed else allowed[0])', self.source)
        self.assertIn('page_kwargs["modules"] = self._accessible_modules()', self.source)

    def test_topbar_exposes_user_name_and_persisted_language_choice(self):
        self.assertIn('text=name, font=font(12, "bold")', self.source)
        self.assertIn('values=["العربية", "English"]', self.source)
        self.assertIn('preferences.save(language=language_code)', self.source)


if __name__ == "__main__":
    unittest.main()
