"""AlexERP — regression: a standalone audit record must commit and release the write lock.

Before Phase 9 the Mobile backup endpoint called AuditService.record() without a
connection; the INSERT left an implicit transaction open on the shared per-thread
connection and every later write (e.g. login) failed with "database is locked".
"""
from __future__ import annotations
import sqlite3
import tempfile
import unittest
from pathlib import Path

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.services.audit_service import AuditService


class AuditAutocommitTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tmp = tempfile.TemporaryDirectory(prefix="alex_audit9_")
        db_module.DATABASE_FILE = Path(self.tmp.name) / "test.db"
        create_database()
        self.conn = Database.connect()

    def tearDown(self):
        Database.close()
        self.tmp.cleanup()

    def test_standalone_record_commits_and_releases_lock(self):
        rid = AuditService.record(user_id=None, company_id=None, module="backup", action="create")
        self.assertFalse(self.conn.in_transaction)
        other = sqlite3.connect(str(db_module.DATABASE_FILE), timeout=1)
        try:
            other.execute("BEGIN IMMEDIATE")  # would raise "database is locked" before the fix
            self.assertEqual(other.execute("SELECT COUNT(*) FROM audit_logs WHERE id=?", (rid,)).fetchone()[0], 1)
            other.rollback()
        finally:
            other.close()

    def test_record_inside_open_transaction_stays_atomic(self):
        self.conn.execute("BEGIN")
        rid = AuditService.record(user_id=None, company_id=None, module="test", action="rollback")
        self.assertTrue(self.conn.in_transaction)
        self.conn.rollback()
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM audit_logs WHERE id=?", (rid,)).fetchone()[0], 0)


if __name__ == "__main__":
    unittest.main()
