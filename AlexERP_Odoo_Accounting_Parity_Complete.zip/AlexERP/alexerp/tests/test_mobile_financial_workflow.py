"""HTTP integration tests for mobile receipts and supplier payments."""
from __future__ import annotations

import json
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from mobile_web.mobile_server import MobileERPHandler, _issue_session


class MobileFinancialWorkflowTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_mobile_fin_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "mobile-test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        branch = self.conn.execute("SELECT id, company_id FROM branches ORDER BY id LIMIT 1").fetchone()
        self.company_id, self.branch_id = int(branch["company_id"]), int(branch["id"])
        self.user = self.conn.execute("SELECT * FROM users ORDER BY id LIMIT 1").fetchone()
        self.customer_id = self.conn.execute(
            "INSERT INTO customers(company_id,code,name) VALUES(?,?,?)",
            (self.company_id, "MOB-C1", "Mobile Customer"),
        ).lastrowid
        self.supplier_id = self.conn.execute(
            "INSERT INTO suppliers(company_id,code,name) VALUES(?,?,?)",
            (self.company_id, "MOB-S1", "Mobile Supplier"),
        ).lastrowid
        self.conn.commit()
        self.token = _issue_session({
            "id": int(self.user["id"]), "username": self.user["username"],
            "full_name": self.user["full_name"], "company_id": self.company_id,
            "branch_id": self.branch_id,
        })
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), MobileERPHandler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)
        Database.close()
        self.tempdir.cleanup()

    def request(self, path, method="GET", payload=None):
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = Request(self.base + path, data=data, method=method, headers={
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        })
        try:
            with urlopen(req, timeout=5) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            return exc.code, json.loads(exc.read().decode("utf-8"))

    def test_mobile_supplier_payment_and_cancellation_workflow(self):
        status, created = self.request("/api/payments/create", "POST", {
            "supplier_id": self.supplier_id, "amount": 25,
        })
        self.assertEqual(status, 200, created)
        payment_id = created["id"]
        status, listing = self.request("/api/payments")
        self.assertEqual(status, 200)
        self.assertTrue(any(int(row["id"]) == payment_id for row in listing["items"]))
        status, cancelled = self.request("/api/payments/cancel", "POST", {"payment_id": payment_id})
        self.assertEqual(status, 200, cancelled)
        row = self.conn.execute("SELECT status FROM payments WHERE id=?", (payment_id,)).fetchone()
        self.assertEqual(row["status"], "CANCELLED")

    def test_mobile_customer_receipt_and_cancellation_workflow(self):
        status, created = self.request("/api/receipts/create", "POST", {
            "customer_id": self.customer_id, "amount": 15,
        })
        self.assertEqual(status, 200, created)
        receipt_id = created["id"]
        status, listing = self.request("/api/receipts")
        self.assertEqual(status, 200)
        self.assertTrue(any(int(row["id"]) == receipt_id for row in listing["items"]))
        status, cancelled = self.request("/api/receipts/cancel", "POST", {"receipt_id": receipt_id})
        self.assertEqual(status, 200, cancelled)
        row = self.conn.execute("SELECT status FROM receipts WHERE id=?", (receipt_id,)).fetchone()
        self.assertEqual(row["status"], "CANCELLED")

    def test_mobile_general_ledger_report_uses_company_and_account_scope(self):
        account = self.conn.execute(
            "SELECT id FROM chart_of_accounts WHERE company_id=? AND COALESCE(allow_posting,1)=1 ORDER BY id LIMIT 1",
            (self.company_id,),
        ).fetchone()
        status, result = self.request(
            f"/api/reports/ledger?account_id={account['id']}&from=2026-01-01&to=2026-12-31"
        )
        self.assertEqual(status, 200, result)
        self.assertTrue(result["ok"])
        self.assertIn("opening_balance", result["report"])
        self.assertIn("closing_balance", result["report"])
        self.assertIn("rows", result["report"])

    def test_mobile_general_ledger_rejects_missing_or_foreign_account(self):
        status, missing = self.request("/api/reports/ledger")
        self.assertEqual(status, 400, missing)
        foreign_company = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('LEDGER-FOREIGN','Ledger Foreign')"
        ).lastrowid
        foreign_account = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_code,account_name,allow_posting) VALUES(?,?,?,1)",
            (foreign_company, "F-100", "Foreign account"),
        ).lastrowid
        self.conn.commit()
        status, result = self.request(f"/api/reports/ledger?account_id={foreign_account}")
        self.assertEqual(status, 404, result)

    def test_mobile_cannot_cancel_another_company_financial_document(self):
        other_company_id = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('FOREIGN-CO','Foreign Company')"
        ).lastrowid
        other_branch_id = self.conn.execute(
            "INSERT INTO branches(company_id,code,name) VALUES(?,?,?)",
            (other_company_id, "FOREIGN-BR", "Foreign Branch"),
        ).lastrowid
        account = self.conn.execute("SELECT id FROM chart_of_accounts WHERE company_id=? ORDER BY id LIMIT 1",
                                   (self.company_id,)).fetchone()
        # Scope check is exercised against a document row owned by a different tenant.
        receipt_id = self.conn.execute(
            "INSERT INTO receipts(company_id,branch_id,receipt_number,customer_id,cash_box_id,amount,created_by) "
            "VALUES(?,?,?,?,?,?,?)",
            (other_company_id, other_branch_id, "FOREIGN-R", None, account["id"], 1, self.user["id"]),
        ).lastrowid
        self.conn.commit()
        status, result = self.request("/api/receipts/cancel", "POST", {"receipt_id": receipt_id})
        self.assertEqual(status, 400, result)
        self.assertFalse(result["ok"])
        row = self.conn.execute("SELECT status FROM receipts WHERE id=?", (receipt_id,)).fetchone()
        self.assertEqual(row["status"], "POSTED")


if __name__ == "__main__":
    unittest.main()
