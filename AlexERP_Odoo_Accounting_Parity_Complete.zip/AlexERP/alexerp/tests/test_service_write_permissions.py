from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.adjustment_service import AdjustmentService
from alexerp.services.auth_service import AuthService
from alexerp.services.company_service import CompanyService
from alexerp.services.customer_service import CustomerService
from alexerp.services.inventory_count_service import InventoryCountService
from alexerp.services.inventory_service import InventoryService
from alexerp.services.permission_service import PermissionDenied
from alexerp.services.product_service import ProductService
from alexerp.services.supplier_service import SupplierService
from alexerp.services.transfer_service import TransferError, TransferService


class ServiceWritePermissionTests(unittest.TestCase):
    @staticmethod
    def _lastrowid(cursor) -> int:
        if cursor.lastrowid is None:
            raise AssertionError("Expected INSERT to return a row id.")
        return cursor.lastrowid

    def setUp(self):
        Database.close()
        self.tmp = tempfile.TemporaryDirectory(prefix="alex_write_permissions_")
        db_module.DATABASE_FILE = Path(self.tmp.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.company_id, self.branch_id, self.admin_id = 1, 1, 1
        role_id = self._lastrowid(self.conn.execute(
            "INSERT INTO roles(code,name,company_id) VALUES('READ_ONLY','Read only',?)",
            (self.company_id,),
        ))
        self.user_id = self._lastrowid(self.conn.execute(
            """INSERT INTO users(username,password_hash,full_name,role_id,company_id,branch_id)
               VALUES('read.only','unused','Read Only',?,?,?)""",
            (role_id, self.company_id, self.branch_id),
        ))
        self.product_id = self._lastrowid(self.conn.execute(
            """INSERT INTO products(code,name,company_id,branch_id,purchase_price,sale_price,quantity)
               VALUES('PERM-P','Permission Product',?,?,5,10,5)""",
            (self.company_id, self.branch_id),
        ))
        self.customer_id = self._lastrowid(self.conn.execute(
            "INSERT INTO customers(company_id,code,name) VALUES(?,'PERM-C','Permission Customer')",
            (self.company_id,),
        ))
        self.supplier_id = self._lastrowid(self.conn.execute(
            "INSERT INTO suppliers(company_id,code,name) VALUES(?,'PERM-S','Permission Supplier')",
            (self.company_id,),
        ))
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tmp.cleanup()

    def test_product_and_stock_mutations_require_action_permissions(self):
        products = ProductService()
        with self.assertRaises(PermissionDenied):
            products.create(
                actor_id=self.user_id, company_id=self.company_id, branch_id=self.branch_id,
                name="Denied Product",
            )
        with self.assertRaises(PermissionDenied):
            products.update(self.product_id, actor_id=self.user_id, name="Denied Update")
        with self.assertRaises(PermissionDenied):
            products.delete(self.product_id, actor_id=self.user_id)
        with self.assertRaises(PermissionDenied):
            products.adjust_stock(self.product_id, 1, user_id=self.user_id)
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM products WHERE name='Denied Product'"
        ).fetchone())
        self.assertEqual(
            float(self.conn.execute(
                "SELECT quantity FROM products WHERE id=?", (self.product_id,)
            ).fetchone()[0]),
            5,
        )

    def test_inventory_adjustments_transfers_counts_and_opening_balance_require_permission(self):
        with self.assertRaises(PermissionDenied):
            AdjustmentService().create_adjustment(
                self.company_id, self.branch_id, 1, "DENIED-ADJ", "2026-01-01",
                "COUNT", [], "", self.user_id,
            )
        with self.assertRaises(TransferError):
            TransferService().create_transfer(
                company_id=self.company_id, branch_id=self.branch_id,
                from_warehouse=1, to_warehouse=1, transfer_number="DENIED-TRANSFER",
                transfer_date="2026-01-01", items=[], notes="", created_by=self.user_id,
            )
        counts = InventoryCountService()
        with self.assertRaises(PermissionDenied):
            counts.create_count(
                self.company_id, self.branch_id, 1, "DENIED-COUNT", "2026-01-01",
                [], "", self.user_id,
            )
        with self.assertRaises(PermissionDenied):
            counts.post_count(999, self.company_id, self.branch_id, 1, self.user_id)
        inventory = InventoryService()
        with self.assertRaises(PermissionDenied):
            inventory.adjust_stock(
                self.company_id, self.branch_id, 1, self.product_id, 10, 5, self.user_id
            )
        with self.assertRaises(PermissionDenied):
            inventory.opening_balance(
                self.company_id, self.branch_id, 1, self.product_id, 5, 5, self.user_id
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM stock_adjustments"
        ).fetchone()[0], 0)
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM inventory_counts"
        ).fetchone()[0], 0)
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM stock_transfers"
        ).fetchone()[0], 0)

    def test_customer_and_supplier_mutations_require_action_permissions(self):
        customers = CustomerService()
        with self.assertRaises(PermissionDenied):
            customers.create_customer(
                self.company_id, "DENIED-C", "Denied Customer", actor_id=self.user_id
            )
        with self.assertRaises(PermissionDenied):
            customers.update_customer(
                self.customer_id, "PERM-C", "Updated", "", "", "", "", "", "", 0, None,
                actor_id=self.user_id,
            )
        with self.assertRaises(PermissionDenied):
            customers.delete(self.customer_id, actor_id=self.user_id)

        suppliers = SupplierService()
        with self.assertRaises(PermissionDenied):
            suppliers.create_supplier(
                self.company_id, "DENIED-S", "Denied Supplier", actor_id=self.user_id
            )
        with self.assertRaises(PermissionDenied):
            suppliers.update_supplier(
                self.supplier_id, "PERM-S", "Updated", "", "", "", "", "", "", None,
                actor_id=self.user_id,
            )
        with self.assertRaises(PermissionDenied):
            suppliers.delete(self.supplier_id, actor_id=self.user_id)

        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM customers WHERE code='DENIED-C'"
        ).fetchone())
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM suppliers WHERE code='DENIED-S'"
        ).fetchone())

    def test_company_and_user_administration_require_admin_permissions(self):
        companies = CompanyService()
        with self.assertRaises(PermissionDenied):
            companies.create_company("DENIED-CO", "Denied Company", actor_id=self.user_id)
        with self.assertRaises(PermissionDenied):
            companies.update_company(
                company_id=self.company_id, code="COMP001", name="Updated",
                commercial_name="", tax_number="", phone="", mobile="", email="",
                website="", address="", city="", country="",
                actor_id=self.user_id,
            )
        with self.assertRaises(PermissionDenied):
            companies.delete(self.company_id, actor_id=self.user_id)
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM companies WHERE code='DENIED-CO'"
        ).fetchone())

        auth = AuthService()
        with self.assertRaises(PermissionDenied):
            auth.create_user(
                "denied.user", "secure-password-123", "Denied", 1, self.company_id,
                self.branch_id, actor_id=self.user_id,
            )
        with self.assertRaises(PermissionDenied):
            auth.activate_user(self.admin_id, actor_id=self.user_id)
        with self.assertRaises(PermissionDenied):
            auth.deactivate_user(self.admin_id, actor_id=self.user_id)
        with self.assertRaises(PermissionDenied):
            auth.change_password(
                self.admin_id, "secure-password-123", actor_id=self.user_id
            )
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM users WHERE username='denied.user'"
        ).fetchone())


if __name__ == "__main__":
    unittest.main()
