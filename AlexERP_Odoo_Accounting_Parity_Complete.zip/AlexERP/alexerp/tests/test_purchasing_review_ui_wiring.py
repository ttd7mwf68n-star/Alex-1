from pathlib import Path
import unittest


class PurchasingReviewUIWiringTests(unittest.TestCase):
    def test_invoice_variance_review_is_exposed_as_read_only_action(self):
        source = (Path(__file__).parents[1] / "ui" / "purchasing_workflow_page.py").read_text(encoding="utf-8")
        self.assertIn('"مراجعة الفروق", self.review_invoice_variances', source)
        self.assertIn('def review_invoice_variances(self):', source)
        self.assertIn('self.service.invoice_match_audit(', source)
        self.assertIn('self._scope()[2]', source)
        self.assertIn('لا يعتمد الفروق ولا يغيّر الفواتير أو القيود المحاسبية', source)

    def test_multi_line_order_and_receipt_editors_are_wired(self):
        source = (Path(__file__).parents[1] / "ui" / "purchasing_workflow_page.py").read_text(encoding="utf-8")
        self.assertIn('def _multi_line_editor(self,', source)
        self.assertIn('def new_order(self):', source)
        self.assertIn('إضافة بند', source)
        self.assertIn('def receive_order(self):', source)
        self.assertIn('استلام متعدد البنود', source)
        self.assertIn('self.service.record_receipt(', source)

    def test_approval_workflows_have_a_desktop_configuration_action(self):
        source = (Path(__file__).parents[1] / "ui" / "purchasing_workflow_page.py").read_text(encoding="utf-8")
        self.assertIn('إعدادات الاعتماد', source)
        self.assertIn('def manage_approval_workflows(self):', source)
        self.assertIn('class ApprovalWorkflowDialog(Dialog):', source)


if __name__ == "__main__":
    unittest.main()
