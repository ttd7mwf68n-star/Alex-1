"""Company-scoped accounting period controls and posting regression tests."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.accounting_service import AccountingService
from alexerp.services.fiscal_period_service import FiscalPeriodService


class FiscalPeriodTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_period_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.account_debit = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_code,account_name) VALUES(1,'D','Debit')"
        ).lastrowid
        self.account_credit = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_code,account_name) VALUES(1,'C','Credit')"
        ).lastrowid
        self.periods = FiscalPeriodService()
        self.accounting = AccountingService()
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def _entry(self, ref_id: int, entry_date: str = "2026-01-15"):
        return self.accounting.create_entry(
            company_id=1, branch_id=1, entry_date=entry_date,
            description="Period test", reference_type="TEST", reference_id=ref_id,
            created_by=1,
            details=[
                {"account_id": self.account_debit, "debit": "100.00", "credit": 0},
                {"account_id": self.account_credit, "debit": 0, "credit": "100.00"},
            ],
        )

    def test_period_creation_and_listing_are_company_scoped(self):
        first = self.periods.create_period(1, "FY2026-Q1", "2026-01-01", "2026-03-31", created_by=1)
        rows = self.periods.list_periods(1)
        self.assertEqual([row["id"] for row in rows], [first])
        self.assertEqual(self.periods.list_periods(2), [])

    def test_overlapping_period_is_rejected(self):
        self.periods.create_period(1, "Jan-Mar", "2026-01-01", "2026-03-31", created_by=1)
        with self.assertRaises(Exception):
            self.periods.create_period(1, "Mar-Apr", "2026-03-01", "2026-04-30", created_by=1)

    def test_configured_company_rejects_posting_outside_all_periods(self):
        self.periods.create_period(1, "FY2026-Q1", "2026-01-01", "2026-03-31", created_by=1)
        with self.assertRaises(Exception):
            self._entry(1, "2026-04-01")
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM journal_entries").fetchone()[0], 0)

    def test_closed_period_blocks_journal_posting(self):
        period_id = self.periods.create_period(1, "FY2026-Q1", "2026-01-01", "2026-03-31", created_by=1)
        self._entry(1)
        self.periods.close_period(period_id, 1)
        with self.assertRaises(Exception):
            self._entry(2)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM journal_entries").fetchone()[0], 1)
        self.assertFalse(self.periods.is_open_for_date(1, "2026-01-15"))
        actions = [row[0] for row in self.conn.execute(
            "SELECT action FROM audit_logs WHERE entity_type='accounting_period' ORDER BY id"
        ).fetchall()]
        self.assertEqual(actions, ["period_created", "period_closed"])

    def test_period_management_requires_explicit_permission(self):
        role_id = self.conn.execute(
            "INSERT INTO roles(code,name,is_system,is_active,company_id) VALUES('LIMITED','Limited',0,1,1)"
        ).lastrowid
        user_id = self.conn.execute(
            "INSERT INTO users(username,password_hash,full_name,role_id,company_id,branch_id,is_active) "
            "VALUES('limited-user','x','Limited User',?,1,1,1)", (role_id,)
        ).lastrowid
        self.conn.commit()
        with self.assertRaises(Exception):
            self.periods.create_period(1, "FY2026-Q1", "2026-01-01", "2026-03-31", created_by=user_id)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM accounting_periods").fetchone()[0], 0)

    def test_close_rejects_unposted_journal(self):
        period_id = self.periods.create_period(1, "FY2026-Q1", "2026-01-01", "2026-03-31", created_by=1)
        entry_id = self.conn.execute(
            """INSERT INTO journal_entries(company_id,branch_id,entry_number,entry_date,
               description,reference_type,reference_id,created_by,is_posted)
               VALUES(1,1,'JV-PENDING','2026-01-15','pending','TEST',98,1,0)"""
        ).lastrowid
        self.conn.execute(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit) VALUES(?,?,100,0)",
            (entry_id, self.account_debit),
        )
        self.conn.execute(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit) VALUES(?,?,0,100)",
            (entry_id, self.account_credit),
        )
        self.conn.commit()
        with self.assertRaises(Exception):
            self.periods.close_period(period_id, 1)
        self.assertEqual(
            self.conn.execute("SELECT is_closed FROM accounting_periods WHERE id=?", (period_id,)).fetchone()[0], 0
        )

    def test_close_rejects_unbalanced_existing_journal(self):
        period_id = self.periods.create_period(1, "FY2026-Q1", "2026-01-01", "2026-03-31", created_by=1)
        entry_id = self.conn.execute(
            """INSERT INTO journal_entries(company_id,branch_id,entry_number,entry_date,
               description,reference_type,reference_id,created_by,is_posted)
               VALUES(1,1,'JV-BAD','2026-01-15','bad','TEST',99,1,1)"""
        ).lastrowid
        self.conn.execute(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit) VALUES(?,?,100,0)",
            (entry_id, self.account_debit),
        )
        self.conn.commit()
        with self.assertRaises(Exception):
            self.periods.close_period(period_id, 1)
        self.assertEqual(
            self.conn.execute("SELECT is_closed FROM accounting_periods WHERE id=?", (period_id,)).fetchone()[0],
            0,
        )

    def test_close_preflight_reports_period_and_ledger_state_through_owned_api(self):
        self.periods.create_period(1, "FY2026-Q1", "2026-01-01", "2026-03-31", created_by=1)
        bad_id = self.conn.execute(
            """INSERT INTO journal_entries(company_id,branch_id,entry_number,entry_date,
               description,reference_type,reference_id,created_by,is_posted)
               VALUES(1,1,'PREFLIGHT-BAD','2026-01-15','bad','TEST',991,1,1)"""
        ).lastrowid
        self.conn.execute(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit) VALUES(?,?,25,0)",
            (bad_id, self.account_debit),
        )
        pending_id = self.conn.execute(
            """INSERT INTO journal_entries(company_id,branch_id,entry_number,entry_date,
               description,reference_type,reference_id,created_by,is_posted)
               VALUES(1,1,'PREFLIGHT-PENDING','2026-01-16','pending','TEST',992,1,0)"""
        ).lastrowid
        self.conn.executemany(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit) VALUES(?,?,?,?)",
            [(pending_id, self.account_debit, 40, 0), (pending_id, self.account_credit, 0, 40)],
        )
        self.conn.commit()

        self.assertEqual(self.periods.close_preflight(1, "2026-01-01", "2026-03-31"), {
            "periods_total": 1,
            "periods_closed": 0,
            "unposted_journals": 1,
            "invalid_journals": 1,
        })

    def test_legacy_company_without_period_configuration_remains_compatible(self):
        self.assertTrue(self.periods.is_open_for_date(1, "2026-01-15"))
        self.assertGreater(self._entry(1), 0)


if __name__ == "__main__":
    unittest.main()
