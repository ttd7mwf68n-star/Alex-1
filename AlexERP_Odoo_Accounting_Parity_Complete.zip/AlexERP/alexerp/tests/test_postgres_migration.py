import sqlite3
import tempfile
import unittest
from pathlib import Path

from alexerp.database.migrate_postgresql import (
    PostgreSQLMigrationError,
    _validate_source,
    _foreign_key_order,
    _order_self_referencing_rows,
)


class PostgreSQLMigrationPlanningTests(unittest.TestCase):
    def test_orders_referenced_tables_before_dependents(self):
        order = _foreign_key_order(
            {"customers", "invoices", "receipts"},
            [("invoices", "customers"), ("receipts", "invoices")],
        )
        self.assertLess(order.index("customers"), order.index("invoices"))
        self.assertLess(order.index("invoices"), order.index("receipts"))

    def test_rejects_cross_table_foreign_key_cycles(self):
        with self.assertRaisesRegex(PostgreSQLMigrationError, "cycle"):
            _foreign_key_order(
                {"a", "b"},
                [("a", "b"), ("b", "a")],
            )

    def test_orders_self_referencing_rows_parent_first(self):
        rows = [
            {"id": 3, "parent_id": 2},
            {"id": 2, "parent_id": None},
            {"id": 4, "parent_id": 3},
        ]
        ordered = _order_self_referencing_rows(
            rows,
            [(("parent_id",), ("id",))],
            ("id",),
        )
        self.assertEqual([row["id"] for row in ordered], [2, 3, 4])

    def test_rejects_self_referencing_row_cycles(self):
        rows = [
            {"id": 1, "parent_id": 2},
            {"id": 2, "parent_id": 1},
        ]
        with self.assertRaisesRegex(PostgreSQLMigrationError, "Self-referencing rows"):
            _order_self_referencing_rows(
                rows,
                [(("parent_id",), ("id",))],
                ("id",),
            )

    def test_source_is_opened_read_only_after_integrity_checks(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "source.db"
            source = sqlite3.connect(path)
            source.execute("CREATE TABLE sample(id INTEGER PRIMARY KEY)")
            source.execute("INSERT INTO sample VALUES(1)")
            source.commit()
            source.close()

            validated = _validate_source(path)
            try:
                self.assertEqual(validated.execute("SELECT COUNT(*) FROM sample").fetchone()[0], 1)
                with self.assertRaises(sqlite3.OperationalError):
                    validated.execute("INSERT INTO sample VALUES(2)")
            finally:
                validated.close()


if __name__ == "__main__":
    unittest.main()
