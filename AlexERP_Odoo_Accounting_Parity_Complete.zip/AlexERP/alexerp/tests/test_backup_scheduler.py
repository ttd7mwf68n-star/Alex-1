from __future__ import annotations
import sqlite3
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from alexerp.database.backup import BackupManager
from alexerp.database.backup_scheduler import DailyBackupScheduler

class DailyBackupSchedulerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.db = root / 'data.db'
        c = sqlite3.connect(self.db); c.execute('CREATE TABLE sample(v TEXT)'); c.execute("INSERT INTO sample VALUES('ok')"); c.commit(); c.close()
        self.manager = BackupManager(root / 'backups', self.db)
        self.scheduler = DailyBackupScheduler(self.manager, hour=2, minute=0, interval_seconds=1)

    def tearDown(self): self.tmp.cleanup()

    def test_not_due_before_local_schedule(self):
        self.assertFalse(self.scheduler.run_if_due(datetime(2026, 11, 17, 1, 59)))
        self.assertEqual(self.manager.list_backups(), [])

    def test_creates_only_one_backup_per_local_day_even_when_called_repeatedly(self):
        now = datetime(2026, 11, 17, 2, 0)
        self.assertTrue(self.scheduler.run_if_due(now))
        self.assertFalse(self.scheduler.run_if_due(now))
        self.assertEqual(len(self.manager.list_backups()), 1)
        self.assertEqual(self.scheduler.last_success, '2026-11-17')

    def test_retention_prunes_only_old_automatic_backups_and_keeps_manual_and_safety(self):
        for i in range(32):
            self.manager.create_backup(backup_type='automatic')
        manual = self.manager.create_backup(backup_type='manual')
        safety = self.manager.create_backup(backup_type='safety')
        self.manager.cleanup_automatic(30)
        automatic = []
        for path in self.manager.list_backups():
            import json
            meta = json.loads(path.with_suffix('.db.json').read_text())
            if meta.get('backup_type') == 'automatic': automatic.append(path)
        self.assertEqual(len(automatic), 30)
        self.assertTrue(manual.exists()); self.assertTrue(safety.exists())

    def test_failure_is_logged_and_does_not_mark_day_successful(self):
        with patch.object(self.manager, 'create_backup', side_effect=OSError('disk full')):
            self.assertFalse(self.scheduler.run_if_due(datetime(2026, 11, 17, 3, 0)))
        self.assertIsNone(self.scheduler.last_success)
        self.assertIn('فشل النسخ', self.scheduler.last_status)

    def test_invalid_schedule_rejected(self):
        with self.assertRaises(ValueError): DailyBackupScheduler(self.manager, hour=24)

if __name__ == '__main__': unittest.main()
