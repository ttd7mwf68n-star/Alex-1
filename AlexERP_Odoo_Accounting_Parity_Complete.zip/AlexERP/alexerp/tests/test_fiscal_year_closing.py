"""Integration tests for atomic fiscal-year closing."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.accounting_service import AccountingService
from alexerp.services.fiscal_period_service import FiscalPeriodService
from alexerp.services.fiscal_year_closing_service import FiscalYearClosingService


class FiscalYearClosingTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_fy_close_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.accounting = AccountingService()
        self.periods = FiscalPeriodService()
        self.closing = FiscalYearClosingService()

        self.cash = self._account("1010", "Cash", 1)
        self.revenue = self._account("4010", "Sales", 4)
        self.expense = self._account("5010", "Rent expense", 5)
        self.retained = self._account("3200", "Retained earnings", 3)
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def _account(self, code, name, account_type_id):
        return int(self.conn.execute(
            """INSERT INTO chart_of_accounts
               (company_id, account_type_id, account_code, account_name, allow_posting, is_active)
               VALUES(1,?,?,?,?,1)""",
            (account_type_id, code, name, 1),
        ).lastrowid)

    def _period(self, name="FY2026", start="2026-01-01", end="2026-12-31"):
        return self.periods.create_period(1, name, start, end, created_by=1)

    def _journal(self, reference_id, entry_date, details):
        return self.accounting.create_entry(
            company_id=1, branch_id=1, entry_date=entry_date,
            description="Fiscal-year test", reference_type="FY_TEST",
            reference_id=reference_id, created_by=1, details=details,
        )

    def _close(self):
        return self.closing.close_year(
            company_id=1, year_name="FY2026", start_date="2026-01-01",
            end_date="2026-12-31", retained_earnings_account_id=self.retained,
            closed_by=1,
        )

    def test_profit_is_closed_to_retained_earnings_and_period_is_closed(self):
        self._period()
        self._journal(1, "2026-03-15", [
            {"account_id": self.cash, "debit": 1000, "credit": 0},
            {"account_id": self.revenue, "debit": 0, "credit": 1000},
        ])
        self._journal(2, "2026-04-15", [
            {"account_id": self.expense, "debit": 300, "credit": 0},
            {"account_id": self.cash, "debit": 0, "credit": 300},
        ])

        result = self._close()
        self.assertEqual(result["net_income"], "700.00")
        self.assertIsNotNone(result["closing_entry_id"])
        self.assertEqual(result["periods_closed"], 1)
        self.assertEqual(self.conn.execute(
            "SELECT is_closed FROM accounting_periods WHERE id=1"
        ).fetchone()[0], 1)

        closing_lines = self.conn.execute(
            "SELECT account_id,debit,credit FROM journal_details WHERE journal_entry_id=?",
            (result["closing_entry_id"],),
        ).fetchall()
        amounts = {row["account_id"]: (round(row["debit"], 2), round(row["credit"], 2)) for row in closing_lines}
        self.assertEqual(amounts[self.revenue], (1000.0, 0.0))
        self.assertEqual(amounts[self.expense], (0.0, 300.0))
        self.assertEqual(amounts[self.retained], (0.0, 700.0))

        # P&L account movement including the closing entry is exactly zero.
        remaining = self.conn.execute(
            """SELECT ROUND(SUM(jd.credit-jd.debit),2) FROM journal_details jd
               JOIN journal_entries je ON je.id=jd.journal_entry_id
               WHERE je.company_id=1 AND je.entry_date BETWEEN '2026-01-01' AND '2026-12-31'
                 AND jd.account_id=?""", (self.revenue,),
        ).fetchone()[0]
        self.assertEqual(remaining, 0.0)

        actions = [row[0] for row in self.conn.execute(
            "SELECT action FROM audit_logs WHERE entity_type='fiscal_year_closing'"
        ).fetchall()]
        self.assertEqual(actions, ["fiscal_year_closed"])

    def test_loss_is_debited_to_retained_earnings(self):
        self._period()
        self._journal(3, "2026-02-01", [
            {"account_id": self.expense, "debit": 450, "credit": 0},
            {"account_id": self.cash, "debit": 0, "credit": 450},
        ])
        result = self._close()
        self.assertEqual(result["net_income"], "-450.00")
        retained_line = self.conn.execute(
            "SELECT debit,credit FROM journal_details WHERE journal_entry_id=? AND account_id=?",
            (result["closing_entry_id"], self.retained),
        ).fetchone()
        self.assertEqual((round(retained_line["debit"], 2), round(retained_line["credit"], 2)), (450.0, 0.0))

    def test_missing_period_coverage_is_rejected_atomically(self):
        self.periods.create_period(1, "H1", "2026-01-01", "2026-06-30", created_by=1)
        self.periods.create_period(1, "H2-partial", "2026-07-02", "2026-12-31", created_by=1)
        with self.assertRaises(Exception):
            self._close()
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM fiscal_year_closings").fetchone()[0], 0)

    def test_non_equity_or_other_company_retained_account_is_rejected(self):
        self._period()
        with self.assertRaises(Exception):
            self.closing.close_year(
                company_id=1, year_name="FY2026", start_date="2026-01-01",
                end_date="2026-12-31", retained_earnings_account_id=self.revenue,
                closed_by=1,
            )
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM fiscal_year_closings").fetchone()[0], 0)

    def test_close_is_idempotently_blocked_on_second_attempt(self):
        self._period()
        self._close()
        with self.assertRaises(Exception):
            self._close()
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM fiscal_year_closings").fetchone()[0], 1)

    def test_unposted_journal_prevents_close(self):
        self._period()
        self.conn.execute(
            """INSERT INTO journal_entries(company_id,branch_id,entry_number,entry_date,
               description,reference_type,reference_id,created_by,is_posted)
               VALUES(1,1,'PENDING-FY','2026-05-01','pending','FY_PENDING',1,1,0)"""
        )
        self.conn.commit()
        with self.assertRaises(Exception):
            self._close()
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM fiscal_year_closings").fetchone()[0], 0)
        self.assertEqual(self.conn.execute(
            "SELECT is_closed FROM accounting_periods WHERE id=1"
        ).fetchone()[0], 0)

    def test_closing_requires_dedicated_permission(self):
        self._period()
        role_id = self.conn.execute(
            "INSERT INTO roles(code,name,is_system,is_active,company_id) VALUES('FY_LIMITED','FY Limited',0,1,1)"
        ).lastrowid
        user_id = self.conn.execute(
            "INSERT INTO users(username,password_hash,full_name,role_id,company_id,branch_id,is_active) "
            "VALUES('fy-limited','x','FY Limited',?,1,1,1)", (role_id,),
        ).lastrowid
        self.conn.commit()
        with self.assertRaises(Exception):
            self.closing.close_year(
                company_id=1, year_name="FY2026", start_date="2026-01-01",
                end_date="2026-12-31", retained_earnings_account_id=self.retained,
                closed_by=int(user_id),
            )
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM fiscal_year_closings").fetchone()[0], 0)


if __name__ == "__main__":
    unittest.main()
