import sqlite3
import unittest
from alexerp.database.schema.receipts_payments_schema import create_receipts_payments_tables


class ReceiptPaymentSchemaMigrationTests(unittest.TestCase):
    def test_legacy_receipts_and_payments_gain_posted_status_without_data_loss(self):
        conn = sqlite3.connect(":memory:")
        cur = conn.cursor()
        cur.execute("""CREATE TABLE receipts(
            id INTEGER PRIMARY KEY, company_id INTEGER, branch_id INTEGER,
            receipt_number TEXT, receipt_date DATE, customer_id INTEGER,
            cash_box_id INTEGER, amount REAL, notes TEXT, created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        cur.execute("""CREATE TABLE payments(
            id INTEGER PRIMARY KEY, company_id INTEGER, branch_id INTEGER,
            payment_number TEXT, payment_date DATE, supplier_id INTEGER,
            cash_box_id INTEGER, amount REAL, notes TEXT, created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        cur.execute("INSERT INTO receipts(id, receipt_number, amount) VALUES(1,'OLD-R',12)")
        cur.execute("INSERT INTO payments(id, payment_number, amount) VALUES(1,'OLD-P',7)")
        create_receipts_payments_tables(cur)
        self.assertEqual(cur.execute("SELECT receipt_number, amount, status FROM receipts WHERE id=1").fetchone(),
                         ("OLD-R", 12.0, "POSTED"))
        self.assertEqual(cur.execute("SELECT payment_number, amount, status FROM payments WHERE id=1").fetchone(),
                         ("OLD-P", 7.0, "POSTED"))
        indexes = {row[1] for row in cur.execute("PRAGMA index_list(receipts)").fetchall()}
        payment_indexes = {row[1] for row in cur.execute("PRAGMA index_list(payments)").fetchall()}
        self.assertIn("ux_receipts_company_branch_number", indexes)
        self.assertIn("ux_payments_company_branch_number", payment_indexes)
        conn.close()


if __name__ == "__main__":
    unittest.main()
