"""Import/wiring checks for the desktop fiscal-management screen."""
import importlib.util
import unittest

if importlib.util.find_spec("customtkinter") is None:
    raise unittest.SkipTest("customtkinter is not installed in this test environment")

from alexerp.ui.fiscal_management_page import FiscalManagementPage
from alexerp.ui.security_admin_page import SecurityAdminPage
from alexerp.ui.main_window import NAVIGATION, NAV_PERMISSIONS


class FiscalManagementUIWiringTests(unittest.TestCase):
    def test_fiscal_management_page_is_registered_in_navigation(self):
        entry = next((item for item in NAVIGATION if item[0] == "fiscal"), None)
        self.assertIsNotNone(entry)
        self.assertIs(entry[3], FiscalManagementPage)
        self.assertEqual(NAV_PERMISSIONS["fiscal"], (
            "accounts.view", "accounting.periods.manage", "accounting.fiscal_year.close",
        ))

    def test_page_exposes_expected_service_actions(self):
        self.assertTrue(callable(FiscalManagementPage._create_period))
        self.assertTrue(callable(FiscalManagementPage._close_period))
        self.assertTrue(callable(FiscalManagementPage._review_year))
        self.assertTrue(callable(FiscalManagementPage._execute_year_close))

    def test_user_and_role_administration_is_registered_and_permission_gated(self):
        entry = next((item for item in NAVIGATION if item[0] == "security_admin"), None)
        self.assertIsNotNone(entry)
        self.assertIs(entry[3], SecurityAdminPage)
        self.assertEqual(NAV_PERMISSIONS["security_admin"], (
            "security.users.manage", "security.roles.manage",
        ))
        self.assertTrue(callable(SecurityAdminPage.add_user))
        self.assertTrue(callable(SecurityAdminPage.add_role))


if __name__ == "__main__":
    unittest.main()
