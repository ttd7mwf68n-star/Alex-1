"""Regression tests for password hash versioning and migration."""
from __future__ import annotations
import hashlib
import unittest

from alexerp.database.auth import PasswordManager


class PasswordSecurityTests(unittest.TestCase):
    def test_new_hash_is_versioned_and_verifies(self):
        encoded = PasswordManager.hash_password("a-long-test-password-42")
        self.assertTrue(encoded.startswith("pbkdf2_sha256$310000$"))
        self.assertTrue(PasswordManager.verify_password("a-long-test-password-42", encoded))
        self.assertFalse(PasswordManager.verify_password("wrong-password", encoded))

    def test_legacy_hash_verifies_and_requires_upgrade(self):
        salt = "legacy-salt-value"
        digest = hashlib.pbkdf2_hmac("sha256", b"legacy-password", salt.encode(), 120_000).hex()
        legacy = f"{salt}${digest}"
        self.assertTrue(PasswordManager.verify_password("legacy-password", legacy))
        self.assertTrue(PasswordManager.needs_rehash(legacy))

    def test_current_hash_does_not_require_upgrade(self):
        encoded = PasswordManager.hash_password("a-long-test-password-42")
        self.assertFalse(PasswordManager.needs_rehash(encoded))

    def test_malformed_hash_is_rejected(self):
        for value in ("", "x$y", "pbkdf2_sha256$999999999$00$00", None):
            self.assertFalse(PasswordManager.verify_password("anything", value))

    def test_password_policy_enforces_minimum_and_maximum(self):
        with self.assertRaises(ValueError):
            PasswordManager.validate_password("short")
        with self.assertRaises(ValueError):
            PasswordManager.validate_password("x" * 1025)
        PasswordManager.validate_password("a-strong-password-123")


if __name__ == "__main__":
    unittest.main()
