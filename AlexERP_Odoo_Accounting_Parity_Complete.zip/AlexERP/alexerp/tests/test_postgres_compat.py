import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from alexerp.database import db as db_module
from alexerp.database.backup import BackupManager
from alexerp.database.postgres_compat import (
    PostgreSQLConnection,
    PostgreSQLRow,
    translate_sql,
)


class PostgreSQLCompatibilityTests(unittest.TestCase):
    def test_placeholders_ignore_question_marks_inside_literals_and_comments(self):
        sql = "SELECT ?, '?' AS literal -- ? ignored\n, \"?\" AS quoted /* ? ignored */"
        self.assertEqual(
            translate_sql(sql),
            "SELECT %s, '?' AS literal -- ? ignored\n, \"?\" AS quoted /* ? ignored */",
        )

    def test_sqlite_schema_and_conflict_syntax_are_translated(self):
        sql = "CREATE TABLE IF NOT EXISTS example(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT)"
        self.assertIn("id SERIAL PRIMARY KEY", translate_sql(sql))
        insert = translate_sql("INSERT OR IGNORE INTO example(code) VALUES(?)")
        self.assertEqual(insert, "INSERT INTO example(code) VALUES(%s) ON CONFLICT DO NOTHING")

    def test_sqlite_null_comparison_and_date_functions_are_translated(self):
        self.assertEqual(
            translate_sql("SELECT * FROM example WHERE branch_id IS ? AND created_at<date('now')"),
            "SELECT * FROM example WHERE branch_id IS NOT DISTINCT FROM %s AND created_at<CURRENT_DATE",
        )
        self.assertEqual(
            translate_sql("SELECT julianday(?) - julianday(?)"),
            "SELECT (%s::date - %s::date)",
        )

    def test_pragma_translation_and_connection_local_pragma(self):
        table_info = translate_sql("PRAGMA table_info('purchase_orders')")
        self.assertIn("information_schema.columns", table_info)
        self.assertIn("table_name='purchase_orders'", table_info)
        self.assertIsNone(translate_sql("PRAGMA foreign_keys = ON"))

    def test_row_supports_sqlite_name_and_position_access(self):
        row = PostgreSQLRow(("id", "name"), (3, "Alex"))
        self.assertEqual(row[0], 3)
        self.assertEqual(row["name"], "Alex")
        self.assertEqual(dict(row), {"id": 3, "name": "Alex"})

    def test_encrypted_backups_refuse_postgresql_backend(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            manager = BackupManager(root / "backups", root / "database.db")
            with patch.object(db_module, "DATABASE_BACKEND", "postgresql"):
                with self.assertRaisesRegex(RuntimeError, "only for SQLite"):
                    manager.create_encrypted_backup("a-long-password")
                with self.assertRaisesRegex(RuntimeError, "only for SQLite"):
                    manager.restore_encrypted_backup(root / "backup.dump.enc", "a-long-password")

    def test_ping_rejects_aborted_postgresql_transactions(self):
        raw_connection = SimpleNamespace(
            closed=False,
            info=SimpleNamespace(
                transaction_status=SimpleNamespace(name="INERROR")
            ),
        )
        with self.assertRaisesRegex(sqlite3.ProgrammingError, "aborted state"):
            PostgreSQLConnection(raw_connection).ping()


if __name__ == "__main__":
    unittest.main()
