"""Tests for non-destructive financial report exports."""
import csv
import tempfile
import unittest
from pathlib import Path

from openpyxl import load_workbook

from alexerp.exports.financial_report_exporter import export_csv, export_xlsx


class FinancialReportExportTests(unittest.TestCase):
    def setUp(self):
        self.columns = [("code", "الكود", 90, "w"), ("amount", "القيمة", 120, "e")]
        self.rows = [{"code": "4101", "amount": 1250.5}]
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_export_")
        self.root = Path(self.tempdir.name)

    def tearDown(self):
        self.tempdir.cleanup()

    def test_csv_export_is_utf8_bom_and_contains_report_rows(self):
        path = self.root / "report.csv"
        export_csv(path, "قائمة الدخل", "2026-01-01", "2026-01-31", self.columns, self.rows)
        raw = path.read_bytes()
        self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
        with path.open(encoding="utf-8-sig", newline="") as stream:
            data = list(csv.reader(stream))
        self.assertIn("الكود", data[3])
        self.assertIn("4101", data[4])

    def test_xlsx_export_has_rtl_sheet_freeze_panes_and_numeric_values(self):
        path = self.root / "report.xlsx"
        export_xlsx(path, "قائمة الدخل", "2026-01-01", "2026-01-31", self.columns, self.rows)
        workbook = load_workbook(path, data_only=True)
        sheet = workbook.active
        self.assertTrue(sheet.sheet_view.rightToLeft)
        self.assertEqual(sheet.freeze_panes, "A5")
        self.assertEqual(sheet.cell(5, 1).value, "4101")
        self.assertEqual(sheet.cell(5, 2).value, 1250.5)


if __name__ == "__main__":
    unittest.main()
