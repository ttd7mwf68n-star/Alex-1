"""Tests for tenant-safe, read-only business intelligence reporting."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.business_intelligence_service import BusinessIntelligenceService


class BusinessIntelligenceTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_bi_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "bi.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.service = BusinessIntelligenceService()
        self.customer_id = self.conn.execute(
            "INSERT INTO customers(company_id,code,name,current_balance) VALUES(1,'BI-C1','BI Customer',350)"
        ).lastrowid
        self.supplier_id = self.conn.execute(
            "INSERT INTO suppliers(company_id,code,name,current_balance) VALUES(1,'BI-S1','BI Supplier',120)"
        ).lastrowid
        self.product_id = self.conn.execute(
            "INSERT INTO products(company_id,branch_id,code,name,purchase_price,sale_price,quantity,minimum_stock) "
            "VALUES(1,1,'BI-P1','BI Product',100,150,10,2)"
        ).lastrowid
        self.sales_feb = self._sales_invoice("BI-SI-2", "2026-02-10", 300, 250, "Posted")
        self.sales_jan = self._sales_invoice("BI-SI-1", "2026-01-15", 100, 100, "Posted", quantity=1, cost=40)
        self.sales_draft = self._sales_invoice("BI-SI-D", "2026-02-11", 999, 999, "Draft")
        self.expense_account_id = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_type_id,account_code,account_name) "
            "VALUES(1,(SELECT id FROM account_types WHERE code='EXPENSE'),'BI-EXP','BI Expense')"
        ).lastrowid
        self.revenue_account_id = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_type_id,account_code,account_name) "
            "VALUES(1,(SELECT id FROM account_types WHERE code='REVENUE'),'BI-REV','BI Revenue')"
        ).lastrowid
        self.conn.execute(
            "INSERT INTO purchase_invoices(company_id,branch_id,supplier_id,invoice_number,invoice_date,total,"
            "paid_amount,remaining_amount,status) VALUES(1,1,?,'BI-PI-1','2026-02-12',120,0,120,'Posted')",
            (self.supplier_id,),
        )
        self.conn.execute(
            "INSERT INTO receipts(company_id,branch_id,receipt_number,receipt_date,customer_id,amount,status) "
            "VALUES(1,1,'BI-R-1','2026-02-15',?,70,'POSTED')", (self.customer_id,)
        )
        self.conn.execute(
            "INSERT INTO payments(company_id,branch_id,payment_number,payment_date,supplier_id,amount,status) "
            "VALUES(1,1,'BI-P-1','2026-02-16',?,20,'POSTED')", (self.supplier_id,)
        )
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def _journal_entry(self, number, day, lines, branch_id=1, posted=1, company_id=1):
        entry_id = self.conn.execute(
            "INSERT INTO journal_entries(company_id,branch_id,entry_number,entry_date,description,is_posted) "
            "VALUES(?,?,?,?,?,?)",
            (company_id, branch_id, number, day, number, posted),
        ).lastrowid
        self.conn.executemany(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit) VALUES(?,?,?,?)",
            [(entry_id, account_id, debit, credit) for account_id, debit, credit in lines],
        )
        self.conn.commit()
        return entry_id

    def _sales_invoice(self, number, day, total, remaining, status, quantity=2, cost=100):
        invoice_id = self.conn.execute(
            "INSERT INTO sales_invoices(company_id,branch_id,customer_id,invoice_number,invoice_date,total,"
            "paid_amount,remaining_amount,status) VALUES(1,1,?,?,?,?,?,?,?)",
            (self.customer_id, number, day, total, total - remaining, remaining, status),
        ).lastrowid
        self.conn.execute(
            "INSERT INTO sales_invoice_items(invoice_id,product_id,quantity,unit_price,unit_cost,total) "
            "VALUES(?,?,?,?,?,?)", (invoice_id, self.product_id, quantity, 150, cost, total),
        )
        self.conn.commit()
        return invoice_id

    def test_executive_summary_calculates_sales_margin_and_cash_movement(self):
        result = self.service.executive_summary(1, "2026-02-01", "2026-02-28", 1)
        self.assertEqual(result["sales_total"], 300.0)
        self.assertEqual(result["sales_invoice_count"], 1)
        self.assertEqual(result["cost_of_goods_sold"], 200.0)
        self.assertEqual(result["gross_profit"], 100.0)
        self.assertEqual(result["gross_margin_percent"], 33.33)
        self.assertEqual(result["purchase_total"], 120.0)
        self.assertEqual(result["receipts_total"], 70.0)
        self.assertEqual(result["payments_total"], 20.0)
        self.assertEqual(result["net_cash_movement"], 50.0)
        self.assertEqual(result["receivables_open"], 350.0)
        self.assertEqual(result["payables_open"], 120.0)

    def test_sales_returns_reduce_net_sales_and_gross_profit_reports(self):
        return_id = self.conn.execute(
            """INSERT INTO sales_returns(
                   company_id,branch_id,sales_invoice_id,customer_id,return_number,
                   return_date,total,status)
               VALUES(1,1,?,?,'BI-RETURN-1','2026-02-20',150,'POSTED')""",
            (self.sales_feb, self.customer_id),
        ).lastrowid
        self.conn.execute(
            """INSERT INTO sales_return_items(
                   return_id,product_id,warehouse_id,quantity,unit_cost,total)
               VALUES(?,?,1,1,100,150)""",
            (return_id, self.product_id),
        )
        self.conn.commit()

        result = self.service.executive_summary(1, "2026-02-01", "2026-02-28", 1)
        self.assertEqual(result["gross_sales_total"], 300.0)
        self.assertEqual(result["sales_returns_total"], 150.0)
        self.assertEqual(result["sales_total"], 150.0)
        self.assertEqual(result["cost_of_goods_sold"], 100.0)
        self.assertEqual(result["returned_cost"], 100.0)
        self.assertEqual(result["gross_profit"], 50.0)

        monthly = self.service.monthly_performance(1, "2026-02-01", "2026-02-28", 1)
        self.assertEqual(monthly[0]["sales"], 150.0)
        self.assertEqual(monthly[0]["gross_profit"], 50.0)
        customer = self.service.top_customers(1, "2026-01-01", "2026-02-28", 1)
        self.assertEqual(customer[0]["sales_total"], 250.0)
        product = self.service.top_products(1, "2026-01-01", "2026-02-28", 1)
        self.assertEqual(product[0]["revenue"], 250.0)
        self.assertEqual(product[0]["gross_profit"], 110.0)

    def test_draft_documents_are_excluded(self):
        result = self.service.executive_summary(1, "2026-02-01", "2026-02-28")
        self.assertEqual(result["sales_total"], 300.0)
        self.assertEqual(result["sales_invoice_count"], 1)

    def test_ledger_expenses_and_net_income_use_posted_company_branch_entries(self):
        other_branch_id = self.conn.execute(
            "INSERT INTO branches(company_id,code,name) VALUES(1,'BI-BR2','BI Branch 2')"
        ).lastrowid
        self._journal_entry("BI-LEDGER-1", "2026-02-10", [
            (self.expense_account_id, 80, 0), (self.revenue_account_id, 0, 300),
        ])
        self._journal_entry("BI-LEDGER-UNPOSTED", "2026-02-15", [
            (self.expense_account_id, 900, 0), (self.revenue_account_id, 0, 900),
        ], posted=0)
        self._journal_entry("BI-LEDGER-OTHER-BRANCH", "2026-02-18", [
            (self.expense_account_id, 50, 0), (self.revenue_account_id, 0, 500),
        ], branch_id=other_branch_id)

        result = self.service.executive_summary(1, "2026-02-01", "2026-02-28", 1)
        self.assertEqual(result["ledger_revenue_total"], 300.0)
        self.assertEqual(result["ledger_expenses_total"], 80.0)
        self.assertEqual(result["net_income"], 220.0)

        monthly = self.service.monthly_performance(1, "2026-02-01", "2026-02-28", 1)
        self.assertEqual(monthly[0]["ledger_expenses"], 80.0)
        self.assertEqual(monthly[0]["net_income"], 220.0)

    def test_monthly_performance_fills_months_without_documents(self):
        rows = self.service.monthly_performance(1, "2026-01-01", "2026-03-31", 1)
        self.assertEqual([r["month"] for r in rows], ["2026-01", "2026-02", "2026-03"])
        self.assertEqual(rows[0]["sales"], 100.0)
        self.assertEqual(rows[0]["gross_profit"], 60.0)
        self.assertEqual(rows[1]["sales"], 300.0)
        self.assertEqual(rows[2]["sales"], 0.0)

    def test_period_comparison_uses_equal_length_previous_window(self):
        result = self.service.period_comparison(1, "2026-02-01", "2026-02-28", 1)
        self.assertEqual(result["previous_from"], "2026-01-04")
        self.assertEqual(result["previous_to"], "2026-01-31")
        self.assertEqual(result["metrics"]["sales_total"]["current"], 300.0)
        self.assertEqual(result["metrics"]["sales_total"]["previous"], 100.0)
        self.assertEqual(result["metrics"]["sales_total"]["change_percent"], 200.0)

    def test_rankings_are_company_and_branch_scoped(self):
        customer_rows = self.service.top_customers(1, "2026-01-01", "2026-02-28", 1)
        product_rows = self.service.top_products(1, "2026-01-01", "2026-02-28", 1)
        self.assertEqual(len(customer_rows), 1)
        self.assertEqual(customer_rows[0]["sales_total"], 400.0)
        self.assertEqual(len(product_rows), 1)
        self.assertEqual(product_rows[0]["revenue"], 400.0)
        self.assertEqual(product_rows[0]["gross_profit"], 160.0)

    def test_other_company_documents_are_never_included(self):
        foreign_company = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('BI-FOREIGN','Foreign BI Company')"
        ).lastrowid
        foreign_customer = self.conn.execute(
            "INSERT INTO customers(company_id,code,name) VALUES(?,?,?)",
            (foreign_company, "BI-FC", "Foreign Customer"),
        ).lastrowid
        foreign_product = self.conn.execute(
            "INSERT INTO products(company_id,code,name) VALUES(?,?,?)",
            (foreign_company, "BI-FP", "Foreign Product"),
        ).lastrowid
        foreign_invoice = self.conn.execute(
            "INSERT INTO sales_invoices(company_id,customer_id,invoice_number,invoice_date,total,status) "
            "VALUES(?,?,?,'2026-02-10',5000,'Posted')",
            (foreign_company, foreign_customer, "BI-F-SI"),
        ).lastrowid
        self.conn.execute(
            "INSERT INTO sales_invoice_items(invoice_id,product_id,quantity,unit_price,unit_cost,total) "
            "VALUES(?,?,1,5000,1,5000)", (foreign_invoice, foreign_product),
        )
        self.conn.commit()
        result = self.service.executive_summary(1, "2026-02-01", "2026-02-28")
        self.assertEqual(result["sales_total"], 300.0)
        self.assertEqual(result["gross_profit"], 100.0)

    def test_invalid_company_dates_and_ranges_are_rejected(self):
        with self.assertRaises(ValueError):
            self.service.executive_summary(0, "2026-02-01", "2026-02-28")
        with self.assertRaises(ValueError):
            self.service.executive_summary(1, "2026-02-30", "2026-03-01")
        with self.assertRaises(ValueError):
            self.service.executive_summary(1, "2026-03-01", "2026-02-01")
        with self.assertRaises(ValueError):
            self.service.executive_summary(1, "2010-01-01", "2026-02-01")


if __name__ == "__main__":
    unittest.main()
