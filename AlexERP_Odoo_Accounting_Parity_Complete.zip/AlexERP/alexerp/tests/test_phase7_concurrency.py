from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.transaction import transaction, TransactionError
from alexerp.repositories.receipt_repository import ReceiptRepository
from alexerp.repositories.payment_repository import PaymentRepository


class Phase7ConcurrencyTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_phase7_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "phase7.db"
        conn = Database.connect()
        conn.executescript("""
            CREATE TABLE receipts (
                id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER,
                branch_id INTEGER, receipt_number TEXT, receipt_date TEXT,
                customer_id INTEGER, cash_box_id INTEGER, amount REAL,
                notes TEXT, created_by INTEGER
            );
            CREATE TABLE payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER,
                branch_id INTEGER, payment_number TEXT, payment_date TEXT,
                supplier_id INTEGER, cash_box_id INTEGER, amount REAL,
                notes TEXT, created_by INTEGER, status TEXT
            );
        """)
        conn.commit()
        self.conn = conn

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def test_outer_transaction_starts_with_begin_immediate(self):
        statements = []
        self.conn.set_trace_callback(statements.append)
        with transaction():
            self.assertTrue(self.conn.in_transaction)
            self.conn.execute("INSERT INTO receipts(company_id, branch_id, receipt_number) VALUES(1,1,'R1')")
        self.conn.set_trace_callback(None)
        self.assertTrue(any(s.strip().upper() == "BEGIN IMMEDIATE" for s in statements))

    def test_nested_transaction_uses_savepoint_and_outer_rollback_is_atomic(self):
        with self.assertRaises(TransactionError):
            with transaction():
                self.conn.execute("INSERT INTO receipts(company_id, branch_id, receipt_number) VALUES(1,1,'R2')")
                with transaction():
                    self.conn.execute("INSERT INTO receipts(company_id, branch_id, receipt_number) VALUES(1,1,'R3')")
                raise RuntimeError("force rollback")
        count = self.conn.execute("SELECT COUNT(*) FROM receipts").fetchone()[0]
        self.assertEqual(count, 0)

    def test_duplicate_receipt_number_is_rejected_within_company_and_branch(self):
        repo = ReceiptRepository()
        repo.create(1, 1, "R-100", "2026-11-17", 1, 1, 50, "", 1)
        with self.assertRaisesRegex(ValueError, "Receipt number already exists"):
            repo.create(1, 1, "R-100", "2026-11-17", 1, 1, 50, "", 1)
        # Same number in another branch is a distinct document namespace.
        repo.create(1, 2, "R-100", "2026-11-17", 1, 1, 50, "", 1)

    def test_duplicate_supplier_payment_number_is_rejected(self):
        repo = PaymentRepository()
        repo.create(1, 1, "P-100", "2026-11-17", 1, 1, 25, "", 1)
        with self.assertRaisesRegex(ValueError, "Payment number already exists"):
            repo.create(1, 1, "P-100", "2026-11-17", 1, 1, 25, "", 1)


if __name__ == "__main__":
    unittest.main()
