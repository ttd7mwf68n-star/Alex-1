"""Tests for company-scoped user and role administration."""
from __future__ import annotations
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.schema.security import create_security_tables
from alexerp.database.seed import seed_database
from alexerp.database.auth import PasswordManager
from alexerp.services.security_admin_service import SecurityAdminService, SecurityAdminError
from alexerp.services.permission_service import PermissionDenied
from alexerp.core.context import set_current_user


class SecurityAdminManagementTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tmp = tempfile.TemporaryDirectory(prefix="alex_security_admin_")
        db_module.DATABASE_FILE = Path(self.tmp.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        admin = self.conn.execute("SELECT * FROM users WHERE username='admin'").fetchone()
        self.admin = dict(admin)
        self.company_id, self.branch_id, self.admin_id = int(admin["company_id"]), int(admin["branch_id"]), int(admin["id"])
        set_current_user(self.admin)
        self.service = SecurityAdminService()
        self.viewer_role = self.service.create_role(self.company_id, "SALES_VIEW", "Sales viewer", "", ["sales.view"])

    def tearDown(self):
        set_current_user(None)
        Database.close()
        self.tmp.cleanup()

    def _create_company_admin(self, company_id, branch_id):
        return int(self.conn.execute(
            """INSERT INTO users(username,password_hash,full_name,role_id,company_id,branch_id)
               VALUES(?,?,?,1,?,?)""",
            (f"admin_{company_id}", "unused", "Company Administrator", company_id, branch_id),
        ).lastrowid)

    def test_create_user_hashes_password_and_scopes_company_branch(self):
        uid = self.service.create_user(company_id=self.company_id, branch_id=self.branch_id,
            username="new.viewer", full_name="New Viewer", password="strong-pass-123",
            role_id=self.viewer_role, email="", phone="")
        row = self.conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        self.assertTrue(PasswordManager.verify_password("strong-pass-123", row["password_hash"]))
        self.assertEqual(row["company_id"], self.company_id)
        self.assertEqual(row["branch_id"], self.branch_id)
        self.assertNotEqual(row["password_hash"], "strong-pass-123")

    def test_rejects_short_password(self):
        with self.assertRaises(SecurityAdminError):
            self.service.create_user(company_id=self.company_id, branch_id=self.branch_id,
                username="new.viewer", full_name="New Viewer", password="short",
                role_id=self.viewer_role)

    def test_rejects_branch_from_another_company(self):
        with self.assertRaises(SecurityAdminError):
            self.service.create_user(company_id=self.company_id, branch_id=999999,
                username="new.viewer", full_name="New Viewer", password="strong-pass-123",
                role_id=self.viewer_role)

    def test_cannot_modify_system_admin_role(self):
        with self.assertRaises(SecurityAdminError):
            self.service.update_role(self.company_id, 1, "Changed", "", [], True)

    def test_cannot_deactivate_role_assigned_to_active_user(self):
        self.service.create_user(company_id=self.company_id, branch_id=self.branch_id,
            username="role.user", full_name="Role User", password="strong-pass-123", role_id=self.viewer_role)
        with self.assertRaises(SecurityAdminError):
            self.service.update_role(self.company_id, self.viewer_role, "Sales viewer", "", ["sales.view"], False)

    def test_cannot_deactivate_self(self):
        admin = self.conn.execute("SELECT role_id FROM users WHERE id=?", (self.admin_id,)).fetchone()
        with self.assertRaises(SecurityAdminError):
            self.service.update_user(actor_id=self.admin_id, company_id=self.company_id,
                user_id=self.admin_id, full_name="Admin", role_id=int(admin[0]),
                branch_id=self.branch_id, is_active=False)

    def test_cannot_remove_last_active_admin(self):
        admin_role = self.conn.execute("SELECT id FROM roles WHERE code='ADMIN'").fetchone()[0]
        other_role = self.service.create_role(self.company_id, "OPS_USER", "Operations", "", ["dashboard.view"])
        second_admin = self.service.create_user(company_id=self.company_id, branch_id=self.branch_id,
            username="second.admin", full_name="Second Admin", password="strong-pass-123", role_id=admin_role)
        # The only remaining admin is the seeded admin when demoting the second one; it is allowed.
        self.service.update_user(actor_id=self.admin_id, company_id=self.company_id, user_id=second_admin,
            full_name="Second Admin", role_id=other_role, branch_id=self.branch_id, is_active=True)
        # Demoting the seeded admin is prohibited because it is the final active admin.
        with self.assertRaises(SecurityAdminError):
            self.service.update_user(actor_id=self.admin_id, company_id=self.company_id, user_id=self.admin_id,
                full_name="Admin", role_id=other_role, branch_id=self.branch_id, is_active=True)

    def test_role_permissions_replace_atomically(self):
        self.service.update_role(self.company_id, self.viewer_role, "Sales and products", "updated",
            ["sales.view", "products.view"], True)
        role = next(r for r in self.service.list_roles(self.company_id) if r["id"] == self.viewer_role)
        self.assertEqual(set(role["permissions"]), {"sales.view", "products.view"})

    def test_action_permissions_are_available_for_role_configuration(self):
        from alexerp.services.permission_service import PermissionService

        user_id = self.service.create_user(
            company_id=self.company_id, branch_id=self.branch_id,
            username="action.viewer", full_name="Action Viewer",
            password="strong-pass-123", role_id=self.viewer_role,
        )
        permission_service = PermissionService()
        for key in (
            "products.update", "products.delete", "inventory.adjust",
            "sales.cancel", "sales.return", "purchases.cancel",
        ):
            with self.subTest(permission=key):
                self.assertFalse(permission_service.has_permission(user_id, key))
                self.assertIn(key, {item["permission_key"] for item in self.service.list_permissions()})

    def test_custom_roles_are_company_scoped(self):
        other_company = self.conn.execute("INSERT INTO companies(code,name) VALUES('OTHER_CO','Other Co')").lastrowid
        other_branch = self.conn.execute("INSERT INTO branches(company_id,code,name) VALUES(?, 'OTHER_BR','Other Branch')", (other_company,)).lastrowid
        other_admin = self._create_company_admin(int(other_company), int(other_branch))
        other_role = self.service.create_role(int(other_company), "OTHER_ROLE", "Other role", "",
                                              ["dashboard.view"], actor_id=other_admin)
        self.assertNotIn(other_role, {r["id"] for r in self.service.list_roles(self.company_id)})
        with self.assertRaises(SecurityAdminError):
            self.service.create_user(company_id=self.company_id, branch_id=self.branch_id,
                username="cross.role", full_name="Cross Role", password="strong-pass-123", role_id=other_role)


    def test_permission_service_rejects_role_from_another_company(self):
        from alexerp.services.permission_service import PermissionService

        other_company = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('PERM_OTHER','Permission Other')"
        ).lastrowid
        other_branch = self.conn.execute(
            "INSERT INTO branches(company_id,code,name) VALUES(?, 'PERM_BR','Permission Branch')",
            (other_company,),
        ).lastrowid
        other_admin = self._create_company_admin(int(other_company), int(other_branch))
        other_role = self.service.create_role(
            int(other_company), "FOREIGN_ROLE", "Foreign role", "", ["dashboard.view"],
            actor_id=other_admin,
        )
        # Simulate legacy/corrupt data that bypassed SecurityAdminService validation.
        self.conn.execute("UPDATE users SET role_id=? WHERE id=?", (other_role, self.admin_id))
        self.conn.commit()
        self.assertFalse(PermissionService().has_permission(self.admin_id, "dashboard.view"))

    def test_legacy_roles_table_gets_company_scope_column_without_data_loss(self):
        legacy = sqlite3.connect(":memory:")
        legacy.execute("CREATE TABLE companies(id INTEGER PRIMARY KEY)")
        legacy.execute("CREATE TABLE branches(id INTEGER PRIMARY KEY)")
        legacy.execute("""CREATE TABLE roles(
            id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
            description TEXT, is_system INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP
        )""")
        legacy.execute("INSERT INTO roles(code,name,is_system) VALUES('OLD_ROLE','Old role',0)")
        create_security_tables(legacy.cursor())
        columns = {row[1] for row in legacy.execute("PRAGMA table_info(roles)")}
        saved = legacy.execute("SELECT code,name FROM roles WHERE id=1").fetchone()
        self.assertIn("company_id", columns)
        self.assertEqual(saved, ("OLD_ROLE", "Old role"))
        legacy.close()

    def test_users_list_is_company_scoped_and_does_not_expose_hash(self):
        users = self.service.list_users(self.company_id)
        self.assertTrue(users)
        self.assertTrue(all("password_hash" not in user for user in users))
        self.assertTrue(all("company_id" not in user for user in users))

    def test_service_rejects_role_management_without_permission(self):
        user_id = self.service.create_user(
            company_id=self.company_id, branch_id=self.branch_id,
            username="no.roles", full_name="No Role Permissions",
            password="strong-pass-123", role_id=self.viewer_role,
        )
        user = dict(self.conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone())
        set_current_user(user)
        with self.assertRaises(PermissionDenied):
            self.service.create_role(
                self.company_id, "DENIED_ROLE", "Denied", "", ["sales.view"]
            )
        with self.assertRaises(PermissionDenied):
            self.service.list_users(self.company_id)
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM roles WHERE code='DENIED_ROLE'"
        ).fetchone())


if __name__ == "__main__":
    unittest.main()
