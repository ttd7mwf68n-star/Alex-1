"""Responsive application catalog layout tests without requiring a GUI runtime."""
import ast
import unittest
from pathlib import Path


class ApplicationCatalogLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source_path = Path(__file__).resolve().parents[1] / "ui" / "applications_page.py"
        tree = ast.parse(source_path.read_text(encoding="utf-8"))
        helper = next(
            node for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "_columns_for_width"
        )
        namespace = {"_MAX_GRID_COLUMNS": 4}
        module = ast.Module(body=[helper], type_ignores=[])
        exec(compile(module, str(source_path), "exec"), namespace)
        cls.columns_for_width = staticmethod(namespace["_columns_for_width"])

    def test_grid_uses_two_columns_when_narrow(self):
        self.assertEqual(self.columns_for_width(600), 2)
        self.assertEqual(self.columns_for_width(759), 2)

    def test_grid_uses_three_columns_at_medium_width(self):
        self.assertEqual(self.columns_for_width(760), 3)
        self.assertEqual(self.columns_for_width(1079), 3)

    def test_grid_uses_four_columns_when_wide(self):
        self.assertEqual(self.columns_for_width(1080), 4)
        self.assertEqual(self.columns_for_width(1500), 4)

    def test_column_limit_is_respected(self):
        self.assertEqual(self.columns_for_width(1500, max_columns=3), 3)
        self.assertEqual(self.columns_for_width(1500, max_columns=2), 2)
        self.assertEqual(self.columns_for_width(500, max_columns=1), 1)
