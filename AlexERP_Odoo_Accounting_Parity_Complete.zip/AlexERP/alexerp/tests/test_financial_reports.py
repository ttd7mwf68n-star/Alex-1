"""Regression tests for company-safe ledger, trial balance and balance sheet reports."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.balance_sheet_service import BalanceSheetService
from alexerp.services.general_ledger_service import GeneralLedgerService
from alexerp.services.trial_balance_service import TrialBalanceService
from alexerp.services.profit_loss_service import ProfitLossService


class FinancialReportTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_reports_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "reports.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.cash = self._account("T1101", "Cash", "ASSET")
        self.capital = self._account("T3101", "Capital", "EQUITY")
        self.sales = self._account("T4101", "Sales", "REVENUE")
        self.expense = self._account("T5101", "Expenses", "EXPENSE")
        self.untyped = self._account("T9901", "Unclassified", None)

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def _account(self, code, name, kind):
        type_id = None
        if kind:
            type_id = self.conn.execute("SELECT id FROM account_types WHERE code=?", (kind,)).fetchone()[0]
        cur = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_type_id,account_code,account_name,allow_posting) VALUES(1,?,?,?,1)",
            (type_id, code, name),
        )
        self.conn.commit()
        return cur.lastrowid

    def _entry(self, number, day, lines, company_id=1, posted=1):
        cur = self.conn.execute(
            "INSERT INTO journal_entries(company_id,branch_id,entry_number,entry_date,description,is_posted,created_by) VALUES(1,1,?,?,?,?,1)",
            (number, day, number, posted),
        )
        entry_id = cur.lastrowid
        if company_id != 1:
            self.conn.execute("UPDATE journal_entries SET company_id=? WHERE id=?", (company_id, entry_id))
        self.conn.executemany(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit,description) VALUES(?,?,?,?,?)",
            [(entry_id, account, debit, credit, number) for account, debit, credit in lines],
        )
        self.conn.commit()
        return entry_id

    def test_trial_balance_has_opening_period_and_closing_columns(self):
        self._entry("OPEN", "2026-01-01", [(self.cash, 1000, 0), (self.capital, 0, 1000)])
        self._entry("PERIOD", "2026-02-10", [(self.cash, 250, 0), (self.sales, 0, 250)])
        self._entry("UNPOSTED", "2026-02-11", [(self.cash, 900, 0), (self.sales, 0, 900)], posted=0)
        report = TrialBalanceService().get_report(1, "2026-02-01", "2026-02-28")
        cash = next(row for row in report["rows"] if row["code"] == "T1101")
        self.assertEqual(cash["opening_debit"], 1000.0)
        self.assertEqual(cash["period_debit"], 250.0)
        self.assertEqual(cash["closing_debit"], 1250.0)
        self.assertEqual(report["closing_debit"], report["closing_credit"])
        self.assertTrue(report["balanced"])

    def test_trial_balance_rejects_invalid_or_reversed_dates(self):
        with self.assertRaises(ValueError):
            TrialBalanceService().get_report(1, "2026-02-30", "2026-03-01")
        with self.assertRaises(ValueError):
            TrialBalanceService().get_report(1, "2026-03-02", "2026-03-01")

    def test_general_ledger_includes_opening_balance_and_excludes_unposted(self):
        self._entry("GL-OPEN", "2026-01-01", [(self.cash, 500, 0), (self.capital, 0, 500)])
        self._entry("GL-PERIOD", "2026-02-10", [(self.cash, 75, 0), (self.sales, 0, 75)])
        self._entry("GL-UNPOSTED", "2026-02-11", [(self.cash, 1000, 0), (self.sales, 0, 1000)], posted=0)
        report = GeneralLedgerService().get_report(1, self.cash, "2026-02-01", "2026-02-28")
        self.assertEqual(report["opening_balance"], 500.0)
        self.assertEqual(len(report["rows"]), 1)
        self.assertEqual(report["rows"][0]["balance"], 575.0)
        self.assertEqual(report["closing_balance"], 575.0)

    def test_general_ledger_is_company_scoped(self):
        self._entry("GL-OWN", "2026-02-10", [(self.cash, 10, 0), (self.capital, 0, 10)])
        foreign = self.conn.execute(
            "INSERT INTO companies(id,code,name) VALUES(2,'C2','Company 2')"
        )
        foreign_account = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_code,account_name,allow_posting) VALUES(2,'T1101','Foreign Cash',1)"
        ).lastrowid
        entry_id = self.conn.execute(
            "INSERT INTO journal_entries(company_id,entry_number,entry_date,description,is_posted) VALUES(2,'FOREIGN','2026-02-10','Foreign',1)"
        ).lastrowid
        self.conn.execute(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit) VALUES(?,?,?,?)",
            (entry_id, foreign_account, 999, 0),
        )
        self.conn.commit()
        report = GeneralLedgerService().get_report(1, self.cash, "2026-02-01", "2026-02-28")
        self.assertEqual(report["closing_balance"], 10.0)

    def test_balance_sheet_includes_current_profit_and_ignores_unposted_entries(self):
        self._entry("BS-CAPITAL", "2026-01-01", [(self.cash, 600, 0), (self.capital, 0, 600)])
        self._entry("BS-SALES", "2026-02-01", [(self.cash, 500, 0), (self.sales, 0, 500)])
        self._entry("BS-EXPENSE", "2026-02-02", [(self.expense, 100, 0), (self.cash, 0, 100)])
        self._entry("BS-UNPOSTED", "2026-02-03", [(self.cash, 1000, 0), (self.sales, 0, 1000)], posted=0)
        report = BalanceSheetService().get_report(1, "2026-02-28")
        self.assertEqual(report["total_assets"], 1000.0)
        self.assertEqual(report["total_equity"], 600.0)
        self.assertEqual(report["unclosed_profit"], 400.0)
        self.assertEqual(report["equity_including_unclosed_profit"], 1000.0)
        self.assertTrue(report["balanced"])

    def test_balance_sheet_does_not_silently_classify_unknown_accounts_as_assets(self):
        self._entry("BS-UNKNOWN", "2026-02-01", [(self.untyped, 10, 0), (self.cash, 0, 10)])
        report = BalanceSheetService().get_report(1, "2026-02-28")
        self.assertEqual(len(report["unclassified"]), 1)
        self.assertFalse(report["balanced"])

    def test_profit_loss_calculates_period_revenue_expenses_and_net_profit(self):
        self._entry("PL-OPENING", "2026-01-15", [(self.cash, 100, 0), (self.sales, 0, 100)])
        self._entry("PL-PERIOD-SALE", "2026-02-10", [(self.cash, 300, 0), (self.sales, 0, 300)])
        self._entry("PL-PERIOD-EXPENSE", "2026-02-11", [(self.expense, 80, 0), (self.cash, 0, 80)])
        self._entry("PL-UNPOSTED", "2026-02-12", [(self.cash, 500, 0), (self.sales, 0, 500)], posted=0)
        report = ProfitLossService().get_report(1, "2026-02-01", "2026-02-28")
        self.assertEqual(report["total_revenue"], 300.0)
        self.assertEqual(report["total_expenses"], 80.0)
        self.assertEqual(report["net_profit"], 220.0)
        self.assertEqual(len(report["revenue"]), 1)
        self.assertTrue(report["is_profitable"])

    def test_profit_loss_is_company_scoped_and_rejects_invalid_dates(self):
        self._entry("PL-OWN", "2026-02-10", [(self.cash, 10, 0), (self.sales, 0, 10)])
        self.conn.execute("INSERT INTO companies(id,code,name) VALUES(2,'C2','Company 2')")
        foreign_revenue = self.conn.execute(
            "INSERT INTO chart_of_accounts(company_id,account_type_id,account_code,account_name,allow_posting) "
            "VALUES(2,(SELECT id FROM account_types WHERE code='REVENUE'),'F4101','Foreign Revenue',1)"
        ).lastrowid
        foreign_entry = self.conn.execute(
            "INSERT INTO journal_entries(company_id,entry_number,entry_date,description,is_posted) VALUES(2,'PL-FOREIGN','2026-02-10','Foreign',1)"
        ).lastrowid
        self.conn.execute(
            "INSERT INTO journal_details(journal_entry_id,account_id,debit,credit) VALUES(?,?,0,999)",
            (foreign_entry, foreign_revenue),
        )
        self.conn.commit()
        report = ProfitLossService().get_report(1, "2026-02-01", "2026-02-28")
        self.assertEqual(report["total_revenue"], 10.0)
        with self.assertRaises(ValueError):
            ProfitLossService().get_report(1, "2026-02-30", "2026-03-01")


if __name__ == "__main__":
    unittest.main()
