from __future__ import annotations
import sqlite3
import tempfile
import unittest
from pathlib import Path
from alexerp.database.backup import BackupManager
from alexerp.database.encrypted_backup import encrypt_backup, decrypt_backup, EncryptedBackupError

class EncryptedBackupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.db = self.root / 'live.db'
        c = sqlite3.connect(self.db)
        c.execute('CREATE TABLE records(value TEXT)')
        c.execute("INSERT INTO records VALUES('before')")
        c.commit(); c.close()
        self.manager = BackupManager(self.root / 'backups', self.db)
        self.password = 'Strong-test-password-2026'

    def tearDown(self): self.tmp.cleanup()

    def test_encrypt_decrypt_roundtrip(self):
        backup = self.manager.create_backup()
        encrypted = encrypt_backup(backup, self.password)
        self.assertNotEqual(encrypted.read_bytes(), backup.read_bytes())
        self.assertEqual(decrypt_backup(encrypted, self.password), backup.read_bytes())

    def test_wrong_password_and_tampering_are_rejected(self):
        backup = self.manager.create_backup()
        encrypted = encrypt_backup(backup, self.password)
        with self.assertRaises(EncryptedBackupError): decrypt_backup(encrypted, 'Wrong-password-2026')
        raw = bytearray(encrypted.read_bytes()); raw[-1] ^= 1; encrypted.write_bytes(raw)
        with self.assertRaises(EncryptedBackupError): decrypt_backup(encrypted, self.password)

    def test_encrypted_restore_preserves_safety_copy(self):
        backup = self.manager.create_backup()
        encrypted = encrypt_backup(backup, self.password)
        c = sqlite3.connect(self.db); c.execute("UPDATE records SET value='after'"); c.commit(); c.close()
        safety = self.manager.restore_encrypted_backup(encrypted, self.password)
        c = sqlite3.connect(self.db)
        try: self.assertEqual(c.execute('SELECT value FROM records').fetchone()[0], 'before')
        finally: c.close()
        self.assertTrue(safety.exists())

    def test_export_encrypted_backup_verifies_copy_and_keeps_source(self):
        backup = self.manager.create_backup()
        encrypted = encrypt_backup(backup, self.password)
        external = self.root / 'external_drive'
        exported = self.manager.export_encrypted_backup(encrypted, external)
        self.assertTrue(encrypted.exists())
        self.assertTrue(exported.exists())
        self.assertEqual(encrypted.read_bytes(), exported.read_bytes())
        self.assertEqual(decrypt_backup(exported, self.password), backup.read_bytes())

    def test_export_rejects_plain_database_backup(self):
        backup = self.manager.create_backup()
        with self.assertRaises(ValueError):
            self.manager.export_encrypted_backup(backup, self.root / 'external_drive')

    def test_weak_password_rejected(self):
        backup = self.manager.create_backup()
        with self.assertRaises(ValueError): encrypt_backup(backup, 'short')

if __name__ == '__main__': unittest.main()
