"""
Stage 2 extended cycle coverage: purchase cancellation, warehouse transfers,
accounting-failure rollback and partial-return tax.

Run from the alexerp3 folder:
    PYTHONPATH=. python -m unittest discover -s alexerp/tests -v
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.purchase_service import PurchaseService, PurchaseError
from alexerp.services.sales_service import SalesService
from alexerp.services.sales_return_service import SalesReturnService
from alexerp.services.transfer_service import TransferService
from alexerp.database.transaction import TransactionError
from alexerp.services.sales_settings_service import SalesSettingsService
from alexerp.services.business_intelligence_service import BusinessIntelligenceService


class Stage2CycleCoverageTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_cov_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.accounts = {}
        for code in ("AR", "AP", "SALES", "INV", "COGS", "TAX"):
            cur = self.conn.execute(
                "INSERT INTO chart_of_accounts(company_id, account_code, account_name) VALUES(1, ?, ?)",
                (code, code),
            )
            self.accounts[code] = cur.lastrowid
        cur = self.conn.execute(
            "INSERT INTO customers(company_id, code, name) VALUES(1, 'C1', 'Test Customer')"
        )
        self.customer_id = cur.lastrowid
        cur = self.conn.execute(
            "INSERT INTO suppliers(company_id, code, name) VALUES(1, 'S1', 'Test Supplier')"
        )
        self.supplier_id = cur.lastrowid
        cur = self.conn.execute(
            "INSERT INTO warehouses(company_id, branch_id, code, name) VALUES(1, 1, 'WH2', 'Warehouse 2')"
        )
        self.warehouse2_id = cur.lastrowid
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def add_product(self, code: str, purchase_price: float, qty: float, average_cost: float):
        cur = self.conn.execute(
            "INSERT INTO products(code, name, company_id, branch_id, purchase_price, sale_price, quantity) "
            "VALUES(?, ?, 1, 1, ?, 20, ?)",
            (code, code, purchase_price, qty),
        )
        product_id = cur.lastrowid
        self.conn.execute(
            "INSERT INTO product_stock(company_id, branch_id, warehouse_id, product_id, quantity, average_cost) "
            "VALUES(1, 1, 1, ?, ?, ?)",
            (product_id, qty, average_cost),
        )
        self.conn.commit()
        return product_id

    def post_purchase(self, number: str, product_id: int, qty: float, cost: float,
                      tax: float = 0.0, paid: float = 0.0):
        total = round(qty * cost + tax, 2)
        return PurchaseService().create_invoice(
            company_id=1, branch_id=1, supplier_id=self.supplier_id,
            invoice_number=number, supplier_invoice_number="SUP-" + number,
            invoice_date="2026-01-01",
            items=[{"product_id": product_id, "warehouse_id": 1, "quantity": qty,
                    "unit_cost": cost, "discount": 0, "tax": tax, "total": total}],
            subtotal=round(qty * cost, 2), discount=0, tax=tax, total=total,
            paid_amount=paid, remaining_amount=round(total - paid, 2),
            notes="test", created_by=1,
            supplier_account=self.accounts["AP"], inventory_account=self.accounts["INV"],
            tax_account=self.accounts["TAX"] if tax else None,
            cash_account=self.accounts["INV"] if paid else None,
        )

    def post_sale(self, number: str, product_id: int, qty: float, unit_price: float, tax: float):
        total = round(qty * unit_price + tax, 2)
        return SalesService().create_invoice(
            company_id=1, branch_id=1, customer_id=self.customer_id,
            invoice_number=number, invoice_date="2026-01-01",
            items=[{"product_id": product_id, "warehouse_id": 1, "quantity": qty,
                    "unit_price": unit_price, "discount": 0, "tax": tax, "total": total}],
            subtotal=round(qty * unit_price, 2), discount=0, tax=tax, total=total,
            paid_amount=0, remaining_amount=total, notes="test", created_by=1,
            receivable_account=self.accounts["AR"], sales_account=self.accounts["SALES"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"] if tax else None,
        )

    def set_sales_policy(self, policy: str):
        self.conn.execute(
            """INSERT INTO company_sales_settings(company_id,inventory_policy)
               VALUES(1,?) ON CONFLICT(company_id) DO UPDATE SET inventory_policy=excluded.inventory_policy""",
            (policy,),
        )
        self.conn.commit()

    def journal_for(self, reference_type: str, reference_id: int):
        entry = self.conn.execute(
            "SELECT id FROM journal_entries WHERE reference_type=? AND reference_id=?",
            (reference_type, reference_id),
        ).fetchone()
        if entry is None:
            return None
        return self.conn.execute(
            "SELECT account_id, debit, credit FROM journal_details WHERE journal_entry_id=?",
            (entry[0],),
        ).fetchall()

    def test_sales_listing_is_company_scoped_and_searchable(self):
        product_id = self.add_product("LIST-P1", 10, 5, 10)
        self.post_sale("LIST-SALE-001", product_id, 1, 20, tax=0)

        rows = SalesService().list_for_company(1)
        self.assertEqual(len([row for row in rows if row["invoice_number"] == "LIST-SALE-001"]), 1)
        matched = SalesService().list_for_company(1, "LIST-SALE-001")
        self.assertEqual(len(matched), 1)
        self.assertEqual(matched[0]["customer_name"], "Test Customer")
        self.assertEqual(SalesService().list_for_company(999999), [])
        self.assertEqual(SalesService().get_product_name(product_id, 1), "LIST-P1")
        self.assertIsNone(SalesService().get_product_name(product_id, 999999))

    def test_purchase_posting_and_cancel_restores_stock_and_reverses_journal(self):
        product_id = self.add_product("PC1", 12, 5, 12)
        invoice_id = self.post_purchase("P-COV", product_id, 3, 12)
        stock = self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()
        self.assertEqual(float(stock[0]), 8.0)
        self.assertIsNotNone(self.journal_for("PURCHASE", invoice_id))

        PurchaseService().cancel_invoice(invoice_id, created_by=1, cancel_date="2026-01-02")

        stock = self.conn.execute(
            "SELECT quantity, average_cost FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()
        self.assertEqual(float(stock[0]), 5.0)
        self.assertEqual(float(stock[1]), 12.0)
        status = self.conn.execute(
            "SELECT status FROM purchase_invoices WHERE id=?", (invoice_id,)
        ).fetchone()[0]
        self.assertEqual(str(status).upper(), "CANCELLED")
        # Reversal journal exists and is balanced
        original = self.conn.execute(
            "SELECT id FROM journal_entries WHERE reference_type='PURCHASE' AND reference_id=?",
            (invoice_id,),
        ).fetchone()[0]
        reversal = self.conn.execute(
            "SELECT id FROM journal_entries WHERE reference_type='REVERSAL' AND reference_id=?",
            (original,),
        ).fetchone()
        self.assertIsNotNone(reversal)
        lines = self.conn.execute(
            "SELECT debit, credit FROM journal_details WHERE journal_entry_id=?", (reversal[0],)
        ).fetchall()
        self.assertEqual(round(sum(float(r[0]) for r in lines), 2),
                         round(sum(float(r[1]) for r in lines), 2))
        # Cancelling twice is rejected
        with self.assertRaises(TransactionError) as ctx:
            PurchaseService().cancel_invoice(invoice_id, created_by=1)
        self.assertIn("already cancelled", str(ctx.exception))

    def test_transfer_both_directions_moves_stock_and_preserves_cost(self):
        product_id = self.add_product("PT1", 10, 10, 10)
        TransferService().create_transfer(
            company_id=1, branch_id=1, from_warehouse=1, to_warehouse=self.warehouse2_id,
            transfer_number="T1", transfer_date="2026-01-01",
            items=[{"product_id": product_id, "quantity": 4}], notes="", created_by=1,
        )
        TransferService().create_transfer(
            company_id=1, branch_id=1, from_warehouse=self.warehouse2_id, to_warehouse=1,
            transfer_number="T2", transfer_date="2026-01-02",
            items=[{"product_id": product_id, "quantity": 1.5}], notes="", created_by=1,
        )
        wh1 = self.conn.execute(
            "SELECT quantity, average_cost FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()
        wh2 = self.conn.execute(
            "SELECT quantity, average_cost FROM product_stock WHERE product_id=? AND warehouse_id=?",
            (product_id, self.warehouse2_id),
        ).fetchone()
        self.assertEqual(float(wh1[0]), 7.5)
        self.assertEqual(float(wh1[1]), 10.0)
        self.assertEqual(float(wh2[0]), 2.5)
        self.assertEqual(float(wh2[1]), 10.0)
        from alexerp.services.audit_service import AuditService
        transfer_events = AuditService().list_events(company_id=1, entity_type="stock_transfer")
        self.assertEqual(len([e for e in transfer_events if e["action"] == "warehouse_transfer_posted"]), 2)

    def test_accounting_failure_rolls_back_entire_purchase(self):
        product_id = self.add_product("PF1", 10, 5, 10)
        service = PurchaseService()
        with mock.patch.object(service.accounting, "create_entry",
                               side_effect=RuntimeError("simulated accounting failure")):
            with self.assertRaises(TransactionError) as ctx:
                service.create_invoice(
                    company_id=1, branch_id=1, supplier_id=self.supplier_id,
                    invoice_number="P-FAIL", supplier_invoice_number="SUP-FAIL",
                    invoice_date="2026-01-01",
                    items=[{"product_id": product_id, "warehouse_id": 1, "quantity": 2,
                            "unit_cost": 10, "discount": 0, "tax": 0, "total": 20}],
                    subtotal=20, discount=0, tax=0, total=20,
                    paid_amount=0, remaining_amount=20, notes="", created_by=1,
                    supplier_account=self.accounts["AP"], inventory_account=self.accounts["INV"],
                )
        self.assertIn("simulated accounting failure", str(ctx.exception))
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM purchase_invoices WHERE invoice_number='P-FAIL'"
        ).fetchone())
        stock = self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()
        self.assertEqual(float(stock[0]), 5.0)
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM stock_movements WHERE reference_type='PURCHASE' AND notes LIKE '%P-FAIL%'"
        ).fetchone())

    def test_partial_return_reverses_proportional_tax(self):
        product_id = self.add_product("PR1", 10, 5, 10)
        invoice_id = self.post_sale("S-PART", product_id, 2, 50, tax=10)
        return_id = SalesReturnService().create_return(
            company_id=1, branch_id=1, sales_invoice_id=invoice_id,
            customer_id=self.customer_id, return_number="R-PART", return_date="2026-01-03",
            items=[{"product_id": product_id, "warehouse_id": 1, "quantity": 1, "total": 55}],
            total=55, notes="half back", created_by=1,
            sales_account=self.accounts["SALES"], receivable_account=self.accounts["AR"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"],
        )
        lines = self.journal_for("SALE_RETURN", return_id)
        tax_debit = sum(float(r[1]) for r in lines if r[0] == self.accounts["TAX"])
        sales_debit = sum(float(r[1]) for r in lines if r[0] == self.accounts["SALES"])
        self.assertEqual(tax_debit, 5.0)
        self.assertEqual(sales_debit, 50.0)
        customer_ar = self.conn.execute(
            "SELECT account_id FROM customers WHERE id=?", (self.customer_id,)
        ).fetchone()[0]
        ar_credit = sum(float(r[2]) for r in lines if r[0] == customer_ar)
        self.assertEqual(ar_credit, 55.0)
        from alexerp.services.audit_service import AuditService
        return_events = AuditService().list_events(company_id=1, entity_type="sales_return")
        self.assertEqual(len(return_events), 1)
        self.assertEqual(return_events[0]["after"]["total"], 55.0)


    def test_financial_document_lifecycle_is_written_to_audit_atomically(self):
        from alexerp.services.payment_service import PaymentService
        from alexerp.services.receipt_service import ReceiptService
        from alexerp.services.audit_service import AuditService

        product_id = self.add_product("AUD-PROD", 10, 5, 10)
        purchase_id = self.post_purchase("AUD-PUR", product_id, 2, 10)
        PaymentService().create_payment(
            company_id=1, branch_id=1, payment_number="AUD-PAY", payment_date="2026-01-02",
            supplier_id=self.supplier_id, cash_account=self.accounts["INV"],
            payable_account=self.accounts["AP"], amount=5, created_by=1)
        payment_id = self.conn.execute(
            "SELECT id FROM payments WHERE payment_number='AUD-PAY'").fetchone()[0]
        PaymentService().cancel_payment(payment_id, created_by=1, cancel_date="2026-01-03")

        sale_id = self.post_sale("AUD-SALE", product_id, 1, 20, tax=0)
        ReceiptService().create_receipt(
            company_id=1, branch_id=1, receipt_number="AUD-REC", receipt_date="2026-01-04",
            customer_id=self.customer_id, cash_account=self.accounts["INV"],
            receivable_account=self.accounts["AR"], amount=5, created_by=1)
        receipt_id = self.conn.execute(
            "SELECT id FROM receipts WHERE receipt_number='AUD-REC'").fetchone()[0]
        ReceiptService().cancel_receipt(receipt_id, created_by=1, cancel_date="2026-01-05")

        events = AuditService().list_events(company_id=1, limit=100)
        actions = {event["action"] for event in events}
        self.assertTrue({"invoice_posted", "supplier_payment_posted", "supplier_payment_cancelled",
                         "customer_receipt_posted", "customer_receipt_cancelled"}.issubset(actions))
        purchase_event = next(e for e in events if e["entity_type"] == "purchase_invoice"
                              and e["record_id"] == purchase_id and e["action"] == "invoice_posted")
        self.assertEqual(purchase_event["after"]["total"], 20.0)
        sale_event = next(e for e in events if e["entity_type"] == "sales_invoice"
                          and e["record_id"] == sale_id and e["action"] == "invoice_posted")
        self.assertEqual(sale_event["after"]["status"], "POSTED")

    def test_failed_purchase_does_not_leave_audit_event(self):
        from alexerp.services.audit_service import AuditService
        from alexerp.services.accounting_service import AccountingService
        product_id = self.add_product("AUD-ROLLBACK", 10, 5, 10)
        with mock.patch.object(AccountingService, "create_entry", side_effect=RuntimeError("ledger unavailable")):
            with self.assertRaises(TransactionError):
                self.post_purchase("AUD-ROLLBACK-FAIL", product_id, 1, 10)
        events = AuditService().list_events(company_id=1, entity_type="purchase_invoice")
        self.assertFalse(any(e["description"] == "Purchase invoice AUD-ROLLBACK-FAIL posted" for e in events))

    def test_reserved_sale_issues_stock_and_cost_only_when_delivered(self):
        product_id = self.add_product("RESERVE-SALE", 10, 10, 10)
        self.set_sales_policy("RESERVE_UNTIL_DELIVERY")
        invoice_id = self.post_sale("S-RESERVE", product_id, 2, 20, tax=0)

        quantity = self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()[0]
        reserved = self.conn.execute(
            "SELECT quantity,status FROM stock_reservations WHERE reference_id=?",
            (invoice_id,),
        ).fetchone()
        self.assertEqual(float(quantity), 10.0)
        self.assertEqual(float(reserved["quantity"]), 2.0)
        self.assertEqual(reserved["status"], "ACTIVE")
        sale_lines = self.journal_for("SALE", invoice_id)
        self.assertEqual(sum(float(row[1]) for row in sale_lines if row[0] == self.accounts["COGS"]), 0.0)

        with self.assertRaises(TransactionError):
            self.post_sale("S-OVER-RESERVED", product_id, 9, 20, tax=0)
        service = SalesService()
        service.update_delivery_status(invoice_id, "SHIPPED", 1)
        service.update_delivery_status(invoice_id, "DELIVERED", 1)

        quantity = self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()[0]
        self.assertEqual(float(quantity), 8.0)
        self.assertEqual(
            self.conn.execute(
                "SELECT status FROM stock_reservations WHERE reference_id=?",
                (invoice_id,),
            ).fetchone()[0],
            "FULFILLED",
        )
        delivery_lines = self.journal_for("SALE_DELIVERY", invoice_id)
        self.assertEqual(
            sum(float(row[1]) for row in delivery_lines if row[0] == self.accounts["COGS"]),
            20.0,
        )
        self.assertEqual(
            self.conn.execute(
                "SELECT delivery_status FROM sales_invoices WHERE id=?",
                (invoice_id,),
            ).fetchone()[0],
            "DELIVERED",
        )
        service.cancel_invoice(invoice_id, created_by=1, cancel_date="2026-01-03")
        restored = self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()[0]
        self.assertEqual(float(restored), 10.0)
        self.assertIsNotNone(self.conn.execute(
            "SELECT 1 FROM journal_entries WHERE reference_type='REVERSAL' AND reference_id=("
            "SELECT id FROM journal_entries WHERE reference_type='SALE_DELIVERY' AND reference_id=?)",
            (invoice_id,),
        ).fetchone())

    def test_delivery_updates_require_company_permission(self):
        product_id = self.add_product("DELIVERY-PERM", 10, 5, 10)
        invoice_id = self.post_sale("S-DELIVERY-PERM", product_id, 1, 20, tax=0)
        role_id = self.conn.execute(
            "INSERT INTO roles(code,name,is_system,is_active,company_id) "
            "VALUES('NO_DELIVERY','No delivery rights',0,1,1)"
        ).lastrowid
        user_id = self.conn.execute(
            """INSERT INTO users(username,password_hash,full_name,role_id,company_id,branch_id)
               VALUES('no.delivery','unused','No Delivery',?,1,1)""",
            (role_id,),
        ).lastrowid
        self.conn.commit()
        if user_id is None:
            self.fail("Failed to create test user")

        with self.assertRaises(TransactionError):
            SalesService().update_delivery_status(invoice_id, "SHIPPED", int(user_id))
        status = self.conn.execute(
            "SELECT delivery_status FROM sales_invoices WHERE id=?",
            (invoice_id,),
        ).fetchone()[0]
        self.assertEqual(status, "PREPARING")

    def test_cancelling_undelivered_reserved_sale_releases_stock(self):
        product_id = self.add_product("RESERVE-CANCEL", 10, 10, 10)
        self.set_sales_policy("RESERVE_UNTIL_DELIVERY")
        invoice_id = self.post_sale("S-RESERVE-CANCEL", product_id, 3, 20, tax=0)

        SalesService().cancel_invoice(invoice_id, created_by=1, cancel_date="2026-01-02")

        quantity = self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (product_id,),
        ).fetchone()[0]
        status = self.conn.execute(
            "SELECT status FROM stock_reservations WHERE reference_id=?",
            (invoice_id,),
        ).fetchone()[0]
        self.assertEqual(float(quantity), 10.0)
        self.assertEqual(status, "RELEASED")

    def test_invoice_defaults_and_invoice_time_receipt_are_recorded_once(self):
        product_id = self.add_product("PAID-SALE", 5, 10, 5)
        SalesSettingsService().save_settings(
            company_id=1, actor_id=1, inventory_policy="DEDUCT_ON_POST",
            receivable_account_id=self.accounts["AR"],
            sales_account_id=self.accounts["SALES"],
            inventory_account_id=self.accounts["INV"],
            cogs_account_id=self.accounts["COGS"],
            tax_account_id=self.accounts["TAX"],
            cash_account_id=self.accounts["INV"],
        )
        invoice_id = SalesService().create_invoice(
            company_id=1, branch_id=1, customer_id=self.customer_id,
            invoice_number="S-PAID-ONCE", invoice_date="2026-01-01",
            items=[{"product_id": product_id, "warehouse_id": 1, "quantity": 2,
                    "unit_price": 20, "discount": 0, "tax": 0, "total": 40}],
            subtotal=40, discount=0, tax=0, total=40, paid_amount=10,
            remaining_amount=30, notes="", created_by=1,
        )
        receipt = self.conn.execute(
            """SELECT id,amount,status,source_sales_invoice_id FROM receipts
               WHERE source_sales_invoice_id=?""",
            (invoice_id,),
        ).fetchone()
        self.assertIsNotNone(receipt)
        self.assertEqual(float(receipt["amount"]), 10.0)
        self.assertEqual(receipt["status"], "POSTED")
        self.assertEqual(int(receipt["source_sales_invoice_id"]), invoice_id)
        self.assertEqual(
            float(self.conn.execute(
                "SELECT SUM(amount) FROM receipt_allocations WHERE receipt_id=? AND status='ACTIVE'",
                (receipt["id"],),
            ).fetchone()[0]),
            10.0,
        )
        self.assertIsNone(self.conn.execute(
            "SELECT 1 FROM journal_entries WHERE reference_type='RECEIPT' AND reference_id=?",
            (receipt["id"],),
        ).fetchone())
        self.assertEqual(
            BusinessIntelligenceService().executive_summary(
                1, "2026-01-01", "2026-01-31", 1,
            )["receipts_total"],
            10.0,
        )

        SalesService().cancel_invoice(invoice_id, created_by=1, cancel_date="2026-01-02")
        self.assertEqual(
            self.conn.execute(
                "SELECT status FROM receipts WHERE id=?", (receipt["id"],)
            ).fetchone()[0],
            "CANCELLED",
        )
        self.assertEqual(
            BusinessIntelligenceService().executive_summary(
                1, "2026-01-01", "2026-01-31", 1,
            )["receipts_total"],
            0.0,
        )


if __name__ == "__main__":
    unittest.main()
