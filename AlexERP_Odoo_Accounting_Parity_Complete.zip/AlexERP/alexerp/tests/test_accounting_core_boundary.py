import json
import re
from pathlib import Path

from alexerp.accounting import (
    AccountingError, AccountingReadService, AccountingService,
    FiscalPeriodService,
)
from alexerp.accounting.repository import AccountingRepository
from alexerp.core.module_registry import ModuleRegistry
from alexerp.modules.generate_python_import_graph import build_payload
from alexerp.services.accounting_service import (
    AccountingError as LegacyAccountingError,
    AccountingService as LegacyAccountingService,
)
from alexerp.repositories.accounting_repository import AccountingRepository as LegacyAccountingRepository
from alexerp.services.fiscal_period_service import FiscalPeriodService as LegacyFiscalPeriodService


ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = ROOT.parent
ACCOUNTING_CONSUMERS = {
    "alexerp.services.customer_financial_note_service",
    "alexerp.services.fiscal_year_closing_service",
    "alexerp.services.payment_service",
    "alexerp.services.purchase_service",
    "alexerp.services.receipt_service",
    "alexerp.services.sales_delivery_service",
    "alexerp.services.sales_return_service",
    "alexerp.services.sales_service",
}


def test_legacy_service_path_is_a_compatibility_alias():
    assert LegacyAccountingService is AccountingService
    assert LegacyAccountingError is AccountingError
    assert AccountingService.__module__ == "alexerp.accounting.posting_service"
    assert LegacyAccountingRepository is AccountingRepository
    assert AccountingRepository.__module__ == "alexerp.accounting.repository"
    assert LegacyFiscalPeriodService is FiscalPeriodService
    assert FiscalPeriodService.__module__ == "alexerp.accounting.period_service"
    assert AccountingReadService.__module__ == "alexerp.accounting.read_service"


def test_production_code_uses_the_new_accounting_boundary():
    legacy_path = "alexerp.services.accounting_service"
    for path in (PROJECT_ROOT / "alexerp").rglob("*.py"):
        if "tests" in path.relative_to(PROJECT_ROOT / "alexerp").parts:
            continue
        if path == PROJECT_ROOT / "alexerp" / "services" / "accounting_service.py":
            continue
        assert legacy_path not in path.read_text(encoding="utf-8"), path
    legacy_repository_path = "alexerp.repositories.accounting_repository"
    for path in (PROJECT_ROOT / "alexerp").rglob("*.py"):
        if "tests" in path.relative_to(PROJECT_ROOT / "alexerp").parts:
            continue
        if path == PROJECT_ROOT / "alexerp" / "repositories" / "accounting_repository.py":
            continue
        assert legacy_repository_path not in path.read_text(encoding="utf-8"), path


def test_ledger_and_period_sql_is_owned_by_accounting_core():
    table_sql = re.compile(
        r"\b(?:FROM|JOIN|UPDATE|INTO)\s+(?:journal_entries|journal_details|accounting_periods)\b",
        re.IGNORECASE,
    )
    for path in (PROJECT_ROOT / "alexerp").rglob("*.py"):
        relative = path.relative_to(PROJECT_ROOT / "alexerp")
        if "tests" in relative.parts or relative.parts[:1] == ("accounting",):
            continue
        if relative.parts[:2] == ("database", "schema"):
            continue
        assert not table_sql.search(path.read_text(encoding="utf-8")), path


def test_accounting_core_manifest_maps_to_the_real_technical_package():
    registry = ModuleRegistry()
    manifests = registry.load()
    core = manifests["accounting_core"]
    assert core.application is False
    assert core.python_package == "alexerp.accounting"
    assert (PROJECT_ROOT / "alexerp" / "accounting" / "__init__.py").is_file()
    assert registry.audit(set())["missing_packages"] == []
    for app_id in {
        "accounting", "business_intelligence", "customers", "fiscal",
        "purchases", "reports", "sales", "settlements",
    }:
        assert "accounting_core" in manifests[app_id].depends


def test_python_import_graph_matches_source_and_records_accounting_consumers():
    generated = build_payload(PROJECT_ROOT)
    persisted = json.loads(
        (ROOT / "modules" / "python_import_graph.json").read_text(encoding="utf-8")
    )
    assert persisted == generated
    imports = generated["static_imports"]
    for consumer in ACCOUNTING_CONSUMERS:
        assert "alexerp.accounting" in imports[consumer], consumer
    assert "alexerp.accounting.repository" in imports["alexerp.accounting.posting_service"]
    assert len(generated["dynamic_entrypoints"]) == 18
    assert all(edge["consumer"] == "alexerp.ui.main_window" for edge in generated["dynamic_entrypoints"])
