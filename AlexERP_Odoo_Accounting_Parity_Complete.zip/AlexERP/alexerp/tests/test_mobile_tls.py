"""HTTPS for the mobile server: real TLS sockets against a real server instance.

Run from the alexerp3 folder:
    PYTHONPATH=. python -m unittest discover -s alexerp/tests -v
"""
from __future__ import annotations

import datetime as dt
import http.client
import json
import os
import shutil
import socket
import ssl
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

from mobile_web import tls_support as T
from mobile_web.mobile_server import build_server


def _client_ctx(cafile: Path | None) -> ssl.SSLContext:
    return ssl.create_default_context(cafile=str(cafile)) if cafile else ssl.create_default_context()


class MobileTLSTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="alexerp_tls_")
        self.dir = Path(self.tmp.name) / "tls"
        self.cert, self.key = T.ensure_self_signed(self.dir, ["localhost"], ["127.0.0.1"])
        self.server = build_server("127.0.0.1", 0, T.build_ssl_context(self.cert, self.key))
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.tmp.cleanup()

    def _https(self, path="/", cafile="pinned", timeout=5):
        ctx = _client_ctx(self.cert if cafile == "pinned" else None)
        conn = http.client.HTTPSConnection("127.0.0.1", self.port, context=ctx, timeout=timeout)
        conn.connect()
        self.tls_version = conn.sock.version()   # read now: the server closes after each reply
        conn.request("GET", path)
        return conn, conn.getresponse()

    # ---- the connection really is encrypted ----
    def test_https_works_with_pinned_cert_and_modern_protocol(self):
        conn, resp = self._https("/")
        try:
            self.assertEqual(resp.status, 200)
            self.assertIn(self.tls_version, ("TLSv1.2", "TLSv1.3"))
            self.assertIn("max-age", resp.getheader("Strict-Transport-Security", ""))
            self.assertEqual(resp.getheader("X-Frame-Options"), "DENY")
            self.assertEqual(resp.getheader("X-Content-Type-Options"), "nosniff")
        finally:
            conn.close()

    def test_api_still_requires_token_over_tls(self):
        conn, resp = self._https("/api/dashboard")
        try:
            self.assertEqual(resp.status, 401)
            self.assertFalse(json.loads(resp.read())["ok"])
        finally:
            conn.close()

    def test_untrusted_certificate_is_rejected_by_default_clients(self):
        with self.assertRaises(ssl.SSLCertVerificationError):
            self._https("/", cafile=None)

    def test_plain_http_to_the_https_port_gets_no_application_data(self):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        with self.assertRaises((http.client.HTTPException, OSError)):
            conn.request("GET", "/api/dashboard")
            conn.getresponse().read()
        conn.close()

    def test_minimum_protocol_is_tls12(self):
        ctx = T.build_ssl_context(self.cert, self.key)
        self.assertGreaterEqual(ctx.minimum_version, ssl.TLSVersion.TLSv1_2)

    def test_stalled_connection_does_not_block_other_clients(self):
        stalled = socket.create_connection(("127.0.0.1", self.port))   # connects, never handshakes
        try:
            conn, resp = self._https("/", timeout=5)
            self.assertEqual(resp.status, 200)
            conn.close()
        finally:
            stalled.close()

    # ---- certificate lifecycle ----
    def test_private_key_is_owner_only(self):
        if os.name != "posix":
            self.skipTest("POSIX permissions only")
        self.assertEqual(self.key.stat().st_mode & 0o077, 0)

    def test_certificate_is_reused_until_address_changes_then_reissued_keeping_old_names(self):
        first = T.fingerprint_sha256(self.cert)
        T.ensure_self_signed(self.dir, ["localhost"], ["127.0.0.1"])
        self.assertEqual(T.fingerprint_sha256(self.cert), first)                 # reused
        T.ensure_self_signed(self.dir, ["localhost"], ["127.0.0.1", "192.0.2.10"])
        self.assertNotEqual(T.fingerprint_sha256(self.cert), first)              # reissued
        sans = set(json.loads((self.dir / "meta.json").read_text())["sans"])
        self.assertTrue({"IP:127.0.0.1", "IP:192.0.2.10", "DNS:localhost"} <= sans)
        # and the new cert truly covers the new address
        from cryptography import x509
        cert = x509.load_pem_x509_certificate(self.cert.read_bytes())
        names = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        self.assertIn("192.0.2.10", [str(i) for i in names.get_values_for_type(x509.IPAddress)])

    def test_certificate_close_to_expiry_is_renewed(self):
        first = T.fingerprint_sha256(self.cert)
        meta = self.dir / "meta.json"
        info = json.loads(meta.read_text())
        info["not_after"] = (dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=3)).isoformat()
        meta.write_text(json.dumps(info))
        T.ensure_self_signed(self.dir, ["localhost"], ["127.0.0.1"])
        self.assertNotEqual(T.fingerprint_sha256(self.cert), first)

    @unittest.skipUnless(shutil.which("openssl"), "openssl not installed")
    def test_openssl_fallback_produces_a_loadable_certificate(self):
        cert, key = self.dir / "o.pem", self.dir / "o.key"
        T._generate_with_openssl(["localhost"], ["127.0.0.1"], cert, key, 30)
        ctx = T.build_ssl_context(cert, key)
        self.assertIsNotNone(ctx)

    # ---- startup policy ----
    def test_plain_http_is_refused_on_network_interfaces_even_if_requested(self):
        with mock.patch.dict(os.environ, {T.ENV_ALLOW_HTTP: "1"}):
            with self.assertRaises(T.TLSConfigError):
                T.prepare_tls("0.0.0.0", self.dir)
            self.assertIsNone(T.prepare_tls("127.0.0.1", self.dir))

    def test_https_is_the_default_without_any_flag(self):
        env = {k: v for k, v in os.environ.items() if k != T.ENV_ALLOW_HTTP}
        with mock.patch.dict(os.environ, env, clear=True):
            info = T.prepare_tls("0.0.0.0", self.dir, "127.0.0.1")
        self.assertIsNotNone(info)
        self.assertTrue(info.self_signed)

    def test_custom_certificate_is_used_and_half_config_is_an_error(self):
        env = {k: v for k, v in os.environ.items() if k != T.ENV_ALLOW_HTTP}
        env[T.ENV_CERT], env[T.ENV_KEY] = str(self.cert), str(self.key)
        with mock.patch.dict(os.environ, env, clear=True):
            info = T.prepare_tls("0.0.0.0", self.dir / "other")
        self.assertFalse(info.self_signed)
        self.assertEqual(info.fingerprint, T.fingerprint_sha256(self.cert))
        env.pop(T.ENV_KEY)
        with mock.patch.dict(os.environ, env, clear=True):
            with self.assertRaises(T.TLSConfigError):
                T.prepare_tls("0.0.0.0", self.dir / "other")


if __name__ == "__main__":
    unittest.main()
