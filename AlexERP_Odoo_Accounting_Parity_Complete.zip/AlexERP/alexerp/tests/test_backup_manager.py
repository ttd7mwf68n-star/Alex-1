from __future__ import annotations

import sqlite3
import tempfile
import unittest
from pathlib import Path

from alexerp.database.backup import BackupManager, BackupValidationError
from alexerp.database import db as db_module
from alexerp.database.db import Database


class BackupManagerTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tmp = tempfile.TemporaryDirectory(prefix="alex_backup_")
        root = Path(self.tmp.name)
        self.db_path = root / "data" / "alex.db"
        self.db_path.parent.mkdir()
        self.backup_dir = root / "backups"
        db_module.DATABASE_FILE = self.db_path
        self._create_db(self.db_path, "live-before")
        self.manager = BackupManager(self.backup_dir, self.db_path)

    def tearDown(self):
        Database.close()
        self.tmp.cleanup()

    @staticmethod
    def _create_db(path: Path, value: str):
        connection = sqlite3.connect(path)
        try:
            connection.execute("CREATE TABLE IF NOT EXISTS records(value TEXT NOT NULL)")
            connection.execute("DELETE FROM records")
            connection.execute("INSERT INTO records(value) VALUES(?)", (value,))
            connection.commit()
        finally:
            connection.close()

    def test_create_backup_is_valid_and_has_checksum_manifest(self):
        backup = self.manager.create_backup()
        self.assertTrue(backup.exists())
        self.assertTrue(backup.with_suffix(".db.json").exists())
        result = self.manager.verify_backup(backup)
        self.assertEqual(result["integrity"], "ok")
        self.assertEqual(result["foreign_key_errors"], 0)

    def test_backup_includes_committed_wal_content(self):
        connection = sqlite3.connect(self.db_path)
        try:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("INSERT INTO records(value) VALUES('wal-committed')")
            connection.commit()
            backup = self.manager.create_backup()
        finally:
            connection.close()
        copied = sqlite3.connect(backup)
        try:
            values = [row[0] for row in copied.execute("SELECT value FROM records")]
        finally:
            copied.close()
        self.assertIn("wal-committed", values)

    def test_restore_validates_and_preserves_pre_restore_database(self):
        backup = self.manager.create_backup()
        self._create_db(self.db_path, "live-after")
        safety_backup = self.manager.restore_backup(backup)
        restored = sqlite3.connect(self.db_path)
        try:
            value = restored.execute("SELECT value FROM records").fetchone()[0]
        finally:
            restored.close()
        self.assertEqual(value, "live-before")
        safety = sqlite3.connect(safety_backup)
        try:
            safety_value = safety.execute("SELECT value FROM records").fetchone()[0]
        finally:
            safety.close()
        self.assertEqual(safety_value, "live-after")

    def test_corrupt_backup_is_rejected_without_changing_live_database(self):
        backup = self.manager.create_backup()
        backup.write_bytes(b"not a sqlite database")
        with self.assertRaises(BackupValidationError):
            self.manager.restore_backup(backup)
        connection = sqlite3.connect(self.db_path)
        try:
            self.assertEqual(connection.execute("SELECT value FROM records").fetchone()[0], "live-before")
        finally:
            connection.close()

    def test_modified_backup_fails_checksum_verification(self):
        backup = self.manager.create_backup()
        with backup.open("ab") as stream:
            stream.write(b"tamper")
        with self.assertRaises(BackupValidationError):
            self.manager.verify_backup(backup)

    def test_restore_closes_app_connection_and_removes_old_wal_sidecars(self):
        backup = self.manager.create_backup()
        connection = Database.connect()
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("INSERT INTO records(value) VALUES('unbacked-current-change')")
        connection.commit()
        self.manager.restore_backup(backup)
        self.assertFalse(Path(str(self.db_path) + "-wal").exists())
        restored = sqlite3.connect(self.db_path)
        try:
            values = [row[0] for row in restored.execute("SELECT value FROM records")]
        finally:
            restored.close()
        self.assertEqual(values, ["live-before"])

    def test_restore_rolls_back_database_and_wal_if_sidecar_move_fails(self):
        from unittest.mock import patch
        backup = self.manager.create_backup()
        self._create_db(self.db_path, "live-after")
        wal = Path(str(self.db_path) + "-wal")
        shm = Path(str(self.db_path) + "-shm")
        original_create = self.manager.create_backup
        real_replace = __import__("os").replace

        def create_safety_then_sidecars(*args, **kwargs):
            result = original_create(*args, **kwargs)
            wal.write_bytes(b"old-wal")
            shm.write_bytes(b"old-shm")
            return result

        def fail_shm_move(src, dst):
            if Path(src) == shm:
                raise OSError("simulated SHM move failure")
            return real_replace(src, dst)

        with patch.object(self.manager, "create_backup", side_effect=create_safety_then_sidecars), \
             patch.object(db_module.Database, "close", return_value=None), \
             patch("alexerp.database.backup.os.replace", side_effect=fail_shm_move):
            with self.assertRaisesRegex(OSError, "SHM move failure"):
                self.manager.restore_backup(backup)
        self.assertEqual(wal.read_bytes(), b"old-wal")
        self.assertEqual(shm.read_bytes(), b"old-shm")
        connection = sqlite3.connect(self.db_path)
        try:
            self.assertEqual(connection.execute("SELECT value FROM records").fetchone()[0], "live-after")
        finally:
            connection.close()

    def test_restore_rolls_back_if_installing_staged_database_fails(self):
        from unittest.mock import patch
        import os
        backup = self.manager.create_backup()
        self._create_db(self.db_path, "live-after")
        real_replace = os.replace

        def fail_install(src, dst):
            if Path(dst) == self.db_path and Path(src).name.startswith(".alex_restore_"):
                raise OSError("simulated install failure")
            return real_replace(src, dst)

        with patch("alexerp.database.backup.os.replace", side_effect=fail_install):
            with self.assertRaisesRegex(OSError, "install failure"):
                self.manager.restore_backup(backup)
        connection = sqlite3.connect(self.db_path)
        try:
            self.assertEqual(connection.execute("SELECT value FROM records").fetchone()[0], "live-after")
        finally:
            connection.close()

    def test_restore_rejects_live_database_as_its_own_source(self):
        with self.assertRaises(ValueError):
            self.manager.restore_backup(self.db_path)

    def test_delete_rejects_paths_outside_backup_directory(self):
        with self.assertRaises(ValueError):
            self.manager.delete_backup(self.db_path)

    def test_cleanup_keeps_at_least_one_backup(self):
        self.manager.create_backup()
        with self.assertRaises(ValueError):
            self.manager.cleanup(0)
        self.assertEqual(len(self.manager.list_backups()), 1)


    def test_backup_without_manifest_is_rejected(self):
        backup = self.manager.create_backup()
        backup.with_suffix(".db.json").unlink()
        with self.assertRaises(BackupValidationError):
            self.manager.verify_backup(backup)


    def test_manifest_claim_tampering_is_rejected_even_when_database_checksum_is_valid(self):
        import json
        backup = self.manager.create_backup()
        manifest_path = backup.with_suffix(".db.json")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["table_count"] = 999
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        with self.assertRaisesRegex(BackupValidationError, "عدد الجداول"):
            self.manager.verify_backup(backup)

    def test_unsupported_manifest_version_is_rejected(self):
        import json
        backup = self.manager.create_backup()
        manifest_path = backup.with_suffix(".db.json")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["format_version"] = 999
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        with self.assertRaisesRegex(BackupValidationError, "إصدار"):
            self.manager.verify_backup(backup)

    def test_backup_failure_does_not_leave_temporary_artifact(self):
        from unittest.mock import patch
        before = set(self.backup_dir.iterdir())
        with patch.object(BackupManager, "_copy_database", side_effect=sqlite3.OperationalError("simulated backup failure")):
            with self.assertRaisesRegex(sqlite3.OperationalError, "simulated"):
                self.manager.create_backup()
        after = set(self.backup_dir.iterdir())
        self.assertEqual(after, before)

    def test_delete_removes_sqlite_sidecar_files(self):
        backup = self.manager.create_backup()
        Path(str(backup) + "-wal").write_bytes(b"sidecar")
        Path(str(backup) + "-shm").write_bytes(b"sidecar")
        self.manager.delete_backup(backup)
        self.assertFalse(Path(str(backup) + "-wal").exists())
        self.assertFalse(Path(str(backup) + "-shm").exists())

if __name__ == "__main__":
    unittest.main()
