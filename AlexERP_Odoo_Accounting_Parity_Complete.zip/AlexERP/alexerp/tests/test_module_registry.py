import json
from pathlib import Path

import pytest

from alexerp.core.module_registry import ModuleRegistry, ModuleRegistryError
from alexerp.ui.main_window import MODULE_MANIFESTS, NAVIGATION, NAV_PERMISSIONS


ROOT = Path(__file__).resolve().parents[1]
SHELL_MODULES = {"apps", "app_catalog"}


def _application_manifest(module_id="safe_module", **overrides):
    raw = {
        "id": module_id,
        "name": "Safe",
        "version": "1.0.0",
        "category": "Test",
        "description": "Test application",
        "state": "available",
        "application": True,
        "entrypoint": "alexerp.ui.safe.SafePage",
        "page_file": "alexerp/ui/safe.py",
        "icon": "S",
        "navigation_section": "Test",
        "sequence": 10,
        "permissions": ["safe.view"],
        "depends": [],
    }
    raw.update(overrides)
    return raw


def test_all_navigable_business_modules_have_valid_manifests():
    registry = ModuleRegistry(ROOT / "modules" / "manifests")
    manifests = registry.load()
    navigation_ids = {item[0] for item in NAVIGATION} - SHELL_MODULES
    assert len(registry.applications({"available"})) == 18
    assert registry.audit(navigation_ids) == {
        "missing_manifests": [],
        "orphan_manifests": [],
        "missing_entrypoints": [],
        "missing_packages": [],
        "dependency_cycles": [],
    }
    assert {module_id for module_id, item in manifests.items() if item.application} == navigation_ids


def test_dependencies_reference_existing_modules():
    manifests = ModuleRegistry().load()
    assert "accounting_core" in manifests["sales"].depends
    assert "accounting_core" in manifests["purchases"].depends
    assert "accounting_core" in manifests["settlements"].depends
    assert "products" in manifests["sales"].integrates_with
    assert "inventory" in manifests["purchasing_workflow"].integrates_with
    assert "accounting" in manifests["fiscal"].integrates_with


def test_navigation_is_derived_from_manifest_metadata():
    navigation = {item[0]: item for item in NAVIGATION}
    for module_id, manifest in MODULE_MANIFESTS.items():
        if not manifest.application or manifest.state != "available":
            continue
        item = navigation[module_id]
        assert item[1] == manifest.name
        assert item[2] == manifest.icon
        assert item[3].__name__ == manifest.entrypoint.rsplit(".", 1)[-1]
        assert item[4] == manifest.navigation_section


def test_manifest_permissions_are_the_navigation_access_source():
    application_ids = {
        module_id for module_id, manifest in MODULE_MANIFESTS.items()
        if manifest.application and manifest.state == "available"
    }
    assert set(NAV_PERMISSIONS) == application_ids
    for module_id in application_ids:
        assert tuple(NAV_PERMISSIONS[module_id]) == MODULE_MANIFESTS[module_id].permissions


def test_dependency_graph_is_generated_from_every_manifest():
    registry = ModuleRegistry()
    generated = registry.dependency_graph_payload()
    persisted = json.loads((ROOT / "modules" / "module_dependency_graph.json").read_text(encoding="utf-8"))
    assert persisted == generated
    assert set(persisted["modules"]) == set(registry.load())
    assert {"sales_orders", "settlements", "security_admin"}.issubset(persisted["modules"])
    assert persisted["modules"]["sales"] == ["accounting_core"]
    assert persisted["integrations"]["sales"] == ["customers", "inventory", "products"]


def test_registry_rejects_path_traversal(tmp_path):
    raw = _application_manifest(page_file="../secret.py")
    (tmp_path / "safe_module.json").write_text(json.dumps(raw), encoding="utf-8")
    with pytest.raises(ModuleRegistryError, match="Unsafe page_file"):
        ModuleRegistry(tmp_path).load()


def test_registry_rejects_unknown_dependencies(tmp_path):
    raw = _application_manifest(depends=["missing_module"])
    (tmp_path / "safe_module.json").write_text(json.dumps(raw), encoding="utf-8")
    with pytest.raises(ModuleRegistryError, match="unknown dependencies"):
        ModuleRegistry(tmp_path).load()


def test_registry_rejects_invalid_permission_key(tmp_path):
    raw = _application_manifest(permissions=["not a permission"])
    (tmp_path / "safe_module.json").write_text(json.dumps(raw), encoding="utf-8")
    with pytest.raises(ModuleRegistryError, match="Invalid permission key"):
        ModuleRegistry(tmp_path).load()


def test_registry_rejects_entrypoint_page_mismatch(tmp_path):
    raw = _application_manifest(page_file="alexerp/ui/other.py")
    (tmp_path / "safe_module.json").write_text(json.dumps(raw), encoding="utf-8")
    with pytest.raises(ModuleRegistryError, match="does not match entrypoint"):
        ModuleRegistry(tmp_path).load()


def test_application_manifest_requires_complete_navigation_metadata(tmp_path):
    raw = _application_manifest()
    del raw["icon"]
    (tmp_path / "safe_module.json").write_text(json.dumps(raw), encoding="utf-8")
    with pytest.raises(ModuleRegistryError, match="missing fields: icon"):
        ModuleRegistry(tmp_path).load()


def test_technical_module_does_not_require_a_ui_entrypoint(tmp_path):
    raw = {
        "id": "accounting_core",
        "name": "Accounting Core",
        "version": "1.0.0",
        "category": "Technical",
        "description": "Shared accounting services",
        "state": "available",
        "application": False,
        "python_package": "alexerp.accounting",
        "depends": [],
    }
    (tmp_path / "accounting_core.json").write_text(json.dumps(raw), encoding="utf-8")
    registry = ModuleRegistry(tmp_path)
    manifest = registry.load()["accounting_core"]
    assert manifest.application is False
    assert manifest.entrypoint is None
    assert manifest.page_file is None
    assert manifest.python_package == "alexerp.accounting"
    assert registry.audit(set())["orphan_manifests"] == []
    assert registry.audit(set())["missing_packages"] == []


def test_topological_order_places_dependencies_first():
    registry = ModuleRegistry()
    manifests = registry.load()
    order = registry.topological_order()
    positions = {module_id: index for index, module_id in enumerate(order)}
    assert set(order) == set(manifests)
    for module_id, manifest in manifests.items():
        for dependency in manifest.depends:
            assert positions[dependency] < positions[module_id]


def test_technical_dependents_and_functional_integrators_are_distinct():
    registry = ModuleRegistry()
    assert registry.dependents_of("accounting_core", transitive=False) == [
        "accounting", "business_intelligence", "customers", "fiscal",
        "purchases", "reports", "sales", "settlements",
    ]
    assert registry.dependents_of("products", transitive=False) == []
    assert registry.integrators_of("products", transitive=False) == [
        "inventory", "inventory_intelligence", "purchases", "sales", "sales_orders"
    ]
    transitive = registry.integrators_of("products")
    assert "accounting" in transitive
    assert "reports" in transitive
    assert "fiscal" in transitive


def test_topological_order_rejects_dependency_cycle(tmp_path):
    first = _application_manifest("module_a", depends=["module_b"])
    second = _application_manifest(
        "module_b",
        name="B",
        entrypoint="alexerp.ui.b.BPage",
        page_file="alexerp/ui/b.py",
        depends=["module_a"],
    )
    (tmp_path / "module_a.json").write_text(json.dumps(first), encoding="utf-8")
    (tmp_path / "module_b.json").write_text(json.dumps(second), encoding="utf-8")
    with pytest.raises(ModuleRegistryError, match="cycle"):
        ModuleRegistry(tmp_path).topological_order()
