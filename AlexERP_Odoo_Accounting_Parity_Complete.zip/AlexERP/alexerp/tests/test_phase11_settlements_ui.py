"""Static regression checks for the Phase 11 allocation workspace."""
import ast
import unittest
from pathlib import Path

from alexerp.ui.main_window import MODULE_MANIFESTS, NAVIGATION, NAV_PERMISSIONS

ROOT = Path(__file__).resolve().parents[1]


class Phase11SettlementsUITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.page = (ROOT / "ui" / "settlements_page.py").read_text(encoding="utf-8")
        cls.main = (ROOT / "ui" / "main_window.py").read_text(encoding="utf-8")
        ast.parse(cls.page)
        ast.parse(cls.main)

    def test_settlement_page_is_registered_in_navigation(self):
        entry = next(item for item in NAVIGATION if item[0] == "settlements")
        manifest = MODULE_MANIFESTS["settlements"]
        self.assertEqual(entry[1], manifest.name)
        self.assertEqual(entry[2], manifest.icon)
        self.assertEqual(entry[3].__name__, manifest.entrypoint.rsplit(".", 1)[-1])
        self.assertEqual(entry[4], manifest.navigation_section)

    def test_navigation_requires_a_relevant_view_permission(self):
        self.assertEqual(NAV_PERMISSIONS["settlements"], MODULE_MANIFESTS["settlements"].permissions)
        self.assertEqual(set(NAV_PERMISSIONS["settlements"]), {
            "receipts.view", "payments.view", "reports.view", "customers.view",
            "suppliers.view", "parties.payment_terms.manage",
        })
        self.assertIn("any(service.has_permission(user_id, permission)", self.main)

    def test_page_delegates_writes_to_domain_service(self):
        self.assertIn("self.service.allocate_receipt(", self.page)
        self.assertIn("self.service.allocate_payment(", self.page)

    def test_document_queries_are_company_scoped(self):
        self.assertIn("WHERE r.company_id=? AND c.company_id=?", self.page)
        self.assertIn("WHERE p.company_id=? AND s.company_id=?", self.page)
        self.assertIn("WHERE company_id=? AND", self.page)

    def test_allocation_actions_check_create_permissions(self):
        self.assertIn('"receipts.create" if self.kind == "receipt" else "payments.create"', self.page)
        self.assertIn("def _allocate(self):", self.page)

    def test_aging_discloses_due_date_basis_and_statement_tab(self):
        self.assertIn("تاريخ الاستحقاق المحفوظ", self.page)
        self.assertIn("customer_aging", self.page)
        self.assertIn("supplier_aging", self.page)
        self.assertIn("customer_statement", self.page)
        self.assertIn("supplier_statement", self.page)


if __name__ == "__main__":
    unittest.main()
