"""Integration tests for invoice-level receipt/payment allocation and aging."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.transaction import TransactionError
from alexerp.database.seed import seed_database
from alexerp.services.invoice_settlement_service import InvoiceSettlementService
from alexerp.services.party_balance_service import PartyBalanceService


class InvoiceSettlementAndAgingTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_settlement_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "settlement.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.user_id = int(self.conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()[0])
        self.company_id = int(self.conn.execute("SELECT id FROM companies ORDER BY id LIMIT 1").fetchone()[0])
        self.branch_id = int(self.conn.execute("SELECT id FROM branches WHERE company_id=? ORDER BY id LIMIT 1", (self.company_id,)).fetchone()[0])
        self.customer_id = self.conn.execute(
            "INSERT INTO customers(company_id,code,name) VALUES(?,?,?)",
            (self.company_id, "C-SET-1", "Settlement Customer"),
        ).lastrowid
        self.supplier_id = self.conn.execute(
            "INSERT INTO suppliers(company_id,code,name) VALUES(?,?,?)",
            (self.company_id, "S-SET-1", "Settlement Supplier"),
        ).lastrowid
        self.sales_invoice_id = self.conn.execute(
            """INSERT INTO sales_invoices(company_id,branch_id,customer_id,invoice_number,invoice_date,
               total,paid_amount,remaining_amount,status,created_by)
               VALUES(?,?,?,?,?,100,0,100,'POSTED',?)""",
            (self.company_id, self.branch_id, self.customer_id, "SI-SET-1", "2026-01-01", self.user_id),
        ).lastrowid
        self.purchase_invoice_id = self.conn.execute(
            """INSERT INTO purchase_invoices(company_id,branch_id,supplier_id,invoice_number,invoice_date,
               total,paid_amount,remaining_amount,status,created_by)
               VALUES(?,?,?,?,?,100,0,100,'POSTED',?)""",
            (self.company_id, self.branch_id, self.supplier_id, "PI-SET-1", "2026-01-01", self.user_id),
        ).lastrowid
        self.receipt_id = self.conn.execute(
            """INSERT INTO receipts(company_id,branch_id,receipt_number,receipt_date,customer_id,amount,created_by,status)
               VALUES(?,?,?,?,?,70,?,'POSTED')""",
            (self.company_id, self.branch_id, "RC-SET-1", "2026-01-15", self.customer_id, self.user_id),
        ).lastrowid
        self.payment_id = self.conn.execute(
            """INSERT INTO payments(company_id,branch_id,payment_number,payment_date,supplier_id,amount,created_by,status)
               VALUES(?,?,?,?,?,70,?,'POSTED')""",
            (self.company_id, self.branch_id, "SP-SET-1", "2026-01-15", self.supplier_id, self.user_id),
        ).lastrowid
        self.conn.commit()
        self.service = InvoiceSettlementService()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def test_customer_receipt_allocation_updates_invoice_and_aging(self):
        self.service.allocate_receipt(self.receipt_id, self.sales_invoice_id, "60.00", self.user_id)
        invoice = self.conn.execute("SELECT paid_amount,remaining_amount FROM sales_invoices WHERE id=?", (self.sales_invoice_id,)).fetchone()
        self.assertEqual(float(invoice["paid_amount"]), 60.0)
        self.assertEqual(float(invoice["remaining_amount"]), 40.0)
        # The unallocated 10 remains an account credit; allocation must not double-subtract it.
        self.assertEqual(PartyBalanceService().customer_balance(self.customer_id), 30.0)
        report = self.service.customer_aging(self.company_id, "2026-02-15")
        self.assertEqual(report["totals"]["days_31_60"], 40.0)
        self.assertEqual(report["totals"]["total"], 40.0)

    def test_supplier_payment_allocation_updates_invoice_and_aging(self):
        self.service.allocate_payment(self.payment_id, self.purchase_invoice_id, 60, self.user_id)
        invoice = self.conn.execute("SELECT paid_amount,remaining_amount FROM purchase_invoices WHERE id=?", (self.purchase_invoice_id,)).fetchone()
        self.assertEqual(float(invoice["paid_amount"]), 60.0)
        self.assertEqual(float(invoice["remaining_amount"]), 40.0)
        self.assertEqual(PartyBalanceService().supplier_balance(self.supplier_id), 30.0)
        report = self.service.supplier_aging(self.company_id, "2026-02-15")
        self.assertEqual(report["totals"]["days_31_60"], 40.0)

    def test_cannot_allocate_more_than_receipt_or_invoice_balance(self):
        with self.assertRaises(TransactionError):
            self.service.allocate_receipt(self.receipt_id, self.sales_invoice_id, 71, self.user_id)
        self.service.allocate_receipt(self.receipt_id, self.sales_invoice_id, 60, self.user_id)
        with self.assertRaises(TransactionError):
            self.service.allocate_receipt(self.receipt_id, self.sales_invoice_id, 11, self.user_id)

    def test_cancelling_receipt_reverses_allocations_and_restores_invoice(self):
        from alexerp.services.receipt_service import ReceiptService
        self.service.allocate_receipt(self.receipt_id, self.sales_invoice_id, 60, self.user_id)
        with mock.patch("alexerp.services.receipt_service.AccountingService.reverse_entry", return_value=True):
            ReceiptService().cancel_receipt(self.receipt_id, self.user_id, cancel_date="2026-02-01")
        invoice = self.conn.execute("SELECT paid_amount,remaining_amount FROM sales_invoices WHERE id=?", (self.sales_invoice_id,)).fetchone()
        self.assertEqual(float(invoice["paid_amount"]), 0.0)
        self.assertEqual(float(invoice["remaining_amount"]), 100.0)
        status = self.conn.execute("SELECT status FROM receipt_allocations WHERE receipt_id=?", (self.receipt_id,)).fetchone()[0]
        self.assertEqual(status, "REVERSED")
        receipt_status = self.conn.execute("SELECT status FROM receipts WHERE id=?", (self.receipt_id,)).fetchone()[0]
        self.assertEqual(receipt_status, "CANCELLED")

    def test_cancelling_payment_reverses_allocations_and_restores_invoice(self):
        from alexerp.services.payment_service import PaymentService
        self.service.allocate_payment(self.payment_id, self.purchase_invoice_id, 60, self.user_id)
        with mock.patch("alexerp.services.payment_service.AccountingService.reverse_entry", return_value=True):
            PaymentService().cancel_payment(self.payment_id, self.user_id, cancel_date="2026-02-01")
        invoice = self.conn.execute("SELECT paid_amount,remaining_amount FROM purchase_invoices WHERE id=?", (self.purchase_invoice_id,)).fetchone()
        self.assertEqual(float(invoice["paid_amount"]), 0.0)
        self.assertEqual(float(invoice["remaining_amount"]), 100.0)
        payment_status = self.conn.execute("SELECT status FROM payments WHERE id=?", (self.payment_id,)).fetchone()[0]
        self.assertEqual(payment_status, "CANCELLED")

    def test_receipt_cannot_be_allocated_to_another_company_invoice(self):
        foreign_company = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('SET-FOREIGN','Foreign Company')"
        ).lastrowid
        foreign_customer = self.conn.execute(
            "INSERT INTO customers(company_id,code,name) VALUES(?,?,?)",
            (foreign_company, "FC-1", "Foreign Customer"),
        ).lastrowid
        foreign_invoice = self.conn.execute(
            """INSERT INTO sales_invoices(company_id,customer_id,invoice_number,invoice_date,total,
               paid_amount,remaining_amount,status) VALUES(?,?,?,'2026-01-01',100,0,100,'POSTED')""",
            (foreign_company, foreign_customer, "FOREIGN-SI"),
        ).lastrowid
        self.conn.commit()
        with self.assertRaises(TransactionError):
            self.service.allocate_receipt(self.receipt_id, foreign_invoice, 10, self.user_id)

    def test_aging_is_company_scoped_and_rejects_invalid_date(self):
        report = self.service.customer_aging(self.company_id, "2026-02-15")
        self.assertEqual(len(report["rows"]), 1)
        with self.assertRaises(ValueError):
            self.service.customer_aging(self.company_id, "2026-02-30")

    def test_customer_statement_reconciles_invoice_and_receipt(self):
        self.service.allocate_receipt(self.receipt_id, self.sales_invoice_id, "60.00", self.user_id)
        report = self.service.customer_statement(
            self.company_id, self.customer_id, "2026-01-01", "2026-01-31"
        )
        self.assertEqual(report["closing_balance"], 30.0)
        self.assertEqual(len(report["rows"]), 2)
        self.assertEqual(report["rows"][-1]["balance"], 30.0)

    def test_supplier_statement_uses_debit_minus_credit_convention(self):
        self.service.allocate_payment(self.payment_id, self.purchase_invoice_id, "60.00", self.user_id)
        report = self.service.supplier_statement(
            self.company_id, self.supplier_id, "2026-01-01", "2026-01-31"
        )
        self.assertEqual(report["closing_balance"], -30.0)
        self.assertEqual(report["rows"][-1]["balance"], -30.0)

    def test_statement_opening_balance_and_date_validation(self):
        report = self.service.customer_statement(
            self.company_id, self.customer_id, "2026-01-15", "2026-01-31"
        )
        self.assertEqual(report["opening_balance"], 100.0)
        self.assertEqual(report["closing_balance"], 30.0)
        with self.assertRaises(ValueError):
            self.service.customer_statement(self.company_id, self.customer_id, "2026-02-01", "2026-01-01")

    def test_due_date_drives_aging_not_invoice_date(self):
        self.conn.execute(
            "UPDATE sales_invoices SET due_date='2026-02-01',payment_terms_days=31 WHERE id=?",
            (self.sales_invoice_id,),
        )
        self.conn.commit()
        report = self.service.customer_aging(self.company_id, "2026-02-15")
        self.assertEqual(report["basis"], "due_date")
        self.assertEqual(report["rows"][0]["due_date"], "2026-02-01")
        self.assertEqual(report["rows"][0]["age_days"], 14)
        self.assertEqual(report["totals"]["days_1_30"], 100.0)

    def test_payment_terms_update_is_company_scoped_and_does_not_rewrite_old_invoices(self):
        self.service.set_payment_terms("customer", self.company_id, self.customer_id, 45, self.user_id)
        customer = self.conn.execute(
            "SELECT payment_terms_days FROM customers WHERE id=?", (self.customer_id,)
        ).fetchone()
        invoice = self.conn.execute(
            "SELECT payment_terms_days,due_date FROM sales_invoices WHERE id=?", (self.sales_invoice_id,)
        ).fetchone()
        self.assertEqual(customer[0], 45)
        self.assertEqual(invoice["payment_terms_days"], 0)
        self.assertIsNone(invoice["due_date"])
        foreign_company = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('TERMS-FOREIGN','Terms Foreign')"
        ).lastrowid
        foreign_customer = self.conn.execute(
            "INSERT INTO customers(company_id,code,name) VALUES(?,?,?)",
            (foreign_company, "FC-TERMS", "Foreign Terms Customer"),
        ).lastrowid
        from alexerp.database.transaction import TransactionError
        with self.assertRaises(TransactionError):
            self.service.set_payment_terms("customer", self.company_id, foreign_customer, 30, self.user_id)

    def test_invalid_payment_terms_are_rejected(self):
        with self.assertRaises(ValueError):
            self.service.set_payment_terms("supplier", self.company_id, self.supplier_id, -1, self.user_id)
        with self.assertRaises(ValueError):
            self.service.set_payment_terms("supplier", self.company_id, self.supplier_id, 3651, self.user_id)

    def test_sales_invoice_snapshots_customer_terms_into_due_date(self):
        from unittest import mock
        from alexerp.services.sales_service import SalesService
        self.conn.execute("UPDATE customers SET payment_terms_days=20 WHERE id=?", (self.customer_id,))
        self.conn.commit()
        service = SalesService()
        warehouse_id = self.conn.execute(
            "INSERT INTO warehouses(company_id,branch_id,code,name) VALUES(?,?,?,?)",
            (self.company_id, self.branch_id, "WH-DUE-S", "Due Test Warehouse S"),
        ).lastrowid
        product_id = self.conn.execute(
            "INSERT INTO products(company_id,branch_id,code,name) VALUES(?,?,?,?)",
            (self.company_id, self.branch_id, "P-DUE-S", "Due Test Product S"),
        ).lastrowid
        with mock.patch("alexerp.services.sales_service.tenancy.require_branch"), \
             mock.patch("alexerp.services.sales_service.tenancy.require_customer"), \
             mock.patch("alexerp.services.sales_service.tenancy.require_accounts"), \
             mock.patch("alexerp.services.sales_service.tenancy.require_item_scope"), \
             mock.patch.object(service.inventory, "check_stock", return_value=True), \
             mock.patch.object(service.inventory, "get_unit_cost", return_value=0), \
             mock.patch.object(service.inventory, "decrease_stock"), \
             mock.patch.object(service.inventory, "get_quantity", return_value=0), \
             mock.patch.object(service.inventory, "add_stock_movement"), \
             mock.patch.object(service.accounting, "create_entry"), \
             mock.patch.object(service.balances, "refresh_customer"):
            invoice_id = service.create_invoice(
                self.company_id, self.branch_id, self.customer_id, "SI-DUE-1", "2026-03-01",
                [{"product_id": product_id, "warehouse_id": warehouse_id, "quantity": 1,
                  "unit_price": 100, "total": 100}],
                100, 0, 0, 100, 0, 100, "", self.user_id, 1, 1, 1, 1,
            )
        invoice = self.conn.execute(
            "SELECT payment_terms_days,due_date FROM sales_invoices WHERE id=?", (invoice_id,)
        ).fetchone()
        self.assertEqual(invoice["payment_terms_days"], 20)
        self.assertEqual(str(invoice["due_date"]), "2026-03-21")

    def test_purchase_invoice_snapshots_supplier_terms_into_due_date(self):
        from unittest import mock
        from alexerp.services.purchase_service import PurchaseService
        self.conn.execute("UPDATE suppliers SET payment_terms_days=30 WHERE id=?", (self.supplier_id,))
        self.conn.commit()
        service = PurchaseService()
        warehouse_id = self.conn.execute(
            "INSERT INTO warehouses(company_id,branch_id,code,name) VALUES(?,?,?,?)",
            (self.company_id, self.branch_id, "WH-DUE-P", "Due Test Warehouse P"),
        ).lastrowid
        product_id = self.conn.execute(
            "INSERT INTO products(company_id,branch_id,code,name) VALUES(?,?,?,?)",
            (self.company_id, self.branch_id, "P-DUE-P", "Due Test Product P"),
        ).lastrowid
        with mock.patch("alexerp.services.purchase_service.tenancy.require_branch"), \
             mock.patch("alexerp.services.purchase_service.tenancy.require_supplier"), \
             mock.patch("alexerp.services.purchase_service.tenancy.require_accounts"), \
             mock.patch("alexerp.services.purchase_service.tenancy.require_item_scope"), \
             mock.patch.object(service.inventory, "increase_stock"), \
             mock.patch.object(service.inventory, "get_quantity", return_value=1), \
             mock.patch.object(service.inventory, "add_stock_movement"), \
             mock.patch.object(service.accounting, "create_entry"), \
             mock.patch.object(service.balances, "refresh_supplier"):
            invoice_id = service.create_invoice(
                self.company_id, self.branch_id, self.supplier_id, "PI-DUE-1", "SUP-DUE-1", "2026-03-01",
                [{"product_id": product_id, "warehouse_id": warehouse_id, "quantity": 1,
                  "unit_cost": 100, "total": 100}],
                100, 0, 0, 100, 0, 100, "", self.user_id, 1, 1,
            )
        invoice = self.conn.execute(
            "SELECT payment_terms_days,due_date FROM purchase_invoices WHERE id=?", (invoice_id,)
        ).fetchone()
        self.assertEqual(invoice["payment_terms_days"], 30)
        self.assertEqual(str(invoice["due_date"]), "2026-03-31")

    def test_customer_gets_a_dedicated_receivable_account(self):
        from alexerp.services.customer_service import CustomerService

        service = CustomerService()
        first_account = service.ensure_customer_account(self.company_id, self.customer_id)
        new_customer_id = service.create_customer(
            self.company_id, "C-SET-2", "Second Settlement Customer",
            actor_id=self.user_id,
        )
        second = self.conn.execute(
            "SELECT account_id FROM customers WHERE id=?", (new_customer_id,)
        ).fetchone()
        accounts = self.conn.execute(
            "SELECT id,account_code,parent_id FROM chart_of_accounts WHERE id IN (?,?)",
            (first_account, second["account_id"]),
        ).fetchall()
        self.assertEqual(len(accounts), 2)
        self.assertNotEqual(first_account, int(second["account_id"]))
        self.assertTrue(all(row["account_code"] != "1201" for row in accounts))

    def test_credit_limit_requires_authorized_explicit_override(self):
        from alexerp.database.transaction import TransactionError
        from contextlib import ExitStack
        from alexerp.services.sales_service import SalesService

        self.conn.execute(
            "UPDATE customers SET credit_limit=80 WHERE id=?", (self.customer_id,)
        )
        warehouse_id = self.conn.execute(
            "INSERT INTO warehouses(company_id,branch_id,code,name) VALUES(?,?,?,?)",
            (self.company_id, self.branch_id, "WH-CREDIT", "Credit Limit Warehouse"),
        ).lastrowid
        product_id = self.conn.execute(
            "INSERT INTO products(company_id,branch_id,code,name) VALUES(?,?,?,?)",
            (self.company_id, self.branch_id, "P-CREDIT", "Credit Limit Product"),
        ).lastrowid
        self.conn.commit()
        service = SalesService()
        before = self.conn.execute(
            "SELECT COUNT(*) FROM sales_invoices WHERE invoice_number='SI-CREDIT-1'"
        ).fetchone()[0]
        patches = (
            mock.patch("alexerp.services.sales_service.tenancy.require_branch"),
            mock.patch("alexerp.services.sales_service.tenancy.require_customer"),
            mock.patch("alexerp.services.sales_service.tenancy.require_accounts"),
            mock.patch("alexerp.services.sales_service.tenancy.require_item_scope"),
            mock.patch.object(service.inventory, "check_stock", return_value=True),
            mock.patch.object(service.inventory, "get_unit_cost", return_value=0),
            mock.patch.object(service.inventory, "decrease_stock"),
            mock.patch.object(service.inventory, "get_quantity", return_value=0),
            mock.patch.object(service.inventory, "add_stock_movement"),
            mock.patch.object(service.accounting, "create_entry"),
        )
        def create_invoice(override=False):
            return service.create_invoice(
                self.company_id, self.branch_id, self.customer_id,
                "SI-CREDIT-1", "2026-02-01",
                [{"product_id": product_id, "warehouse_id": warehouse_id,
                  "quantity": 1, "unit_price": 60, "total": 60}],
                60, 0, 0, 60, 0, 60, "", self.user_id,
                sales_account=12, inventory_account=5, cogs_account=14,
                override_credit_limit=override,
            )

        with ExitStack() as stack:
            for patcher in patches:
                stack.enter_context(patcher)
            with self.assertRaises(TransactionError):
                create_invoice()
            after_block = self.conn.execute(
                "SELECT COUNT(*) FROM sales_invoices WHERE invoice_number='SI-CREDIT-1'"
            ).fetchone()[0]
            self.assertEqual(after_block, before)
            permission_id = self.conn.execute(
                "SELECT id FROM permissions WHERE permission_key='customers.credit_limit.override'"
            ).fetchone()[0]
            role_id = self.conn.execute(
                "SELECT role_id FROM users WHERE id=?", (self.user_id,)
            ).fetchone()[0]
            self.conn.execute(
                "DELETE FROM role_permissions WHERE role_id=? AND permission_id=?",
                (role_id, permission_id),
            )
            self.conn.commit()
            with self.assertRaises(TransactionError):
                create_invoice(override=True)
            self.conn.execute(
                "INSERT INTO role_permissions(role_id,permission_id) VALUES(?,?)",
                (role_id, permission_id),
            )
            self.conn.commit()
            invoice_id = create_invoice(override=True)

        account_id = self.conn.execute(
            "SELECT account_id FROM customers WHERE id=?", (self.customer_id,)
        ).fetchone()[0]
        self.assertNotEqual(int(account_id), 4)
        self.assertEqual(
            self.conn.execute(
                "SELECT COUNT(*) FROM sales_invoices WHERE id=? AND status='POSTED'",
                (invoice_id,),
            ).fetchone()[0],
            1,
        )

    def test_customer_financial_notes_update_balance_statement_and_aging(self):
        from alexerp.services.customer_financial_note_service import CustomerFinancialNoteService
        from alexerp.services.customer_service import CustomerService

        CustomerService().ensure_customer_account(self.company_id, self.customer_id)
        notes = CustomerFinancialNoteService()
        stock_movement_count = self.conn.execute(
            "SELECT COUNT(*) FROM stock_movements"
        ).fetchone()[0]
        credit_note_id = notes.create_note(
            self.company_id, self.branch_id, self.customer_id,
            self.sales_invoice_id, "CN-SET-1", "CREDIT", "2026-02-01",
            25, 12, "تسوية مالية دون مرتجع مخزني", self.user_id,
        )
        with self.assertRaises(TransactionError):
            notes.create_note(
                self.company_id, self.branch_id, self.customer_id,
                self.sales_invoice_id, "CN-SET-OVER", "CREDIT", "2026-02-01",
                76, 12, "تجاوز الرصيد المتاح", self.user_id,
            )
        invoice = self.conn.execute(
            "SELECT remaining_amount FROM sales_invoices WHERE id=?",
            (self.sales_invoice_id,),
        ).fetchone()
        self.assertEqual(float(invoice["remaining_amount"]), 75.0)
        self.assertEqual(PartyBalanceService().customer_balance(self.customer_id), 5.0)
        statement = notes.list_notes(self.company_id, self.user_id)
        self.assertEqual(len(statement), 1)
        customer_statement = self.service.customer_statement(
            self.company_id, self.customer_id, "2026-01-01", "2026-02-15"
        )
        self.assertEqual(customer_statement["closing_balance"], 5.0)
        self.assertEqual(customer_statement["rows"][-1]["type"], "إشعار دائن للعميل")
        aging = self.service.customer_aging(self.company_id, "2026-02-15")
        self.assertEqual(aging["totals"]["days_31_60"], 75.0)
        self.assertTrue(notes.cancel_note(credit_note_id, self.user_id, "2026-02-16"))
        self.assertEqual(PartyBalanceService().customer_balance(self.customer_id), 30.0)

        debit_note_id = notes.create_note(
            self.company_id, self.branch_id, self.customer_id,
            self.sales_invoice_id, "DN-SET-1", "DEBIT", "2026-02-02",
            10, 12, "رسوم إضافية", self.user_id,
        )
        self.assertEqual(PartyBalanceService().customer_balance(self.customer_id), 40.0)
        self.assertTrue(notes.cancel_note(debit_note_id, self.user_id, "2026-02-17"))
        self.assertEqual(PartyBalanceService().customer_balance(self.customer_id), 30.0)
        self.assertEqual(
            self.conn.execute("SELECT COUNT(*) FROM stock_movements").fetchone()[0],
            stock_movement_count,
        )


if __name__ == "__main__":
    unittest.main()
