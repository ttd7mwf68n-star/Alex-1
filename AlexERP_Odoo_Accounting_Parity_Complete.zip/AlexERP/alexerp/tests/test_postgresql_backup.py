import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from alexerp.database import db as db_module
from alexerp.database.backup import BackupManager
from alexerp.database.db import Database


_RESTORE_LIST = "\n".join((
    "1; 0 0 TABLE public companies alexerp",
    "2; 0 0 TABLE DATA public companies alexerp",
    "3; 0 0 TABLE public users alexerp",
))


class PostgreSQLBackupTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        root = Path(self.temp_dir.name)
        self.manager = BackupManager(root / "backups", root / "unused.db")
        self.backend_patch = patch.object(db_module, "DATABASE_BACKEND", "postgresql")
        self.url_patch = patch(
            "alexerp.config.DATABASE_URL",
            "postgresql://backup_user:local-test-secret@localhost:5432/alexerp"
            "?sslmode=verify-full",
        )
        self.tool_patch = patch.object(
            self.manager,
            "_find_postgresql_tool",
            side_effect=lambda _env, executable: f"fake-{executable}",
        )
        self.backend_patch.start()
        self.url_patch.start()
        self.tool_patch.start()
        self.addCleanup(self.temp_dir.cleanup)
        self.addCleanup(self.backend_patch.stop)
        self.addCleanup(self.url_patch.stop)
        self.addCleanup(self.tool_patch.stop)
        self.commands = []
        self.run_patch = patch(
            "alexerp.database.backup.subprocess.run",
            side_effect=self._run_tool,
        )
        self.run_patch.start()
        self.addCleanup(self.run_patch.stop)

    def _run_tool(self, command, **kwargs):
        self.commands.append((command, kwargs))
        if command[0] == "fake-pg_dump":
            output = next(arg.split("=", 1)[1] for arg in command if arg.startswith("--file="))
            Path(output).write_bytes(b"fake custom PostgreSQL archive")
            return subprocess.CompletedProcess(command, 0, stdout="", stderr="")
        if "--list" in command:
            return subprocess.CompletedProcess(
                command, 0, stdout=_RESTORE_LIST, stderr=""
            )
        return subprocess.CompletedProcess(command, 0, stdout="", stderr="")

    def test_create_and_verify_custom_archive_without_credentials_in_argv(self):
        backup = self.manager.create_backup()
        self.assertEqual(backup.suffix, ".dump")
        info = self.manager.verify_backup(backup)
        self.assertEqual(info["table_count"], 2)
        self.assertEqual(info["integrity"], "ok")
        self.assertTrue(backup.with_suffix(".dump.json").is_file())
        manifest = json.loads(backup.with_suffix(".dump.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["backend"], "postgresql")
        self.assertEqual(manifest["format_version"], 2)

        dump_call = next(call for call in self.commands if call[0][0] == "fake-pg_dump")
        self.assertNotIn("local-test-secret", " ".join(dump_call[0]))
        self.assertEqual(dump_call[1]["env"]["PGPASSWORD"], "local-test-secret")
        self.assertEqual(dump_call[1]["env"]["PGSSLMODE"], "verify-full")

    def test_restore_creates_safety_archive_and_uses_single_transaction(self):
        backup = self.manager.create_backup()
        with patch.object(Database, "close") as close_database:
            safety = self.manager.restore_backup(backup)

        self.assertTrue(safety.is_file())
        close_database.assert_called()
        restore_calls = [
            call for call in self.commands
            if call[0][0] == "fake-pg_restore" and "--list" not in call[0]
        ]
        self.assertEqual(len(restore_calls), 1)
        self.assertIn("--single-transaction", restore_calls[0][0])
        self.assertIn("--clean", restore_calls[0][0])
        self.assertNotIn("local-test-secret", " ".join(restore_calls[0][0]))


if __name__ == "__main__":
    unittest.main()
