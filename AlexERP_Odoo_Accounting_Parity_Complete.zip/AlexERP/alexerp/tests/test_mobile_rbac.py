"""Integration tests for server-enforced role permissions."""
from __future__ import annotations

import json
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from mobile_web.mobile_server import MobileERPHandler, _issue_session


class MobileRBACTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_rbac_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "data" / "rbac.db"
        db_module.DATABASE_FILE.parent.mkdir(parents=True, exist_ok=True)
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        admin = self.conn.execute("SELECT * FROM users WHERE username='admin'").fetchone()
        self.company_id, self.branch_id = int(admin["company_id"]), int(admin["branch_id"])
        self.role_id = self.conn.execute(
            "INSERT INTO roles(code,name,is_system,is_active) VALUES('REPORT_VIEWER','Report viewer',0,1)"
        ).lastrowid
        permission_id = self.conn.execute(
            "SELECT id FROM permissions WHERE permission_key='dashboard.view'"
        ).fetchone()["id"]
        self.conn.execute(
            "INSERT INTO role_permissions(role_id,permission_id) VALUES(?,?)",
            (self.role_id, permission_id),
        )
        self.user_id = self.conn.execute(
            """INSERT INTO users(username,password_hash,full_name,role_id,company_id,branch_id)
               VALUES('viewer','not-used','Viewer',?,?,?)""",
            (self.role_id, self.company_id, self.branch_id),
        ).lastrowid
        self.conn.commit()
        self.token = _issue_session({
            "id": self.user_id, "username": "viewer", "full_name": "Viewer",
            "role_id": self.role_id, "company_id": self.company_id, "branch_id": self.branch_id,
        })
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), MobileERPHandler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)
        Database.close()
        self.tempdir.cleanup()

    def request(self, path, method="GET", payload=None):
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = Request(self.base + path, data=data, method=method, headers={
            "Authorization": f"Bearer {self.token}", "Content-Type": "application/json",
        })
        try:
            with urlopen(req, timeout=5) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            return exc.code, json.loads(exc.read().decode("utf-8"))

    def test_role_can_access_granted_endpoint(self):
        status, payload = self.request("/api/dashboard")
        self.assertEqual(status, 200, payload)

    def test_sales_order_api_requires_sales_view_and_confirmation_permissions(self):
        status, payload = self.request("/api/sales/orders")
        self.assertEqual(status, 403, payload)
        self.grant_permission("sales.view")
        status, payload = self.request("/api/sales/orders")
        self.assertEqual(status, 200, payload)
        self.assertEqual(payload["items"], [])
        status, payload = self.request("/api/sales/orders/confirm", "POST", {"order_id": 1})
        self.assertEqual(status, 403, payload)

    def test_role_cannot_create_supplier_payment_without_permission(self):
        status, payload = self.request("/api/payments/create", "POST", {"supplier_id": 1, "amount": 1})
        self.assertEqual(status, 403, payload)
        self.assertEqual(payload["error"], "Insufficient permissions.")

    def test_unknown_api_endpoint_is_denied_by_default(self):
        status, payload = self.request("/api/unmapped-operation")
        self.assertEqual(status, 403, payload)

    def test_inactive_role_is_denied_even_if_permission_mapping_exists(self):
        self.conn.execute("UPDATE roles SET is_active=0 WHERE id=?", (self.role_id,))
        self.conn.commit()
        status, payload = self.request("/api/dashboard")
        self.assertEqual(status, 403, payload)

    def grant_permission(self, key):
        permission_id = self.conn.execute(
            "SELECT id FROM permissions WHERE permission_key=?", (key,)
        ).fetchone()["id"]
        self.conn.execute(
            "INSERT OR IGNORE INTO role_permissions(role_id,permission_id) VALUES(?,?)",
            (self.role_id, permission_id),
        )
        self.conn.commit()

    def test_security_management_api_requires_explicit_permission(self):
        status, payload = self.request("/api/security/roles")
        self.assertEqual(status, 403, payload)
        self.grant_permission("security.roles.manage")
        status, payload = self.request("/api/security/roles")
        self.assertEqual(status, 200, payload)
        self.assertTrue(any(role["code"] == "ADMIN" for role in payload["items"]))

    def test_security_role_creation_is_company_scoped(self):
        self.grant_permission("security.roles.manage")
        status, payload = self.request("/api/security/roles/create", "POST", {
            "code": "MOBILE_SALES", "name": "مندوب مبيعات", "description": "",
            "permissions": ["sales.view", "sales.create"],
        })
        self.assertEqual(status, 201, payload)
        role = self.conn.execute("SELECT company_id FROM roles WHERE id=?", (payload["id"],)).fetchone()
        self.assertEqual(int(role["company_id"]), self.company_id)

    def test_audit_api_requires_permission_and_is_company_scoped(self):
        status, payload = self.request("/api/security/audit")
        self.assertEqual(status, 403, payload)
        self.grant_permission("security.audit.view")
        from alexerp.services.audit_service import AuditService
        AuditService.record(user_id=self.user_id, company_id=self.company_id, module="security",
                            action="audit_test", entity_type="user", record_id=9,
                            after={"full_name": "Visible"})
        self.conn.commit()
        status, payload = self.request("/api/security/audit?limit=10&action=audit_test")
        self.assertEqual(status, 200, payload)
        self.assertEqual(len(payload["items"]), 1)
        self.assertEqual(payload["items"][0]["action"], "audit_test")
        status, filtered = self.request("/api/security/audit?limit=10&from=2999-01-01&to=2999-12-31")
        self.assertEqual(status, 200, filtered)
        self.assertEqual(filtered["items"], [])
        other_company = self.conn.execute("INSERT INTO companies(code,name) VALUES('AUD_API_OTHER','Other')").lastrowid
        AuditService.record(user_id=None, company_id=int(other_company), module="security", action="foreign_event")
        self.conn.commit()
        status, payload = self.request("/api/security/audit?limit=10")
        self.assertEqual(status, 200, payload)
        self.assertTrue(all(item["company_id"] == self.company_id for item in payload["items"]))


    def test_backup_center_requires_view_permission_and_manage_actions_require_manage_permission(self):
        status, payload = self.request("/api/backups")
        self.assertEqual(status, 403, payload)
        self.grant_permission("backup.view")
        status, payload = self.request("/api/backups")
        self.assertEqual(status, 200, payload)
        self.assertFalse(payload["can_manage"])
        status, payload = self.request("/api/backups/create", "POST", {})
        self.assertEqual(status, 403, payload)
        self.grant_permission("backup.manage")
        status, created = self.request("/api/backups/create", "POST", {})
        self.assertEqual(status, 201, created)
        status, verified = self.request("/api/backups/verify", "POST", {"name": created["name"]})
        self.assertEqual(status, 200, verified)
        self.assertEqual(verified["verification"]["integrity"], "ok")
        status, denied_restore = self.request("/api/backups/restore", "POST", {"name": created["name"]})
        self.assertEqual(status, 400, denied_restore)

    def test_backup_endpoint_rejects_path_traversal(self):
        self.grant_permission("backup.view")
        status, payload = self.request("/api/backups/verify", "POST", {"name": "../alex_erp_fake.db"})
        self.assertEqual(status, 400, payload)

    def test_user_management_api_does_not_expose_password_hash(self):
        self.grant_permission("security.users.manage")
        status, payload = self.request("/api/security/users")
        self.assertEqual(status, 200, payload)
        self.assertTrue(payload["items"])
        self.assertTrue(all("password_hash" not in user for user in payload["items"]))


if __name__ == "__main__":
    unittest.main()
