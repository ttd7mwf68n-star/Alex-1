"""Regression tests for company-scoped inventory intelligence."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.inventory_intelligence_service import InventoryIntelligenceService


class InventoryIntelligenceTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_inventory_bi_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "inventory.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.service = InventoryIntelligenceService()
        self.company_id = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('II-COMPANY','Inventory Test Company')"
        ).lastrowid
        self.branch_id = self.conn.execute(
            "INSERT INTO branches(company_id,code,name) VALUES(?, 'II-BR','Inventory Test Branch')",
            (self.company_id,),
        ).lastrowid
        self.warehouse_id = self.conn.execute(
            "INSERT INTO warehouses(company_id,branch_id,code,name) VALUES(?,?,'II-WH','Inventory Test Warehouse')",
            (self.company_id, self.branch_id),
        ).lastrowid
        self.product_id = self._product("II-P1", "Slow Stock", 1, 2, 2)
        self.conn.commit()

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def _product(self, code, name, quantity, minimum, average_cost, company_id=None, branch_id=None):
        company_id = self.company_id if company_id is None else company_id
        branch_id = self.branch_id if company_id == self.company_id and branch_id is None else branch_id
        product_id = self.conn.execute(
            "INSERT INTO products(company_id,branch_id,code,name,quantity,minimum_stock,maximum_stock,is_active) "
            "VALUES(?,?,?,?,?,?,?,1)",
            (company_id, branch_id, code, name, quantity, minimum, minimum * 3),
        ).lastrowid
        warehouse = self.warehouse_id if company_id == self.company_id else self.conn.execute(
            "INSERT INTO warehouses(company_id,branch_id,code,name) VALUES(?,?,'II-FWH','Foreign WH')",
            (company_id, branch_id),
        ).lastrowid
        self.conn.execute(
            "INSERT INTO product_stock(company_id,branch_id,warehouse_id,product_id,quantity,average_cost) "
            "VALUES(?,?,?,?,?,?)", (company_id, branch_id, warehouse, product_id, quantity, average_cost),
        )
        return product_id

    def test_summary_values_and_low_stock_are_calculated(self):
        result = self.service.inventory_summary(self.company_id, self.branch_id)
        self.assertGreaterEqual(result["product_count"], 1)
        self.assertEqual(result["total_quantity"], 1.0)
        self.assertEqual(result["inventory_value"], 2.0)
        self.assertGreaterEqual(result["low_stock_products"], 1)
        self.assertEqual(result["unallocated_legacy_products"], 0)

    def test_reorder_suggestion_targets_maximum_or_minimum(self):
        rows = self.service.reorder_suggestions(self.company_id, self.branch_id)
        row = next(item for item in rows if item["product_id"] == self.product_id)
        self.assertEqual(row["on_hand"], 1.0)
        self.assertEqual(row["suggested_reorder"], 5.0)

    def test_warehouse_valuation_uses_company_scope(self):
        rows = self.service.warehouse_valuation(self.company_id, self.branch_id)
        row = next(item for item in rows if item["warehouse_id"] == self.warehouse_id)
        self.assertEqual(row["inventory_value"], 2.0)
        self.assertEqual(row["product_count"], 1)

    def test_non_moving_stock_uses_last_sale_date_not_any_movement(self):
        self.conn.execute(
            "INSERT INTO stock_movements(company_id,branch_id,warehouse_id,product_id,transaction_type,"
            "quantity_in,quantity_out,unit_cost,balance_after,transaction_date) "
            "VALUES(?,?,?, ?, 'PURCHASE',5,0,2,5,'2026-01-01')",
            (self.company_id, self.branch_id, self.warehouse_id, self.product_id),
        )
        self.conn.commit()
        rows = self.service.non_moving_stock(self.company_id, "2026-05-01", 90, self.branch_id)
        row = next(item for item in rows if item["product_id"] == self.product_id)
        self.assertIsNone(row["last_sale_date"])
        self.assertIsNone(row["days_without_sale"])

    def test_recent_sale_excludes_product_from_non_moving_list(self):
        self.conn.execute(
            "INSERT INTO stock_movements(company_id,branch_id,warehouse_id,product_id,transaction_type,"
            "quantity_in,quantity_out,unit_cost,balance_after,transaction_date) "
            "VALUES(?,?,?, ?, 'SALE',0,1,2,4,'2026-04-15')",
            (self.company_id, self.branch_id, self.warehouse_id, self.product_id),
        )
        self.conn.commit()
        rows = self.service.non_moving_stock(self.company_id, "2026-05-01", 90, self.branch_id)
        self.assertNotIn(self.product_id, [item["product_id"] for item in rows])

    def test_unallocated_legacy_stock_is_reported_but_not_valued(self):
        self.conn.execute(
            "INSERT INTO legacy_stock_unallocated(product_id,quantity,reason) VALUES(?,7,'ambiguous')",
            (self.product_id,),
        )
        self.conn.commit()
        result = self.service.inventory_summary(self.company_id, self.branch_id)
        self.assertEqual(result["unallocated_legacy_products"], 1)
        self.assertEqual(result["unallocated_legacy_quantity"], 7.0)
        self.assertEqual(result["inventory_value"], 2.0)

    def test_foreign_company_inventory_is_excluded(self):
        company_id = self.conn.execute(
            "INSERT INTO companies(code,name) VALUES('II-FOREIGN','Foreign Inventory')"
        ).lastrowid
        foreign_product_id = self._product("II-FP", "Foreign Product", 100, 1, 999, company_id, None)
        self.conn.commit()
        result = self.service.inventory_summary(self.company_id)
        self.assertEqual(result["inventory_value"], 2.0)
        self.assertNotIn(foreign_product_id, [r["product_id"] for r in self.service.reorder_suggestions(self.company_id)])

    def test_branch_scope_does_not_aggregate_another_branch_stock(self):
        branch2 = self.conn.execute(
            "INSERT INTO branches(company_id,code,name) VALUES(?, 'II-BR2','Second Branch')",
            (self.company_id,),
        ).lastrowid
        warehouse2 = self.conn.execute(
            "INSERT INTO warehouses(company_id,branch_id,code,name) VALUES(?,?,'II-WH2','Second Warehouse')",
            (self.company_id, branch2),
        ).lastrowid
        shared_product = self.conn.execute(
            "INSERT INTO products(company_id,branch_id,code,name,minimum_stock,maximum_stock) "
            "VALUES(?,NULL,'II-SHARED','Shared Product',10,30)", (self.company_id,),
        ).lastrowid
        self.conn.executemany(
            "INSERT INTO product_stock(company_id,branch_id,warehouse_id,product_id,quantity,average_cost) "
            "VALUES(?,?,?,?,?,?)",
            [(self.company_id, self.branch_id, self.warehouse_id, shared_product, 3, 4),
             (self.company_id, branch2, warehouse2, shared_product, 20, 4)],
        )
        self.conn.commit()
        branch1_rows = self.service.reorder_suggestions(self.company_id, self.branch_id)
        shared = next(row for row in branch1_rows if row["product_id"] == shared_product)
        self.assertEqual(shared["on_hand"], 3.0)
        summary = self.service.inventory_summary(self.company_id, self.branch_id)
        self.assertEqual(summary["total_quantity"], 4.0)

    def test_movement_summary_is_period_and_branch_scoped(self):
        self.conn.execute(
            "INSERT INTO stock_movements(company_id,branch_id,warehouse_id,product_id,transaction_type,"
            "quantity_in,quantity_out,unit_cost,balance_after,transaction_date) "
            "VALUES(?,?,?, ?, 'PURCHASE',3,0,2,8,'2026-04-10')",
            (self.company_id, self.branch_id, self.warehouse_id, self.product_id),
        )
        self.conn.commit()
        result = self.service.movement_summary(self.company_id, "2026-04-01", "2026-04-30", self.branch_id)
        purchase = next(r for r in result["movements"] if r["transaction_type"] == "PURCHASE")
        self.assertEqual(purchase["quantity_in"], 3.0)

    def test_invalid_scope_dates_and_threshold_are_rejected(self):
        with self.assertRaises(ValueError):
            self.service.inventory_summary(0)
        with self.assertRaises(ValueError):
            self.service.movement_summary(self.company_id, "2026-04-31", "2026-05-01")
        with self.assertRaises(ValueError):
            self.service.non_moving_stock(self.company_id, "2026-05-01", 0)


if __name__ == "__main__":
    unittest.main()
