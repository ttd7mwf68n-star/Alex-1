import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from alexerp.core.helpers import allocate_discount
from mobile_web.mobile_server import MobileERPHandler, _smart_local_assistant


class FakeTools:
    def get_dashboard_summary(self):
        return {
            "sales_today": 12.5,
            "sales_month": 120.0,
            "stock_value": 700.0,
            "receivables": 30.0,
            "products": 8,
            "low_stock": 1,
            "purchases_month": 40.0,
            "payables": 20.0,
        }

    def get_low_stock(self, limit):
        return [{"name": "Item A", "quantity": 1, "minimum_stock": 3}]

    def get_top_products(self, limit, days):
        return [{"name": "Item A", "revenue": 45.0}]

    def get_top_debtors(self, limit):
        return [{"name": "Customer A", "current_balance": 17.0}]


class MobileAssistantTests(unittest.TestCase):
    def test_discount_allocator_distributes_currency_cents_exactly(self):
        allocations = allocate_discount([60.00, 40.00], 10.00)
        self.assertEqual(allocations, [6.0, 4.0])
        self.assertEqual(round(sum(allocations), 2), 10.0)
        with self.assertRaises(ValueError):
            allocate_discount([10.00], 10.01)

    def test_arabic_answers_have_real_line_breaks_for_supported_topics(self):
        tools = FakeTools()
        cases = (
            ("مخزون", "Item A"),
            ("المبيعات", "45.00"),
            ("ديون العملاء", "Customer A"),
            ("مرحبا", "AlexERP"),
        )

        for question, expected in cases:
            with self.subTest(question=question):
                answer = _smart_local_assistant(question, tools)
                self.assertIn(expected, answer)
                self.assertNotIn("\\n", answer)
                self.assertTrue("\n" in answer or question == "مخزون")

    def test_mobile_api_rejects_requests_without_a_bearer_session(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), MobileERPHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            request = Request(f"http://127.0.0.1:{server.server_port}/api/customers")
            with self.assertRaises(HTTPError) as error:
                urlopen(request, timeout=3)
            self.assertEqual(error.exception.code, 401)
            payload = json.loads(error.exception.read().decode("utf-8"))
            self.assertFalse(payload["ok"])
            self.assertIn("Authentication", payload["error"])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
