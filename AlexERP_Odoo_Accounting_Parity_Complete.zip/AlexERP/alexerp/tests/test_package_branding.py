from pathlib import Path
import importlib
import os


def test_application_package_uses_alexerp_name():
    importlib.import_module("alexerp")
    config = importlib.import_module("alexerp.config")
    assert Path(config.__file__).parent.name == "alexerp"
    assert config.APP_NAME == "AlexERP"
    assert config.COMPANY_NAME == "AlexERP"


def test_environment_overrides_are_applied_to_configuration(monkeypatch):
    monkeypatch.setenv("ALEXERP_APP_NAME", "AlexERP-Prod")
    monkeypatch.setenv("ALEXERP_COMPANY_NAME", "Contoso")
    monkeypatch.setenv("ALEXERP_DATA_DIR", str(Path(__file__).resolve().parents[2] / "runtime_data"))
    monkeypatch.setenv("ALEXERP_AUTO_BACKUP_ENABLED", "false")
    monkeypatch.setenv("ALEXERP_AUTO_BACKUP_HOUR", "5")
    monkeypatch.setenv("ALEXERP_AUTO_BACKUP_MINUTE", "15")

    config = importlib.import_module("alexerp.config")
    importlib.reload(config)
    try:
        assert config.APP_NAME == "AlexERP-Prod"
        assert config.COMPANY_NAME == "Contoso"
        assert config.DATABASE_DIR.name == "runtime_data"
        assert config.AUTO_BACKUP_ENABLED is False
        assert config.AUTO_BACKUP_HOUR == 5
        assert config.AUTO_BACKUP_MINUTE == 15
    finally:
        for key in (
            "ALEXERP_APP_NAME",
            "ALEXERP_COMPANY_NAME",
            "ALEXERP_DATA_DIR",
            "ALEXERP_AUTO_BACKUP_ENABLED",
            "ALEXERP_AUTO_BACKUP_HOUR",
            "ALEXERP_AUTO_BACKUP_MINUTE",
        ):
            monkeypatch.delenv(key, raising=False)
        importlib.reload(config)


def test_legacy_package_directory_is_not_part_of_current_source_tree():
    project_root = Path(__file__).resolve().parents[2]
    assert (project_root / "alexerp").is_dir()
    assert not (project_root / ("alex" + "gameerp")).exists()
