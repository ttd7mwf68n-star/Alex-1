from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from alexerp.database import db as db_module
from alexerp.database.db import Database
from alexerp.database.schema import create_database
from alexerp.database.seed import seed_database
from alexerp.services.sales_order_service import SalesOrderService, SalesOrderError


class SalesOrderCycleTests(unittest.TestCase):
    def setUp(self):
        Database.close()
        self.tempdir = tempfile.TemporaryDirectory(prefix="alexerp_sales_order_")
        db_module.DATABASE_FILE = Path(self.tempdir.name) / "test.db"
        create_database()
        with mock.patch.dict("os.environ", {"ALEXERP_INITIAL_ADMIN_PASSWORD": "test-admin-password"}):
            seed_database()
        self.conn = Database.connect()
        self.accounts = {}
        for code in ("AR", "SALES", "INV", "COGS", "TAX"):
            cur = self.conn.execute(
                "INSERT INTO chart_of_accounts(company_id,account_code,account_name) VALUES(1,?,?)",
                (code, code),
            )
            self.accounts[code] = int(cur.lastrowid)
        customer = self.conn.execute(
            "INSERT INTO customers(company_id,code,name) VALUES(1,'SO-C1','Sales Order Customer')"
        )
        self.customer_id = int(customer.lastrowid)
        product = self.conn.execute(
            "INSERT INTO products(code,name,company_id,branch_id,purchase_price,sale_price,quantity) "
            "VALUES('SO-P1','Order Product',1,1,5,10,20)"
        )
        self.product_id = int(product.lastrowid)
        self.conn.execute(
            "INSERT INTO product_stock(company_id,branch_id,warehouse_id,product_id,quantity,average_cost) "
            "VALUES(1,1,1,?,20,5)", (self.product_id,),
        )
        self.conn.commit()
        self.invoice_accounts = {
            "sales_account": self.accounts["SALES"],
            "inventory_account": self.accounts["INV"],
            "cogs_account": self.accounts["COGS"],
            "tax_account": self.accounts["TAX"],
        }

    def tearDown(self):
        Database.close()
        self.tempdir.cleanup()

    def create_quote(self, quantity=5):
        return SalesOrderService().create_quotation(
            company_id=1, branch_id=1, customer_id=self.customer_id,
            quotation_number="Q-100", document_date="2026-01-01",
            expiry_date="2027-01-01", created_by=1,
            items=[{"product_id": self.product_id, "warehouse_id": 1,
                    "quantity": quantity, "unit_price": 10,
                    "discount": 0, "tax": 0, "total": quantity * 10}],
        )

    def test_quotation_send_and_confirmation_lifecycle(self):
        service = SalesOrderService()
        order_id = self.create_quote()
        self.assertEqual(service.get_order(order_id)["status"], "DRAFT")
        service.send_quotation(order_id, created_by=1)
        self.assertEqual(service.get_order(order_id)["status"], "SENT")
        order_number = service.confirm_order(order_id, created_by=1)
        self.assertTrue(order_number.startswith("SO-1-"))
        self.assertEqual(service.get_order(order_id)["status"], "CONFIRMED")
        with self.assertRaises(Exception):
            service.confirm_order(order_id, created_by=1)
        stock = self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0]
        self.assertEqual(float(stock), 20.0)  # Confirmation does not double-reserve or issue stock.

    def test_partial_invoicing_then_final_invoice_completes_order(self):
        service = SalesOrderService()
        order_id = self.create_quote(quantity=5)
        service.confirm_order(order_id, created_by=1)
        line_id = int(service.get_items(order_id)[0]["id"])
        invoice1 = service.create_invoice_from_order(
            order_id, "SO-INV-1", "2026-01-02", 1,
            quantities={line_id: 2}, invoice_accounts=self.invoice_accounts,
        )
        self.assertEqual(int(self.conn.execute(
            "SELECT sales_order_id FROM sales_invoices WHERE id=?", (invoice1,)
        ).fetchone()[0]), order_id)
        self.assertEqual(int(self.conn.execute(
            "SELECT sales_order_item_id FROM sales_invoice_items WHERE invoice_id=?", (invoice1,)
        ).fetchone()[0]), line_id)
        self.assertEqual(service.get_order(order_id)["status"], "PARTIALLY_INVOICED")

        invoice2 = service.create_invoice_from_order(
            order_id, "SO-INV-2", "2026-01-03", 1,
            invoice_accounts=self.invoice_accounts,
        )
        self.assertNotEqual(invoice1, invoice2)
        self.assertEqual(service.get_order(order_id)["status"], "INVOICED")
        invoiced = self.conn.execute(
            "SELECT invoiced_quantity FROM sales_order_items WHERE sales_order_id=?", (order_id,)
        ).fetchone()[0]
        self.assertEqual(float(invoiced), 5.0)
        invoice_total = self.conn.execute(
            "SELECT SUM(total) FROM sales_invoices WHERE sales_order_id=?", (order_id,)
        ).fetchone()[0]
        self.assertEqual(float(invoice_total), 50.0)

    def test_selected_line_invoice_does_not_silently_invoice_other_lines(self):
        service = SalesOrderService()
        order_id = service.create_quotation(
            company_id=1, branch_id=1, customer_id=self.customer_id,
            quotation_number="Q-SELECT", document_date="2026-01-01", created_by=1,
            items=[
                {"product_id": self.product_id, "warehouse_id": 1,
                 "quantity": 2, "unit_price": 10, "discount": 0, "tax": 0, "total": 20},
                {"product_id": self.product_id, "warehouse_id": 1,
                 "quantity": 3, "unit_price": 10, "discount": 0, "tax": 0, "total": 30},
            ],
        )
        service.confirm_order(order_id, created_by=1)
        lines = service.get_items(order_id)
        service.create_invoice_from_order(
            order_id, "SO-SELECT-1", "2026-01-02", 1,
            quantities={int(lines[0]["id"]): 1}, invoice_accounts=self.invoice_accounts,
        )
        quantities = [float(row["invoiced_quantity"]) for row in service.get_items(order_id)]
        self.assertEqual(quantities, [1.0, 0.0])
        self.assertEqual(service.get_order(order_id)["status"], "PARTIALLY_INVOICED")

    def test_partial_invoices_allocate_line_discount_and_tax_without_rounding_drift(self):
        service = SalesOrderService()
        order_id = service.create_quotation(
            company_id=1, branch_id=1, customer_id=self.customer_id,
            quotation_number="Q-ALLOC", document_date="2026-01-01",
            created_by=1,
            items=[{"product_id": self.product_id, "warehouse_id": 1,
                    "quantity": 3, "unit_price": 10, "discount": 1,
                    "tax": 1, "total": 30}],
        )
        service.confirm_order(order_id, created_by=1)
        line_id = int(service.get_items(order_id)[0]["id"])
        first = service.create_invoice_from_order(
            order_id, "SO-ALLOC-1", "2026-01-02", 1,
            quantities={line_id: 1}, invoice_accounts=self.invoice_accounts,
        )
        second = service.create_invoice_from_order(
            order_id, "SO-ALLOC-2", "2026-01-03", 1,
            invoice_accounts=self.invoice_accounts,
        )
        totals = self.conn.execute(
            "SELECT SUM(subtotal),SUM(discount),SUM(tax),SUM(total) FROM sales_invoices "
            "WHERE id IN (?,?)", (first, second),
        ).fetchone()
        self.assertEqual(tuple(round(float(x), 2) for x in totals), (30.0, 1.0, 1.0, 30.0))
        self.assertEqual(service.get_order(order_id)["status"], "INVOICED")

    def test_confirmation_rejects_aggregate_stock_shortage(self):
        service = SalesOrderService()
        order_id = self.create_quote(quantity=21)
        with self.assertRaises(Exception):
            service.confirm_order(order_id, created_by=1)
        self.assertEqual(service.get_order(order_id)["status"], "DRAFT")

    def test_cannot_invoice_more_than_remaining_order_quantity(self):
        service = SalesOrderService()
        order_id = self.create_quote(quantity=5)
        service.confirm_order(order_id, created_by=1)
        line_id = int(service.get_items(order_id)[0]["id"])
        with self.assertRaises(Exception):
            service.create_invoice_from_order(
                order_id, "SO-OVER", "2026-01-02", 1,
                quantities={line_id: 6}, invoice_accounts=self.invoice_accounts,
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM sales_invoices WHERE invoice_number='SO-OVER'"
        ).fetchone()[0], 0)
        self.assertEqual(service.get_order(order_id)["status"], "CONFIRMED")

    def test_accounting_failure_rolls_back_invoice_and_order_quantities(self):
        service = SalesOrderService()
        order_id = self.create_quote(quantity=3)
        service.confirm_order(order_id, created_by=1)
        self.conn.execute("""
            CREATE TRIGGER fail_sales_order_invoice BEFORE INSERT ON journal_entries
            WHEN NEW.reference_type='SALE'
            BEGIN SELECT RAISE(ABORT, 'simulated accounting failure'); END
        """)
        self.conn.commit()
        line_id = int(service.get_items(order_id)[0]["id"])
        with self.assertRaises(Exception):
            service.create_invoice_from_order(
                order_id, "SO-ROLLBACK", "2026-01-02", 1,
                quantities={line_id: 1}, invoice_accounts=self.invoice_accounts,
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM sales_invoices WHERE invoice_number='SO-ROLLBACK'"
        ).fetchone()[0], 0)
        self.assertEqual(float(self.conn.execute(
            "SELECT invoiced_quantity FROM sales_order_items WHERE id=?", (line_id,)
        ).fetchone()[0]), 0.0)
        self.assertEqual(service.get_order(order_id)["status"], "CONFIRMED")

    def test_cancelling_order_invoice_reopens_quantities_for_reinvoicing(self):
        service = SalesOrderService()
        order_id = self.create_quote(quantity=4)
        service.confirm_order(order_id, created_by=1)
        line_id = int(service.get_items(order_id)[0]["id"])
        invoice_id = service.create_invoice_from_order(
            order_id, "SO-CANCEL-1", "2026-01-02", 1,
            quantities={line_id: 2}, invoice_accounts=self.invoice_accounts,
        )
        self.assertEqual(service.get_order(order_id)["status"], "PARTIALLY_INVOICED")
        from alexerp.services.sales_service import SalesService
        SalesService().cancel_invoice(invoice_id, created_by=1, cancel_date="2026-01-03")
        self.assertEqual(service.get_order(order_id)["status"], "CONFIRMED")
        self.assertEqual(float(service.get_items(order_id)[0]["invoiced_quantity"]), 0.0)
        replacement = service.create_invoice_from_order(
            order_id, "SO-CANCEL-2", "2026-01-04", 1,
            invoice_accounts=self.invoice_accounts,
        )
        self.assertTrue(replacement > invoice_id)
        self.assertEqual(service.get_order(order_id)["status"], "INVOICED")

    def test_multiple_fractional_lines_reconcile_using_currency_line_rounding(self):
        service = SalesOrderService()
        order_id = service.create_quotation(
            company_id=1, branch_id=1, customer_id=self.customer_id,
            quotation_number="Q-FRACTION", document_date="2026-01-01", created_by=1,
            items=[
                {"product_id": self.product_id, "warehouse_id": 1,
                 "quantity": 0.333, "unit_price": 0.05, "discount": 0, "tax": 0, "total": 0.02},
                {"product_id": self.product_id, "warehouse_id": 1,
                 "quantity": 0.333, "unit_price": 0.05, "discount": 0, "tax": 0, "total": 0.02},
            ],
        )
        self.assertEqual(float(service.get_order(order_id)["total"]), 0.04)
        service.confirm_order(order_id, created_by=1)
        invoice_id = service.create_invoice_from_order(
            order_id, "SO-FRACTION", "2026-01-02", 1,
            invoice_accounts=self.invoice_accounts,
        )
        self.assertEqual(float(self.conn.execute(
            "SELECT total FROM sales_invoices WHERE id=?", (invoice_id,)
        ).fetchone()[0]), 0.04)

    def test_expired_quotation_cannot_be_sent_or_confirmed_and_is_marked_expired(self):
        service = SalesOrderService()
        order_id = service.create_quotation(
            company_id=1, branch_id=1, customer_id=self.customer_id,
            quotation_number="Q-EXPIRED", document_date="2025-01-01",
            expiry_date="2025-01-02", created_by=1,
            items=[{"product_id": self.product_id, "warehouse_id": 1,
                    "quantity": 1, "unit_price": 10, "discount": 0,
                    "tax": 0, "total": 10}],
        )
        self.assertIs(service.send_quotation(order_id, created_by=1), False)
        self.assertEqual(service.get_order(order_id)["status"], "EXPIRED")
        with self.assertRaises(Exception):
            service.confirm_order(order_id, created_by=1)

    def test_invalid_line_amount_rejected_before_document_creation(self):
        with self.assertRaises(SalesOrderError):
            SalesOrderService().create_quotation(
                company_id=1, branch_id=1, customer_id=self.customer_id,
                quotation_number="Q-BAD", document_date="2026-01-01", created_by=1,
                items=[{"product_id": self.product_id, "warehouse_id": 1,
                        "quantity": 2, "unit_price": 10, "discount": -1,
                        "tax": 0, "total": 21}],
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM sales_orders WHERE quotation_number='Q-BAD'"
        ).fetchone()[0], 0)

    def test_partial_delivery_tracks_order_and_invoice_without_double_deducting_stock(self):
        from alexerp.services.sales_delivery_service import SalesDeliveryService
        from alexerp.services.sales_service import SalesService
        service = SalesOrderService()
        order_id = self.create_quote(quantity=5)
        service.confirm_order(order_id, created_by=1)
        line_id = int(service.get_items(order_id)[0]["id"])
        invoice_id = service.create_invoice_from_order(
            order_id, "SO-DELIVERY-1", "2026-01-02", 1,
            quantities={line_id: 5}, invoice_accounts=self.invoice_accounts,
        )
        before = float(self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0])
        invoice_item_id = int(self.conn.execute(
            "SELECT id FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
        ).fetchone()[0])
        delivery = SalesDeliveryService().create_and_post(
            order_id=order_id, invoice_id=invoice_id, delivery_number="DN-001",
            delivery_date="2026-01-03", quantities={invoice_item_id: 2}, created_by=1,
        )
        self.assertGreater(delivery, 0)
        self.assertEqual(float(service.get_items(order_id)[0]["delivered_quantity"]), 2.0)
        self.assertEqual(float(self.conn.execute(
            "SELECT delivered_quantity FROM sales_invoice_items WHERE id=?", (invoice_item_id,)
        ).fetchone()[0]), 2.0)
        after = float(self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0])
        self.assertEqual(before, after)  # DEDUCT_ON_POST already issued stock at invoice posting.
        self.assertEqual(SalesDeliveryService().get_delivery(delivery)["status"], "POSTED")
        with self.assertRaises(Exception):
            SalesService().cancel_invoice(invoice_id, created_by=1, cancel_date="2026-01-04")

    def test_reserved_stock_is_fulfilled_incrementally_by_partial_delivery(self):
        from alexerp.services.sales_delivery_service import SalesDeliveryService
        self.conn.execute(
            "INSERT INTO company_sales_settings(company_id,inventory_policy) VALUES(1,'RESERVE_UNTIL_DELIVERY') "
            "ON CONFLICT(company_id) DO UPDATE SET inventory_policy='RESERVE_UNTIL_DELIVERY'"
        )
        self.conn.commit()
        service = SalesOrderService()
        order_id = self.create_quote(quantity=5)
        service.confirm_order(order_id, created_by=1)
        line_id = int(service.get_items(order_id)[0]["id"])
        invoice_id = service.create_invoice_from_order(
            order_id, "SO-DELIVERY-RES", "2026-01-02", 1,
            quantities={line_id: 5}, invoice_accounts=self.invoice_accounts,
        )
        invoice_item_id = int(self.conn.execute(
            "SELECT id FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
        ).fetchone()[0])
        self.assertEqual(float(self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0]), 20.0)
        delivery_service = SalesDeliveryService()
        delivery_service.create_and_post(
            order_id=order_id, invoice_id=invoice_id, delivery_number="DN-RES-001",
            delivery_date="2026-01-03", quantities={invoice_item_id: 2}, created_by=1,
        )
        self.assertEqual(float(self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0]), 18.0)
        reserved = float(self.conn.execute(
            "SELECT SUM(quantity) FROM stock_reservations WHERE reference_type='SALE' AND reference_id=? AND status='ACTIVE'",
            (invoice_id,),
        ).fetchone()[0])
        self.assertEqual(reserved, 3.0)
        delivery_service.create_and_post(
            order_id=order_id, invoice_id=invoice_id, delivery_number="DN-RES-002",
            delivery_date="2026-01-04", quantities={invoice_item_id: 3}, created_by=1,
        )
        self.assertEqual(float(self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0]), 15.0)
        active = self.conn.execute(
            "SELECT COUNT(*) FROM stock_reservations WHERE reference_type='SALE' AND reference_id=? AND status='ACTIVE'",
            (invoice_id,),
        ).fetchone()[0]
        self.assertEqual(active, 0)
        self.assertEqual(self.conn.execute(
            "SELECT delivery_status FROM sales_invoices WHERE id=?", (invoice_id,)
        ).fetchone()[0], "DELIVERED")

    def test_delivery_rejects_overdelivery_and_wrong_invoice_line_atomically(self):
        from alexerp.services.sales_delivery_service import SalesDeliveryService
        service = SalesOrderService()
        order_id = self.create_quote(quantity=3)
        service.confirm_order(order_id, created_by=1)
        line_id = int(service.get_items(order_id)[0]["id"])
        invoice_id = service.create_invoice_from_order(
            order_id, "SO-DELIVERY-OVER", "2026-01-02", 1,
            quantities={line_id: 2}, invoice_accounts=self.invoice_accounts,
        )
        invoice_item_id = int(self.conn.execute(
            "SELECT id FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
        ).fetchone()[0])
        delivery_service = SalesDeliveryService()
        with self.assertRaises(Exception):
            delivery_service.create_and_post(
                order_id=order_id, invoice_id=invoice_id, delivery_number="DN-OVER",
                delivery_date="2026-01-03", quantities={invoice_item_id: 3}, created_by=1,
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM sales_deliveries WHERE delivery_number='DN-OVER'"
        ).fetchone()[0], 0)
        self.assertEqual(float(service.get_items(order_id)[0]["delivered_quantity"]), 0.0)
    def test_reserved_delivery_accounting_failure_rolls_back_stock_reservation_and_document(self):
        from alexerp.services.sales_delivery_service import SalesDeliveryService
        self.conn.execute(
            "INSERT INTO company_sales_settings(company_id,inventory_policy) VALUES(1,'RESERVE_UNTIL_DELIVERY') "
            "ON CONFLICT(company_id) DO UPDATE SET inventory_policy='RESERVE_UNTIL_DELIVERY'"
        )
        self.conn.commit()
        service = SalesOrderService()
        order_id = self.create_quote(quantity=4)
        service.confirm_order(order_id, created_by=1)
        line_id = int(service.get_items(order_id)[0]["id"])
        invoice_id = service.create_invoice_from_order(
            order_id, "SO-DELIVERY-ROLLBACK", "2026-01-02", 1,
            quantities={line_id: 4}, invoice_accounts=self.invoice_accounts,
        )
        invoice_item_id = int(self.conn.execute(
            "SELECT id FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
        ).fetchone()[0])
        self.conn.execute("""
            CREATE TRIGGER fail_delivery_journal BEFORE INSERT ON journal_entries
            WHEN NEW.reference_type='SALE_DELIVERY'
            BEGIN SELECT RAISE(ABORT, 'simulated delivery accounting failure'); END
        """)
        self.conn.commit()
        with self.assertRaises(Exception):
            SalesDeliveryService().create_and_post(
                order_id=order_id, invoice_id=invoice_id, delivery_number="DN-ROLLBACK",
                delivery_date="2026-01-03", quantities={invoice_item_id: 2}, created_by=1,
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM sales_deliveries WHERE delivery_number='DN-ROLLBACK'"
        ).fetchone()[0], 0)
        self.assertEqual(float(self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0]), 20.0)
        self.assertEqual(float(self.conn.execute(
            "SELECT SUM(quantity) FROM stock_reservations WHERE reference_type='SALE' AND reference_id=? AND status='ACTIVE'",
            (invoice_id,),
        ).fetchone()[0]), 4.0)
        self.assertEqual(float(service.get_items(order_id)[0]["delivered_quantity"]), 0.0)

    def test_partial_return_is_linked_to_delivery_and_updates_net_delivered_quantity(self):
        from alexerp.services.sales_delivery_service import SalesDeliveryService
        from alexerp.services.sales_return_service import SalesReturnService
        order_service = SalesOrderService()
        order_id = self.create_quote(quantity=5)
        order_service.confirm_order(order_id, created_by=1)
        order_line_id = int(order_service.get_items(order_id)[0]["id"])
        invoice_id = order_service.create_invoice_from_order(
            order_id, "SO-RETURN-DELIVERY", "2026-01-02", 1,
            invoice_accounts=self.invoice_accounts,
        )
        invoice_item_id = int(self.conn.execute(
            "SELECT id FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
        ).fetchone()[0])
        delivery_service = SalesDeliveryService()
        delivery_id = delivery_service.create_and_post(
            order_id=order_id, invoice_id=invoice_id, delivery_number="DN-RETURN-001",
            delivery_date="2026-01-03", quantities={invoice_item_id: 3}, created_by=1,
        )
        delivery_item_id = int(self.conn.execute(
            "SELECT id FROM sales_delivery_items WHERE delivery_id=?", (delivery_id,)
        ).fetchone()[0])
        return_service = SalesReturnService()
        return_id = return_service.create_return_from_delivery(
            company_id=1, branch_id=1, sales_delivery_id=delivery_id,
            return_number="R-DN-RETURN-001", return_date="2026-01-04",
            items=[{"delivery_item_id": delivery_item_id, "quantity": 2}],
            notes="Partial return", created_by=1,
            sales_account=self.accounts["SALES"], receivable_account=self.accounts["AR"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"],
        )
        header = self.conn.execute(
            "SELECT sales_invoice_id,sales_order_id,sales_delivery_id FROM sales_returns WHERE id=?",
            (return_id,),
        ).fetchone()
        self.assertEqual(tuple(header), (invoice_id, order_id, delivery_id))
        return_line = self.conn.execute(
            "SELECT sales_delivery_item_id,sales_invoice_item_id,sales_order_item_id,quantity "
            "FROM sales_return_items WHERE return_id=?", (return_id,),
        ).fetchone()
        self.assertEqual(tuple(return_line), (delivery_item_id, invoice_item_id, order_line_id, 2.0))
        delivery_line = self.conn.execute(
            "SELECT quantity,returned_quantity FROM sales_delivery_items WHERE id=?",
            (delivery_item_id,),
        ).fetchone()
        self.assertEqual(tuple(float(value) for value in delivery_line), (3.0, 2.0))
        self.assertEqual(float(return_service.get_delivery_return_items(
            delivery_id, 1, 1, 1
        )[0]["available_quantity"]), 1.0)
        self.assertEqual(float(self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0]), 17.0)
        self.assertEqual(float(order_service.get_items(order_id)[0]["delivered_quantity"]), 3.0)

        return_service.create_return_from_delivery(
            company_id=1, branch_id=1, sales_delivery_id=delivery_id,
            return_number="R-DN-RETURN-002", return_date="2026-01-05",
            items=[{"delivery_item_id": delivery_item_id, "quantity": 1}],
            notes="Complete delivery return", created_by=1,
            sales_account=self.accounts["SALES"], receivable_account=self.accounts["AR"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"],
        )
        self.assertEqual(return_service.list_returnable_deliveries(order_id, 1, 1, 1), [])
        self.assertEqual(float(self.conn.execute(
            "SELECT quantity-returned_quantity FROM sales_delivery_items WHERE id=?",
            (delivery_item_id,),
        ).fetchone()[0]), 0.0)

    def test_delivery_return_cannot_exceed_shipped_quantity_and_rolls_back_on_journal_failure(self):
        from alexerp.database.transaction import TransactionError
        from alexerp.services.sales_delivery_service import SalesDeliveryService
        from alexerp.services.sales_return_service import SalesReturnService
        self.conn.execute(
            "INSERT INTO company_sales_settings(company_id,inventory_policy) VALUES(1,'RESERVE_UNTIL_DELIVERY') "
            "ON CONFLICT(company_id) DO UPDATE SET inventory_policy='RESERVE_UNTIL_DELIVERY'"
        )
        self.conn.commit()
        order_service = SalesOrderService()
        order_id = self.create_quote(quantity=5)
        order_service.confirm_order(order_id, created_by=1)
        order_line_id = int(order_service.get_items(order_id)[0]["id"])
        invoice_id = order_service.create_invoice_from_order(
            order_id, "SO-RETURN-RES", "2026-01-02", 1,
            invoice_accounts=self.invoice_accounts,
        )
        invoice_item_id = int(self.conn.execute(
            "SELECT id FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
        ).fetchone()[0])
        delivery_id = SalesDeliveryService().create_and_post(
            order_id=order_id, invoice_id=invoice_id, delivery_number="DN-RETURN-RES",
            delivery_date="2026-01-03", quantities={invoice_item_id: 2}, created_by=1,
        )
        delivery_item_id = int(self.conn.execute(
            "SELECT id FROM sales_delivery_items WHERE delivery_id=?", (delivery_id,)
        ).fetchone()[0])
        return_service = SalesReturnService()
        kwargs = dict(
            company_id=1, branch_id=1, sales_delivery_id=delivery_id,
            return_date="2026-01-04", notes="", created_by=1,
            sales_account=self.accounts["SALES"], receivable_account=self.accounts["AR"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"],
        )
        with self.assertRaises(TransactionError):
            return_service.create_return_from_delivery(
                **kwargs, return_number="R-TOO-MUCH",
                items=[{"delivery_item_id": delivery_item_id, "quantity": 3}],
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM sales_returns WHERE return_number='R-TOO-MUCH'"
        ).fetchone()[0], 0)
        self.conn.execute("""
            CREATE TRIGGER fail_sales_return_journal BEFORE INSERT ON journal_entries
            WHEN NEW.reference_type='SALE_RETURN'
            BEGIN SELECT RAISE(ABORT, 'simulated sales return accounting failure'); END
        """)
        self.conn.commit()
        with self.assertRaises(Exception):
            return_service.create_return_from_delivery(
                **kwargs, return_number="R-ROLLBACK",
                items=[{"delivery_item_id": delivery_item_id, "quantity": 1}],
            )
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM sales_returns WHERE return_number='R-ROLLBACK'"
        ).fetchone()[0], 0)
        self.assertEqual(float(self.conn.execute(
            "SELECT returned_quantity FROM sales_delivery_items WHERE id=?", (delivery_item_id,)
        ).fetchone()[0]), 0.0)
        self.assertEqual(float(self.conn.execute(
            "SELECT quantity FROM product_stock WHERE product_id=? AND warehouse_id=1",
            (self.product_id,),
        ).fetchone()[0]), 18.0)
        self.assertEqual(float(self.conn.execute(
            "SELECT SUM(quantity) FROM stock_reservations WHERE reference_type='SALE' "
            "AND reference_id=? AND status='ACTIVE'", (invoice_id,),
        ).fetchone()[0]), 3.0)

    def test_legacy_invoice_return_reduces_available_quantity_for_new_delivery_return(self):
        from alexerp.database.transaction import TransactionError
        from alexerp.services.sales_delivery_service import SalesDeliveryService
        from alexerp.services.sales_return_service import SalesReturnService
        order_service = SalesOrderService()
        order_id = self.create_quote(quantity=5)
        order_service.confirm_order(order_id, created_by=1)
        order_line_id = int(order_service.get_items(order_id)[0]["id"])
        invoice_id = order_service.create_invoice_from_order(
            order_id, "SO-LEGACY-RETURN", "2026-01-02", 1,
            invoice_accounts=self.invoice_accounts,
        )
        return_service = SalesReturnService()
        return_service.create_return(
            company_id=1, branch_id=1, sales_invoice_id=invoice_id,
            customer_id=self.customer_id, return_number="R-LEGACY-INV",
            return_date="2026-01-03",
            items=[{"product_id": self.product_id, "warehouse_id": 1,
                    "quantity": 2, "total": 20}],
            total=20, notes="Historical invoice-only return", created_by=1,
            sales_account=self.accounts["SALES"], receivable_account=self.accounts["AR"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"],
        )
        invoice_item_id = int(self.conn.execute(
            "SELECT id FROM sales_invoice_items WHERE invoice_id=?", (invoice_id,)
        ).fetchone()[0])
        delivery_id = SalesDeliveryService().create_and_post(
            order_id=order_id, invoice_id=invoice_id, delivery_number="DN-LEGACY-RETURN",
            delivery_date="2026-01-04", quantities={invoice_item_id: 3}, created_by=1,
        )
        delivery_item_id = int(self.conn.execute(
            "SELECT id FROM sales_delivery_items WHERE delivery_id=?", (delivery_id,)
        ).fetchone()[0])
        lines = return_service.get_delivery_return_items(delivery_id, 1, 1, 1)
        self.assertEqual(float(lines[0]["available_quantity"]), 1.0)
        documents = return_service.list_returnable_deliveries(order_id, 1, 1, 1)
        self.assertEqual(float(documents[0]["remaining_quantity"]), 1.0)
        kwargs = dict(
            company_id=1, branch_id=1, sales_delivery_id=delivery_id,
            return_date="2026-01-05", notes="", created_by=1,
            sales_account=self.accounts["SALES"], receivable_account=self.accounts["AR"],
            inventory_account=self.accounts["INV"], cogs_account=self.accounts["COGS"],
            tax_account=self.accounts["TAX"],
        )
        with self.assertRaises(TransactionError):
            return_service.create_return_from_delivery(
                **kwargs, return_number="R-LEGACY-OVER",
                items=[{"delivery_item_id": delivery_item_id, "quantity": 2}],
            )
        return_service.create_return_from_delivery(
            **kwargs, return_number="R-LEGACY-VALID",
            items=[{"delivery_item_id": delivery_item_id, "quantity": 1}],
        )
        self.assertEqual(return_service.list_returnable_deliveries(order_id, 1, 1, 1), [])
        self.assertEqual(float(order_service.get_items(order_id)[0]["delivered_quantity"]), 3.0)

if __name__ == "__main__":
    unittest.main()
