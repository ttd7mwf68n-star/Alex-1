# AlexERP 3.1 - Stage 1 Inventory Foundation

## What changed

- Added `product_stock` as the warehouse-level stock balance table.
- Added `stock_adjustments` and `stock_adjustment_items`.
- Added an idempotent migration (`multi_warehouse_stock_v1`).
- Preserved `products.quantity` as a compatibility aggregate for older screens.
- Added `legacy_stock_unallocated` for balances that cannot be safely assigned.
- Automatically migrates an old product balance only when exactly one active warehouse matches its company/branch.
- Writes an opening stock movement for automatically migrated balances when a branch is available.
- Added `allocate_legacy_stock(conn, product_id, warehouse_id)` for explicit allocation of ambiguous balances.
- Refactored inventory and product stock operations to update warehouse balances and keep the aggregate quantity synchronized.
- Refactored sales, purchases, transfers, adjustments, and sales-return inventory calls to pass the relevant warehouse.
- Fixed stock movement repository transaction behavior and the low-stock report method placement.

## Important upgrade instructions

1. Back up the existing database before replacing the application files.
2. Keep the existing `data` directory and database file. The archive does not contain a replacement database.
3. Start the application once. `create_database()` creates the new tables and runs the migration.
4. Review unresolved balances:

   ```sql
   SELECT p.code, p.name, u.quantity, u.reason
   FROM legacy_stock_unallocated u
   JOIN products p ON p.id = u.product_id
   WHERE u.resolved_at IS NULL;
   ```

5. Assign each unresolved balance to the correct warehouse. Do not split or distribute it automatically unless the real warehouse quantities are known.

## Verification performed

- Python compilation across all project `.py` files.
- Fresh SQLite schema creation and default seed.
- Required inventory tables created.
- Single-warehouse legacy balance migration.
- Ambiguous multi-warehouse balance preserved for manual allocation.
- Manual allocation and opening movement creation.
- Multi-warehouse increase/decrease operations.
- Product aggregate quantity synchronization.
- Stock movement recording.
- Negative-stock prevention and transaction rollback.
- `StockService` and low-stock report smoke tests.

## Scope and limitations

This is the inventory/database foundation stage, not a production-readiness certification. The GUI was not launched in this environment. Full end-to-end testing of invoice posting, accounting integration, returns, and transfer workflows remains a separate validation step. The archive intentionally does not include user database files.
