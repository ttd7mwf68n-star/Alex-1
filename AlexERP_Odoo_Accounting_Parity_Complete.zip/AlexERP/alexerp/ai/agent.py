"""
AlexERP — Business Management System
AI agent: a tool-use loop on top of the Anthropic Messages API.
"""

from __future__ import annotations

import json
from typing import Callable

from alexerp.ai import settings
from alexerp.ai.tools import (
    REQUIRES_CONFIRMATION, TOOL_SCHEMAS, ToolBox, describe_action, run_tool,
)

SYSTEM_PROMPT = """أنت "مساعد Alex"، مساعد ذكي داخل نظام AlexERP لإدارة المبيعات والمشتريات والمخزون والحسابات.

قواعد العمل:
- أجب بنفس لغة المستخدم (غالباً العربية) وباختصار ووضوح.
- لا تخترع أي رقم أو اسم. اعتمد دائماً على نتائج الأدوات. وإن لم تجد بيانات فقل ذلك صراحة.
- لا تستخدم تنسيق Markdown (لا نجوم ولا عناوين #). استخدم نصاً بسيطاً وشرطات للقوائم.
- للأسئلة عن الأرقام استخدم الأدوات أولاً ثم لخّص النتيجة وقدّم توصية عملية عند الفائدة.
- الأدوات التي تعدّل البيانات (adjust_stock, create_product) تحتاج موافقة المستخدم في كل مرة. اشرح ما ستفعله قبل استدعائها، ولا تنفذ تعديلاً لم يطلبه المستخدم.
- إن رُفض إجراء فلا تكرره ولا تلتف عليه.
- أنت تعمل على بيانات المستخدم فقط ولا تخرج عن نطاق إدارة النظام."""

MAX_STEPS = 8
MAX_HISTORY = 40


class AgentError(Exception):
    pass


class AIAgent:
    def __init__(
        self,
        user=None,
        confirm: Callable[[str], bool] | None = None,
        client=None,
        model: str | None = None,
    ):
        self.toolbox = ToolBox(user)
        self.confirm = confirm or (lambda _desc: False)  # deny by default
        self.model = model or settings.get_model()
        self._client = client
        self.messages: list[dict] = []

    # -------------------------------------------------

    @property
    def client(self):
        if self._client is None:
            key = settings.get_api_key()
            if not key:
                raise AgentError("لم يتم ضبط مفتاح الـ API. افتح الإعدادات وأدخله.")
            try:
                import anthropic
            except ImportError as exc:
                raise AgentError("ثبّت المكتبة أولاً:  pip install anthropic") from exc
            self._client = anthropic.Anthropic(api_key=key)
        return self._client

    def reset(self) -> None:
        self.messages.clear()

    def _trim(self) -> None:
        # Drop oldest turns, always starting at a plain user message so that
        # tool_use / tool_result pairs are never split.
        while len(self.messages) > MAX_HISTORY:
            self.messages.pop(0)
            while self.messages and not (
                self.messages[0]["role"] == "user"
                and isinstance(self.messages[0]["content"], str)
            ):
                self.messages.pop(0)

    # -------------------------------------------------

    def ask(self, text: str, on_status: Callable[[str], None] | None = None) -> str:
        status = on_status or (lambda _s: None)
        self.messages.append({"role": "user", "content": text})
        self._trim()

        for _ in range(MAX_STEPS):
            status("يفكر...")
            response = self.client.messages.create(
                model=self.model,
                max_tokens=1500,
                system=SYSTEM_PROMPT,
                tools=TOOL_SCHEMAS,
                messages=self.messages,
            )
            self.messages.append({"role": "assistant", "content": response.content})

            if response.stop_reason != "tool_use":
                return "".join(
                    b.text for b in response.content if b.type == "text").strip()

            results = []
            for block in response.content:
                if block.type != "tool_use":
                    continue
                status(f"ينفّذ: {block.name}")
                results.append(self._run(block))
            self.messages.append({"role": "user", "content": results})

        return "توقفت بعد عدد كبير من الخطوات. أعد صياغة الطلب بشكل أبسط."

    def _run(self, block) -> dict:
        result = {"type": "tool_result", "tool_use_id": block.id}
        args = dict(block.input or {})
        try:
            if block.name in REQUIRES_CONFIRMATION:
                if not self.confirm(describe_action(block.name, args)):
                    result.update(content="رفض المستخدم هذا الإجراء. لم يتم أي تعديل.",
                                  is_error=True)
                    return result
            data = run_tool(self.toolbox, block.name, args)
            result["content"] = json.dumps(data, ensure_ascii=False, default=str)[:8000]
        except Exception as exc:  # report to the model so it can recover
            result.update(content=f"{type(exc).__name__}: {exc}", is_error=True)
        return result
