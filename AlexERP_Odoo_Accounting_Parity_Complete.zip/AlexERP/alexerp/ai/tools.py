"""
AlexERP — Business Management System
Tools the AI agent can call. Read tools run freely; write tools
(`requires_confirmation`) are gated by a confirmation callback in the agent.
"""

from __future__ import annotations

from typing import Any, Callable

from alexerp.core import context
from alexerp.services.dashboard_service import DashboardService
from alexerp.services.product_service import ProductService


def _product_view(r) -> dict:
    return {
        "id": r["id"], "code": r["code"], "barcode": r["barcode"], "name": r["name"],
        "purchase_price": r["purchase_price"], "sale_price": r["sale_price"],
        "quantity": r["quantity"], "minimum_stock": r["minimum_stock"],
    }


class ToolBox:
    def __init__(self, user=None):
        self.user = user
        self.products = ProductService()
        self.dash = DashboardService()
        if user is None:
            self.user_id = 0
            self.company_id = context.current_company_id()
            self.branch_id = context.current_branch_id()
        else:
            user_keys = user.keys() if hasattr(user, "keys") else ()
            self.user_id = int(user["id"]) if "id" in user_keys else 0
            self.company_id = int(user["company_id"]) if "company_id" in user_keys else context.current_company_id()
            self.branch_id = int(user["branch_id"]) if "branch_id" in user_keys else context.current_branch_id()

    # ---------------- read tools ----------------

    def get_dashboard_summary(self) -> dict:
        return self.dash.summary(self.company_id, self.branch_id)

    def search_products(self, keyword: str, limit: int = 15) -> list[dict]:
        rows = self.products.search(keyword)
        rows = [r for r in rows if int(r["company_id"]) == self.company_id
                and (r["branch_id"] is None or int(r["branch_id"]) == self.branch_id)]
        return [_product_view(r) for r in rows[: int(limit)]]

    def get_low_stock(self, limit: int = 20) -> list[dict]:
        return self.dash.low_stock_items(int(limit), self.company_id, self.branch_id)

    def get_sales_trend(self, days: int = 14) -> list[dict]:
        days = max(1, min(int(days), 90))
        return [{"date": d["date"], "total": d["total"]}
                for d in self.dash.sales_trend(days, self.company_id, self.branch_id)]

    def get_top_products(self, limit: int = 5, days: int = 30) -> list[dict]:
        return self.dash.top_products(int(limit), int(days), self.company_id, self.branch_id)

    def get_top_debtors(self, limit: int = 5) -> list[dict]:
        return self.dash.top_debtors(int(limit), self.company_id, self.branch_id)

    # ---------------- write tools ----------------

    def adjust_stock(self, product_id: int, quantity_change: float, reason: str = "") -> dict:
        product = self.products.get(int(product_id))
        if (product is None or int(product["company_id"]) != self.company_id
                or (product["branch_id"] is not None and int(product["branch_id"]) != self.branch_id)):
            raise ValueError("Product does not belong to the signed-in company/branch.")
        qty = self.products.adjust_stock(
            int(product_id), float(quantity_change),
            reason=f"[AI] {reason}".strip(), user_id=self.user_id)
        return {"product_id": product_id, "new_quantity": qty}

    def create_product(self, name: str, code: str | None = None,
                       barcode: str | None = None, purchase_price: float = 0,
                       sale_price: float = 0, minimum_stock: float = 0) -> dict:
        pid = self.products.create(
            name=name, code=code, barcode=barcode,
            purchase_price=float(purchase_price), sale_price=float(sale_price),
            minimum_stock=float(minimum_stock), company_id=self.company_id,
            branch_id=self.branch_id, actor_id=self.user_id)
        return {"product_id": pid}


def _schema(name: str, description: str, props: dict | None = None,
            required: list[str] | None = None) -> dict:
    return {
        "name": name,
        "description": description,
        "input_schema": {"type": "object", "properties": props or {},
                         "required": required or []},
    }


TOOL_SCHEMAS: list[dict] = [
    _schema("get_dashboard_summary",
            "Key business numbers: product/customer/supplier counts, stock value, "
            "sales today and this month, purchases this month, receivables, payables."),
    _schema("search_products", "Search products by code, barcode or name.",
            {"keyword": {"type": "string"}, "limit": {"type": "integer"}}, ["keyword"]),
    _schema("get_low_stock", "Products whose quantity is at or below minimum stock.",
            {"limit": {"type": "integer"}}),
    _schema("get_sales_trend", "Total sales per day for the last N days (max 90).",
            {"days": {"type": "integer"}}),
    _schema("get_top_products", "Best-selling products by revenue.",
            {"limit": {"type": "integer"}, "days": {"type": "integer"}}),
    _schema("get_top_debtors", "Customers with the highest outstanding balance.",
            {"limit": {"type": "integer"}}),
    _schema("adjust_stock",
            "Increase (positive) or decrease (negative) a product's quantity and "
            "record an audit movement. The user must approve every call.",
            {"product_id": {"type": "integer"},
             "quantity_change": {"type": "number"},
             "reason": {"type": "string"}},
            ["product_id", "quantity_change"]),
    _schema("create_product", "Create a new product. The user must approve every call.",
            {"name": {"type": "string"}, "code": {"type": "string"},
             "barcode": {"type": "string"}, "purchase_price": {"type": "number"},
             "sale_price": {"type": "number"}, "minimum_stock": {"type": "number"}},
            ["name"]),
]

REQUIRES_CONFIRMATION = {"adjust_stock", "create_product"}


def describe_action(name: str, args: dict[str, Any]) -> str:
    """Human-readable (Arabic) description shown in the confirmation dialog."""
    if name == "adjust_stock":
        sign = "زيادة" if float(args.get("quantity_change", 0)) > 0 else "خصم"
        return (f"{sign} كمية المنتج رقم {args.get('product_id')} "
                f"بمقدار {abs(float(args.get('quantity_change', 0))):g}"
                + (f"\nالسبب: {args['reason']}" if args.get("reason") else ""))
    if name == "create_product":
        return (f"إنشاء منتج جديد: {args.get('name')}\n"
                f"سعر الشراء: {args.get('purchase_price', 0)} | "
                f"سعر البيع: {args.get('sale_price', 0)}")
    return f"{name}: {args}"


def run_tool(box: ToolBox, name: str, args: dict[str, Any]):
    fn: Callable | None = getattr(box, name, None)
    if name not in {s["name"] for s in TOOL_SCHEMAS} or fn is None:
        raise ValueError(f"Unknown tool: {name}")
    return fn(**args)
