"""
AlexERP — Business Management System
AI assistant settings (API key + model), stored next to the database.
The ANTHROPIC_API_KEY environment variable always wins over the saved key.
"""

from __future__ import annotations

import json
import os

from alexerp.database.db import DATABASE_DIR

SETTINGS_FILE = DATABASE_DIR / "settings.json"
DEFAULT_MODEL = "claude-sonnet-5-5"


def _load() -> dict:
    try:
        return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def get_api_key() -> str:
    return os.environ.get("ANTHROPIC_API_KEY") or _load().get("api_key", "")


def get_model() -> str:
    return _load().get("model") or DEFAULT_MODEL


def save(api_key: str | None = None, model: str | None = None) -> None:
    data = _load()
    if api_key is not None:
        data["api_key"] = api_key.strip()
    if model is not None:
        data["model"] = model.strip() or DEFAULT_MODEL
    SETTINGS_FILE.parent.mkdir(exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                             encoding="utf-8")
    try:
        os.chmod(SETTINGS_FILE, 0o600)
    except OSError:
        pass
