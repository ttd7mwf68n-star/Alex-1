# Stage 2: Document, Inventory and Accounting Cycle

This stage builds on the Stage 1 warehouse-level inventory model.

## Implemented

- Purchase invoice posting creates the invoice and its lines, receives quantities into the selected warehouse, writes stock movements, and posts a balanced journal entry in one database transaction.
- Sales invoice posting validates available stock, records the actual issue cost on each invoice line, decreases the selected warehouse balance, writes stock movements, and posts a balanced journal entry.
- Sales returns are linked to the original posted sales invoice. Returned quantities cannot exceed the quantity sold less earlier posted returns. Return values are checked against the original invoice line value, and returned stock uses the original recorded issue cost.
- Sales return accounting splits the returned amount between net sales and output tax, then reverses the cost of goods sold into inventory.
- Sales and purchase cancellation are audit-preserving operations. They reverse the original journal entry and create compensating stock movements; posted documents are not physically deleted.
- Journal reversals are one-time only. A second reversal attempt is rejected.
- Nested transaction handling uses SQLite savepoints so an accounting failure can roll back the complete parent document operation.
- Journal entries reject unbalanced or invalid debit/credit lines and duplicate source references / journal numbers.
- Paid-at-invoice amounts are split between cash/bank and receivable/payable. Supplying a paid amount without a cash/bank account is rejected instead of silently posting the wrong account.
- The missing transfer repository was added and the trial-balance service import was corrected. Warehouse transfers remain inside a single transaction.
- Existing databases gain the `unit_cost` field on `sales_invoice_items` and the sales-return tables when the schema initializer runs.

## Accounting treatment

- Sale: debit cash/bank for the amount paid and accounts receivable for the remaining amount; credit net sales and output tax. Separately debit COGS and credit inventory using the recorded issue cost.
- Purchase: debit inventory net of discount and input tax; credit cash/bank for the paid amount and accounts payable for the balance.
- Sales return: debit net sales returns and output tax; credit customer receivable. Separately debit inventory and credit COGS using the original sale cost.
- Cancellation: create a reversing journal entry that swaps every original debit and credit. The corresponding inventory movement is reversed in the same transaction.

## Validation performed

The isolated SQLite regression run covered:

1. Fresh schema creation and the backward-compatible sales-item migration.
2. Purchase posting and warehouse receipt.
3. Warehouse-to-warehouse transfer in both directions.
4. Sales posting and stock issue, including persisted unit cost.
5. Sales return and stock receipt.
6. Rejection of a return quantity greater than the remaining sold quantity.
7. Journal reversal and rejection of a second reversal.
8. Sales cancellation and purchase cancellation, including stock and journal reversal.
9. Paid-at-invoice purchase and sales accounting splits.
10. Rollback of a failed purchase posting without leaving an invoice or stock change.
11. Verification that every generated journal entry balances.

All 164 Python files passed syntax parsing. The business-cycle tests passed on an isolated in-memory database. The desktop GUI was not launched in this environment, and the user's live database was not opened or migrated.

## Operational notes

- Back up the live database before replacing program files or launching the updated version.
- Existing invoices created by earlier releases are not retroactively recalculated or reposted by this stage.
- Review Stage 1 unresolved legacy warehouse balances before posting stock documents for affected products.
- The UI screens and their field wiring still need a separate end-to-end pass. These workflows are implemented and tested at the service/repository/database layer.
- Legacy sales lines that have no recorded issue cost are not silently returned at an invented cost. If the product has a purchase cost but the old invoice line has no issue cost, the return is blocked for a controlled cost review.


## Patch validation (2026-11-16)

The delivered patch adds `tests/test_stage2_repairs.py`. Its five isolated regression tests cover persisted issue cost and cancellation, exempt-item return tax, purchase invoice listing, per-thread SQLite connections, and rollback of a failed legacy-stock allocation. The tests pass with `PYTHONPATH=. python -m unittest discover -s alexerp/tests -v`. The earlier validation list above describes the original development report; its original test suite was not present in the submitted archive.
