"""
AlexERP — Business Management System
Application Configuration

Environment overrides are supported for deployment and production readiness:
  - ALEXERP_APP_NAME
  - ALEXERP_COMPANY_NAME
  - ALEXERP_LANGUAGE
  - ALEXERP_DATA_DIR
  - ALEXERP_DATABASE_NAME
  - ALEXERP_DATABASE_BACKEND
  - ALEXERP_DATABASE_URL
  - ALEXERP_PG_DUMP
  - ALEXERP_PG_RESTORE
  - ALEXERP_EXPORT_DIR
  - ALEXERP_REPORTS_DIR
  - ALEXERP_BACKUP_DIR
  - ALEXERP_AUTO_BACKUP_ENABLED
  - ALEXERP_AUTO_BACKUP_HOUR
  - ALEXERP_AUTO_BACKUP_MINUTE
  - ALEXERP_AUTO_BACKUP_KEEP
  - ALEXERP_AUTO_BACKUP_CHECK_SECONDS
"""

from __future__ import annotations

import os
from pathlib import Path


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip().lower()
    if value in {"1", "true", "yes", "on"}:
        return True
    if value in {"0", "false", "no", "off"}:
        return False
    return default


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_path(name: str, default: Path) -> Path:
    raw = os.getenv(name)
    if not raw:
        return default
    return Path(raw).expanduser().resolve()


# ==========================================================
# Application
# ==========================================================

APP_NAME = os.getenv("ALEXERP_APP_NAME", "AlexERP")

APP_TAGLINE = os.getenv("ALEXERP_APP_TAGLINE", "Business Management System")

APP_VERSION = os.getenv("ALEXERP_APP_VERSION", "2.0.0")

COMPANY_NAME = os.getenv("ALEXERP_COMPANY_NAME", "AlexERP")

AUTHOR = os.getenv("ALEXERP_AUTHOR", "Ahmed Hamdy")

# ==========================================================
# Window
# ==========================================================

WINDOW_WIDTH = _env_int("ALEXERP_WINDOW_WIDTH", 1400)
WINDOW_HEIGHT = _env_int("ALEXERP_WINDOW_HEIGHT", 800)

WINDOW_SIZE = f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}"

MIN_WIDTH = _env_int("ALEXERP_MIN_WIDTH", 1200)
MIN_HEIGHT = _env_int("ALEXERP_MIN_HEIGHT", 700)

# ==========================================================
# Theme
# ==========================================================

DEFAULT_APPEARANCE = os.getenv("ALEXERP_DEFAULT_APPEARANCE", "System")
DEFAULT_COLOR_THEME = os.getenv("ALEXERP_DEFAULT_COLOR_THEME", "blue")

# ==========================================================
# Language
# ==========================================================

LANGUAGE = os.getenv("ALEXERP_LANGUAGE", "ar")

DATE_FORMAT = os.getenv("ALEXERP_DATE_FORMAT", "%Y-%m-%d")
TIME_FORMAT = os.getenv("ALEXERP_TIME_FORMAT", "%H:%M:%S")
DATETIME_FORMAT = os.getenv("ALEXERP_DATETIME_FORMAT", "%Y-%m-%d %H:%M:%S")

# ==========================================================
# Database
# ==========================================================

BASE_DIR = Path(__file__).resolve().parent

# Single source of truth for the SQLite database location.
# Keep the database in the application's data directory, matching
# alexerp.database.db and all database/backup services.
DATABASE_DIR = _env_path("ALEXERP_DATA_DIR", BASE_DIR / "data")
DATABASE_NAME = os.getenv("ALEXERP_DATABASE_NAME", "alex_erp.db")
DATABASE_PATH = DATABASE_DIR / DATABASE_NAME
DATABASE_BACKEND = os.getenv("ALEXERP_DATABASE_BACKEND", "sqlite").strip().lower()
DATABASE_URL = os.getenv("ALEXERP_DATABASE_URL", "").strip()
if DATABASE_BACKEND not in {"sqlite", "postgresql"}:
    raise ValueError("ALEXERP_DATABASE_BACKEND must be 'sqlite' or 'postgresql'.")

# ==========================================================
# Export
# ==========================================================

EXPORT_DIR = _env_path("ALEXERP_EXPORT_DIR", BASE_DIR / "exports")
REPORTS_DIR = _env_path("ALEXERP_REPORTS_DIR", BASE_DIR / "reports")
BACKUP_DIR = _env_path("ALEXERP_BACKUP_DIR", BASE_DIR / "backup")

# ==========================================================
# Images
# ==========================================================

ASSETS_DIR = _env_path("ALEXERP_ASSETS_DIR", BASE_DIR / "assets")
ICONS_DIR = ASSETS_DIR / "icons"
LOGO_DIR = ASSETS_DIR / "logo"

# ==========================================================
# Security
# ==========================================================

PASSWORD_ITERATIONS = _env_int("ALEXERP_PASSWORD_ITERATIONS", 100_000)
PASSWORD_HASH = os.getenv("ALEXERP_PASSWORD_HASH", "sha256")

# ==========================================================
# SQLite
# ==========================================================

SQLITE_TIMEOUT = _env_int("ALEXERP_SQLITE_TIMEOUT", 30)
SQLITE_BUSY_TIMEOUT = _env_int("ALEXERP_SQLITE_BUSY_TIMEOUT", 30000)
ENABLE_FOREIGN_KEYS = _env_bool("ALEXERP_ENABLE_FOREIGN_KEYS", True)
ENABLE_WAL = _env_bool("ALEXERP_ENABLE_WAL", True)

# ==========================================================
# UI
# ==========================================================

DEFAULT_FONT = os.getenv("ALEXERP_DEFAULT_FONT", "Segoe UI")
TITLE_FONT_SIZE = _env_int("ALEXERP_TITLE_FONT_SIZE", 28)
NORMAL_FONT_SIZE = _env_int("ALEXERP_NORMAL_FONT_SIZE", 14)
SMALL_FONT_SIZE = _env_int("ALEXERP_SMALL_FONT_SIZE", 12)
BUTTON_HEIGHT = _env_int("ALEXERP_BUTTON_HEIGHT", 40)
ENTRY_HEIGHT = _env_int("ALEXERP_ENTRY_HEIGHT", 38)
TABLE_ROW_HEIGHT = _env_int("ALEXERP_TABLE_ROW_HEIGHT", 34)

# ==========================================================
# Pagination
# ==========================================================

DEFAULT_PAGE_SIZE = _env_int("ALEXERP_DEFAULT_PAGE_SIZE", 50)
SEARCH_DELAY = _env_int("ALEXERP_SEARCH_DELAY", 300)

# ==========================================================
# Create Folders
# ==========================================================

for directory in (DATABASE_DIR, EXPORT_DIR, REPORTS_DIR, BACKUP_DIR, ASSETS_DIR, ICONS_DIR, LOGO_DIR):
    directory.mkdir(parents=True, exist_ok=True)

# Daily local backup schedule (runs only while Desktop or Mobile server is open).
AUTO_BACKUP_ENABLED = _env_bool("ALEXERP_AUTO_BACKUP_ENABLED", True)
AUTO_BACKUP_HOUR = _env_int("ALEXERP_AUTO_BACKUP_HOUR", 2)
AUTO_BACKUP_MINUTE = _env_int("ALEXERP_AUTO_BACKUP_MINUTE", 0)
AUTO_BACKUP_KEEP = _env_int("ALEXERP_AUTO_BACKUP_KEEP", 30)
AUTO_BACKUP_CHECK_SECONDS = _env_int("ALEXERP_AUTO_BACKUP_CHECK_SECONDS", 30)
