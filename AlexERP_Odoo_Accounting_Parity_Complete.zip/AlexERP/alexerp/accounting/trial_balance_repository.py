from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class TrialBalanceRepository(BaseRepository):
    def get_trial_balance(self, company_id: int, date_from: str, date_to: str):
        sql = """
        SELECT
            coa.id,
            coa.account_code AS code,
            coa.account_name AS name,
            COALESCE(at.code, 'UNKNOWN') AS account_type,
            COALESCE(SUM(CASE WHEN je.entry_date < ? THEN jd.debit ELSE 0 END), 0) AS opening_debit,
            COALESCE(SUM(CASE WHEN je.entry_date < ? THEN jd.credit ELSE 0 END), 0) AS opening_credit,
            COALESCE(SUM(CASE WHEN je.entry_date BETWEEN ? AND ? THEN jd.debit ELSE 0 END), 0) AS period_debit,
            COALESCE(SUM(CASE WHEN je.entry_date BETWEEN ? AND ? THEN jd.credit ELSE 0 END), 0) AS period_credit
        FROM chart_of_accounts coa
        LEFT JOIN account_types at ON at.id = coa.account_type_id
        LEFT JOIN journal_details jd ON jd.account_id = coa.id
        LEFT JOIN journal_entries je
            ON je.id = jd.journal_entry_id
            AND je.company_id = ?
            AND je.entry_date <= ?
            AND COALESCE(je.is_posted, 1) = 1
        WHERE coa.company_id = ?
          AND COALESCE(coa.is_active, 1) = 1
          AND COALESCE(coa.allow_posting, 1) = 1
        GROUP BY coa.id, coa.account_code, coa.account_name, at.code
        HAVING opening_debit != 0 OR opening_credit != 0
            OR period_debit != 0 OR period_credit != 0
        ORDER BY coa.account_code
        """
        return self.execute(sql, (
            date_from, date_from, date_from, date_to, date_from, date_to,
            company_id, date_to, company_id,
        )).fetchall()
