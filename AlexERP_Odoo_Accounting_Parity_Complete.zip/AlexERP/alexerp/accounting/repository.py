"""
AlexERP — Business Management System
Accounting Repository
"""

from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class AccountingRepository(BaseRepository):

    table_name = "journal_entries"

    # =====================================================
    # Create Journal Entry
    # =====================================================

    def create_entry(
        self,
        company_id: int,
        branch_id: int,
        entry_number: str,
        entry_date: str,
        description: str,
        reference_type: str,
        reference_id: int,
        created_by: int,
    ) -> int:

        sql = """
        INSERT INTO journal_entries(

            company_id,
            branch_id,
            entry_number,
            entry_date,
            description,
            reference_type,
            reference_id,
            created_by

        )
        VALUES(?,?,?,?,?,?,?,?)
        """

        cursor = self.execute(
            sql,
            (
                company_id,
                branch_id,
                entry_number,
                entry_date,
                description,
                reference_type,
                reference_id,
                created_by,
            ),
        )

        return cursor.lastrowid

    # =====================================================
    # Add Journal Detail
    # =====================================================

    def add_detail(
        self,
        journal_entry_id: int,
        account_id: int,
        cost_center_id: int | None,
        debit: float,
        credit: float,
        description: str = "",
    ) -> None:

        sql = """
        INSERT INTO journal_details(

            journal_entry_id,
            account_id,
            cost_center_id,
            debit,
            credit,
            description

        )
        VALUES(?,?,?,?,?,?)
        """

        self.execute(
            sql,
            (
                journal_entry_id,
                account_id,
                cost_center_id,
                debit,
                credit,
                description,
            ),
        )

    def get_by_entry_number(self, entry_number: str):
        return self.execute("SELECT * FROM journal_entries WHERE entry_number=? LIMIT 1",
                            (entry_number,)).fetchone()

    def get_by_reference(self, reference_type: str, reference_id: int):
        cursor = self.execute("""
            SELECT * FROM journal_entries
            WHERE reference_type=? AND reference_id=?
            ORDER BY id DESC LIMIT 1
        """, (reference_type, reference_id))
        return cursor.fetchone()

    # =====================================================
    # Get Journal Entry
    # =====================================================

    def get_entry(self, entry_id: int):

        sql = """
        SELECT *
        FROM journal_entries
        WHERE id=?
        """

        cursor = self.execute(sql, (entry_id,))

        return cursor.fetchone()

    # =====================================================
    # Get Journal Details
    # =====================================================

    def get_details(self, entry_id: int):

        sql = """
        SELECT *
        FROM journal_details
        WHERE journal_entry_id=?
        ORDER BY id
        """

        cursor = self.execute(sql, (entry_id,))

        return cursor.fetchall()

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        sql = """
        SELECT *
        FROM journal_entries

        WHERE
            entry_number LIKE ?
            OR description LIKE ?

        ORDER BY entry_date DESC
        """

        cursor = self.execute(
            sql,
            (
                f"%{keyword}%",
                f"%{keyword}%",
            ),
        )

        return cursor.fetchall()

    # =====================================================
    # Delete Journal Entry
    # =====================================================

    def delete_entry(self, entry_id: int) -> None:

        sql = """
        DELETE FROM journal_entries
        WHERE id=?
        """

        self.execute(sql, (entry_id,))

    # =====================================================
    # Get All
    # =====================================================

    def get_all(self):

        sql = """
        SELECT *
        FROM journal_entries
        ORDER BY entry_date DESC, id DESC
        """

        cursor = self.execute(sql)

        return cursor.fetchall()

    # =====================================================
    # Last Entry Number
    # =====================================================

    def get_last_entry_number(self):

        sql = """
        SELECT entry_number
        FROM journal_entries
        WHERE entry_number GLOB 'JV-[0-9]*'
        ORDER BY CAST(SUBSTR(entry_number, 4) AS INTEGER) DESC
        LIMIT 1
        """

        cursor = self.execute(sql)

        row = cursor.fetchone()

        if row:
            return row["entry_number"]

        return None

    # =====================================================
    # Update Entry
    # =====================================================

    def update_entry(self, entry_id: int, description: str) -> None:

        sql = """
        UPDATE journal_entries
        SET
            description=?
        WHERE id=?
        """

        self.execute(sql, (description, entry_id))
        self.commit()

    # =====================================================
    # Delete Details
    # =====================================================

    def delete_details(self, entry_id: int) -> None:

        sql = """
        DELETE FROM journal_details
        WHERE journal_entry_id=?
        """

        self.execute(sql, (entry_id,))
        self.commit()

