from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class BalanceSheetRepository(BaseRepository):
    def get_balance_sheet(self, company_id: int, date_to: str):
        sql = """
        SELECT
            coa.id,
            coa.account_code AS code,
            coa.account_name AS name,
            COALESCE(at.code, 'UNKNOWN') AS account_type,
            COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jd.debit ELSE 0 END), 0) AS debit,
            COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jd.credit ELSE 0 END), 0) AS credit
        FROM chart_of_accounts coa
        LEFT JOIN account_types at ON at.id = coa.account_type_id
        LEFT JOIN journal_details jd ON jd.account_id = coa.id
        LEFT JOIN journal_entries je
            ON je.id = jd.journal_entry_id
            AND je.company_id = ?
            AND je.entry_date <= ?
            AND COALESCE(je.is_posted, 1) = 1
        WHERE coa.company_id = ?
          AND COALESCE(coa.is_active, 1) = 1
          AND COALESCE(coa.allow_posting, 1) = 1
        GROUP BY coa.id, coa.account_code, coa.account_name, at.code
        HAVING debit != 0 OR credit != 0
        ORDER BY coa.account_code
        """
        return self.execute(sql, (company_id, date_to, company_id)).fetchall()

    def get_profit_and_loss(self, company_id: int, date_to: str):
        sql = """
        SELECT
            COALESCE(at.code, 'UNKNOWN') AS account_type,
            COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jd.debit ELSE 0 END), 0) AS debit,
            COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jd.credit ELSE 0 END), 0) AS credit
        FROM chart_of_accounts coa
        LEFT JOIN account_types at ON at.id = coa.account_type_id
        JOIN journal_details jd ON jd.account_id = coa.id
        JOIN journal_entries je
            ON je.id = jd.journal_entry_id
            AND je.company_id = ?
            AND je.entry_date <= ?
            AND COALESCE(je.is_posted, 1) = 1
        WHERE coa.company_id = ?
          AND COALESCE(coa.is_active, 1) = 1
          AND COALESCE(coa.allow_posting, 1) = 1
          AND at.code IN ('REVENUE', 'EXPENSE')
        GROUP BY at.code
        """
        return self.execute(sql, (company_id, date_to, company_id)).fetchall()
