"""Company-scoped profit and loss queries."""
from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class ProfitLossRepository(BaseRepository):
    def get_profit_and_loss(self, company_id: int, date_from: str, date_to: str):
        sql = """
        SELECT
            coa.id,
            coa.account_code AS code,
            coa.account_name AS name,
            at.code AS account_type,
            COALESCE(SUM(jd.debit), 0) AS debit,
            COALESCE(SUM(jd.credit), 0) AS credit
        FROM chart_of_accounts coa
        JOIN account_types at ON at.id = coa.account_type_id
        JOIN journal_details jd ON jd.account_id = coa.id
        JOIN journal_entries je ON je.id = jd.journal_entry_id
        WHERE coa.company_id = ?
          AND je.company_id = coa.company_id
          AND je.entry_date BETWEEN ? AND ?
          AND COALESCE(je.is_posted, 1) = 1
          AND COALESCE(coa.is_active, 1) = 1
          AND COALESCE(coa.allow_posting, 1) = 1
          AND at.code IN ('REVENUE', 'EXPENSE')
        GROUP BY coa.id, coa.account_code, coa.account_name, at.code
        HAVING debit != 0 OR credit != 0
        ORDER BY CASE at.code WHEN 'REVENUE' THEN 1 ELSE 2 END, coa.account_code
        """
        return self.execute(sql, (company_id, date_from, date_to)).fetchall()
