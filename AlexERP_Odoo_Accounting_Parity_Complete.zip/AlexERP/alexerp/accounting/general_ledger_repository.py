"""Company-scoped general-ledger queries."""
from __future__ import annotations

from alexerp.repositories.base_repository import BaseRepository


class GeneralLedgerRepository(BaseRepository):
    def get_opening_balance(self, company_id: int, account_id: int, date_from: str):
        sql = """
        SELECT COALESCE(SUM(jd.debit), 0) AS debit,
               COALESCE(SUM(jd.credit), 0) AS credit
        FROM journal_details jd
        JOIN journal_entries je ON je.id = jd.journal_entry_id
        JOIN chart_of_accounts coa ON coa.id = jd.account_id
        WHERE je.company_id = ?
          AND jd.account_id = ?
          AND coa.company_id = je.company_id
          AND je.entry_date < ?
          AND COALESCE(je.is_posted, 1) = 1
        """
        return self.execute(sql, (company_id, account_id, date_from)).fetchone()

    def get_ledger(self, company_id: int, account_id: int, date_from: str, date_to: str):
        sql = """
        SELECT
            je.entry_number,
            je.entry_date,
            je.description,
            jd.debit,
            jd.credit,
            jd.description AS line_description
        FROM journal_details jd
        JOIN journal_entries je ON je.id = jd.journal_entry_id
        JOIN chart_of_accounts coa ON coa.id = jd.account_id
        WHERE je.company_id = ?
          AND jd.account_id = ?
          AND coa.company_id = je.company_id
          AND je.entry_date BETWEEN ? AND ?
          AND COALESCE(je.is_posted, 1) = 1
        ORDER BY je.entry_date, je.id, jd.id
        """
        return self.execute(sql, (company_id, account_id, date_from, date_to)).fetchall()
