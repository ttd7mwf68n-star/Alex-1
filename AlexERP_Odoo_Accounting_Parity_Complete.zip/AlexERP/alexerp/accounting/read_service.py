"""Public read interface for the accounting technical package.

Business applications and UI code should depend on this service, not on ledger
SQL or accounting-table repositories. Transactional methods accept a connection
so callers can validate the same snapshot they are about to modify.
"""
from __future__ import annotations

from alexerp.accounting.balance_sheet_repository import BalanceSheetRepository
from alexerp.accounting.general_ledger_repository import GeneralLedgerRepository
from alexerp.accounting.ledger_read_repository import LedgerReadRepository
from alexerp.accounting.profit_loss_repository import ProfitLossRepository
from alexerp.accounting.trial_balance_repository import TrialBalanceRepository


class AccountingReadService:
    def __init__(self, *, ledger=None, general_ledger=None, trial_balance=None,
                 balance_sheet=None, profit_loss=None):
        self.ledger = ledger or LedgerReadRepository()
        self.general_ledger = general_ledger or GeneralLedgerRepository()
        self.trial_balance = trial_balance or TrialBalanceRepository()
        self.balance_sheet = balance_sheet or BalanceSheetRepository()
        self.profit_loss = profit_loss or ProfitLossRepository()

    @staticmethod
    def _require_company(company_id: int) -> None:
        if isinstance(company_id, bool) or not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("A valid company_id is required.")

    # Financial reports -------------------------------------------------
    def get_opening_balance(self, company_id: int, account_id: int, date_from: str):
        self._require_company(company_id)
        return self.general_ledger.get_opening_balance(company_id, account_id, date_from)

    def get_account_ledger(self, company_id: int, account_id: int,
                           date_from: str, date_to: str):
        self._require_company(company_id)
        return self.general_ledger.get_ledger(company_id, account_id, date_from, date_to)

    def get_trial_balance_rows(self, company_id: int, date_from: str, date_to: str):
        self._require_company(company_id)
        return self.trial_balance.get_trial_balance(company_id, date_from, date_to)

    def get_balance_sheet_rows(self, company_id: int, date_to: str):
        self._require_company(company_id)
        return self.balance_sheet.get_balance_sheet(company_id, date_to)

    def get_balance_sheet_income_totals(self, company_id: int, date_to: str):
        self._require_company(company_id)
        return self.balance_sheet.get_profit_and_loss(company_id, date_to)

    def get_profit_loss_rows(self, company_id: int, date_from: str, date_to: str):
        self._require_company(company_id)
        return self.profit_loss.get_profit_and_loss(company_id, date_from, date_to)

    # Journal workspace ------------------------------------------------
    def count_journal_entries(self, company_id: int, connection=None) -> int:
        self._require_company(company_id)
        return self.ledger.count_journal_entries(company_id, connection)

    def search_journal_entries(self, company_id: int, keyword: str = "", limit: int = 500,
                               connection=None):
        self._require_company(company_id)
        return self.ledger.search_journal_entries(company_id, keyword, limit, connection)

    def search_journal_lines(self, company_id: int, keyword: str = "", *,
                             posted_only: bool = True, limit: int = 500, connection=None):
        self._require_company(company_id)
        return self.ledger.search_journal_lines(
            company_id, keyword, posted_only=posted_only, limit=limit, connection=connection
        )

    def journal_exists_by_reference(self, reference_type: str, reference_id: int,
                                    company_id: int | None = None, connection=None) -> bool:
        if not str(reference_type or "").strip() or isinstance(reference_id, bool) \
                or not isinstance(reference_id, int) or reference_id <= 0:
            raise ValueError("A reference type and positive reference_id are required.")
        if company_id is not None:
            self._require_company(company_id)
        return self.ledger.journal_exists_by_reference(
            reference_type, reference_id, company_id=company_id, connection=connection
        )

    # Close controls; callers may share their active transaction ----------
    def find_unbalanced_journal(self, company_id: int, start_date: str, end_date: str,
                                connection=None):
        self._require_company(company_id)
        return self.ledger.find_unbalanced_journal(
            company_id, start_date, end_date, connection=connection
        )

    def count_unbalanced_journals(self, company_id: int, start_date: str, end_date: str,
                                  connection=None) -> int:
        self._require_company(company_id)
        return self.ledger.count_unbalanced_journals(
            company_id, start_date, end_date, connection=connection
        )

    def find_unposted_journal(self, company_id: int, start_date: str, end_date: str,
                              connection=None):
        self._require_company(company_id)
        return self.ledger.find_unposted_journal(
            company_id, start_date, end_date, connection=connection
        )

    def count_unposted_journals(self, company_id: int, start_date: str, end_date: str,
                                connection=None) -> int:
        self._require_company(company_id)
        return self.ledger.count_unposted_journals(
            company_id, start_date, end_date, connection=connection
        )

    def get_profit_loss_account_balances(self, company_id: int, start_date: str, end_date: str,
                                         connection=None):
        self._require_company(company_id)
        return self.ledger.get_profit_loss_account_balances(
            company_id, start_date, end_date, connection=connection
        )

    def get_account_for_closing(self, company_id: int, account_id: int, connection=None):
        self._require_company(company_id)
        return self.ledger.get_account_for_closing(company_id, account_id, connection=connection)

    def get_account_posting_state(self, company_id: int, account_id: int, connection=None):
        self._require_company(company_id)
        return self.ledger.get_account_posting_state(company_id, account_id, connection=connection)

    # BI ledger metrics --------------------------------------------------
    def ledger_profit_totals(self, company_id: int, branch_id: int | None,
                             start_date: str, end_date: str, connection=None):
        self._require_company(company_id)
        if branch_id is not None and (isinstance(branch_id, bool)
                                      or not isinstance(branch_id, int) or branch_id <= 0):
            raise ValueError("branch_id must be a positive integer.")
        row = self.ledger.ledger_profit_totals(
            company_id, branch_id, start_date, end_date, connection=connection
        )
        return {
            "revenue": row["revenue"] if row else 0,
            "expenses": row["expenses"] if row else 0,
        }

    def monthly_ledger_profit(self, company_id: int, branch_id: int | None,
                              start_date: str, end_date: str, connection=None):
        self._require_company(company_id)
        if branch_id is not None and (isinstance(branch_id, bool)
                                      or not isinstance(branch_id, int) or branch_id <= 0):
            raise ValueError("branch_id must be a positive integer.")
        rows = self.ledger.monthly_ledger_profit(
            company_id, branch_id, start_date, end_date, connection=connection
        )
        return {
            row["month"]: {"revenue": row["revenue"], "expenses": row["expenses"]}
            for row in rows
        }
