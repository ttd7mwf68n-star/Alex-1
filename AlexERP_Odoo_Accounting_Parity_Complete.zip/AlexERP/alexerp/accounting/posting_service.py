"""
AlexERP — Business Management System
Accounting Service
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from alexerp.database.db import Database

from alexerp.database.transaction import transaction
from alexerp.accounting.repository import AccountingRepository


class AccountingError(Exception):
    """Accounting operation failed."""
    pass


_CENT = Decimal("0.01")


def _to_money(value) -> Decimal:
    try:
        amount = Decimal(str(value if value is not None else 0))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise AccountingError("Journal amounts must be valid numbers.") from exc
    if not amount.is_finite():
        raise AccountingError("Journal amounts must be finite numbers.")
    return amount.quantize(_CENT, rounding=ROUND_HALF_UP)


class AccountingService:

    def __init__(self):

        self.repo = AccountingRepository()

    def generate_entry_number(self) -> str:

        last = self.repo.get_last_entry_number()

        if not last:
            return "JV-000001"

        parts = str(last).split("-")

        if len(parts) < 2:
            return "JV-000001"

        try:
            number = int(parts[1]) + 1
        except ValueError:
            return "JV-000001"

        return f"JV-{number:06d}"


    # =====================================================
    # Create Journal Entry
    # =====================================================

    def create_entry(
        self,
        company_id: int,
        branch_id: int,
        entry_date: str,
        description: str,
        reference_type: str,
        reference_id: int,
        created_by: int,
        details: list,
        entry_number: str | None = None,
    ) -> int:
        if not details:
            raise AccountingError("Journal entry must contain at least one detail.")
        if not isinstance(company_id, int) or company_id <= 0:
            raise AccountingError("A valid company_id is required.")
        try:
            date.fromisoformat(str(entry_date))
        except (TypeError, ValueError) as exc:
            raise AccountingError("Journal entry date must be a valid ISO date (YYYY-MM-DD).") from exc
        if not str(reference_type or "").strip() or not isinstance(reference_id, int) or reference_id <= 0:
            raise AccountingError("A valid reference type and positive reference_id are required.")

        total_debit = Decimal("0.00")
        total_credit = Decimal("0.00")
        cleaned_details = []

        for row in details:
            debit = _to_money(row.get("debit"))
            credit = _to_money(row.get("credit"))
            if debit < 0 or credit < 0 or (debit > 0 and credit > 0):
                raise AccountingError("Each journal line must have non-negative debit or credit, not both.")
            if debit == 0 and credit == 0:
                continue
            total_debit += debit
            total_credit += credit
            cleaned_details.append({**row, "debit": float(debit), "credit": float(credit)})

        if not cleaned_details:
            raise AccountingError("Journal entry cannot have all zero lines.")

        if total_debit != total_credit:
            raise AccountingError(
                f"Journal entry is not balanced (Debit={total_debit:.2f}, Credit={total_credit:.2f})."
            )

        from alexerp.core import tenancy
        tenancy.require_branch(company_id, branch_id)
        connection = Database.connect()
        for row in cleaned_details:
            account_id = row.get("account_id")
            if not isinstance(account_id, int) or account_id <= 0:
                raise AccountingError("Every journal line must reference a valid account.")
            tenancy.require_account(company_id, account_id, "Journal account")
            account = connection.execute(
                "SELECT is_active, allow_posting FROM chart_of_accounts WHERE id=? AND company_id=?",
                (account_id, company_id),
            ).fetchone()
            if account is None or not int(account["is_active"] or 0):
                raise AccountingError(f"Account {account_id} is inactive or unavailable.")
            if not int(account["allow_posting"] if account["allow_posting"] is not None else 1):
                raise AccountingError(f"Account {account_id} is a header account and cannot receive postings.")
            cost_center_id = row.get("cost_center_id")
            if cost_center_id is not None:
                cost_center = connection.execute(
                    "SELECT company_id, is_active FROM cost_centers WHERE id=?", (cost_center_id,)
                ).fetchone()
                if (cost_center is None or cost_center["company_id"] is None
                        or int(cost_center["company_id"]) != company_id
                        or not int(cost_center["is_active"] if cost_center["is_active"] is not None else 1)):
                    raise AccountingError(f"Cost center {cost_center_id} is inactive or belongs to another company.")
        with transaction():
            # Period validation is centralized here so desktop, mobile, and
            # automated document workflows cannot post around a closed period.
            self._require_open_period(company_id, entry_date)
            existing = self.repo.get_by_reference(reference_type, reference_id)
            if existing is not None:
                raise AccountingError(
                    f"A journal entry already exists for {reference_type} #{reference_id}."
                )
            entry_number = entry_number or self.generate_entry_number()
            if self.repo.get_by_entry_number(entry_number) is not None:
                raise AccountingError(f"Journal entry number {entry_number} already exists.")

            entry_id = self.repo.create_entry(
                company_id=company_id,
                branch_id=branch_id,
                entry_number=entry_number,
                entry_date=entry_date,
                description=description,
                reference_type=reference_type,
                reference_id=reference_id,
                created_by=created_by,
            )

            for row in cleaned_details:
                self.repo.add_detail(
                    journal_entry_id=entry_id,
                    account_id=row["account_id"],
                    cost_center_id=row.get("cost_center_id"),
                    debit=row["debit"],
                    credit=row["credit"],
                    description=row.get("description", ""),
                )

            return entry_id

    @staticmethod
    def _require_open_period(company_id: int, entry_date: str) -> None:
        """Enforce configured company accounting periods.

        Legacy companies with no configured periods remain operational. Once a
        company creates its first period, every journal date must fall inside
        exactly one configured period and that period must be open.
        """
        from alexerp.accounting.period_service import FiscalPeriodService

        state = FiscalPeriodService().posting_date_status(
            company_id, entry_date, connection=Database.connect()
        )
        if state["status"] in ("unconfigured", "open"):
            return
        if state["status"] == "missing":
            raise AccountingError(
                f"No accounting period is configured for {entry_date} in this company."
            )
        if state["status"] == "closed":
            raise AccountingError(
                f"Accounting period '{state['period']['name']}' is closed; posting is not allowed."
            )
        raise AccountingError(
            f"More than one accounting period covers {entry_date}; posting is blocked until the overlap is resolved."
        )

    # =====================================================
    # Get Entry
    # =====================================================

    def get_entry(self, entry_id: int):

        return self.repo.get_entry(entry_id)

    # =====================================================
    # Get Details
    # =====================================================

    def get_details(self, entry_id: int):

        return self.repo.get_details(entry_id)

    # =====================================================
    # Search
    # =====================================================

    def search(self, keyword: str):

        return self.repo.search(keyword)

    def reverse_entry(self, reference_type: str, reference_id: int,
                      created_by: int, reversal_date: str | None = None) -> int:
        """Create one balanced reversing journal entry for a source document."""
        from datetime import date
        from alexerp.core.constants import ReferenceType

        with transaction():
            original = self.repo.get_by_reference(reference_type, reference_id)
            if original is None:
                raise AccountingError("Original journal entry was not found.")
            existing = self.repo.get_by_reference("REVERSAL", int(original["id"]))
            if existing is not None:
                raise AccountingError("This journal entry has already been reversed.")
            original_details = self.repo.get_details(int(original["id"]))
            details = [{
                "account_id": row["account_id"],
                "cost_center_id": row["cost_center_id"],
                "debit": float(row["credit"] or 0),
                "credit": float(row["debit"] or 0),
                "description": f"Reversal: {row['description'] or ''}",
            } for row in original_details]
            return self.create_entry(
                company_id=int(original["company_id"]),
                branch_id=int(original["branch_id"]) if original["branch_id"] is not None else None,
                entry_date=reversal_date or date.today().isoformat(),
                description=f"Reversal of {original['entry_number']}",
                reference_type="REVERSAL",
                reference_id=int(original["id"]),
                created_by=created_by,
                details=details,
                entry_number=None,
            )

    # =====================================================
    # Delete Entry
    # =====================================================

    def delete(self, entry_id: int):
        raise AccountingError(
            "Posted journal entries cannot be deleted for audit compliance. Use reverse_entry() instead."
        )
