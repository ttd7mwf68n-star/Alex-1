"""Company-scoped accounting period management and controlled closing."""
from __future__ import annotations

from datetime import date, datetime, timezone

from alexerp.database.db import Database
from alexerp.database.transaction import transaction
from alexerp.accounting.read_service import AccountingReadService


class FiscalPeriodError(ValueError):
    """Raised when an accounting period operation violates business rules."""


def _iso_date(value: str, label: str) -> str:
    try:
        parsed = date.fromisoformat(str(value))
    except (TypeError, ValueError) as exc:
        raise FiscalPeriodError(f"{label} must be a valid ISO date (YYYY-MM-DD).") from exc
    normalized = parsed.isoformat()
    if str(value) != normalized:
        raise FiscalPeriodError(f"{label} must use YYYY-MM-DD format.")
    return normalized


class FiscalPeriodService:
    """Create/list/close accounting periods without modifying posted history."""

    def __init__(self, accounting_reads=None):
        self.accounting_reads = accounting_reads or AccountingReadService()

    @staticmethod
    def _require_company(company_id: int) -> None:
        if isinstance(company_id, bool) or not isinstance(company_id, int) or company_id <= 0:
            raise FiscalPeriodError("A valid company_id is required.")

    def create_period(self, company_id: int, name: str, start_date: str,
                      end_date: str, created_by: int) -> int:
        if not isinstance(company_id, int) or company_id <= 0:
            raise FiscalPeriodError("A valid company_id is required.")
        if not isinstance(created_by, int) or created_by <= 0:
            raise FiscalPeriodError("A valid created_by user ID is required.")
        name = str(name or "").strip()
        if not name:
            raise FiscalPeriodError("Accounting period name is required.")
        start = _iso_date(start_date, "start_date")
        end = _iso_date(end_date, "end_date")
        if start > end:
            raise FiscalPeriodError("Period start_date must not be after end_date.")

        with transaction() as conn:
            company = conn.execute("SELECT id FROM companies WHERE id=?", (company_id,)).fetchone()
            if company is None:
                raise FiscalPeriodError("Company does not exist.")
            self._require_manager(conn, created_by, company_id)
            overlap = conn.execute(
                """SELECT id, name FROM accounting_periods
                   WHERE company_id=? AND NOT(end_date<? OR start_date>?) LIMIT 1""",
                (company_id, start, end),
            ).fetchone()
            if overlap is not None:
                raise FiscalPeriodError(
                    f"Period overlaps existing period '{overlap['name']}' (ID {overlap['id']})."
                )
            cursor = conn.execute(
                """INSERT INTO accounting_periods
                   (company_id, name, start_date, end_date, created_by, is_closed)
                   VALUES(?,?,?,?,?,0)""",
                (company_id, name, start, end, created_by),
            )
            period_id = int(cursor.lastrowid)
            from alexerp.services.audit_service import AuditService
            AuditService.record(
                user_id=created_by, company_id=company_id, module="accounting",
                action="period_created", entity_type="accounting_period",
                record_id=period_id, description=f"Created accounting period {name}",
                after={"name": name, "start_date": start, "end_date": end},
                connection=conn,
            )
            return period_id

    def list_periods(self, company_id: int):
        if not isinstance(company_id, int) or company_id <= 0:
            raise FiscalPeriodError("A valid company_id is required.")
        return Database.connect().execute(
            """SELECT * FROM accounting_periods WHERE company_id=?
               ORDER BY start_date, id""", (company_id,)
        ).fetchall()

    def close_period(self, period_id: int, closed_by: int) -> None:
        if not isinstance(period_id, int) or period_id <= 0:
            raise FiscalPeriodError("A valid period_id is required.")
        if not isinstance(closed_by, int) or closed_by <= 0:
            raise FiscalPeriodError("A valid closed_by user ID is required.")

        with transaction() as conn:
            period = conn.execute(
                "SELECT * FROM accounting_periods WHERE id=?", (period_id,)
            ).fetchone()
            if period is None:
                raise FiscalPeriodError("Accounting period was not found.")
            if int(period["is_closed"] or 0):
                raise FiscalPeriodError("Accounting period is already closed.")
            self._require_manager(conn, closed_by, int(period["company_id"]))

            invalid = self.accounting_reads.find_unbalanced_journal(
                int(period["company_id"]), period["start_date"], period["end_date"],
                connection=conn,
            )
            if invalid is not None:
                raise FiscalPeriodError(
                    f"Cannot close period: journal {invalid['entry_number'] or invalid['id']} "
                    "has no lines or is unbalanced."
                )

            unposted = self.accounting_reads.count_unposted_journals(
                int(period["company_id"]), period["start_date"], period["end_date"],
                connection=conn,
            )
            if unposted:
                raise FiscalPeriodError("Cannot close period while unposted journal entries exist.")

            closed_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
            conn.execute(
                """UPDATE accounting_periods
                   SET is_closed=1, closed_at=?, closed_by=?
                   WHERE id=? AND is_closed=0""",
                (closed_at, closed_by, period_id),
            )
            from alexerp.services.audit_service import AuditService
            AuditService.record(
                user_id=closed_by, company_id=int(period["company_id"]),
                module="accounting", action="period_closed",
                entity_type="accounting_period", record_id=period_id,
                description=f"Closed accounting period {period['name']}",
                before={"is_closed": 0}, after={"is_closed": 1, "closed_at": closed_at},
                connection=conn,
            )

    @staticmethod
    def _require_manager(conn, user_id: int, company_id: int) -> None:
        allowed = conn.execute(
            """SELECT 1 FROM users u
               JOIN roles r ON r.id=u.role_id AND r.is_active=1
                 AND (r.company_id IS NULL OR r.company_id=u.company_id)
               JOIN role_permissions rp ON rp.role_id=r.id
               JOIN permissions p ON p.id=rp.permission_id
               WHERE u.id=? AND u.company_id=? AND u.is_active=1
                 AND p.permission_key='accounting.periods.manage' LIMIT 1""",
            (user_id, company_id),
        ).fetchone()
        if allowed is None:
            raise FiscalPeriodError("User is not authorized to manage accounting periods.")

    def posting_date_status(self, company_id: int, entry_date: str, connection=None) -> dict:
        """Describe period state for a posting date without exposing SQL to callers."""
        self._require_company(company_id)
        value = _iso_date(entry_date, "entry_date")
        conn = connection or Database.connect()
        configured = conn.execute(
            "SELECT 1 FROM accounting_periods WHERE company_id=? LIMIT 1", (company_id,)
        ).fetchone()
        if configured is None:
            return {"status": "unconfigured", "period": None}
        rows = conn.execute(
            """SELECT id,name,is_closed FROM accounting_periods
               WHERE company_id=? AND start_date<=? AND end_date>=? ORDER BY id""",
            (company_id, value, value),
        ).fetchall()
        if not rows:
            return {"status": "missing", "period": None}
        if len(rows) != 1:
            return {"status": "ambiguous", "period": None}
        period = rows[0]
        if int(period["is_closed"] or 0):
            return {"status": "closed", "period": period}
        return {"status": "open", "period": period}

    def is_open_for_date(self, company_id: int, entry_date: str) -> bool:
        """Return whether a date is postable, retaining legacy behavior if unconfigured."""
        return self.posting_date_status(company_id, entry_date)["status"] in ("unconfigured", "open")

    def periods_overlapping(self, company_id: int, start_date: str, end_date: str,
                            connection=None):
        self._require_company(company_id)
        start = _iso_date(start_date, "start_date")
        end = _iso_date(end_date, "end_date")
        if start > end:
            raise FiscalPeriodError("Period start_date must not be after end_date.")
        conn = connection or Database.connect()
        return conn.execute(
            """SELECT * FROM accounting_periods
               WHERE company_id=? AND end_date>=? AND start_date<=?
               ORDER BY start_date,id""",
            (company_id, start, end),
        ).fetchall()

    def close_preflight(self, company_id: int, start_date: str, end_date: str) -> dict:
        """Read-only fiscal-year readiness summary; close_year rechecks transactionally."""
        self._require_company(company_id)
        start = _iso_date(start_date, "start_date")
        end = _iso_date(end_date, "end_date")
        if start > end:
            raise FiscalPeriodError("Period start_date must not be after end_date.")
        periods = Database.connect().execute(
            """SELECT COUNT(*) AS total,
                      SUM(CASE WHEN is_closed=1 THEN 1 ELSE 0 END) AS closed
               FROM accounting_periods WHERE company_id=? AND start_date>=? AND end_date<=?""",
            (company_id, start, end),
        ).fetchone()
        return {
            "periods_total": int(periods["total"] or 0),
            "periods_closed": int(periods["closed"] or 0),
            "unposted_journals": self.accounting_reads.count_unposted_journals(
                company_id, start, end,
            ),
            "invalid_journals": self.accounting_reads.count_unbalanced_journals(
                company_id, start, end,
            ),
        }

    @staticmethod
    def _close_periods_in_transaction(connection, company_id: int, period_ids,
                                      closed_by: int, closed_at: str) -> int:
        """Atomic close primitive for FiscalYearClosingService only."""
        updated = 0
        for period_id in period_ids:
            cursor = connection.execute(
                """UPDATE accounting_periods SET is_closed=1,closed_at=?,closed_by=?
                   WHERE id=? AND company_id=? AND is_closed=0""",
                (closed_at, closed_by, int(period_id), company_id),
            )
            updated += max(0, int(cursor.rowcount or 0))
        return updated
