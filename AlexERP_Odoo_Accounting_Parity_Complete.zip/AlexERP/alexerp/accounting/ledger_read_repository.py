"""Read-side SQL owned by the accounting technical package.

Application services should use AccountingReadService rather than querying
journal tables directly. Methods accept an optional connection so fiscal close
checks can participate in the caller's transaction.
"""
from __future__ import annotations

from alexerp.database.db import Database


class LedgerReadRepository:
    @staticmethod
    def _conn(connection=None):
        return connection or Database.connect()

    @staticmethod
    def _limit(value: int) -> int:
        if isinstance(value, bool):
            return 500
        try:
            return max(1, min(int(value), 500))
        except (TypeError, ValueError):
            return 500

    def count_journal_entries(self, company_id: int, connection=None) -> int:
        row = self._conn(connection).execute(
            "SELECT COUNT(*) FROM journal_entries WHERE company_id=?", (company_id,)
        ).fetchone()
        return int(row[0] or 0)

    def search_journal_entries(self, company_id: int, keyword: str = "", limit: int = 500,
                               connection=None):
        sql = """SELECT entry_number,entry_date,description,reference_type,reference_id,is_posted
                 FROM journal_entries WHERE company_id=?"""
        params: list[object] = [company_id]
        keyword = str(keyword or "").strip()
        if keyword:
            sql += " AND (entry_number LIKE ? OR description LIKE ?)"
            params.extend((f"%{keyword}%", f"%{keyword}%"))
        sql += " ORDER BY entry_date DESC,id DESC LIMIT ?"
        params.append(self._limit(limit))
        return self._conn(connection).execute(sql, tuple(params)).fetchall()

    def search_journal_lines(self, company_id: int, keyword: str = "", *,
                             posted_only: bool = True, limit: int = 500, connection=None):
        sql = """SELECT je.entry_date,je.entry_number,coa.account_code,coa.account_name,
                        jd.description AS line_description,je.description AS entry_description,
                        jd.debit,jd.credit,
                        CASE
                          WHEN je.reference_type IN ('SALE','SALE_CANCEL','SALE_DELIVERY') THEN
                            (SELECT c.name FROM sales_invoices si JOIN customers c ON c.id=si.customer_id
                             WHERE si.id=je.reference_id AND si.company_id=je.company_id)
                          WHEN je.reference_type='SALE_RETURN' THEN
                            (SELECT c.name FROM sales_returns sr JOIN customers c ON c.id=sr.customer_id
                             WHERE sr.id=je.reference_id AND sr.company_id=je.company_id)
                          WHEN je.reference_type IN ('PURCHASE','PURCHASE_CANCEL') THEN
                            (SELECT s.name FROM purchase_invoices pi JOIN suppliers s ON s.id=pi.supplier_id
                             WHERE pi.id=je.reference_id AND pi.company_id=je.company_id)
                          WHEN je.reference_type='RECEIPT' THEN
                            (SELECT c.name FROM receipts r JOIN customers c ON c.id=r.customer_id
                             WHERE r.id=je.reference_id AND r.company_id=je.company_id)
                          WHEN je.reference_type='SUPPLIER_PAYMENT' THEN
                            (SELECT s.name FROM payments p JOIN suppliers s ON s.id=p.supplier_id
                             WHERE p.id=je.reference_id AND p.company_id=je.company_id)
                          ELSE ''
                        END AS partner_name
                 FROM journal_details jd
                 JOIN journal_entries je ON je.id=jd.journal_entry_id
                 JOIN chart_of_accounts coa ON coa.id=jd.account_id
                 WHERE je.company_id=? AND coa.company_id=je.company_id"""
        params: list[object] = [company_id]
        if posted_only:
            sql += " AND COALESCE(je.is_posted,1)=1"
        keyword = str(keyword or "").strip()
        if keyword:
            pattern = f"%{keyword}%"
            sql += """ AND (je.entry_number LIKE ? OR je.description LIKE ?
                            OR jd.description LIKE ? OR coa.account_code LIKE ?
                            OR coa.account_name LIKE ?)"""
            params.extend((pattern, pattern, pattern, pattern, pattern))
        sql += " ORDER BY je.entry_date DESC,je.id DESC,jd.id LIMIT ?"
        params.append(self._limit(limit))
        return self._conn(connection).execute(sql, tuple(params)).fetchall()

    def journal_exists_by_reference(self, reference_type: str, reference_id: int,
                                    company_id: int | None = None, connection=None) -> bool:
        sql = "SELECT 1 FROM journal_entries WHERE reference_type=? AND reference_id=?"
        params: list[object] = [reference_type, reference_id]
        if company_id is not None:
            sql += " AND company_id=?"
            params.append(company_id)
        return self._conn(connection).execute(sql + " LIMIT 1", tuple(params)).fetchone() is not None

    def find_unbalanced_journal(self, company_id: int, start_date: str, end_date: str,
                                connection=None):
        return self._conn(connection).execute(
            """SELECT je.id, je.entry_number,
                      ROUND(COALESCE(SUM(jd.debit),0),2) AS debit_total,
                      ROUND(COALESCE(SUM(jd.credit),0),2) AS credit_total,
                      COUNT(jd.id) AS line_count
               FROM journal_entries je
               LEFT JOIN journal_details jd ON jd.journal_entry_id=je.id
               WHERE je.company_id=? AND je.entry_date BETWEEN ? AND ?
               GROUP BY je.id, je.entry_number
               HAVING COUNT(jd.id)=0
                   OR ROUND(COALESCE(SUM(jd.debit),0),2)<>ROUND(COALESCE(SUM(jd.credit),0),2)
               LIMIT 1""",
            (company_id, start_date, end_date),
        ).fetchone()

    def count_unbalanced_journals(self, company_id: int, start_date: str, end_date: str,
                                  connection=None) -> int:
        row = self._conn(connection).execute(
            """SELECT COUNT(*) FROM (
                   SELECT je.id
                   FROM journal_entries je
                   LEFT JOIN journal_details jd ON jd.journal_entry_id=je.id
                   WHERE je.company_id=? AND je.entry_date BETWEEN ? AND ?
                   GROUP BY je.id
                   HAVING COUNT(jd.id)=0
                       OR ROUND(COALESCE(SUM(jd.debit),0),2)<>ROUND(COALESCE(SUM(jd.credit),0),2)
               ) invalid_entries""",
            (company_id, start_date, end_date),
        ).fetchone()
        return int(row[0] or 0)

    def find_unposted_journal(self, company_id: int, start_date: str, end_date: str,
                              connection=None):
        return self._conn(connection).execute(
            """SELECT entry_number FROM journal_entries
               WHERE company_id=? AND entry_date BETWEEN ? AND ?
                 AND COALESCE(is_posted,0)=0
               ORDER BY entry_date,id LIMIT 1""",
            (company_id, start_date, end_date),
        ).fetchone()

    def count_unposted_journals(self, company_id: int, start_date: str, end_date: str,
                                connection=None) -> int:
        row = self._conn(connection).execute(
            """SELECT COUNT(*) FROM journal_entries WHERE company_id=?
               AND entry_date BETWEEN ? AND ? AND COALESCE(is_posted,0)=0""",
            (company_id, start_date, end_date),
        ).fetchone()
        return int(row[0] or 0)

    def get_profit_loss_account_balances(self, company_id: int, start_date: str, end_date: str,
                                         connection=None):
        return self._conn(connection).execute(
            """SELECT coa.id, coa.account_code, coa.account_name, at.code AS account_type,
                      ROUND(COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jd.debit ELSE 0 END),0),2) AS debit_total,
                      ROUND(COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jd.credit ELSE 0 END),0),2) AS credit_total
               FROM chart_of_accounts coa
               JOIN account_types at ON at.id=coa.account_type_id
               LEFT JOIN journal_details jd ON jd.account_id=coa.id
               LEFT JOIN journal_entries je
                 ON je.id=jd.journal_entry_id AND je.company_id=?
                AND je.entry_date BETWEEN ? AND ? AND COALESCE(je.is_posted,1)=1
               WHERE coa.company_id=? AND at.code IN ('REVENUE','EXPENSE')
               GROUP BY coa.id, coa.account_code, coa.account_name, at.code
               ORDER BY coa.account_code""",
            (company_id, start_date, end_date, company_id),
        ).fetchall()

    def get_account_for_closing(self, company_id: int, account_id: int, connection=None):
        return self._conn(connection).execute(
            """SELECT coa.id, coa.account_name, coa.is_active, coa.allow_posting,
                      at.code AS account_type
               FROM chart_of_accounts coa
               JOIN account_types at ON at.id=coa.account_type_id
               WHERE coa.id=? AND coa.company_id=?""",
            (account_id, company_id),
        ).fetchone()

    def get_account_posting_state(self, company_id: int, account_id: int, connection=None):
        return self._conn(connection).execute(
            "SELECT is_active,allow_posting FROM chart_of_accounts WHERE id=? AND company_id=?",
            (account_id, company_id),
        ).fetchone()

    def ledger_profit_totals(self, company_id: int, branch_id: int | None,
                             start_date: str, end_date: str, connection=None):
        sql = """SELECT
                    COALESCE(SUM(CASE WHEN at.code='REVENUE' THEN jd.credit-jd.debit ELSE 0 END),0) AS revenue,
                    COALESCE(SUM(CASE WHEN at.code='EXPENSE' THEN jd.debit-jd.credit ELSE 0 END),0) AS expenses
                 FROM journal_entries je
                 JOIN journal_details jd ON jd.journal_entry_id=je.id
                 JOIN chart_of_accounts coa ON coa.id=jd.account_id AND coa.company_id=je.company_id
                 JOIN account_types at ON at.id=coa.account_type_id
                 WHERE je.company_id=? AND je.entry_date BETWEEN ? AND ?
                   AND COALESCE(je.is_posted,1)=1
                   AND COALESCE(coa.is_active,1)=1
                   AND COALESCE(coa.allow_posting,1)=1
                   AND at.code IN ('REVENUE','EXPENSE')"""
        params: list[object] = [company_id, start_date, end_date]
        if branch_id is not None:
            sql += " AND je.branch_id=?"
            params.append(branch_id)
        return self._conn(connection).execute(sql, tuple(params)).fetchone()

    def monthly_ledger_profit(self, company_id: int, branch_id: int | None,
                              start_date: str, end_date: str, connection=None):
        sql = """SELECT substr(je.entry_date,1,7) AS month,
                        COALESCE(SUM(CASE WHEN at.code='REVENUE'
                                          THEN jd.credit-jd.debit ELSE 0 END),0) AS revenue,
                        COALESCE(SUM(CASE WHEN at.code='EXPENSE'
                                          THEN jd.debit-jd.credit ELSE 0 END),0) AS expenses
                 FROM journal_entries je
                 JOIN journal_details jd ON jd.journal_entry_id=je.id
                 JOIN chart_of_accounts coa ON coa.id=jd.account_id AND coa.company_id=je.company_id
                 JOIN account_types at ON at.id=coa.account_type_id
                 WHERE je.company_id=? AND je.entry_date BETWEEN ? AND ?
                   AND COALESCE(je.is_posted,1)=1
                   AND COALESCE(coa.is_active,1)=1
                   AND COALESCE(coa.allow_posting,1)=1
                   AND at.code IN ('REVENUE','EXPENSE')"""
        params: list[object] = [company_id, start_date, end_date]
        if branch_id is not None:
            sql += " AND je.branch_id=?"
            params.append(branch_id)
        sql += " GROUP BY substr(je.entry_date,1,7)"
        return self._conn(connection).execute(sql, tuple(params)).fetchall()
