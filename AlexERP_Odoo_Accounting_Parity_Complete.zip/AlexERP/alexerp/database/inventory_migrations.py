"""
Safe, idempotent inventory migrations.

Legacy product quantities are assigned automatically only when a product has
exactly one matching warehouse. Ambiguous balances are retained in
legacy_stock_unallocated for explicit manual allocation.
"""
from __future__ import annotations

import sqlite3
import itertools

_allocation_savepoint_counter = itertools.count(1)


def migrate_inventory_schema(conn: sqlite3.Connection) -> dict[str, int]:
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS legacy_stock_unallocated (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL UNIQUE,
            quantity REAL NOT NULL,
            reason TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            resolved_at TIMESTAMP,
            FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS inventory_schema_migrations (
            migration_key TEXT PRIMARY KEY,
            applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cur.execute("SELECT 1 FROM inventory_schema_migrations WHERE migration_key=?",
                ("multi_warehouse_stock_v1",))
    if cur.fetchone():
        return {"assigned": 0, "unallocated": 0, "skipped": 0}

    assigned = unallocated = skipped = 0
    products = cur.execute("""
        SELECT id, company_id, branch_id, COALESCE(quantity, 0) AS quantity,
               COALESCE(purchase_price, 0) AS purchase_price
        FROM products
        WHERE COALESCE(quantity, 0) != 0
    """).fetchall()

    for product_id, company_id, branch_id, quantity, purchase_price in products:
        exists = cur.execute(
            "SELECT 1 FROM product_stock WHERE product_id=? LIMIT 1",
            (product_id,),
        ).fetchone()
        pending = cur.execute(
            "SELECT 1 FROM legacy_stock_unallocated WHERE product_id=?",
            (product_id,),
        ).fetchone()
        if exists or pending:
            skipped += 1
            continue

        if branch_id is None:
            warehouses = cur.execute("""
                SELECT id, branch_id FROM warehouses
                WHERE company_id=? AND is_active=1
                ORDER BY id
            """, (company_id,)).fetchall()
        else:
            warehouses = cur.execute("""
                SELECT id, branch_id FROM warehouses
                WHERE company_id=? AND branch_id=? AND is_active=1
                ORDER BY id
            """, (company_id, branch_id)).fetchall()

        if len(warehouses) == 1:
            warehouse_id, warehouse_branch_id = warehouses[0]
            cur.execute("""
                INSERT INTO product_stock
                    (company_id, branch_id, warehouse_id, product_id,
                     quantity, average_cost, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """, (company_id, warehouse_branch_id, warehouse_id,
                  product_id, quantity, purchase_price))
            movement_branch = warehouse_branch_id if warehouse_branch_id is not None else branch_id
            if movement_branch is None:
                default_branch = cur.execute(
                    "SELECT id FROM branches WHERE company_id=? ORDER BY id LIMIT 1",
                    (company_id,),
                ).fetchone()
                movement_branch = default_branch[0] if default_branch else None
            if movement_branch is not None:
                cur.execute("""
                    INSERT INTO stock_movements
                        (company_id, branch_id, warehouse_id, product_id,
                         transaction_type, reference_type, reference_id,
                         quantity_in, quantity_out, unit_cost, balance_after, notes)
                    VALUES (?, ?, ?, ?, 'OPENING', 'MIGRATION', ?, ?, ?, ?, ?, ?)
                """, (company_id, movement_branch, warehouse_id, product_id,
                      product_id, max(float(quantity), 0), max(-float(quantity), 0),
                      purchase_price, quantity,
                      'Opening balance migrated from products.quantity'))
            assigned += 1
        else:
            reason = ("No matching active warehouse" if not warehouses
                      else "Multiple matching warehouses; manual allocation required")
            cur.execute("""
                INSERT INTO legacy_stock_unallocated(product_id, quantity, reason)
                VALUES (?, ?, ?)
            """, (product_id, quantity, reason))
            unallocated += 1

    cur.execute("""
        INSERT INTO inventory_schema_migrations(migration_key)
        VALUES ('multi_warehouse_stock_v1')
    """)
    return {"assigned": assigned, "unallocated": unallocated, "skipped": skipped}


def _allocate_legacy_stock(conn: sqlite3.Connection, product_id: int,
                           warehouse_id: int) -> float:
    """Explicitly allocate a preserved legacy balance to a selected warehouse."""
    cur = conn.cursor()
    pending = cur.execute("""
        SELECT quantity FROM legacy_stock_unallocated
        WHERE product_id=? AND resolved_at IS NULL
    """, (product_id,)).fetchone()
    if pending is None:
        raise ValueError("No unresolved legacy balance exists for this product.")

    product = cur.execute("""
        SELECT company_id, branch_id, purchase_price
        FROM products WHERE id=?
    """, (product_id,)).fetchone()
    warehouse = cur.execute("""
        SELECT company_id, branch_id, is_active
        FROM warehouses WHERE id=?
    """, (warehouse_id,)).fetchone()
    if product is None or warehouse is None or not warehouse[2]:
        raise ValueError("Product or active warehouse was not found.")
    if int(product[0]) != int(warehouse[0]):
        raise ValueError("Product and warehouse belong to different companies.")
    if product[1] is not None and warehouse[1] is not None and int(product[1]) != int(warehouse[1]):
        raise ValueError("Product and warehouse belong to different branches.")

    quantity = float(pending[0])
    existing = cur.execute("""
        SELECT quantity, average_cost FROM product_stock
        WHERE product_id=? AND warehouse_id=?
    """, (product_id, warehouse_id)).fetchone()
    old_quantity = float(existing[0]) if existing else 0.0
    old_cost = float(existing[1]) if existing else float(product[2] or 0)
    new_quantity = old_quantity + quantity
    new_cost = ((old_quantity * old_cost + quantity * float(product[2] or 0)) /
                new_quantity) if new_quantity > 0 else float(product[2] or 0)

    cur.execute("""
        INSERT INTO product_stock
            (company_id, branch_id, warehouse_id, product_id, quantity, average_cost, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(warehouse_id, product_id) DO UPDATE SET
            quantity=excluded.quantity, average_cost=excluded.average_cost,
            updated_at=CURRENT_TIMESTAMP
    """, (warehouse[0], warehouse[1], warehouse_id, product_id, new_quantity, new_cost))

    branch_id = warehouse[1] or product[1]
    if branch_id is None:
        row = cur.execute("SELECT id FROM branches WHERE company_id=? ORDER BY id LIMIT 1",
                          (product[0],)).fetchone()
        branch_id = row[0] if row else None
    if branch_id is not None:
        cur.execute("""
            INSERT INTO stock_movements
                (company_id, branch_id, warehouse_id, product_id,
                 transaction_type, reference_type, reference_id,
                 quantity_in, quantity_out, unit_cost, balance_after, notes)
            VALUES (?, ?, ?, ?, 'OPENING', 'MIGRATION_ALLOCATION', ?, ?, ?, ?, ?, ?)
        """, (product[0], branch_id, warehouse_id, product_id, product_id,
              max(quantity, 0), max(-quantity, 0), float(product[2] or 0),
              new_quantity, "Legacy stock manually allocated to warehouse"))

    cur.execute("""
        UPDATE legacy_stock_unallocated SET resolved_at=CURRENT_TIMESTAMP
        WHERE product_id=? AND resolved_at IS NULL
    """, (product_id,))
    assigned = cur.execute(
        "SELECT COALESCE(SUM(quantity),0) FROM product_stock WHERE product_id=?",
        (product_id,),
    ).fetchone()[0]
    still_pending = cur.execute(
        "SELECT COALESCE(SUM(quantity),0) FROM legacy_stock_unallocated "
        "WHERE product_id=? AND resolved_at IS NULL", (product_id,),
    ).fetchone()[0]
    cur.execute("UPDATE products SET quantity=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (float(assigned or 0) + float(still_pending or 0), product_id))
    return new_quantity


def allocate_legacy_stock(conn: sqlite3.Connection, product_id: int,
                          warehouse_id: int) -> float:
    """Allocate a legacy balance atomically, nesting safely in caller transactions."""
    savepoint = f"legacy_stock_allocation_{next(_allocation_savepoint_counter)}"
    conn.execute(f"SAVEPOINT {savepoint}")
    try:
        result = _allocate_legacy_stock(conn, product_id, warehouse_id)
        conn.execute(f"RELEASE SAVEPOINT {savepoint}")
        return result
    except Exception:
        conn.execute(f"ROLLBACK TO SAVEPOINT {savepoint}")
        conn.execute(f"RELEASE SAVEPOINT {savepoint}")
        raise
