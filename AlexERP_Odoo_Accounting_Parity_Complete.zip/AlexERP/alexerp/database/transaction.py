"""
AlexERP — Business Management System
Database Transaction Manager
"""

from __future__ import annotations

from contextlib import contextmanager
import itertools

from alexerp.database.db import Database


class TransactionError(Exception):
    """Raised when a database transaction fails."""


_savepoint_counter = itertools.count(1)


@contextmanager
def transaction():
    """Atomic transaction with safe nesting on the shared SQLite connection."""
    conn = Database.connect()
    nested = conn.in_transaction
    savepoint = f"alex_sp_{next(_savepoint_counter)}" if nested else None
    try:
        if nested:
            conn.execute(f"SAVEPOINT {savepoint}")
        else:
            # Acquire SQLite's reserved write lock before reading business state.
            # This serializes competing writers and avoids read-then-write races.
            conn.execute("BEGIN IMMEDIATE")
        yield conn
        if nested:
            conn.execute(f"RELEASE SAVEPOINT {savepoint}")
        else:
            conn.commit()
    except Exception as exc:
        if nested:
            conn.execute(f"ROLLBACK TO SAVEPOINT {savepoint}")
            conn.execute(f"RELEASE SAVEPOINT {savepoint}")
        else:
            conn.rollback()
        raise TransactionError(str(exc)) from exc
