"""
AlexERP — Business Management System
Database Seed
"""

from __future__ import annotations

import os
import sys

from alexerp.database.auth import PasswordManager
from alexerp.database.transaction import transaction


def seed_database() -> None:
    """
    Insert default data.
    """

    configured_password = os.environ.get("ALEXERP_INITIAL_ADMIN_PASSWORD", "").strip()
    initial_password = configured_password or "admin"  # Development/demo default requested for this distribution.
    password = PasswordManager.hash_password(initial_password)

    with transaction() as conn:

        cursor = conn.cursor()

        # =====================================================
        # COMPANY
        # =====================================================

        cursor.execute("""

        INSERT OR IGNORE INTO companies(

            id,
            code,
            name

        )

        VALUES(

            1,
            'COMP001',
            'AlexERP'

        )

        """)

        # =====================================================
        # BRANCH
        # =====================================================

        cursor.execute("""

        INSERT OR IGNORE INTO branches(

            id,
            company_id,
            code,
            name

        )

        VALUES(

            1,
            1,
            'MAIN',
            'Main Branch'

        )

        """)

        # =====================================================
        # ROLE
        # =====================================================

        cursor.execute("""

        INSERT OR IGNORE INTO roles(

            id,
            code,
            name,
            is_system

        )

        VALUES(

            1,
            'ADMIN',
            'Administrator',
            1

        )

        """)

        # =====================================================
        # DEFAULT PERMISSION CATALOG
        # =====================================================
        default_permissions = [
            ("dashboard", "dashboard.view", "View dashboard"),
            ("products", "products.view", "View products"),
            ("products", "products.create", "Create products"),
            ("products", "products.update", "Update products"),
            ("products", "products.delete", "Delete products"),
            ("inventory", "inventory.adjust", "Adjust inventory quantities"),
            ("customers", "customers.view", "View customers"),
            ("customers", "customers.create", "Create customers"),
            ("customers", "customers.update", "Update customers"),
            ("customers", "customers.delete", "Delete customers"),
            ("customers", "customers.credit_limit.override", "Override customer credit limits"),
            ("customers", "customers.notes.view", "View customer financial notes"),
            ("customers", "customers.notes.create", "Create customer financial notes"),
            ("customers", "customers.notes.cancel", "Cancel customer financial notes"),
            ("suppliers", "suppliers.view", "View suppliers"),
            ("suppliers", "suppliers.create", "Create suppliers"),
            ("suppliers", "suppliers.update", "Update suppliers"),
            ("suppliers", "suppliers.delete", "Delete suppliers"),
            ("parties", "parties.payment_terms.manage", "Manage customer and supplier payment terms"),
            ("sales", "sales.view", "View sales"),
            ("sales", "sales.create", "Create sales"),
            ("sales", "sales.cancel", "Cancel sales invoices"),
            ("sales", "sales.return", "Create sales returns"),
            ("sales", "sales.delivery.update", "Update sales delivery status"),
            ("sales", "sales.delivery.create", "Create sales delivery documents"),
            ("sales", "sales.delivery.post", "Post sales delivery documents"),
            ("sales", "sales.confirm", "Confirm sales quotations into orders"),
            ("sales", "sales.invoice_from_order", "Create invoices from sales orders"),
            ("purchases", "purchases.view", "View purchases"),
            ("purchases", "purchases.create", "Create purchases"),
            ("purchases", "purchases.cancel", "Cancel purchase invoices"),
            ("purchases", "purchases.approve", "Approve purchase orders"),
            ("purchases", "purchases.receive", "Receive goods against purchase orders"),
            ("purchases", "purchases.match", "Match purchase invoices to purchase orders"),
            ("purchases", "purchases.workflow.manage", "Manage purchase approval workflows"),
            ("receipts", "receipts.view", "View receipts"),
            ("receipts", "receipts.create", "Create receipts"),
            ("receipts", "receipts.cancel", "Cancel receipts"),
            ("payments", "payments.view", "View supplier payments"),
            ("payments", "payments.create", "Create supplier payments"),
            ("payments", "payments.cancel", "Cancel supplier payments"),
            ("reports", "reports.view", "View financial reports"),
            ("accounts", "accounts.view", "View accounts"),
            ("ai", "ai.use", "Use AI assistant"),
            ("security", "security.roles.manage", "Manage roles and permissions"),
            ("security", "security.users.manage", "Manage users"),
            ("security", "security.audit.view", "View security and administrative audit trail"),
            ("companies", "companies.manage", "Manage company records"),
            ("backup", "backup.view", "View and verify database backups"),
            ("backup", "backup.manage", "Create, restore and delete database backups"),
            ("accounting", "accounting.periods.manage", "Manage and close accounting periods"),
            ("accounting", "accounting.fiscal_year.close", "Close fiscal years and transfer net income"),
        ]
        for module, key, name in default_permissions:
            cursor.execute(
                "INSERT OR IGNORE INTO permissions(module, permission_key, permission_name) VALUES(?,?,?)",
                (module, key, name),
            )

        # =====================================================
        # ADMIN ROLE GRANTS ALL CURRENT PERMISSIONS
        # =====================================================
        cursor.execute("""
            INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
            SELECT 1, id FROM permissions
        """)

        # =====================================================
        # ADMIN USER
        # =====================================================

        cursor.execute("""

        INSERT OR IGNORE INTO users(

            id,
            username,
            password_hash,
            full_name,
            role_id,
            company_id,
            branch_id

        )

        VALUES(

            1,
            'admin',
            ?,
            'Administrator',
            1,
            1,
            1

        )

        """, (password,))
        admin_created = cursor.rowcount == 1
        if admin_created:
            print(
                "Initial admin password for user 'admin': "
                f"{initial_password} (change it immediately; default credentials are unsafe).",
                file=sys.stderr,
            )
        else:
            admin = cursor.execute(
                "SELECT id, password_hash FROM users WHERE username='admin'"
            ).fetchone()
            if admin and PasswordManager.verify_password("1234", admin["password_hash"]):
                cursor.execute(
                    "UPDATE users SET password_hash=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (password, admin["id"]),
                )
                print(
                    "Legacy admin/1234 credential was rotated. Initial admin password "
                    f"for user 'admin': {initial_password} (change it after first login).",
                    file=sys.stderr,
                )

        # =====================================================
        # DEFAULT WAREHOUSE
        # =====================================================

        cursor.execute("""

        INSERT OR IGNORE INTO warehouses(

            id,
            company_id,
            branch_id,
            code,
            name

        )

        VALUES(

            1,
            1,
            1,
            'MAIN',
            'Main Warehouse'

        )

        """)

        # =====================================================
        # PAYMENT METHODS
        # =====================================================

        cursor.execute("""

        INSERT OR IGNORE INTO payment_methods(

            id,
            code,
            name

        )

        VALUES

        (1,'CASH','Cash'),
        (2,'BANK','Bank'),
        (3,'VISA','Visa'),
        (4,'MASTER','Master Card')

        """)

        # =====================================================
        # ACCOUNT TYPES
        # =====================================================

        cursor.execute("""

        INSERT OR IGNORE INTO account_types(

            id,
            code,
            name,
            normal_balance

        )

        VALUES

        (1,'ASSET','Assets','Debit'),
        (2,'LIABILITY','Liabilities','Credit'),
        (3,'EQUITY','Equity','Credit'),
        (4,'REVENUE','Revenue','Credit'),
        (5,'EXPENSE','Expenses','Debit')

        """)

        # =====================================================
        # DEFAULT CHART OF ACCOUNTS
        # =====================================================
        default_accounts = [
            (1, 1, None, 1, '1000', 'الأصول (Assets)', 1, 1, 0),
            (2, 1, 1, 1, '1101', 'النقدية بالصندوق (Cash)', 2, 0, 1),
            (3, 1, 1, 1, '1102', 'البنك (Bank)', 2, 0, 1),
            (4, 1, 1, 1, '1201', 'العملاء / الذمم المدينة (Accounts Receivable)', 2, 0, 1),
            (5, 1, 1, 1, '1301', 'المخزون (Inventory)', 2, 0, 1),
            (6, 1, None, 2, '2000', 'الالتزامات (Liabilities)', 1, 1, 0),
            (7, 1, 6, 2, '2101', 'الموردون / الذمم الدائنة (Accounts Payable)', 2, 0, 1),
            (8, 1, 6, 2, '2201', 'ضريبة القيمة المضافة (VAT Payable/Input)', 2, 0, 1),
            (9, 1, None, 3, '3000', 'حقوق الملكية (Equity)', 1, 1, 0),
            (10, 1, 9, 3, '3101', 'رأس المال (Capital)', 2, 0, 1),
            (11, 1, None, 4, '4000', 'الإيرادات (Revenue)', 1, 1, 0),
            (12, 1, 11, 4, '4101', 'إيرادات المبيعات (Sales Revenue)', 2, 0, 1),
            (13, 1, None, 5, '5000', 'المصروفات والتكاليف (Expenses)', 1, 1, 0),
            (14, 1, 13, 5, '5101', 'تكلفة البضاعة المباعة (COGS)', 2, 0, 1),
            (15, 1, 13, 5, '5201', 'فروق الجرد والتسويات (Inventory Adjustments)', 2, 0, 1),
        ]
        cursor.executemany("""
        INSERT OR IGNORE INTO chart_of_accounts(
            id, company_id, parent_id, account_type_id,
            account_code, account_name, account_level, is_header, allow_posting
        )
        VALUES(?,?,?,?,?,?,?,?,?)
        """, default_accounts)

        conn.commit()
