"""
AlexERP — Business Management System
Database Helpers
"""

from __future__ import annotations

import sqlite3
from typing import Any, Iterable


def execute(
    cursor: sqlite3.Cursor,
    sql: str,
    parameters: Iterable[Any] | None = None,
) -> None:
    """
    Execute SQL statement.
    """

    if parameters is None:
        cursor.execute(sql)
    else:
        cursor.execute(sql, tuple(parameters))


def executemany(
    cursor: sqlite3.Cursor,
    sql: str,
    values: Iterable[Iterable[Any]],
) -> None:
    """
    Execute many SQL statements.
    """

    cursor.executemany(sql, values)


def create_index(
    cursor: sqlite3.Cursor,
    index_name: str,
    table_name: str,
    columns: str,
    unique: bool = False,
) -> None:
    """
    Create database index.
    """

    unique_sql = "UNIQUE " if unique else ""

    cursor.execute(
        f"""
        CREATE {unique_sql}INDEX IF NOT EXISTS {index_name}
        ON {table_name}({columns})
        """
    )


def drop_table(
    cursor: sqlite3.Cursor,
    table_name: str,
) -> None:
    """
    Drop table if exists.
    """

    cursor.execute(
        f"DROP TABLE IF EXISTS {table_name}"
    )


def table_exists(
    cursor: sqlite3.Cursor,
    table_name: str,
) -> bool:
    """
    Check if table exists.
    """

    cursor.execute(
        """
        SELECT name
        FROM sqlite_master
        WHERE type='table'
        AND name=?
        """,
        (table_name,),
    )

    return cursor.fetchone() is not None