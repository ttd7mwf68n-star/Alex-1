"""
AlexERP — Business Management System
System Database Schema
"""

from __future__ import annotations

import sqlite3


def create_system_tables(cursor: sqlite3.Cursor) -> None:
    """
    Create system tables.
    """

    # ==========================================================
    # COMPANIES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS companies(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT NOT NULL UNIQUE,

        name TEXT NOT NULL,

        commercial_name TEXT,

        tax_number TEXT,

        commercial_register TEXT,

        phone TEXT,

        mobile TEXT,

        email TEXT,

        website TEXT,

        address TEXT,

        city TEXT,

        country TEXT,

        logo TEXT,

        currency_code TEXT DEFAULT 'EGP',

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_companies_code
    ON companies(code)
    """)

    # ==========================================================
    # BRANCHES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS branches(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER NOT NULL,

        code TEXT NOT NULL,

        name TEXT NOT NULL,

        phone TEXT,

        email TEXT,

        address TEXT,

        manager_name TEXT,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id)
        ON DELETE CASCADE

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_branch_company_code
    ON branches(company_id,code)
    """)

    # ==========================================================
    # DEPARTMENTS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS departments(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        branch_id INTEGER,

        code TEXT,

        name TEXT NOT NULL,

        description TEXT,

        is_active INTEGER DEFAULT 1,

        FOREIGN KEY(branch_id)
        REFERENCES branches(id)

    )
    """)

    # ==========================================================
    # CURRENCIES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS currencies(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT UNIQUE,

        name TEXT,

        symbol TEXT,

        exchange_rate REAL DEFAULT 1,

        is_default INTEGER DEFAULT 0,

        is_active INTEGER DEFAULT 1

    )
    """)

    # ==========================================================
    # FISCAL YEARS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS fiscal_years(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        name TEXT,

        start_date DATE,

        end_date DATE,

        is_closed INTEGER DEFAULT 0,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)

    # ==========================================================
    # SYSTEM SETTINGS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS system_settings(

        setting_key TEXT PRIMARY KEY,

        setting_value TEXT,

        description TEXT,

        updated_at TIMESTAMP

    )
    """)

    # ==========================================================
    # LANGUAGES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS languages(

        code TEXT PRIMARY KEY,

        name TEXT,

        is_default INTEGER DEFAULT 0

    )
    """)