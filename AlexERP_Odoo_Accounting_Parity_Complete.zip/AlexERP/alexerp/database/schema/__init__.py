"""
AlexERP — Business Management System
Database Schema Manager
"""

from __future__ import annotations

from alexerp.database.transaction import transaction

from alexerp.database.schema.system import create_system_tables
from alexerp.database.schema.security import create_security_tables
from alexerp.database.schema.inventory import create_inventory_tables
from alexerp.database.schema.accounting import create_accounting_tables
from alexerp.database.schema.sales import create_sales_tables
from alexerp.database.schema.purchases import create_purchase_tables
from alexerp.database.schema.cash_bank_schema import create_cash_tables
from alexerp.database.schema.receipts_payments_schema import create_receipts_payments_tables
from alexerp.database.inventory_migrations import migrate_inventory_schema


def create_database() -> None:
    """
    Create complete database.
    """

    with transaction() as conn:

        cursor = conn.cursor()

        # ============================================
        # SYSTEM
        # ============================================

        create_system_tables(cursor)

        # ============================================
        # SECURITY
        # ============================================

        create_security_tables(cursor)

        # ============================================
        # INVENTORY
        # ============================================

        create_inventory_tables(cursor)

        # ============================================
        # ACCOUNTING
        # ============================================

        create_accounting_tables(cursor)

        # ============================================
        # SALES
        # ============================================

        create_sales_tables(cursor)

        # ============================================
        # PURCHASES
        # ============================================

        create_purchase_tables(cursor)

        create_cash_tables(cursor)

        create_receipts_payments_tables(cursor)

        # Create/migrate warehouse-level stock balances without discarding legacy quantities.
        migrate_inventory_schema(conn)
        conn.commit()
