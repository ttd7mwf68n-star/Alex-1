"""
AlexERP — Business Management System
Purchasing Database Schema
"""

from __future__ import annotations

import sqlite3


def create_purchase_tables(cursor: sqlite3.Cursor) -> None:
    """
    Create purchasing tables.
    """

    # ==========================================================
    # SUPPLIERS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS suppliers(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        code TEXT NOT NULL,

        name TEXT NOT NULL,

        tax_number TEXT,

        phone TEXT,

        mobile TEXT,

        email TEXT,

        address TEXT,

        city TEXT,

        current_balance NUMERIC DEFAULT 0,

        account_id INTEGER,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(account_id)
        REFERENCES chart_of_accounts(id)

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_supplier_code
    ON suppliers(company_id,code)
    """)

    # Phase 12: default supplier payment terms (safe for existing databases).
    supplier_columns = {row[1] for row in cursor.execute("PRAGMA table_info(suppliers)").fetchall()}
    if "payment_terms_days" not in supplier_columns:
        cursor.execute("ALTER TABLE suppliers ADD COLUMN payment_terms_days INTEGER NOT NULL DEFAULT 0")

    # ==========================================================
    # PURCHASE INVOICES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS purchase_invoices(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        branch_id INTEGER,

        supplier_id INTEGER NOT NULL,

        invoice_number TEXT NOT NULL,

        supplier_invoice_number TEXT,

        invoice_date DATE NOT NULL,

        subtotal NUMERIC DEFAULT 0,

        discount NUMERIC DEFAULT 0,

        tax NUMERIC DEFAULT 0,

        total NUMERIC DEFAULT 0,

        paid_amount NUMERIC DEFAULT 0,

        remaining_amount NUMERIC DEFAULT 0,

        status TEXT DEFAULT 'Draft',

        notes TEXT,

        created_by INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id),

        FOREIGN KEY(supplier_id)
        REFERENCES suppliers(id),

        FOREIGN KEY(created_by)
        REFERENCES users(id)

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_purchase_invoice_number
    ON purchase_invoices(company_id,invoice_number)
    """)

    # Preserve the terms agreed when each purchase invoice was recorded.
    purchase_invoice_columns = {row[1] for row in cursor.execute("PRAGMA table_info(purchase_invoices)").fetchall()}
    if "payment_terms_days" not in purchase_invoice_columns:
        cursor.execute("ALTER TABLE purchase_invoices ADD COLUMN payment_terms_days INTEGER NOT NULL DEFAULT 0")
    if "due_date" not in purchase_invoice_columns:
        cursor.execute("ALTER TABLE purchase_invoices ADD COLUMN due_date DATE")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_purchase_invoice_due_date ON purchase_invoices(company_id, due_date)")

    # ==========================================================
    # PURCHASE INVOICE ITEMS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS purchase_invoice_items(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        invoice_id INTEGER NOT NULL,

        product_id INTEGER NOT NULL,

        warehouse_id INTEGER,

        quantity NUMERIC NOT NULL,

        unit_cost NUMERIC NOT NULL,

        discount NUMERIC DEFAULT 0,

        tax NUMERIC DEFAULT 0,

        total NUMERIC DEFAULT 0,

        FOREIGN KEY(invoice_id)
        REFERENCES purchase_invoices(id)
        ON DELETE CASCADE,

        FOREIGN KEY(product_id)
        REFERENCES products(id),

        FOREIGN KEY(warehouse_id)
        REFERENCES warehouses(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_purchase_items_invoice
    ON purchase_invoice_items(invoice_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_purchase_items_product
    ON purchase_invoice_items(product_id)
    """)

    # ==========================================================
    # PURCHASE RETURNS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS purchase_returns(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        purchase_invoice_id INTEGER,

        supplier_id INTEGER,

        return_number TEXT,

        return_date DATE,

        total NUMERIC DEFAULT 0,

        notes TEXT,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(purchase_invoice_id)
        REFERENCES purchase_invoices(id),

        FOREIGN KEY(supplier_id)
        REFERENCES suppliers(id)

    )
    """)

    # ==========================================================
    # PURCHASE RETURN ITEMS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS purchase_return_items(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        return_id INTEGER,

        product_id INTEGER,

        quantity NUMERIC,

        unit_cost NUMERIC,

        total NUMERIC,

        FOREIGN KEY(return_id)
        REFERENCES purchase_returns(id)
        ON DELETE CASCADE,

        FOREIGN KEY(product_id)
        REFERENCES products(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_purchase_return_product
    ON purchase_return_items(product_id)
    """)





    # ==========================================================
    # PURCHASING WORKFLOW (Phase 15)
    # ==========================================================
    workflow_sql = """
    CREATE TABLE IF NOT EXISTS purchase_requisitions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        requisition_number TEXT NOT NULL,
        request_date DATE NOT NULL,
        requested_by INTEGER,
        status TEXT NOT NULL DEFAULT 'OPEN',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(company_id, requisition_number),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(requested_by) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS purchase_requisition_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        requisition_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        warehouse_id INTEGER NOT NULL,
        quantity NUMERIC NOT NULL CHECK(quantity > 0),
        notes TEXT,
        FOREIGN KEY(requisition_id) REFERENCES purchase_requisitions(id) ON DELETE CASCADE,
        FOREIGN KEY(product_id) REFERENCES products(id),
        FOREIGN KEY(warehouse_id) REFERENCES warehouses(id)
    );
    CREATE TABLE IF NOT EXISTS purchase_orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        supplier_id INTEGER NOT NULL,
        requisition_id INTEGER,
        order_number TEXT NOT NULL,
        order_date DATE NOT NULL,
        expected_date DATE,
        status TEXT NOT NULL DEFAULT 'OPEN',
        notes TEXT,
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(company_id, order_number),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(supplier_id) REFERENCES suppliers(id),
        FOREIGN KEY(requisition_id) REFERENCES purchase_requisitions(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS purchase_order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        warehouse_id INTEGER NOT NULL,
        ordered_quantity NUMERIC NOT NULL CHECK(ordered_quantity > 0),
        received_quantity NUMERIC NOT NULL DEFAULT 0 CHECK(received_quantity >= 0),
        unit_cost NUMERIC NOT NULL CHECK(unit_cost >= 0),
        discount NUMERIC NOT NULL DEFAULT 0,
        tax NUMERIC NOT NULL DEFAULT 0,
        FOREIGN KEY(order_id) REFERENCES purchase_orders(id) ON DELETE CASCADE,
        FOREIGN KEY(product_id) REFERENCES products(id),
        FOREIGN KEY(warehouse_id) REFERENCES warehouses(id)
    );
    CREATE TABLE IF NOT EXISTS purchase_receipts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        order_id INTEGER NOT NULL,
        receipt_number TEXT NOT NULL,
        receipt_date DATE NOT NULL,
        received_by INTEGER,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(company_id, receipt_number),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(order_id) REFERENCES purchase_orders(id),
        FOREIGN KEY(received_by) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS purchase_receipt_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receipt_id INTEGER NOT NULL,
        order_item_id INTEGER NOT NULL,
        quantity NUMERIC NOT NULL CHECK(quantity > 0),
        FOREIGN KEY(receipt_id) REFERENCES purchase_receipts(id) ON DELETE CASCADE,
        FOREIGN KEY(order_item_id) REFERENCES purchase_order_items(id)
    );
    CREATE TABLE IF NOT EXISTS supplier_quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        supplier_id INTEGER NOT NULL,
        quote_number TEXT NOT NULL,
        quote_date DATE NOT NULL,
        valid_until DATE,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(company_id, quote_number),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
    );
    CREATE TABLE IF NOT EXISTS supplier_quote_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity NUMERIC NOT NULL CHECK(quantity > 0),
        unit_cost NUMERIC NOT NULL CHECK(unit_cost >= 0),
        delivery_days INTEGER NOT NULL DEFAULT 0 CHECK(delivery_days >= 0),
        FOREIGN KEY(quote_id) REFERENCES supplier_quotes(id) ON DELETE CASCADE,
        FOREIGN KEY(product_id) REFERENCES products(id)
    );
    CREATE INDEX IF NOT EXISTS idx_purchase_orders_scope_date ON purchase_orders(company_id, branch_id, order_date);
    CREATE INDEX IF NOT EXISTS idx_purchase_receipts_order ON purchase_receipts(order_id, receipt_date);
    CREATE INDEX IF NOT EXISTS idx_purchase_quotes_scope ON supplier_quotes(company_id, supplier_id, quote_date);
    """
    for statement in workflow_sql.split(";"):
        if statement.strip():
            cursor.execute(statement)

    # Phase 16: explicit approval metadata and relational PO/invoice matching.
    po_columns = {row[1] for row in cursor.execute("PRAGMA table_info(purchase_orders)").fetchall()}
    for name, declaration in (
        ("approval_status", "TEXT NOT NULL DEFAULT 'APPROVED'"),
        ("approved_by", "INTEGER"),
        ("approved_at", "TIMESTAMP"),
        ("approval_notes", "TEXT"),
    ):
        if name not in po_columns:
            cursor.execute(f"ALTER TABLE purchase_orders ADD COLUMN {name} {declaration}")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS purchase_order_invoice_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        order_id INTEGER NOT NULL,
        order_item_id INTEGER NOT NULL,
        invoice_id INTEGER NOT NULL,
        invoice_item_id INTEGER NOT NULL,
        matched_quantity NUMERIC NOT NULL CHECK(matched_quantity > 0),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(invoice_item_id, order_item_id),
        FOREIGN KEY(order_id) REFERENCES purchase_orders(id),
        FOREIGN KEY(order_item_id) REFERENCES purchase_order_items(id),
        FOREIGN KEY(invoice_id) REFERENCES purchase_invoices(id),
        FOREIGN KEY(invoice_item_id) REFERENCES purchase_invoice_items(id)
    )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_po_invoice_links_order ON purchase_order_invoice_links(company_id,order_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_po_invoice_links_invoice ON purchase_order_invoice_links(company_id,invoice_id)")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS approval_workflows (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        entity_type TEXT NOT NULL DEFAULT 'purchase_order' CHECK(entity_type='purchase_order'),
        name TEXT NOT NULL,
        min_amount NUMERIC NOT NULL DEFAULT 0 CHECK(min_amount >= 0),
        max_amount NUMERIC CHECK(max_amount IS NULL OR max_amount > min_amount),
        is_active INTEGER NOT NULL DEFAULT 1,
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP,
        UNIQUE(company_id, name),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS approval_workflow_steps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workflow_id INTEGER NOT NULL,
        step_order INTEGER NOT NULL CHECK(step_order > 0),
        role_id INTEGER NOT NULL,
        UNIQUE(workflow_id, step_order),
        FOREIGN KEY(workflow_id) REFERENCES approval_workflows(id) ON DELETE CASCADE,
        FOREIGN KEY(role_id) REFERENCES roles(id)
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS purchase_order_approval_steps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        workflow_id INTEGER NOT NULL,
        step_order INTEGER NOT NULL CHECK(step_order > 0),
        role_id INTEGER NOT NULL,
        approval_status TEXT NOT NULL DEFAULT 'PENDING'
            CHECK(approval_status IN ('PENDING','APPROVED','REJECTED')),
        acted_by INTEGER,
        acted_at TIMESTAMP,
        notes TEXT,
        UNIQUE(order_id, step_order),
        FOREIGN KEY(order_id) REFERENCES purchase_orders(id) ON DELETE CASCADE,
        FOREIGN KEY(workflow_id) REFERENCES approval_workflows(id),
        FOREIGN KEY(role_id) REFERENCES roles(id),
        FOREIGN KEY(acted_by) REFERENCES users(id)
    )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_approval_workflows_company_active ON approval_workflows(company_id,is_active)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_po_approval_steps_order ON purchase_order_approval_steps(order_id,step_order)")
