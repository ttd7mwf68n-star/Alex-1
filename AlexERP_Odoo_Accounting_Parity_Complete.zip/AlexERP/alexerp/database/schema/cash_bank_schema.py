"""
AlexERP — Business Management System
Cash & Bank Database Schema
"""

from __future__ import annotations

import sqlite3


def create_cash_tables(cursor: sqlite3.Cursor):

    # ==========================================================
    # CASH BOXES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS cash_boxes(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER NOT NULL,

        branch_id INTEGER NOT NULL,

        code TEXT NOT NULL,

        name TEXT NOT NULL,

        account_id INTEGER NOT NULL,

        current_balance REAL DEFAULT 0,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id),

        FOREIGN KEY(account_id)
        REFERENCES chart_of_accounts(id)

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_cashbox_code
    ON cash_boxes(company_id,code)
    """)

    # ==========================================================
    # BANK ACCOUNTS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS bank_accounts(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        bank_name TEXT,

        account_name TEXT,

        account_number TEXT,

        iban TEXT,

        swift TEXT,

        account_id INTEGER,

        current_balance REAL DEFAULT 0,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(account_id)
        REFERENCES chart_of_accounts(id)

    )
    """)