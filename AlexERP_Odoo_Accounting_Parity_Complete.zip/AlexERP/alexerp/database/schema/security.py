"""
AlexERP — Business Management System
Security Database Schema
"""

from __future__ import annotations

import sqlite3


def create_security_tables(cursor: sqlite3.Cursor) -> None:
    """
    Create all security-related database tables.
    """

    # ==========================================================
    # ROLES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS roles (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT NOT NULL UNIQUE,

        name TEXT NOT NULL,

        description TEXT,

        is_system INTEGER NOT NULL DEFAULT 0,

        is_active INTEGER NOT NULL DEFAULT 1,

        company_id INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id) REFERENCES companies(id)

    )
    """)

    # Backward-compatible migration: custom roles become company-scoped.
    role_columns = {row[1] for row in cursor.execute("PRAGMA table_info(roles)").fetchall()}
    if "company_id" not in role_columns:
        cursor.execute("ALTER TABLE roles ADD COLUMN company_id INTEGER")

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_roles_code
    ON roles(code)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_roles_name
    ON roles(name)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_roles_company
    ON roles(company_id)
    """)

    # ==========================================================
    # PERMISSIONS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS permissions (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        module TEXT NOT NULL,

        permission_key TEXT NOT NULL UNIQUE,

        permission_name TEXT NOT NULL,

        description TEXT,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_permissions_module
    ON permissions(module)
    """)

    # ==========================================================
    # ROLE PERMISSIONS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS role_permissions (

        role_id INTEGER NOT NULL,

        permission_id INTEGER NOT NULL,

        PRIMARY KEY(role_id, permission_id),

        FOREIGN KEY(role_id)
        REFERENCES roles(id)
        ON DELETE CASCADE,

        FOREIGN KEY(permission_id)
        REFERENCES permissions(id)
        ON DELETE CASCADE

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_role_permissions_role
    ON role_permissions(role_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_role_permissions_permission
    ON role_permissions(permission_id)
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS role_field_policies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_id INTEGER NOT NULL,
        entity_type TEXT NOT NULL,
        field_key TEXT NOT NULL,
        access_level TEXT NOT NULL CHECK(access_level IN ('READ_WRITE','READ_ONLY','HIDDEN')),
        UNIQUE(role_id, entity_type, field_key),
        FOREIGN KEY(role_id) REFERENCES roles(id) ON DELETE CASCADE
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS role_record_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_id INTEGER NOT NULL,
        entity_type TEXT NOT NULL,
        effect TEXT NOT NULL CHECK(effect IN ('ALLOW','DENY')),
        field_key TEXT NOT NULL,
        operator TEXT NOT NULL CHECK(operator IN ('EQ','NE','GT','GTE','LT','LTE')),
        value TEXT NOT NULL,
        FOREIGN KEY(role_id) REFERENCES roles(id) ON DELETE CASCADE
    )
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_role_field_policies_role_entity
    ON role_field_policies(role_id, entity_type)
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_role_record_rules_role_entity
    ON role_record_rules(role_id, entity_type)
    """)

    # ==========================================================
    # USERS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        username TEXT NOT NULL UNIQUE,

        password_hash TEXT NOT NULL,

        full_name TEXT NOT NULL,

        email TEXT UNIQUE,

        phone TEXT,

        role_id INTEGER,

        company_id INTEGER,

        branch_id INTEGER,

        is_active INTEGER NOT NULL DEFAULT 1,

        failed_login_attempts INTEGER NOT NULL DEFAULT 0,

        locked_until TIMESTAMP,

        password_changed_at TIMESTAMP,

        last_login TIMESTAMP,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(role_id)
        REFERENCES roles(id),

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_users_username
    ON users(username)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_users_role
    ON users(role_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_users_company
    ON users(company_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_users_branch
    ON users(branch_id)
    """)

    # ==========================================================
    # USER PREFERENCES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_preferences (

        user_id INTEGER PRIMARY KEY,

        language TEXT DEFAULT 'ar',

        theme TEXT DEFAULT 'dark',

        date_format TEXT DEFAULT 'dd/MM/yyyy',

        time_format TEXT DEFAULT '24',

        currency_code TEXT DEFAULT 'EGP',

        dashboard_layout TEXT,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(user_id)
        REFERENCES users(id)
        ON DELETE CASCADE

    )
    """)

    # ==========================================================
    # USER SESSIONS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_sessions (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER NOT NULL,

        session_token TEXT NOT NULL UNIQUE,

        login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        logout_time TIMESTAMP,

        expires_at TIMESTAMP,

        ip_address TEXT,

        device TEXT,

        is_active INTEGER NOT NULL DEFAULT 1,

        FOREIGN KEY(user_id)
        REFERENCES users(id)
        ON DELETE CASCADE

    )
    """)

    session_columns = {row[1] for row in cursor.execute("PRAGMA table_info(user_sessions)").fetchall()}
    if "expires_at" not in session_columns:
        cursor.execute("ALTER TABLE user_sessions ADD COLUMN expires_at TIMESTAMP")

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_sessions_user
    ON user_sessions(user_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_sessions_token
    ON user_sessions(session_token)
    """)

    # ==========================================================
    # AUDIT LOGS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_logs (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER,

        module TEXT NOT NULL,

        action TEXT NOT NULL,

        record_id INTEGER,

        description TEXT,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(user_id)
        REFERENCES users(id)
        ON DELETE SET NULL

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_audit_user
    ON audit_logs(user_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_audit_module
    ON audit_logs(module)
    """)

    # Additive audit metadata migration. Existing audit rows are preserved.
    audit_columns = {row[1] for row in cursor.execute("PRAGMA table_info(audit_logs)").fetchall()}
    for column, declaration in (
        ("company_id", "INTEGER"),
        ("branch_id", "INTEGER"),
        ("entity_type", "TEXT"),
        ("before_json", "TEXT"),
        ("after_json", "TEXT"),
        ("ip_address", "TEXT"),
        ("request_id", "TEXT"),
    ):
        if column not in audit_columns:
            cursor.execute(f"ALTER TABLE audit_logs ADD COLUMN {column} {declaration}")

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_audit_date
    ON audit_logs(created_at)
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_audit_company_date
    ON audit_logs(company_id, created_at)
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_audit_entity
    ON audit_logs(entity_type, record_id)
    """)
