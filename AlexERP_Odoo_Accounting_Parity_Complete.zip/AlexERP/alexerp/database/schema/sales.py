"""
AlexERP — Business Management System
Sales Database Schema
"""

from __future__ import annotations

import sqlite3


def create_sales_tables(cursor: sqlite3.Cursor) -> None:
    """
    Create sales tables.
    """

    # ==========================================================
    # CUSTOMERS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customers(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        code TEXT NOT NULL,

        name TEXT NOT NULL,

        tax_number TEXT,

        phone TEXT,

        mobile TEXT,

        email TEXT,

        address TEXT,

        city TEXT,

        credit_limit NUMERIC DEFAULT 0,

        current_balance NUMERIC DEFAULT 0,

        account_id INTEGER,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(account_id)
        REFERENCES chart_of_accounts(id)

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_customer_code
    ON customers(company_id,code)
    """)

    # Phase 12: default customer payment terms (safe for existing databases).
    customer_columns = {row[1] for row in cursor.execute("PRAGMA table_info(customers)").fetchall()}
    if "payment_terms_days" not in customer_columns:
        cursor.execute("ALTER TABLE customers ADD COLUMN payment_terms_days INTEGER NOT NULL DEFAULT 0")

    # ==========================================================
    # SALES INVOICES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_invoices(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        branch_id INTEGER,

        customer_id INTEGER NOT NULL,

        invoice_number TEXT NOT NULL,

        invoice_date DATE NOT NULL,

        subtotal NUMERIC DEFAULT 0,

        discount NUMERIC DEFAULT 0,

        tax NUMERIC DEFAULT 0,

        total NUMERIC DEFAULT 0,

        paid_amount NUMERIC DEFAULT 0,

        remaining_amount NUMERIC DEFAULT 0,

        status TEXT DEFAULT 'Draft',

        notes TEXT,

        created_by INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id),

        FOREIGN KEY(customer_id)
        REFERENCES customers(id),

        FOREIGN KEY(created_by)
        REFERENCES users(id)

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_invoice_number
    ON sales_invoices(company_id,invoice_number)
    """)

    # Snapshot terms and due date on each invoice so later customer changes do
    # not rewrite the contractual terms of already-issued documents.
    sales_invoice_columns = {row[1] for row in cursor.execute("PRAGMA table_info(sales_invoices)").fetchall()}
    if "payment_terms_days" not in sales_invoice_columns:
        cursor.execute("ALTER TABLE sales_invoices ADD COLUMN payment_terms_days INTEGER NOT NULL DEFAULT 0")
    if "due_date" not in sales_invoice_columns:
        cursor.execute("ALTER TABLE sales_invoices ADD COLUMN due_date DATE")
    if "delivery_status" not in sales_invoice_columns:
        cursor.execute(
            "ALTER TABLE sales_invoices ADD COLUMN delivery_status TEXT NOT NULL DEFAULT 'PREPARING'"
        )
    if "inventory_policy" not in sales_invoice_columns:
        cursor.execute(
            "ALTER TABLE sales_invoices ADD COLUMN inventory_policy TEXT NOT NULL DEFAULT 'DEDUCT_ON_POST'"
        )
    if "delivery_updated_by" not in sales_invoice_columns:
        cursor.execute("ALTER TABLE sales_invoices ADD COLUMN delivery_updated_by INTEGER")
    if "delivery_updated_at" not in sales_invoice_columns:
        cursor.execute("ALTER TABLE sales_invoices ADD COLUMN delivery_updated_at TIMESTAMP")
    if "delivered_at" not in sales_invoice_columns:
        cursor.execute("ALTER TABLE sales_invoices ADD COLUMN delivered_at TIMESTAMP")
    if "inventory_account_id" not in sales_invoice_columns:
        cursor.execute("ALTER TABLE sales_invoices ADD COLUMN inventory_account_id INTEGER")
    if "cogs_account_id" not in sales_invoice_columns:
        cursor.execute("ALTER TABLE sales_invoices ADD COLUMN cogs_account_id INTEGER")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_invoice_due_date ON sales_invoices(company_id, due_date)")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS company_sales_settings(
        company_id INTEGER PRIMARY KEY,
        inventory_policy TEXT NOT NULL DEFAULT 'DEDUCT_ON_POST'
            CHECK(inventory_policy IN ('DEDUCT_ON_POST','RESERVE_UNTIL_DELIVERY')),
        receivable_account_id INTEGER,
        sales_account_id INTEGER,
        inventory_account_id INTEGER,
        cogs_account_id INTEGER,
        tax_account_id INTEGER,
        cash_account_id INTEGER,
        updated_by INTEGER,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(receivable_account_id) REFERENCES chart_of_accounts(id),
        FOREIGN KEY(sales_account_id) REFERENCES chart_of_accounts(id),
        FOREIGN KEY(inventory_account_id) REFERENCES chart_of_accounts(id),
        FOREIGN KEY(cogs_account_id) REFERENCES chart_of_accounts(id),
        FOREIGN KEY(tax_account_id) REFERENCES chart_of_accounts(id),
        FOREIGN KEY(cash_account_id) REFERENCES chart_of_accounts(id),
        FOREIGN KEY(updated_by) REFERENCES users(id)
    )
    """)

    # ==========================================================
    # SALES INVOICE ITEMS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_invoice_items(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        invoice_id INTEGER NOT NULL,

        product_id INTEGER NOT NULL,

        warehouse_id INTEGER,

        quantity NUMERIC NOT NULL,

        unit_price NUMERIC NOT NULL,

        unit_cost NUMERIC DEFAULT 0,

        discount NUMERIC DEFAULT 0,

        tax NUMERIC DEFAULT 0,

        total NUMERIC DEFAULT 0,

        FOREIGN KEY(invoice_id)
        REFERENCES sales_invoices(id)
        ON DELETE CASCADE,

        FOREIGN KEY(product_id)
        REFERENCES products(id),

        FOREIGN KEY(warehouse_id)
        REFERENCES warehouses(id)

    )
    """)

    # Backward-compatible addition for databases created before stage 2.
    cursor.execute("PRAGMA table_info(sales_invoice_items)")
    sales_item_columns = {row[1] for row in cursor.fetchall()}
    if "unit_cost" not in sales_item_columns:
        cursor.execute("ALTER TABLE sales_invoice_items ADD COLUMN unit_cost NUMERIC DEFAULT 0")

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_sales_items_invoice
    ON sales_invoice_items(invoice_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_sales_items_product
    ON sales_invoice_items(product_id)
    """)

    # ==========================================================
    # SALES RETURNS
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_returns(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER,
        branch_id INTEGER,
        sales_invoice_id INTEGER NOT NULL,
        customer_id INTEGER NOT NULL,
        return_number TEXT NOT NULL,
        return_date DATE NOT NULL,
        total NUMERIC NOT NULL DEFAULT 0,
        notes TEXT,
        status TEXT NOT NULL DEFAULT 'POSTED',
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(sales_invoice_id) REFERENCES sales_invoices(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)
    sales_return_columns = {
        row[1] for row in cursor.execute("PRAGMA table_info(sales_returns)").fetchall()
    }
    for column in ("sales_order_id", "sales_delivery_id"):
        if column not in sales_return_columns:
            cursor.execute(f"ALTER TABLE sales_returns ADD COLUMN {column} INTEGER")
    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_return_number
    ON sales_returns(company_id, return_number)
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_return_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        return_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        warehouse_id INTEGER NOT NULL,
        quantity NUMERIC NOT NULL,
        unit_cost NUMERIC NOT NULL DEFAULT 0,
        total NUMERIC NOT NULL DEFAULT 0,
        sales_delivery_item_id INTEGER,
        sales_invoice_item_id INTEGER,
        sales_order_item_id INTEGER,
        FOREIGN KEY(return_id) REFERENCES sales_returns(id) ON DELETE CASCADE,
        FOREIGN KEY(product_id) REFERENCES products(id),
        FOREIGN KEY(warehouse_id) REFERENCES warehouses(id)
    )
    """)
    sales_return_item_columns = {
        row[1] for row in cursor.execute("PRAGMA table_info(sales_return_items)").fetchall()
    }
    for column in (
        "sales_delivery_item_id", "sales_invoice_item_id", "sales_order_item_id"
    ):
        if column not in sales_return_item_columns:
            cursor.execute(f"ALTER TABLE sales_return_items ADD COLUMN {column} INTEGER")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_return_items_return ON sales_return_items(return_id)")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customer_financial_notes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER NOT NULL,
        customer_id INTEGER NOT NULL,
        sales_invoice_id INTEGER NOT NULL,
        note_number TEXT NOT NULL,
        note_type TEXT NOT NULL CHECK(note_type IN ('DEBIT','CREDIT')),
        note_date DATE NOT NULL,
        amount NUMERIC NOT NULL CHECK(CAST(amount AS REAL)>0),
        counter_account_id INTEGER NOT NULL,
        description TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'POSTED',
        created_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        cancelled_at TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(sales_invoice_id) REFERENCES sales_invoices(id),
        FOREIGN KEY(counter_account_id) REFERENCES chart_of_accounts(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)
    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_customer_financial_note_number
    ON customer_financial_notes(company_id, note_number)
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_customer_financial_note_invoice
    ON customer_financial_notes(company_id, sales_invoice_id, status)
    """)



    # ==========================================================
    # SALES QUOTATIONS / SALES ORDERS (Phase 9)
    # A quotation becomes the sales order on confirmation. The same
    # immutable commercial lines are retained throughout the lifecycle.
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER NOT NULL,
        customer_id INTEGER NOT NULL,
        quotation_number TEXT NOT NULL,
        order_number TEXT,
        document_date DATE NOT NULL,
        expiry_date DATE,
        status TEXT NOT NULL DEFAULT 'DRAFT'
            CHECK(status IN ('DRAFT','SENT','CONFIRMED','PARTIALLY_INVOICED','INVOICED','CANCELLED','EXPIRED')),
        subtotal NUMERIC NOT NULL DEFAULT 0,
        discount NUMERIC NOT NULL DEFAULT 0,
        tax NUMERIC NOT NULL DEFAULT 0,
        total NUMERIC NOT NULL DEFAULT 0,
        notes TEXT,
        created_by INTEGER NOT NULL,
        confirmed_by INTEGER,
        confirmed_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(created_by) REFERENCES users(id),
        FOREIGN KEY(confirmed_by) REFERENCES users(id)
    )
    """)
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_order_quote_number ON sales_orders(company_id, quotation_number)")
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_order_order_number ON sales_orders(company_id, order_number) WHERE order_number IS NOT NULL")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_orders_status ON sales_orders(company_id, branch_id, status, document_date)")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_order_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sales_order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        warehouse_id INTEGER NOT NULL,
        quantity NUMERIC NOT NULL CHECK(quantity > 0),
        delivered_quantity NUMERIC NOT NULL DEFAULT 0 CHECK(delivered_quantity >= 0),
        invoiced_quantity NUMERIC NOT NULL DEFAULT 0 CHECK(invoiced_quantity >= 0),
        unit_price NUMERIC NOT NULL CHECK(unit_price >= 0),
        discount NUMERIC NOT NULL DEFAULT 0 CHECK(discount >= 0),
        tax NUMERIC NOT NULL DEFAULT 0 CHECK(tax >= 0),
        line_total NUMERIC NOT NULL CHECK(line_total >= 0),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(sales_order_id) REFERENCES sales_orders(id) ON DELETE RESTRICT,
        FOREIGN KEY(product_id) REFERENCES products(id),
        FOREIGN KEY(warehouse_id) REFERENCES warehouses(id)
    )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_order_items_order ON sales_order_items(sales_order_id, id)")

    # Safe additive migration for existing invoice tables.
    invoice_columns = {row[1] for row in cursor.execute("PRAGMA table_info(sales_invoices)").fetchall()}
    if "sales_order_id" not in invoice_columns:
        cursor.execute("ALTER TABLE sales_invoices ADD COLUMN sales_order_id INTEGER")
    invoice_item_columns = {row[1] for row in cursor.execute("PRAGMA table_info(sales_invoice_items)").fetchall()}
    if "sales_order_item_id" not in invoice_item_columns:
        cursor.execute("ALTER TABLE sales_invoice_items ADD COLUMN sales_order_item_id INTEGER")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_invoice_order ON sales_invoices(sales_order_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_invoice_item_order_line ON sales_invoice_items(sales_order_item_id)")

    # Phase 10: delivery documents are independent from invoices and support
    # partial shipments against posted invoice lines.
    invoice_item_columns = {row[1] for row in cursor.execute("PRAGMA table_info(sales_invoice_items)").fetchall()}
    if "delivered_quantity" not in invoice_item_columns:
        cursor.execute("ALTER TABLE sales_invoice_items ADD COLUMN delivered_quantity NUMERIC NOT NULL DEFAULT 0")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_deliveries(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL, branch_id INTEGER NOT NULL,
        sales_order_id INTEGER NOT NULL, sales_invoice_id INTEGER NOT NULL,
        delivery_number TEXT NOT NULL, delivery_date DATE NOT NULL,
        status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','POSTED','CANCELLED')),
        notes TEXT, created_by INTEGER NOT NULL, posted_by INTEGER,
        posted_at TIMESTAMP, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(sales_order_id) REFERENCES sales_orders(id) ON DELETE RESTRICT,
        FOREIGN KEY(sales_invoice_id) REFERENCES sales_invoices(id) ON DELETE RESTRICT,
        FOREIGN KEY(created_by) REFERENCES users(id), FOREIGN KEY(posted_by) REFERENCES users(id)
    )
    """)
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_delivery_number ON sales_deliveries(company_id, delivery_number)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_delivery_order ON sales_deliveries(company_id, sales_order_id, delivery_date)")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_delivery_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT, delivery_id INTEGER NOT NULL,
        sales_order_item_id INTEGER NOT NULL, sales_invoice_item_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL, warehouse_id INTEGER NOT NULL,
        quantity NUMERIC NOT NULL CHECK(quantity > 0), unit_cost NUMERIC NOT NULL DEFAULT 0,
        returned_quantity NUMERIC NOT NULL DEFAULT 0 CHECK(returned_quantity >= 0),
        FOREIGN KEY(delivery_id) REFERENCES sales_deliveries(id) ON DELETE RESTRICT,
        FOREIGN KEY(sales_order_item_id) REFERENCES sales_order_items(id) ON DELETE RESTRICT,
        FOREIGN KEY(sales_invoice_item_id) REFERENCES sales_invoice_items(id) ON DELETE RESTRICT,
        FOREIGN KEY(product_id) REFERENCES products(id), FOREIGN KEY(warehouse_id) REFERENCES warehouses(id)
    )
    """)
    delivery_item_columns = {
        row[1] for row in cursor.execute("PRAGMA table_info(sales_delivery_items)").fetchall()
    }
    if "returned_quantity" not in delivery_item_columns:
        cursor.execute(
            "ALTER TABLE sales_delivery_items ADD COLUMN returned_quantity NUMERIC NOT NULL DEFAULT 0"
        )
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_delivery_items_delivery ON sales_delivery_items(delivery_id)")
