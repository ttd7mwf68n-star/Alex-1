"""
AlexERP — Business Management System
Accounting Database Schema
"""

from __future__ import annotations

import sqlite3


def create_accounting_tables(cursor: sqlite3.Cursor) -> None:
    """
    Create accounting tables.
    """

    # ==========================================================
    # ACCOUNT TYPES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS account_types(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT NOT NULL UNIQUE,

        name TEXT NOT NULL,

        normal_balance TEXT NOT NULL,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)

    # ==========================================================
    # CHART OF ACCOUNTS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chart_of_accounts(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        parent_id INTEGER,

        account_type_id INTEGER,

        account_code TEXT NOT NULL,

        account_name TEXT NOT NULL,

        account_level INTEGER DEFAULT 1,

        is_header INTEGER DEFAULT 0,

        allow_posting INTEGER DEFAULT 1,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(parent_id)
        REFERENCES chart_of_accounts(id),

        FOREIGN KEY(account_type_id)
        REFERENCES account_types(id)

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_chart_code
    ON chart_of_accounts(company_id,account_code)
    """)

    # ==========================================================
    # COST CENTERS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS cost_centers(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        code TEXT,

        name TEXT,

        is_active INTEGER DEFAULT 1,

        FOREIGN KEY(company_id)
        REFERENCES companies(id)

    )
    """)

    # ==========================================================
    # JOURNAL ENTRIES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS journal_entries(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        branch_id INTEGER,

        entry_number TEXT,

        entry_date DATE,

        description TEXT,

        reference_type TEXT,

        reference_id INTEGER,

        is_posted INTEGER DEFAULT 1,

        created_by INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id),

        FOREIGN KEY(created_by)
        REFERENCES users(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_entry_date
    ON journal_entries(entry_date)
    """)

    # ==========================================================
    # JOURNAL DETAILS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS journal_details(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        journal_entry_id INTEGER NOT NULL,

        account_id INTEGER NOT NULL,

        cost_center_id INTEGER,

        debit NUMERIC DEFAULT 0,

        credit NUMERIC DEFAULT 0,

        description TEXT,

        FOREIGN KEY(journal_entry_id)
        REFERENCES journal_entries(id)
        ON DELETE CASCADE,

        FOREIGN KEY(account_id)
        REFERENCES chart_of_accounts(id),

        FOREIGN KEY(cost_center_id)
        REFERENCES cost_centers(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_journal_account
    ON journal_details(account_id)
    """)

    # ==========================================================
    # COMPANY-SCOPED ACCOUNTING PERIODS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS accounting_periods(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        is_closed INTEGER NOT NULL DEFAULT 0 CHECK(is_closed IN (0, 1)),
        closed_at TIMESTAMP,
        created_by INTEGER NOT NULL,
        closed_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(created_by) REFERENCES users(id),
        FOREIGN KEY(closed_by) REFERENCES users(id),
        CHECK(start_date <= end_date)
    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_accounting_period_company_dates
    ON accounting_periods(company_id, start_date, end_date)
    """)

    # ==========================================================
    # FISCAL YEAR CLOSINGS (idempotent, company-scoped)
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS fiscal_year_closings(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        year_name TEXT NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        retained_earnings_account_id INTEGER NOT NULL,
        closing_entry_id INTEGER,
        net_income NUMERIC NOT NULL DEFAULT 0,
        closed_by INTEGER NOT NULL,
        closed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(company_id, start_date, end_date),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(retained_earnings_account_id) REFERENCES chart_of_accounts(id),
        FOREIGN KEY(closing_entry_id) REFERENCES journal_entries(id),
        FOREIGN KEY(closed_by) REFERENCES users(id),
        CHECK(start_date <= end_date)
    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_fiscal_year_closings_company
    ON fiscal_year_closings(company_id, start_date, end_date)
    """)

    # ==========================================================
    # PAYMENT METHODS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS payment_methods(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT UNIQUE,

        name TEXT,

        is_active INTEGER DEFAULT 1

    )
    """)

    # ==========================================================
    # TAXES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS taxes(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT UNIQUE,

        name TEXT,

        tax_rate NUMERIC DEFAULT 0,

        is_active INTEGER DEFAULT 1

    )
    """)
