from __future__ import annotations

import sqlite3


def create_receipts_payments_tables(cursor: sqlite3.Cursor) -> None:

    # ==========================================================
    # RECEIPTS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS receipts(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        branch_id INTEGER,

        receipt_number TEXT,

        receipt_date DATE,

        customer_id INTEGER,

        cash_box_id INTEGER,

        amount REAL,

        notes TEXT,

        created_by INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT NOT NULL DEFAULT 'POSTED',
        source_sales_invoice_id INTEGER,
        source_type TEXT NOT NULL DEFAULT 'MANUAL',
        FOREIGN KEY(source_sales_invoice_id) REFERENCES sales_invoices(id)

    )
    """)


    # ==========================================================
    # PAYMENTS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS payments(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        branch_id INTEGER,

        payment_number TEXT,

        payment_date DATE,

        supplier_id INTEGER,

        cash_box_id INTEGER,

        amount REAL,

        notes TEXT,

        created_by INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT NOT NULL DEFAULT 'POSTED'

    )
    """)

    # Upgrade databases created by earlier releases without discarding records.
    for table in ("receipts", "payments"):
        columns = {row[1] for row in cursor.execute(f"PRAGMA table_info({table})").fetchall()}
        if "status" not in columns:
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN status TEXT NOT NULL DEFAULT 'POSTED'")
    receipt_columns = {
        row[1] for row in cursor.execute("PRAGMA table_info(receipts)").fetchall()
    }
    if "source_sales_invoice_id" not in receipt_columns:
        cursor.execute("ALTER TABLE receipts ADD COLUMN source_sales_invoice_id INTEGER")
    if "source_type" not in receipt_columns:
        cursor.execute("ALTER TABLE receipts ADD COLUMN source_type TEXT NOT NULL DEFAULT 'MANUAL'")
    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_receipts_source_sales_invoice
    ON receipts(source_sales_invoice_id) WHERE source_sales_invoice_id IS NOT NULL
    """)

    # ==========================================================
    # RECEIPT / PAYMENT ALLOCATIONS TO OPEN INVOICES
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS receipt_allocations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        receipt_id INTEGER NOT NULL,
        sales_invoice_id INTEGER NOT NULL,
        amount NUMERIC NOT NULL CHECK(amount > 0),
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        reversed_at TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(receipt_id) REFERENCES receipts(id),
        FOREIGN KEY(sales_invoice_id) REFERENCES sales_invoices(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_receipt_allocations_receipt
    ON receipt_allocations(receipt_id, status)
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_receipt_allocations_invoice
    ON receipt_allocations(sales_invoice_id, status)
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS payment_allocations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        payment_id INTEGER NOT NULL,
        purchase_invoice_id INTEGER NOT NULL,
        amount NUMERIC NOT NULL CHECK(amount > 0),
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        reversed_at TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(payment_id) REFERENCES payments(id),
        FOREIGN KEY(purchase_invoice_id) REFERENCES purchase_invoices(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_payment_allocations_payment
    ON payment_allocations(payment_id, status)
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_payment_allocations_invoice
    ON payment_allocations(purchase_invoice_id, status)
    """)

    # Protect document numbers at the database layer where legacy data permits.
    # If an older database already contains duplicates, preserve every row and
    # rely on the serialized service-level duplicate check until it is reviewed.
    for table, number_column, index_name in (
        ("receipts", "receipt_number", "ux_receipts_company_branch_number"),
        ("payments", "payment_number", "ux_payments_company_branch_number"),
    ):
        duplicates = cursor.execute(
            f"SELECT 1 FROM {table} WHERE {number_column} IS NOT NULL "
            f"GROUP BY company_id, branch_id, {number_column} HAVING COUNT(*) > 1 LIMIT 1"
        ).fetchone()
        if duplicates is None:
            cursor.execute(
                f"CREATE UNIQUE INDEX IF NOT EXISTS {index_name} "
                f"ON {table}(company_id, branch_id, {number_column})"
            )
