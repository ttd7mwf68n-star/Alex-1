"""
AlexERP — Business Management System
Inventory Database Schema
"""

from __future__ import annotations

import sqlite3


def create_inventory_tables(cursor: sqlite3.Cursor) -> None:

    # ==========================================================
    # PRODUCT CATEGORIES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS product_categories(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT NOT NULL UNIQUE,

        name TEXT NOT NULL,

        parent_id INTEGER,

        description TEXT,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(parent_id)
        REFERENCES product_categories(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_category_name
    ON product_categories(name)
    """)



    # ==========================================================
    # BRANDS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS brands(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT UNIQUE,

        name TEXT NOT NULL,

        description TEXT,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)

    # ==========================================================
    # UNITS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS units(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT UNIQUE,

        name TEXT NOT NULL,

        symbol TEXT,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)

    # ==========================================================
    # WAREHOUSES
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS warehouses(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER,

        branch_id INTEGER,

        code TEXT UNIQUE,

        name TEXT NOT NULL,

        address TEXT,

        manager_name TEXT,

        phone TEXT,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id)

    )
    """)

    # ==========================================================
    # WAREHOUSE LOCATIONS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS warehouse_locations(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        warehouse_id INTEGER NOT NULL,

        code TEXT,

        name TEXT,

        description TEXT,

        FOREIGN KEY(warehouse_id)
        REFERENCES warehouses(id)
        ON DELETE CASCADE

    )
    """)

    # ==========================================================
    # PRODUCTS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        code TEXT UNIQUE,

        barcode TEXT UNIQUE,

        name TEXT NOT NULL,

        category_id INTEGER,

        brand_id INTEGER,

        company_id INTEGER NOT NULL,

        branch_id INTEGER,
                     
        unit_id INTEGER,

        purchase_price REAL DEFAULT 0,

        sale_price REAL DEFAULT 0,
                   
       quantity REAL DEFAULT 0,

        minimum_stock REAL DEFAULT 0,

        maximum_stock REAL DEFAULT 0,

        allow_negative_stock INTEGER DEFAULT 0,

        track_serial INTEGER DEFAULT 0,

        track_batch INTEGER DEFAULT 0,

        track_expiry INTEGER DEFAULT 0,

        weight REAL,

        description TEXT,

        is_active INTEGER DEFAULT 1,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(category_id)
        REFERENCES product_categories(id),

        FOREIGN KEY(brand_id)
        REFERENCES brands(id),

        FOREIGN KEY(unit_id)
        REFERENCES units(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_product_code
    ON products(code)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_product_barcode
    ON products(barcode)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_product_name
    ON products(name)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_products_category
    ON products(category_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_products_brand
    ON products(brand_id)
    """)
   

    # ==========================================================
    # STOCK MOVEMENTS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stock_movements(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER NOT NULL,

        branch_id INTEGER NOT NULL,

        warehouse_id INTEGER NOT NULL,

        location_id INTEGER,

        product_id INTEGER NOT NULL,

        transaction_type TEXT NOT NULL CHECK(transaction_type IN (
            'PURCHASE',
            'SALE',
            'SALE_RETURN',
            'PURCHASE_RETURN',
            'TRANSFER_IN',
            'TRANSFER_OUT',
            'ADJUSTMENT',
            'OPENING',
            'INVENTORY_COUNT'
        )),

        reference_type TEXT,

        reference_id INTEGER,

        quantity_in REAL DEFAULT 0,

        quantity_out REAL DEFAULT 0,

        unit_cost REAL DEFAULT 0,

        balance_after REAL DEFAULT 0,

        transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        notes TEXT,

        created_by INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id),

        FOREIGN KEY(warehouse_id)
        REFERENCES warehouses(id),

        FOREIGN KEY(location_id)
        REFERENCES warehouse_locations(id),

        FOREIGN KEY(product_id)
        REFERENCES products(id),

        FOREIGN KEY(created_by)
        REFERENCES users(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_stock_movements_product
    ON stock_movements(product_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_stock_warehouse
    ON stock_movements(warehouse_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_stock_reference
    ON stock_movements(reference_type, reference_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_stock_date
    ON stock_movements(transaction_date)
    """)


# ==========================================================
# STOCK TRANSFERS
# ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stock_transfers(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER NOT NULL,

        branch_id INTEGER NOT NULL,

        transfer_number TEXT NOT NULL,

        from_warehouse_id INTEGER NOT NULL,

        to_warehouse_id INTEGER NOT NULL,

        transfer_date DATE NOT NULL,

        status TEXT DEFAULT 'Posted',

        notes TEXT,

        created_by INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id),

        FOREIGN KEY(from_warehouse_id)
        REFERENCES warehouses(id),

        FOREIGN KEY(to_warehouse_id)
        REFERENCES warehouses(id),

        FOREIGN KEY(created_by)
        REFERENCES users(id)

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_transfer_number
    ON stock_transfers(company_id,transfer_number)
    """)


    # ==========================================================
    # STOCK TRANSFER ITEMS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stock_transfer_items(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        transfer_id INTEGER NOT NULL,

        product_id INTEGER NOT NULL,

        quantity REAL NOT NULL,

        unit_cost REAL DEFAULT 0,

        total REAL DEFAULT 0,

        FOREIGN KEY(transfer_id)
        REFERENCES stock_transfers(id)
        ON DELETE CASCADE,

        FOREIGN KEY(product_id)
        REFERENCES products(id)

    )
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_transfer_items_transfer
    ON stock_transfer_items(transfer_id)
    """)

    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_transfer_items_product
    ON stock_transfer_items(product_id)
    """)



    # ==========================================================
    # INVENTORY COUNT
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS inventory_counts(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        company_id INTEGER NOT NULL,

        branch_id INTEGER NOT NULL,

        warehouse_id INTEGER NOT NULL,

        count_number TEXT NOT NULL,

        count_date DATE NOT NULL,

        status TEXT DEFAULT 'Draft',

        notes TEXT,

        created_by INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(company_id)
        REFERENCES companies(id),

        FOREIGN KEY(branch_id)
        REFERENCES branches(id),

        FOREIGN KEY(warehouse_id)
        REFERENCES warehouses(id),

        FOREIGN KEY(created_by)
        REFERENCES users(id)

    )
    """)

    cursor.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_count_number
    ON inventory_counts(company_id,count_number)
    """)




    # ==========================================================
    # INVENTORY COUNT ITEMS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS inventory_count_items(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        inventory_count_id INTEGER NOT NULL,

        product_id INTEGER NOT NULL,

        system_quantity REAL DEFAULT 0,

        counted_quantity REAL DEFAULT 0,

        difference REAL DEFAULT 0,

        unit_cost REAL DEFAULT 0,

        FOREIGN KEY(inventory_count_id)
        REFERENCES inventory_counts(id)
        ON DELETE CASCADE,

        FOREIGN KEY(product_id)
        REFERENCES products(id)

    )
    """)


    # ==========================================================
    # WAREHOUSE STOCK BALANCES (multi-warehouse source of truth)
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS product_stock(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        warehouse_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity REAL NOT NULL DEFAULT 0,
        average_cost REAL NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP,
        UNIQUE(warehouse_id, product_id),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(warehouse_id) REFERENCES warehouses(id),
        FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
    )
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_product_stock_product
    ON product_stock(product_id)
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_product_stock_warehouse
    ON product_stock(warehouse_id)
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stock_reservations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        warehouse_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        reference_type TEXT NOT NULL,
        reference_id INTEGER NOT NULL,
        quantity REAL NOT NULL CHECK(quantity > 0),
        unit_cost REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'ACTIVE'
            CHECK(status IN ('ACTIVE','FULFILLED','RELEASED')),
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP,
        UNIQUE(company_id, reference_type, reference_id, warehouse_id, product_id),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(warehouse_id) REFERENCES warehouses(id),
        FOREIGN KEY(product_id) REFERENCES products(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_stock_reservations_available
    ON stock_reservations(company_id, warehouse_id, product_id, status)
    """)

    # ==========================================================
    # STOCK ADJUSTMENTS
    # ==========================================================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stock_adjustments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        branch_id INTEGER,
        warehouse_id INTEGER NOT NULL,
        adjustment_number TEXT NOT NULL,
        adjustment_date DATE NOT NULL,
        reason TEXT,
        status TEXT NOT NULL DEFAULT 'Draft'
            CHECK(status IN ('Draft','Posted','Cancelled')),
        notes TEXT,
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP,
        UNIQUE(company_id, adjustment_number),
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(warehouse_id) REFERENCES warehouses(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stock_adjustment_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        adjustment_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        system_quantity REAL NOT NULL DEFAULT 0,
        counted_quantity REAL NOT NULL DEFAULT 0,
        difference REAL NOT NULL DEFAULT 0,
        unit_cost REAL NOT NULL DEFAULT 0,
        FOREIGN KEY(adjustment_id) REFERENCES stock_adjustments(id)
            ON DELETE CASCADE,
        FOREIGN KEY(product_id) REFERENCES products(id)
    )
    """)
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_stock_adjustment_items_header
    ON stock_adjustment_items(adjustment_id)
    """)
