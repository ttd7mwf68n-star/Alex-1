"""
AlexERP — Business Management System
Central SQLite database engine.
"""

from __future__ import annotations

import sqlite3
import threading
from pathlib import Path
from typing import Any

from alexerp.config import (
    DATABASE_BACKEND, DATABASE_DIR, DATABASE_NAME, DATABASE_PATH, DATABASE_URL,
    SQLITE_BUSY_TIMEOUT, SQLITE_TIMEOUT, ENABLE_FOREIGN_KEYS, ENABLE_WAL,
)
from alexerp.database.postgres_compat import PostgreSQLConnection

# Backwards-compatible name used by backup.py and other existing modules.
DATABASE_FILE: Path = DATABASE_PATH

# Previous releases/configurations used this location. If it exists and the
# canonical database does not, copy it using SQLite's backup API so committed
# data is preserved safely. The original file is deliberately left untouched.
# Upgrade compatibility: older installations stored the application database
# inside the former Python package directory. Keep this lookup isolated here;
# all current imports, modules, and runtime paths use the AlexERP package.
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_LEGACY_PACKAGE_NAME = "alex" + "gameerp"
LEGACY_PACKAGE_DATABASE_PATH = (
    _PROJECT_ROOT / _LEGACY_PACKAGE_NAME / "data" / "alex_erp.db"
)
LEGACY_DATABASE_PATH = Path(__file__).resolve().parent / ("alex" + "game.db")

DATABASE_DIR.mkdir(parents=True, exist_ok=True)


def _migrate_legacy_database() -> None:
    if DATABASE_BACKEND != "sqlite":
        return
    if DATABASE_FILE.exists():
        return

    legacy_source_path = next(
        (path for path in (LEGACY_PACKAGE_DATABASE_PATH, LEGACY_DATABASE_PATH) if path.is_file()),
        None,
    )
    if legacy_source_path is None:
        return

    source = sqlite3.connect(str(legacy_source_path), timeout=30)
    destination = sqlite3.connect(str(DATABASE_FILE), timeout=30)
    try:
        source.backup(destination)
        destination.commit()
    except Exception:
        destination.close()
        source.close()
        DATABASE_FILE.unlink(missing_ok=True)
        raise
    else:
        destination.close()
        source.close()


_migrate_legacy_database()


class Database:
    # Kept as a compatibility alias for code that inspected this attribute.
    _connection: Any | None = None
    _local = threading.local()
    _connections: set[Any] = set()
    _connections_lock = threading.RLock()

    @classmethod
    def connect(cls):
        connection = getattr(cls._local, "connection", None)
        if connection is not None:
            try:
                if DATABASE_BACKEND == "postgresql":
                    connection.ping()
                else:
                    connection.execute("SELECT 1")
                return connection
            except (sqlite3.ProgrammingError, OSError):
                cls._local.connection = None

        with cls._connections_lock:
            connection = getattr(cls._local, "connection", None)
            if connection is not None:
                return connection
            if DATABASE_BACKEND == "postgresql":
                if not DATABASE_URL:
                    raise RuntimeError(
                        "ALEXERP_DATABASE_URL is required when the PostgreSQL backend is selected."
                    )
                try:
                    import psycopg
                    from psycopg.conninfo import conninfo_to_dict
                    from psycopg.rows import tuple_row
                except ImportError as exc:
                    raise RuntimeError(
                        "The PostgreSQL backend requires psycopg 3. Install project requirements."
                    ) from exc
                connection_options = conninfo_to_dict(DATABASE_URL)
                if connection_options.get("sslmode") not in {"verify-ca", "verify-full"}:
                    raise RuntimeError(
                        "PostgreSQL direct connections require sslmode=verify-full "
                        "(or verify-ca) in ALEXERP_DATABASE_URL."
                    )
                raw_connection = psycopg.connect(
                    DATABASE_URL,
                    connect_timeout=SQLITE_TIMEOUT,
                    row_factory=tuple_row,
                )
                connection = PostgreSQLConnection(raw_connection)
            else:
                connection = sqlite3.connect(
                    str(DATABASE_FILE),
                    timeout=SQLITE_TIMEOUT,
                    detect_types=sqlite3.PARSE_DECLTYPES,
                    check_same_thread=False,
                )
                connection.row_factory = sqlite3.Row
                if ENABLE_FOREIGN_KEYS:
                    connection.execute("PRAGMA foreign_keys = ON")
                if ENABLE_WAL:
                    connection.execute("PRAGMA journal_mode = WAL")
                connection.execute("PRAGMA synchronous = NORMAL")
                connection.execute(f"PRAGMA busy_timeout = {int(SQLITE_BUSY_TIMEOUT)}")
            cls._local.connection = connection
            cls._connections.add(connection)
            if cls._connection is None:
                cls._connection = connection

        return connection

    @classmethod
    def close_current(cls) -> None:
        """Close only the calling thread's connection."""
        connection = getattr(cls._local, "connection", None)
        if connection is None:
            return
        cls._local.connection = None
        with cls._connections_lock:
            cls._connections.discard(connection)
            if cls._connection is connection:
                cls._connection = next(iter(cls._connections), None)
        connection.close()

    @classmethod
    def close(cls) -> None:
        """Close all registered connections during application shutdown."""
        with cls._connections_lock:
            connections = list(cls._connections)
            cls._connections.clear()
            cls._connection = None
            cls._local.connection = None
        for connection in connections:
            try:
                connection.close()
            except sqlite3.Error:
                pass
