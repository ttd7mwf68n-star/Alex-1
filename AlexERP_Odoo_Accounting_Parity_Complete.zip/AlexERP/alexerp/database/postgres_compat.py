"""Small DB-API compatibility layer for the application's PostgreSQL backend."""
from __future__ import annotations

import re
import sqlite3
from typing import Any


POSTGRES_BOOTSTRAP_LOCK_ID = 72460742394320


_INSERT_TABLE = re.compile(
    r"\bINSERT\s+(?:OR\s+IGNORE\s+)?INTO\s+([A-Za-z_][A-Za-z0-9_\.]*)",
    re.IGNORECASE,
)
_TABLE_INFO = re.compile(
    r"^\s*PRAGMA\s+table_info\s*\(\s*['\"`]?([A-Za-z_][A-Za-z0-9_]*)['\"`]?\s*\)\s*;?\s*$",
    re.IGNORECASE,
)
_NOOP_PRAGMA = re.compile(
    r"^\s*PRAGMA\s+(?:foreign_keys|journal_mode|synchronous|busy_timeout)\b",
    re.IGNORECASE,
)


class PostgreSQLRow:
    """Row supporting SQLite-style integer and name indexing."""

    __slots__ = ("_values", "_names")

    def __init__(self, names: tuple[str, ...], values: tuple[Any, ...]):
        self._names = names
        self._values = values

    def __getitem__(self, key):
        if isinstance(key, str):
            return self._values[self._names.index(key)]
        return self._values[key]

    def __iter__(self):
        return iter(self._values)

    def __len__(self):
        return len(self._values)

    def keys(self):
        return self._names


class _EmptyCursor:
    rowcount = 0
    lastrowid = None
    description = None

    @staticmethod
    def fetchone():
        return None

    @staticmethod
    def fetchall():
        return []

    @staticmethod
    def fetchmany(size=None):
        return []

    def __iter__(self):
        return iter(())

    @staticmethod
    def close():
        return None


def _replace_qmark_placeholders(sql: str) -> str:
    result = []
    index = 0
    quote = None
    while index < len(sql):
        char = sql[index]
        if quote:
            result.append(char)
            if char == quote:
                if index + 1 < len(sql) and sql[index + 1] == quote:
                    result.append(sql[index + 1])
                    index += 1
                else:
                    quote = None
        elif char in {"'", '"'}:
            quote = char
            result.append(char)
        elif char == "-" and index + 1 < len(sql) and sql[index + 1] == "-":
            end = sql.find("\n", index)
            if end < 0:
                result.append(sql[index:])
                break
            result.append(sql[index:end + 1])
            index = end
        elif char == "/" and index + 1 < len(sql) and sql[index + 1] == "*":
            end = sql.find("*/", index + 2)
            if end < 0:
                result.append(sql[index:])
                break
            result.append(sql[index:end + 2])
            index = end + 1
        elif char == "?":
            result.append("%s")
        else:
            result.append(char)
        index += 1
    return "".join(result)


def translate_sql(sql: str) -> str | None:
    """Translate the limited SQLite dialect used by application SQL.

    Returns ``None`` for connection-local pragmas that do not apply to
    PostgreSQL. Unsupported SQLite constructs are deliberately not guessed.
    """
    table_info = _TABLE_INFO.match(sql)
    if table_info:
        return (
            "SELECT ordinal_position - 1 AS cid, column_name AS name, "
            "data_type AS type, is_nullable AS notnull, column_default AS dflt_value, "
            "0 AS pk FROM information_schema.columns "
            f"WHERE table_schema=current_schema() AND table_name='{table_info.group(1)}' "
            "ORDER BY ordinal_position"
        )
    if _NOOP_PRAGMA.match(sql):
        return None

    translated = re.sub(
        r"^\s*BEGIN\s+IMMEDIATE\b", "BEGIN", sql, flags=re.IGNORECASE
    )
    translated = re.sub(
        r"\bINTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT\b",
        "SERIAL PRIMARY KEY",
        translated,
        flags=re.IGNORECASE,
    )
    ignored_insert = bool(re.search(r"\bINSERT\s+OR\s+IGNORE\s+INTO\b", translated, re.IGNORECASE))
    translated = re.sub(
        r"\bINSERT\s+OR\s+IGNORE\s+INTO\b", "INSERT INTO", translated, flags=re.IGNORECASE
    )
    translated = re.sub(
        r"\bIS\s*\?", "IS NOT DISTINCT FROM ?", translated, flags=re.IGNORECASE
    )
    translated = re.sub(
        r"\bdatetime\s*\(\s*'now'\s*\)", "CURRENT_TIMESTAMP", translated, flags=re.IGNORECASE
    )
    translated = re.sub(
        r"\bdate\s*\(\s*'now'\s*\)", "CURRENT_DATE", translated, flags=re.IGNORECASE
    )
    translated = re.sub(
        r"julianday\s*\(\s*\?\s*\)\s*-\s*julianday\s*\(\s*\?\s*\)",
        "(?::date - ?::date)", translated, flags=re.IGNORECASE,
    )
    translated = _replace_qmark_placeholders(translated)
    if ignored_insert and not re.search(r"\bON\s+CONFLICT\b", translated, re.IGNORECASE):
        translated = translated.rstrip().rstrip(";") + " ON CONFLICT DO NOTHING"
    return translated


def synchronize_postgresql_sequences(connection, *, commit: bool = True) -> None:
    """Set SERIAL sequences past the largest explicitly inserted id."""
    tables = connection.execute(
        """SELECT table_name FROM information_schema.columns
           WHERE table_schema=current_schema()
             AND column_name='id'
             AND column_default LIKE 'nextval(%'"""
    ).fetchall()
    for (table_name,) in tables:
        quoted_table = '"' + table_name.replace('"', '""') + '"'
        connection.execute(
            """SELECT setval(
                   pg_get_serial_sequence(?, 'id'),
                   COALESCE(MAX(id), 1),
                   MAX(id) IS NOT NULL
               ) FROM """ + quoted_table
        ).fetchone()
    if commit:
        connection.commit()


class PostgreSQLCursor:
    def __init__(self, connection, cursor, source_sql: str = ""):
        self._connection = connection
        self._cursor = cursor
        self._source_sql = source_sql

    @property
    def rowcount(self):
        return self._cursor.rowcount

    @property
    def description(self):
        return self._cursor.description

    @property
    def lastrowid(self):
        match = _INSERT_TABLE.search(self._source_sql)
        if not match:
            return None
        table_name = match.group(1).replace('"', "")
        cursor = self._connection._connection.cursor()
        try:
            cursor.execute("SELECT pg_get_serial_sequence(%s, 'id')", (table_name,))
            sequence = cursor.fetchone()[0]
            if sequence is None:
                return None
            cursor.execute("SELECT currval(%s::regclass)", (sequence,))
            value = cursor.fetchone()[0]
            return int(value) if value is not None else None
        finally:
            cursor.close()

    def _row(self, values):
        if values is None:
            return None
        names = tuple(column.name for column in self._cursor.description)
        return PostgreSQLRow(names, tuple(values))

    def fetchone(self):
        return self._row(self._cursor.fetchone())

    def fetchall(self):
        return [self._row(row) for row in self._cursor.fetchall()]

    def fetchmany(self, size=None):
        rows = self._cursor.fetchmany(size) if size is not None else self._cursor.fetchmany()
        return [self._row(row) for row in rows]

    def __iter__(self):
        for row in self._cursor:
            yield self._row(row)

    def close(self):
        self._cursor.close()


class PostgreSQLConnection:
    def __init__(self, connection):
        self._connection = connection

    @property
    def in_transaction(self):
        return self._connection.info.transaction_status.name != "IDLE"

    def _execute(self, sql: str, parameters=(), many=False):
        translated = translate_sql(sql)
        if translated is None:
            return _EmptyCursor()
        cursor = self._connection.cursor()
        try:
            if many:
                cursor.executemany(translated, parameters)
            elif parameters:
                cursor.execute(translated, parameters)
            else:
                cursor.execute(translated)
        except Exception as exc:
            cursor.close()
            try:
                from psycopg import IntegrityError
            except ImportError:
                IntegrityError = ()
            if IntegrityError and isinstance(exc, IntegrityError):
                raise sqlite3.IntegrityError(str(exc)) from exc
            raise
        return PostgreSQLCursor(self, cursor, sql)

    def execute(self, sql: str, parameters=()):
        return self._execute(sql, parameters)

    def executemany(self, sql: str, parameters):
        return self._execute(sql, parameters, many=True)

    def cursor(self):
        return _PostgreSQLCursorFactory(self)

    def commit(self):
        self._connection.commit()

    def rollback(self):
        self._connection.rollback()

    def ping(self):
        try:
            if self._connection.closed:
                raise sqlite3.ProgrammingError("PostgreSQL connection is closed")
            status = self._connection.info.transaction_status.name
            if status == "INERROR":
                raise sqlite3.ProgrammingError("PostgreSQL transaction is in an aborted state")
            if status in {"INTRANS", "ACTIVE"}:
                return
            if status == "UNKNOWN":
                raise sqlite3.ProgrammingError("PostgreSQL connection state is unknown")
            self._connection.execute("SELECT 1")
            self._connection.rollback()
        except Exception as exc:
            # Keep the compatibility layer usable in SQLite-only installs and
            # in unit tests that deliberately exercise local error states.
            # A missing optional PostgreSQL driver must never mask the
            # original connection error.
            try:
                from psycopg import Error
            except ImportError:
                if isinstance(exc, sqlite3.Error):
                    raise exc
                raise
            if isinstance(exc, Error):
                raise sqlite3.ProgrammingError(str(exc)) from exc
            raise

    def close(self):
        self._connection.close()


class _PostgreSQLCursorFactory:
    def __init__(self, connection: PostgreSQLConnection):
        self._connection = connection
        self._current = None

    def execute(self, sql: str, parameters=()):
        self._current = self._connection.execute(sql, parameters)
        return self

    def executemany(self, sql: str, parameters):
        self._current = self._connection.executemany(sql, parameters)
        return self

    def fetchone(self):
        return self._current.fetchone() if self._current is not None else None

    def fetchall(self):
        return self._current.fetchall() if self._current is not None else []

    def fetchmany(self, size=None):
        return self._current.fetchmany(size) if self._current is not None else []

    @property
    def lastrowid(self):
        return self._current.lastrowid if self._current is not None else None

    @property
    def rowcount(self):
        return self._current.rowcount if self._current is not None else -1

    @property
    def description(self):
        return self._current.description if self._current is not None else None

    def close(self):
        if self._current is not None:
            self._current.close()
