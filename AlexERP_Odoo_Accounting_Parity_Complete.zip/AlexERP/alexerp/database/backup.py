"""Safe SQLite backup and restore utilities for AlexERP — Business Management System.

Backups are created through SQLite's online backup API (WAL-safe), validated,
checksummed, and atomically published. Restore validates the source first,
creates a safety backup of the current database, then atomically replaces it.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from alexerp.database import db as db_module


class BackupValidationError(ValueError):
    """Raised when a backup is corrupt or fails database consistency checks."""


class BackupManager:
    def __init__(self, backup_dir: Path | None = None, database_file: Path | None = None):
        self.database_file = Path(database_file or db_module.DATABASE_FILE)
        self.backup_dir = Path(backup_dir) if backup_dir else self.database_file.parent.parent / "backups"
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _require_sqlite_backend() -> None:
        if db_module.DATABASE_BACKEND != "sqlite":
            raise RuntimeError(
                "Encrypted in-app backups are currently supported only for SQLite."
            )

    @staticmethod
    def _find_postgresql_tool(environment_variable: str, executable: str) -> str:
        configured = os.getenv(environment_variable)
        if configured:
            path = Path(configured).expanduser()
            if path.is_file():
                return str(path.resolve())
            raise RuntimeError(f"{environment_variable} does not point to a file.")
        found = shutil.which(executable)
        if found is None:
            raise RuntimeError(
                f"{executable} is required for PostgreSQL backups. Install PostgreSQL client tools "
                f"or set {environment_variable}."
            )
        return found

    @classmethod
    def postgresql_backup_tools_available(cls) -> bool:
        try:
            cls._find_postgresql_tool("ALEXERP_PG_DUMP", "pg_dump")
            cls._find_postgresql_tool("ALEXERP_PG_RESTORE", "pg_restore")
        except RuntimeError:
            return False
        return True

    @staticmethod
    def _postgresql_environment() -> dict[str, str]:
        from alexerp.config import DATABASE_URL

        if not DATABASE_URL:
            raise RuntimeError(
                "ALEXERP_DATABASE_URL is required for PostgreSQL backup and restore."
            )
        try:
            from psycopg.conninfo import conninfo_to_dict
        except ImportError as exc:
            raise RuntimeError(
                "PostgreSQL backup requires psycopg 3. Install project requirements."
            ) from exc

        options = conninfo_to_dict(DATABASE_URL)
        if options.get("sslmode") not in {"verify-ca", "verify-full"}:
            raise RuntimeError(
                "PostgreSQL backup tools require sslmode=verify-full or verify-ca."
            )
        environment = os.environ.copy()
        variables = {
            "host": "PGHOST",
            "hostaddr": "PGHOSTADDR",
            "port": "PGPORT",
            "dbname": "PGDATABASE",
            "user": "PGUSER",
            "password": "PGPASSWORD",
            "sslmode": "PGSSLMODE",
            "sslrootcert": "PGSSLROOTCERT",
            "sslcert": "PGSSLCERT",
            "sslkey": "PGSSLKEY",
            "sslpassword": "PGSSLPASSWORD",
            "connect_timeout": "PGCONNECT_TIMEOUT",
            "application_name": "PGAPPNAME",
            "options": "PGOPTIONS",
            "target_session_attrs": "PGTARGETSESSIONATTRS",
            "keepalives": "PGKEEPALIVES",
            "keepalives_idle": "PGKEEPALIVESIDLE",
            "keepalives_interval": "PGKEEPALIVESINTERVAL",
            "keepalives_count": "PGKEEPALIVESCOUNT",
        }
        for option, variable in variables.items():
            if option in options:
                environment[variable] = str(options[option])
        return environment

    @staticmethod
    def _run_postgresql_tool(
        executable: str,
        arguments: list[str],
        environment: dict[str, str] | None = None,
    ) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [executable, *arguments],
                check=True,
                capture_output=True,
                text=True,
                env=environment,
            )
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or exc.stdout or "").strip()
            raise RuntimeError(
                f"{Path(executable).name} failed"
                + (f": {detail}" if detail else ".")
            ) from exc

    def _postgresql_archive_info(self, backup_file: Path) -> dict[str, int]:
        if not backup_file.is_file() or backup_file.stat().st_size == 0:
            raise BackupValidationError("ملف النسخة غير موجود أو فارغ")
        pg_restore = self._find_postgresql_tool(
            "ALEXERP_PG_RESTORE", "pg_restore"
        )
        try:
            result = self._run_postgresql_tool(
                pg_restore, ["--list", str(backup_file)]
            )
        except RuntimeError as exc:
            raise BackupValidationError(
                f"ملف نسخة PostgreSQL غير صالح: {exc}"
            ) from exc
        entries = [
            line for line in result.stdout.splitlines()
            if re.match(r"^\s*\d+;", line)
        ]
        table_count = sum(
            bool(
                re.match(
                    r"^\s*\d+;\s+\d+\s+\d+\s+TABLE\s+(?!DATA\b)",
                    line,
                )
            )
            for line in entries
        )
        if not table_count:
            raise BackupValidationError(
                "نسخة PostgreSQL لا تحتوي على جداول تطبيق قابلة للاستعادة."
            )
        return {"table_count": table_count, "archive_entries": len(entries)}

    def _create_postgresql_backup(self, backup_type: str) -> Path:
        pg_dump = self._find_postgresql_tool("ALEXERP_PG_DUMP", "pg_dump")
        self._find_postgresql_tool("ALEXERP_PG_RESTORE", "pg_restore")
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        destination = self.backup_dir / f"alex_erp_{stamp}.dump"
        fd, temp_name = tempfile.mkstemp(
            prefix=".alex_backup_", suffix=".dump", dir=self.backup_dir
        )
        os.close(fd)
        temp_path = Path(temp_name)
        try:
            self._run_postgresql_tool(
                pg_dump,
                [
                    "--format=custom",
                    "--no-owner",
                    "--no-acl",
                    f"--file={temp_path}",
                ],
                self._postgresql_environment(),
            )
            archive_info = self._postgresql_archive_info(temp_path)
            checksum = self._sha256(temp_path)
            os.replace(temp_path, destination)
            self._fsync_directory(self.backup_dir)
            self._write_manifest(destination, {
                "format_version": 2,
                "backend": "postgresql",
                "backup_type": backup_type,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "sha256": checksum,
                **archive_info,
            })
            return destination
        except Exception:
            temp_path.unlink(missing_ok=True)
            destination.unlink(missing_ok=True)
            destination.with_suffix(destination.suffix + ".json").unlink(missing_ok=True)
            raise

    def _verify_postgresql_backup(self, backup_file: Path) -> dict[str, Any]:
        if backup_file.suffix != ".dump":
            raise BackupValidationError("صيغة نسخة PostgreSQL غير مدعومة")
        manifest_path = backup_file.with_suffix(backup_file.suffix + ".json")
        if not manifest_path.is_file():
            raise BackupValidationError("ملف بيانات نسخة PostgreSQL مفقود")
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise BackupValidationError("ملف بيانات نسخة PostgreSQL تالف") from exc
        if (
            not isinstance(manifest, dict)
            or manifest.get("format_version") != 2
            or manifest.get("backend") != "postgresql"
        ):
            raise BackupValidationError("إصدار بيانات نسخة PostgreSQL غير مدعوم")

        archive_info = self._postgresql_archive_info(backup_file)
        expected = manifest.get("sha256")
        if not isinstance(expected, str) or len(expected) != 64:
            raise BackupValidationError("بصمة نسخة PostgreSQL مفقودة أو غير صالحة")
        try:
            int(expected, 16)
        except ValueError as exc:
            raise BackupValidationError("صيغة بصمة نسخة PostgreSQL غير صالحة") from exc
        actual = self._sha256(backup_file)
        if expected.lower() != actual:
            raise BackupValidationError("بصمة نسخة PostgreSQL غير مطابقة")
        if (
            manifest.get("table_count") != archive_info["table_count"]
            or manifest.get("archive_entries") != archive_info["archive_entries"]
        ):
            raise BackupValidationError(
                "بيانات النسخة لا تطابق محتويات أرشيف PostgreSQL الفعلية"
            )
        return {
            "integrity": "ok",
            **archive_info,
            "sha256": actual,
            "created_at": manifest.get("created_at"),
            "backup_type": manifest.get("backup_type"),
        }

    def _restore_postgresql_backup(self, backup_file: Path) -> Path:
        self._verify_postgresql_backup(backup_file)
        safety_copy = self.create_backup(backup_type="safety")
        pg_restore = self._find_postgresql_tool(
            "ALEXERP_PG_RESTORE", "pg_restore"
        )
        environment = self._postgresql_environment()
        db_module.Database.close()
        try:
            self._run_postgresql_tool(
                pg_restore,
                [
                    "--clean",
                    "--if-exists",
                    "--single-transaction",
                    "--exit-on-error",
                    "--no-owner",
                    "--no-acl",
                    str(backup_file),
                ],
                environment,
            )
        finally:
            db_module.Database.close()
        return safety_copy

    @staticmethod
    def _sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _validate_database(path: Path) -> dict[str, Any]:
        if not path.is_file() or path.stat().st_size == 0:
            raise BackupValidationError("ملف قاعدة البيانات غير موجود أو فارغ")
        connection = sqlite3.connect(f"file:{path.resolve().as_posix()}?mode=ro&immutable=1", uri=True, timeout=30)
        try:
            integrity = [row[0] for row in connection.execute("PRAGMA integrity_check")]
            if integrity != ["ok"]:
                raise BackupValidationError("فشل فحص سلامة قاعدة البيانات: " + "; ".join(integrity[:5]))
            foreign_key_errors = connection.execute("PRAGMA foreign_key_check").fetchall()
            if foreign_key_errors:
                raise BackupValidationError(f"قاعدة البيانات تحتوي على مخالفات علاقات: {len(foreign_key_errors)}")
            user_tables = connection.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchone()[0]
            if not user_tables:
                raise BackupValidationError("الملف لا يحتوي على جداول تطبيق")
            return {"integrity": "ok", "foreign_key_errors": 0, "table_count": int(user_tables)}
        except sqlite3.DatabaseError as exc:
            raise BackupValidationError(f"تعذر قراءة قاعدة البيانات: {exc}") from exc
        finally:
            connection.close()

    @staticmethod
    def _fsync_directory(directory: Path) -> None:
        """Best-effort directory flush after atomic renames (supported on POSIX)."""
        if os.name == "nt":
            return
        descriptor = None
        try:
            descriptor = os.open(directory, os.O_RDONLY)
            os.fsync(descriptor)
        except OSError:
            # Some filesystems do not allow fsync on directory descriptors.
            pass
        finally:
            if descriptor is not None:
                os.close(descriptor)

    def _write_manifest(self, backup_file: Path, metadata: dict[str, Any]) -> Path:
        manifest = backup_file.with_suffix(backup_file.suffix + ".json")
        fd, temporary_name = tempfile.mkstemp(
            prefix=f".{manifest.name}.", suffix=".tmp", dir=manifest.parent
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                json.dump(metadata, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, manifest)
            self._fsync_directory(manifest.parent)
            return manifest
        except Exception:
            temporary.unlink(missing_ok=True)
            raise

    @staticmethod
    def _copy_database(source: sqlite3.Connection, target: sqlite3.Connection) -> None:
        """Copy a consistent SQLite snapshot using the online backup API."""
        source.backup(target)
        target.commit()

    def create_backup(self, backup_type: str = "manual") -> Path:
        if db_module.DATABASE_BACKEND == "postgresql":
            return self._create_postgresql_backup(backup_type)
        if not self.database_file.is_file():
            raise FileNotFoundError(str(self.database_file))
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        destination = self.backup_dir / f"alex_erp_{stamp}.db"
        fd, temp_name = tempfile.mkstemp(prefix=".alex_backup_", suffix=".tmp", dir=self.backup_dir)
        os.close(fd)
        temp_path = Path(temp_name)
        source = sqlite3.connect(str(self.database_file), timeout=30)
        target = sqlite3.connect(str(temp_path), timeout=30)
        try:
            try:
                self._copy_database(source, target)
            except Exception:
                # Close SQLite handles before deleting any temp file. On Windows,
                # unlink() can fail while the database file is still open.
                target.close()
                source.close()
                temp_path.unlink(missing_ok=True)
                raise
            finally:
                target.close()
                source.close()
            validation = self._validate_database(temp_path)
            checksum = self._sha256(temp_path)
            # Flush database bytes before publishing the final filename.
            fd = os.open(temp_path, os.O_RDONLY | getattr(os, "O_BINARY", 0))
            try:
                try:
                    os.fsync(fd)
                except OSError:
                    if os.name != "nt":
                        raise
            finally:
                os.close(fd)
            os.replace(temp_path, destination)
            self._fsync_directory(self.backup_dir)
            self._write_manifest(destination, {
                "format_version": 1,
                "backup_type": backup_type,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "database_file": self.database_file.name,
                "sha256": checksum,
                **validation,
            })
            return destination
        except Exception:
            temp_path.unlink(missing_ok=True)
            destination.unlink(missing_ok=True)
            destination.with_suffix(destination.suffix + ".json").unlink(missing_ok=True)
            raise

    def verify_backup(self, backup_file: Path) -> dict[str, Any]:
        backup_file = Path(backup_file)
        if db_module.DATABASE_BACKEND == "postgresql":
            return self._verify_postgresql_backup(backup_file)
        validation = self._validate_database(backup_file)
        manifest_path = backup_file.with_suffix(backup_file.suffix + ".json")
        if not manifest_path.is_file():
            raise BackupValidationError("ملف بيانات النسخة الاحتياطية مفقود؛ لا يمكن اعتماد سلامتها")
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise BackupValidationError("ملف بيانات النسخة الاحتياطية تالف") from exc
        if not isinstance(manifest, dict) or manifest.get("format_version") != 1:
            raise BackupValidationError("إصدار بيانات النسخة الاحتياطية غير مدعوم")
        expected = manifest.get("sha256")
        if not isinstance(expected, str) or len(expected) != 64:
            raise BackupValidationError("بصمة النسخة الاحتياطية مفقودة أو غير صالحة")
        try:
            int(expected, 16)
        except ValueError as exc:
            raise BackupValidationError("صيغة بصمة النسخة الاحتياطية غير صالحة") from exc
        actual = self._sha256(backup_file)
        if expected.lower() != actual:
            raise BackupValidationError("بصمة النسخة الاحتياطية غير مطابقة")
        # Manifest claims must agree with checks performed against the actual DB.
        if manifest.get("integrity") != validation["integrity"]:
            raise BackupValidationError("بيانات سلامة النسخة لا تطابق نتيجة الفحص الفعلي")
        if manifest.get("foreign_key_errors") != validation["foreign_key_errors"]:
            raise BackupValidationError("بيانات العلاقات المرجعية لا تطابق نتيجة الفحص الفعلي")
        if manifest.get("table_count") != validation["table_count"]:
            raise BackupValidationError("عدد الجداول في بيانات النسخة غير مطابق")
        validation["created_at"] = manifest.get("created_at")
        validation["sha256"] = actual
        validation["backup_type"] = manifest.get("backup_type")
        return validation

    def restore_backup(self, backup_file: Path) -> Path:
        backup_file = Path(backup_file)
        if db_module.DATABASE_BACKEND == "postgresql":
            return self._restore_postgresql_backup(backup_file)
        current = self.database_file
        if backup_file == current:
            raise ValueError("لا يمكن استعادة قاعدة البيانات من نفس ملف التشغيل")
        self.verify_backup(backup_file)
        if not current.is_file():
            raise FileNotFoundError(str(current))

        # Preserve the live database before replacing it. This also uses SQLite's
        # online backup API, so committed WAL content is included.
        safety_copy = self.create_backup(backup_type="safety")
        fd, temp_name = tempfile.mkstemp(prefix=".alex_restore_", suffix=".db", dir=current.parent)
        os.close(fd)
        staged = Path(temp_name)
        try:
            source = sqlite3.connect(f"file:{backup_file.as_posix()}?mode=ro&immutable=1", uri=True, timeout=30)
            target = sqlite3.connect(str(staged), timeout=30)
            try:
                source.backup(target)
                target.commit()
            finally:
                target.close()
                source.close()
            self._validate_database(staged)

            # Close registered app connections before swapping the database file.
            # SQLite WAL/SHM sidecars belong to the old database and must never be
            # left beside the restored file, otherwise stale WAL pages could be
            # replayed against the replacement database.
            db_module.Database.close()
            # Use a unique rollback name: never overwrite an older recovery
            # artifact from a previous interrupted restore.
            restore_stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            rollback_path = current.with_name(current.name + f".pre_restore_{restore_stamp}")
            wal_path = Path(str(current) + "-wal")
            shm_path = Path(str(current) + "-shm")
            rollback_wal = Path(str(rollback_path) + "-wal")
            rollback_shm = Path(str(rollback_path) + "-shm")
            moved_database = moved_wal = moved_shm = installed_new = False
            try:
                os.replace(current, rollback_path)
                moved_database = True
                if wal_path.exists():
                    os.replace(wal_path, rollback_wal)
                    moved_wal = True
                if shm_path.exists():
                    os.replace(shm_path, rollback_shm)
                    moved_shm = True
                os.replace(staged, current)
                installed_new = True
                # Verify the installed database after the atomic replacement.
                self._validate_database(current)
            except Exception:
                # Roll back every completed filesystem operation, including a
                # failure while moving WAL/SHM (before the new DB is installed).
                if installed_new:
                    current.unlink(missing_ok=True)
                if moved_database and rollback_path.exists():
                    os.replace(rollback_path, current)
                if moved_wal and rollback_wal.exists():
                    os.replace(rollback_wal, wal_path)
                if moved_shm and rollback_shm.exists():
                    os.replace(rollback_shm, shm_path)
                raise
            else:
                # The independent safety backup remains available in backups/.
                # Remove only the transient rollback files after validation.
                rollback_path.unlink(missing_ok=True)
                rollback_wal.unlink(missing_ok=True)
                rollback_shm.unlink(missing_ok=True)
            return safety_copy
        except Exception:
            staged.unlink(missing_ok=True)
            raise

    def create_encrypted_backup(self, password: str, backup_type: str = "manual") -> Path:
        """Create and encrypt a verified backup; password is never stored."""
        self._require_sqlite_backend()
        from alexerp.database.encrypted_backup import encrypt_backup
        plain_backup = self.create_backup(backup_type=backup_type)
        try:
            encrypted = encrypt_backup(plain_backup, password)
            return encrypted
        finally:
            # Keep the ordinary local backup: it remains useful for fast local restore.
            # The encrypted copy is the portable/off-device artifact.
            pass

    def restore_encrypted_backup(self, encrypted_file: Path, password: str) -> Path:
        """Authenticate/decrypt to a private temporary DB, then use normal safe restore."""
        self._require_sqlite_backend()
        from alexerp.database.encrypted_backup import decrypt_backup
        import secrets
        encrypted_file = Path(encrypted_file)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        temporary = self.backup_dir / f".decrypted_{secrets.token_hex(8)}.db"
        manifest = temporary.with_suffix(temporary.suffix + ".json")
        try:
            plaintext = decrypt_backup(encrypted_file, password)
            temporary.write_bytes(plaintext)
            validation = self._validate_database(temporary)
            self._write_manifest(temporary, {
                "format_version": 1,
                "backup_type": "encrypted-import",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "database_file": self.database_file.name,
                "sha256": self._sha256(temporary),
                **validation,
            })
            return self.restore_backup(temporary)
        finally:
            temporary.unlink(missing_ok=True)
            manifest.unlink(missing_ok=True)


    def list_encrypted_backups(self) -> list[Path]:
        """Return encrypted portable backups stored beside local backups."""
        if db_module.DATABASE_BACKEND != "sqlite":
            return []
        return sorted(self.backup_dir.glob("alex_erp_*.db.enc"), key=lambda p: p.stat().st_mtime, reverse=True)

    def export_encrypted_backup(self, encrypted_file: Path, destination_dir: Path) -> Path:
        """Atomically copy an encrypted backup to an external folder and verify it.

        Only encrypted artifacts are accepted. The source is never removed.
        """
        import shutil
        source = Path(encrypted_file)
        destination_dir = Path(destination_dir).expanduser()
        if source.suffix != ".enc" or not source.is_file():
            raise ValueError("يُسمح بنقل ملفات النسخ المشفرة فقط")
        if source.parent != self.backup_dir:
            raise ValueError("ملف النسخة المصدر يجب أن يكون داخل مجلد النسخ المحلي")
        destination_dir.mkdir(parents=True, exist_ok=True)
        if destination_dir == source.parent:
            raise ValueError("اختر مجلدًا خارجيًا مختلفًا عن مجلد النسخ المحلي")
        destination = destination_dir / source.name
        fd, temp_name = tempfile.mkstemp(prefix=".alex_export_", suffix=".tmp", dir=destination_dir)
        os.close(fd)
        temporary = Path(temp_name)
        try:
            shutil.copyfile(source, temporary)
            fd = os.open(temporary, os.O_RDONLY | getattr(os, "O_BINARY", 0))
            try:
                try:
                    os.fsync(fd)
                except OSError:
                    if os.name != "nt":
                        raise
            finally:
                os.close(fd)
            if self._sha256(source) != self._sha256(temporary):
                raise BackupValidationError("فشل التحقق من تطابق النسخة بعد النقل")
            os.replace(temporary, destination)
            if self._sha256(source) != self._sha256(destination):
                destination.unlink(missing_ok=True)
                raise BackupValidationError("فشل التحقق النهائي من النسخة المنقولة")
            return destination
        finally:
            temporary.unlink(missing_ok=True)

    def delete_backup(self, backup_file: Path) -> None:
        backup_file = Path(backup_file)
        # Only allow deletion of files inside this manager's backup directory.
        allowed_suffix = ".dump" if db_module.DATABASE_BACKEND == "postgresql" else ".db"
        if backup_file.resolve().parent != self.backup_dir.resolve() or backup_file.suffix != allowed_suffix:
            raise ValueError("مسار النسخة الاحتياطية غير مسموح")
        backup_file.unlink(missing_ok=True)
        backup_file.with_suffix(backup_file.suffix + ".json").unlink(missing_ok=True)
        Path(str(backup_file) + "-wal").unlink(missing_ok=True)
        Path(str(backup_file) + "-shm").unlink(missing_ok=True)

    def list_backups(self) -> list[Path]:
        pattern = "alex_erp_*.dump" if db_module.DATABASE_BACKEND == "postgresql" else "alex_erp_*.db"
        return sorted(self.backup_dir.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)

    def cleanup_automatic(self, keep_last: int = 30) -> None:
        """Prune only scheduler-created backups; manual and safety copies are never pruned."""
        if keep_last < 1:
            raise ValueError("يجب الاحتفاظ بنسخة تلقائية واحدة على الأقل")
        automatic = []
        for backup in self.list_backups():
            manifest = backup.with_suffix(backup.suffix + ".json")
            try:
                metadata = json.loads(manifest.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if metadata.get("backup_type") == "automatic":
                automatic.append(backup)
        # list_backups is newest first; never delete the newest automatic copy.
        for backup in automatic[keep_last:]:
            self.delete_backup(backup)

    def cleanup(self, keep_last: int = 20) -> None:
        if keep_last < 1:
            raise ValueError("يجب الاحتفاظ بنسخة واحدة على الأقل")
        for backup in self.list_backups()[keep_last:]:
            self.delete_backup(backup)
