"""Migrate a current SQLite database into an empty PostgreSQL database."""
from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path
from typing import Any

from alexerp.config import DATABASE_BACKEND
from alexerp.database.db import Database
from alexerp.database.postgres_compat import (
    POSTGRES_BOOTSTRAP_LOCK_ID,
    synchronize_postgresql_sequences,
)


_METADATA_TABLE = "alexerp_runtime_metadata"
_INITIAL_SEED_KEY = "initial_seed_v1"
_BATCH_SIZE = 1000


class PostgreSQLMigrationError(RuntimeError):
    """Raised when a safe SQLite-to-PostgreSQL migration cannot proceed."""


def _quote_identifier(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def _foreign_key_order(
    tables: set[str],
    dependencies: list[tuple[str, str]],
) -> list[str]:
    required = {table: set() for table in tables}
    for child, parent in dependencies:
        if child in tables and parent in tables and child != parent:
            required[child].add(parent)

    ordered: list[str] = []
    while required:
        ready = sorted(table for table, parents in required.items() if not parents)
        if not ready:
            circular = ", ".join(sorted(required))
            raise PostgreSQLMigrationError(
                f"Foreign-key cycle cannot be imported safely: {circular}"
            )
        ordered.extend(ready)
        for table in ready:
            del required[table]
        for parents in required.values():
            parents.difference_update(ready)
    return ordered


def _order_self_referencing_rows(
    rows: list[dict[str, Any]],
    foreign_keys: list[tuple[tuple[str, ...], tuple[str, ...]]],
    primary_key: tuple[str, ...],
) -> list[dict[str, Any]]:
    if not rows or not foreign_keys:
        return rows

    dependencies = {index: set() for index in range(len(rows))}
    for from_columns, to_columns in foreign_keys:
        target_columns = to_columns or primary_key
        if not target_columns or len(from_columns) != len(target_columns):
            raise PostgreSQLMigrationError(
                "A self-referencing table has an unsupported foreign key."
            )
        parent_by_key = {
            tuple(row[column] for column in target_columns): index
            for index, row in enumerate(rows)
        }
        for index, row in enumerate(rows):
            reference = tuple(row[column] for column in from_columns)
            if any(value is None for value in reference):
                continue
            parent = parent_by_key.get(reference)
            if parent is not None and parent != index:
                dependencies[index].add(parent)

    order: list[int] = []
    while dependencies:
        ready = sorted(index for index, parents in dependencies.items() if not parents)
        if not ready:
            raise PostgreSQLMigrationError(
                "Self-referencing rows contain a cycle that PostgreSQL cannot import safely."
            )
        order.extend(ready)
        for index in ready:
            del dependencies[index]
        for parents in dependencies.values():
            parents.difference_update(ready)
    return [rows[index] for index in order]


def _source_tables(connection: sqlite3.Connection) -> set[str]:
    return {
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }


def _source_foreign_keys(
    connection: sqlite3.Connection,
    tables: set[str],
) -> tuple[list[tuple[str, str]], dict[str, list[tuple[tuple[str, ...], tuple[str, ...]]]]]:
    table_dependencies: list[tuple[str, str]] = []
    self_references: dict[
        str, list[tuple[tuple[str, ...], tuple[str, ...]]]
    ] = {}
    for table in tables:
        quoted_table = _quote_identifier(table)
        rows = connection.execute(
            f"PRAGMA foreign_key_list({quoted_table})"
        ).fetchall()
        grouped: dict[
            int, list[tuple[int, str, str | None, str | None]]
        ] = {}
        for row in rows:
            grouped.setdefault(int(row[0]), []).append(
                (int(row[1]), str(row[2]), row[3], row[4])
            )
        for foreign_key in grouped.values():
            foreign_key.sort(key=lambda item: item[0])
            parent = foreign_key[0][1]
            table_dependencies.append((table, parent))
            if parent == table:
                from_columns = tuple(item[2] for item in foreign_key)
                to_values = tuple(item[3] for item in foreign_key)
                if any(column is None for column in from_columns):
                    raise PostgreSQLMigrationError(
                        "A self-referencing table has an unnamed foreign-key column."
                    )
                if any(column is None for column in to_values) and any(
                    column is not None for column in to_values
                ):
                    raise PostgreSQLMigrationError(
                        "A self-referencing composite foreign key is incomplete."
                    )
                self_references.setdefault(table, []).append(
                    (
                        tuple(str(column) for column in from_columns),
                        tuple(str(column) for column in to_values if column is not None),
                    )
                )
    return table_dependencies, self_references


def _primary_key_columns(
    connection: sqlite3.Connection,
    table: str,
) -> tuple[str, ...]:
    columns = connection.execute(
        f"PRAGMA table_info({_quote_identifier(table)})"
    ).fetchall()
    return tuple(
        row[1]
        for row in sorted((row for row in columns if row[5]), key=lambda row: row[5])
    )


def _target_tables(connection) -> set[str]:
    return {
        row[0]
        for row in connection.execute(
            """SELECT table_name FROM information_schema.tables
               WHERE table_schema=current_schema() AND table_type='BASE TABLE'"""
        ).fetchall()
    }


def _assert_target_empty(connection, tables: set[str]) -> None:
    for table in tables:
        quoted_table = _quote_identifier(table)
        count = int(
            connection.execute(
                f"SELECT COUNT(*) FROM {quoted_table}"
            ).fetchone()[0]
        )
        if count and table != "inventory_schema_migrations":
            raise PostgreSQLMigrationError(
                f"Target table {table!r} is not empty; migration was not started."
            )


def _validate_source(path: Path) -> sqlite3.Connection:
    if not path.is_file():
        raise FileNotFoundError(str(path))
    connection = sqlite3.connect(
        path.resolve().as_uri() + "?mode=ro",
        uri=True,
        detect_types=sqlite3.PARSE_DECLTYPES,
    )
    try:
        integrity = [row[0] for row in connection.execute("PRAGMA integrity_check")]
        if integrity != ["ok"]:
            raise PostgreSQLMigrationError(
                "SQLite integrity check failed: " + "; ".join(integrity[:5])
            )
        foreign_key_errors = connection.execute("PRAGMA foreign_key_check").fetchall()
        if foreign_key_errors:
            raise PostgreSQLMigrationError(
                f"SQLite source has {len(foreign_key_errors)} foreign-key violations."
            )
        return connection
    except Exception:
        connection.close()
        raise


def _validate_table_columns(source, target, table: str) -> list[str]:
    source_info = source.execute(
        f"PRAGMA table_info({_quote_identifier(table)})"
    ).fetchall()
    source_columns = [row[1] for row in source_info]
    target_info = target.execute(
        """SELECT column_name, is_nullable, column_default, is_identity, is_generated
           FROM information_schema.columns
           WHERE table_schema=current_schema() AND table_name=?""",
        (table,),
    ).fetchall()
    target_columns = {row[0]: row for row in target_info}
    unknown = set(source_columns) - set(target_columns)
    if unknown:
        raise PostgreSQLMigrationError(
            f"Source table {table!r} has columns absent from the PostgreSQL schema: "
            + ", ".join(sorted(unknown))
        )
    missing_required = [
        column
        for column, nullable, default, identity, generated in target_info
        if column not in source_columns
        and nullable == "NO"
        and default is None
        and identity == "NO"
        and generated == "NEVER"
    ]
    if missing_required:
        raise PostgreSQLMigrationError(
            f"Source table {table!r} lacks required PostgreSQL columns: "
            + ", ".join(sorted(missing_required))
        )
    return source_columns


def _copy_table(
    source: sqlite3.Connection,
    target,
    table: str,
    columns: list[str],
    self_references: list[tuple[tuple[str, ...], tuple[str, ...]]],
) -> int:
    quoted_table = _quote_identifier(table)
    quoted_columns = ", ".join(_quote_identifier(column) for column in columns)
    placeholders = ", ".join("?" for _ in columns)
    insert_sql = (
        f"INSERT INTO {quoted_table} ({quoted_columns}) "
        f"VALUES ({placeholders})"
    )
    source_cursor = source.execute(f"SELECT {quoted_columns} FROM {quoted_table}")
    copied = 0

    if self_references:
        rows = [
            dict(zip(columns, row))
            for row in source_cursor.fetchall()
        ]
        rows = _order_self_referencing_rows(
            rows, self_references, _primary_key_columns(source, table)
        )
        target.executemany(
            insert_sql,
            [tuple(row[column] for column in columns) for row in rows],
        )
        return len(rows)

    while True:
        rows = source_cursor.fetchmany(_BATCH_SIZE)
        if not rows:
            break
        target.executemany(insert_sql, rows)
        copied += len(rows)
    return copied


def migrate_sqlite_to_postgresql(source_path: Path) -> dict[str, int]:
    """Copy an integrity-checked SQLite database into an empty PostgreSQL schema."""
    if DATABASE_BACKEND != "postgresql":
        raise PostgreSQLMigrationError(
            "Set ALEXERP_DATABASE_BACKEND=postgresql before running this migration."
        )

    source_path = Path(source_path).expanduser().resolve()
    source = _validate_source(source_path)
    source_tables = _source_tables(source)
    target = Database.connect()
    lock_acquired = False
    try:
        target.execute(
            "SELECT pg_advisory_lock(?)", (POSTGRES_BOOTSTRAP_LOCK_ID,)
        ).fetchone()
        lock_acquired = True
        target.commit()

        _assert_target_empty(target, _target_tables(target))
        from alexerp.database.schema import create_database

        create_database()
        target_tables = _target_tables(target)
        _assert_target_empty(target, target_tables)
        target.execute(
            """CREATE TABLE IF NOT EXISTS alexerp_runtime_metadata (
                   metadata_key TEXT PRIMARY KEY,
                   metadata_value TEXT NOT NULL
               )"""
        )
        target.commit()
        target_tables.discard(_METADATA_TABLE)

        unknown_tables = source_tables - target_tables
        if unknown_tables:
            raise PostgreSQLMigrationError(
                "SQLite source contains tables absent from the application schema: "
                + ", ".join(sorted(unknown_tables))
            )
        missing_tables = target_tables - source_tables
        if missing_tables:
            raise PostgreSQLMigrationError(
                "SQLite source schema is older than the current application schema. "
                "Open it once with the current SQLite version to apply migrations, "
                "then retry. Missing tables: " + ", ".join(sorted(missing_tables))
            )

        dependencies, self_references = _source_foreign_keys(source, source_tables)
        table_order = _foreign_key_order(source_tables, dependencies)
        table_columns = {
            table: _validate_table_columns(source, target, table)
            for table in source_tables
        }

        truncate_tables = ", ".join(
            _quote_identifier(table) for table in sorted(target_tables)
        )
        if truncate_tables:
            target.execute(
                f"TRUNCATE TABLE {truncate_tables} RESTART IDENTITY CASCADE"
            )

        counts: dict[str, int] = {}
        for table in table_order:
            counts[table] = _copy_table(
                source,
                target,
                table,
                table_columns[table],
                self_references.get(table, []),
            )
            count_row = target.execute(
                f"SELECT COUNT(*) FROM {_quote_identifier(table)}"
            ).fetchone()
            if count_row is None:
                raise PostgreSQLMigrationError(
                    f"Could not verify the migrated row count for {table!r}."
                )
            target_count = int(count_row[0])
            if target_count != counts[table]:
                raise PostgreSQLMigrationError(
                    f"Row-count mismatch for {table!r}: "
                    f"SQLite={counts[table]}, PostgreSQL={target_count}."
                )

        synchronize_postgresql_sequences(target, commit=False)
        target.execute(
            """INSERT INTO alexerp_runtime_metadata(metadata_key, metadata_value)
               VALUES(?, ?)
               ON CONFLICT(metadata_key) DO UPDATE SET metadata_value=excluded.metadata_value""",
            (_INITIAL_SEED_KEY, "complete"),
        )
        target.commit()
        return counts
    except Exception:
        if target.in_transaction:
            target.rollback()
        raise
    finally:
        source.close()
        if lock_acquired:
            if target.in_transaction:
                target.rollback()
            target.execute(
                "SELECT pg_advisory_unlock(?)", (POSTGRES_BOOTSTRAP_LOCK_ID,)
            ).fetchone()
            target.commit()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Copy an integrity-checked SQLite database to PostgreSQL."
    )
    parser.add_argument("sqlite_database", type=Path)
    args = parser.parse_args()
    counts = migrate_sqlite_to_postgresql(args.sqlite_database)
    print(f"Migration complete: {sum(counts.values())} rows across {len(counts)} tables.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
