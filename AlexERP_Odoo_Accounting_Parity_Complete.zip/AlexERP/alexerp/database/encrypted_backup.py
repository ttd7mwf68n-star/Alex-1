"""Password-based encryption for portable AlexERP backup files.

The password is never persisted. The encrypted file uses PBKDF2-HMAC-SHA256
and Fernet (AES-128-CBC + HMAC-SHA256). Keep the password separately from backups.
"""
from __future__ import annotations

import hashlib
import os
import tempfile
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

MAGIC = b"ALEXERP-ENC-BACKUP-1\n"
SALT_SIZE = 16
ITERATIONS = 600_000


class EncryptedBackupError(ValueError):
    """Encrypted backup is invalid or cannot be authenticated."""


def _fernet(password: str, salt: bytes) -> Fernet:
    if not isinstance(password, str) or len(password) < 12:
        raise ValueError("كلمة مرور النسخة المشفرة يجب ألا تقل عن 12 حرفًا")
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=ITERATIONS)
    import base64
    return Fernet(base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8"))))


def encrypt_backup(source: Path, password: str, destination: Path | None = None) -> Path:
    source = Path(source)
    if not source.is_file() or source.stat().st_size == 0:
        raise FileNotFoundError(str(source))
    destination = Path(destination) if destination else source.with_suffix(source.suffix + ".enc")
    destination.parent.mkdir(parents=True, exist_ok=True)
    salt = os.urandom(SALT_SIZE)
    payload = MAGIC + salt + _fernet(password, salt).encrypt(source.read_bytes())
    fd, tmp_name = tempfile.mkstemp(prefix=".alex_enc_", suffix=".tmp", dir=destination.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp_name, destination)
    except Exception:
        Path(tmp_name).unlink(missing_ok=True)
        raise
    return destination


def decrypt_backup(source: Path, password: str) -> bytes:
    source = Path(source)
    try:
        payload = source.read_bytes()
    except OSError as exc:
        raise EncryptedBackupError("تعذر قراءة ملف النسخة المشفرة") from exc
    if not payload.startswith(MAGIC) or len(payload) <= len(MAGIC) + SALT_SIZE:
        raise EncryptedBackupError("صيغة ملف النسخة المشفرة غير صحيحة")
    offset = len(MAGIC)
    salt = payload[offset:offset + SALT_SIZE]
    try:
        return _fernet(password, salt).decrypt(payload[offset + SALT_SIZE:])
    except (InvalidToken, ValueError) as exc:
        raise EncryptedBackupError("كلمة المرور غير صحيحة أو الملف تعرض للتلف") from exc
