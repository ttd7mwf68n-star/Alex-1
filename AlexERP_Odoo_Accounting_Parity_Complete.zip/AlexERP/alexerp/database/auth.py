"""Versioned password hashing with transparent legacy-hash migration."""
from __future__ import annotations

import hashlib
import hmac
import secrets


class PasswordManager:
    """PBKDF2 password hashing; new hashes carry their algorithm parameters."""

    ALGORITHM = "pbkdf2_sha256"
    ITERATIONS = 310_000
    LEGACY_ITERATIONS = 120_000
    SALT_BYTES = 16
    MAX_PASSWORD_LENGTH = 1024

    @classmethod
    def validate_password(cls, password: str, *, minimum: int = 12) -> None:
        if not isinstance(password, str):
            raise ValueError("كلمة المرور يجب أن تكون نصًا صالحًا.")
        if len(password) < minimum:
            raise ValueError(f"كلمة المرور يجب ألا تقل عن {minimum} حرفًا.")
        if len(password) > cls.MAX_PASSWORD_LENGTH:
            raise ValueError("كلمة المرور أطول من الحد المسموح.")

    @classmethod
    def hash_password(cls, password: str) -> str:
        if not isinstance(password, str) or len(password) > cls.MAX_PASSWORD_LENGTH:
            raise ValueError("Invalid password length.")
        salt = secrets.token_bytes(cls.SALT_BYTES)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, cls.ITERATIONS)
        return f"{cls.ALGORITHM}${cls.ITERATIONS}${salt.hex()}${digest.hex()}"

    @classmethod
    def verify_password(cls, password: str, stored_password: str) -> bool:
        if not isinstance(password, str) or len(password) > cls.MAX_PASSWORD_LENGTH:
            return False
        if not isinstance(stored_password, str):
            return False
        try:
            parts = stored_password.split("$")
            if len(parts) == 4 and parts[0] == cls.ALGORITHM:
                iterations = int(parts[1])
                if not cls.LEGACY_ITERATIONS <= iterations <= 2_000_000:
                    return False
                salt = bytes.fromhex(parts[2])
                saved_hash = bytes.fromhex(parts[3])
            elif len(parts) == 2:  # Existing releases: salt$hash, 120k rounds.
                iterations = cls.LEGACY_ITERATIONS
                salt = parts[0].encode("utf-8")
                saved_hash = bytes.fromhex(parts[1])
            else:
                return False
            if not salt or len(saved_hash) != 32:
                return False
            current = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
            return hmac.compare_digest(saved_hash, current)
        except (ValueError, TypeError, OverflowError):
            return False

    @classmethod
    def needs_rehash(cls, stored_password: str) -> bool:
        if not isinstance(stored_password, str):
            return True
        parts = stored_password.split("$")
        if len(parts) != 4 or parts[0] != cls.ALGORITHM:
            return True
        try:
            return int(parts[1]) < cls.ITERATIONS
        except ValueError:
            return True
