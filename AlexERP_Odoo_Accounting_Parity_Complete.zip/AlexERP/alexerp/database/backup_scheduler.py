"""Daily local backup scheduler. Runs only while an app runtime is alive."""
from __future__ import annotations
import json
import logging
import os
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Callable

from alexerp.database.backup import BackupManager

log = logging.getLogger(__name__)

class DailyBackupScheduler:
    def __init__(self, manager: BackupManager | None = None, *, hour: int = 2, minute: int = 0,
                 interval_seconds: int = 30, keep_last: int = 30,
                 clock: Callable[[], datetime] = datetime.now):
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError("وقت النسخ الاحتياطي غير صالح")
        self.manager = manager or BackupManager()
        self.hour, self.minute = hour, minute
        self.interval_seconds = max(1, int(interval_seconds))
        self.keep_last = max(1, int(keep_last))
        self.clock = clock
        self.state_file = self.manager.backup_dir / ".daily_backup_state.json"
        self.lock_file = self.manager.backup_dir / ".daily_backup.lock"
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._run_lock = threading.Lock()
        self.last_status = "لم يتم تنفيذ نسخة تلقائية بعد"
        self.last_success = self._read_state().get("last_success")

    def _read_state(self) -> dict:
        try:
            data = json.loads(self.state_file.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def _write_state(self, data: dict) -> None:
        temp = self.state_file.with_suffix(".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, self.state_file)

    def run_if_due(self, now: datetime | None = None) -> bool:
        now = now or self.clock()
        day = now.date().isoformat()
        if (now.hour, now.minute) < (self.hour, self.minute):
            return False
        if self._read_state().get("last_success") == day:
            return False
        if not self._run_lock.acquire(blocking=False):
            return False
        lock_fd = None
        try:
            # O_EXCL also prevents a second application process from duplicating today's backup.
            try:
                lock_fd = os.open(self.lock_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                os.write(lock_fd, str(os.getpid()).encode("ascii"))
            except FileExistsError:
                # Recover only demonstrably stale locks (owner process no longer exists).
                try:
                    pid = int(self.lock_file.read_text(encoding="ascii"))
                    os.kill(pid, 0)
                except ProcessLookupError:
                    self.lock_file.unlink(missing_ok=True)
                    try:
                        lock_fd = os.open(self.lock_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                        os.write(lock_fd, str(os.getpid()).encode("ascii"))
                    except (FileExistsError, OSError):
                        return False
                except (ValueError, PermissionError, OSError):
                    return False
                else:
                    return False
            # Recheck after acquiring cross-process lock.
            if self._read_state().get("last_success") == day:
                return False
            backup = self.manager.create_backup(backup_type="automatic")
            # Persist success immediately: a retention cleanup problem must not
            # cause a second daily backup on the next scheduler tick.
            state = self._read_state()
            state.update(last_success=day, last_backup=backup.name, last_error=None)
            self._write_state(state)
            self.last_success = day
            self.last_status = f"آخر نسخة تلقائية ناجحة: {day}"
            log.info("Daily backup created: %s", backup)
            try:
                self.manager.cleanup_automatic(keep_last=self.keep_last)
            except Exception:
                log.exception("Automatic backup retention cleanup failed")
            return True
        except Exception as exc:
            self.last_status = f"فشل النسخ التلقائي: {exc}"
            log.exception("Daily backup failed")
            try:
                state = self._read_state(); state["last_error"] = str(exc); self._write_state(state)
            except Exception:
                log.exception("Could not persist daily backup failure")
            return False
        finally:
            if lock_fd is not None:
                os.close(lock_fd)
                self.lock_file.unlink(missing_ok=True)
            self._run_lock.release()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="AlexERP-DailyBackup", daemon=True)
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.is_set():
            self.run_if_due()
            self._stop.wait(self.interval_seconds)

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=max(2, self.interval_seconds + 1))
        self._thread = None

    def status(self) -> dict:
        return {"enabled": True, "schedule_local": f"{self.hour:02d}:{self.minute:02d}",
                "last_success": self.last_success, "status": self.last_status,
                "runs_while_app_open": True}
