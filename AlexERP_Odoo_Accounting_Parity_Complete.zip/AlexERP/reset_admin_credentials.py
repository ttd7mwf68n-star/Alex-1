"""One-time helper: set the local AlexERP administrator login to admin/admin.

Run from the project root:
    python reset_admin_credentials.py

This changes only the local SQLite database configured by alexerp.config.
"""
from alexerp.database.auth import PasswordManager
from alexerp.database.transaction import transaction


def main() -> None:
    password_hash = PasswordManager.hash_password("admin")
    with transaction() as conn:
        user = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()
        if user is None:
            raise SystemExit("لم يتم العثور على حساب admin. شغّل تهيئة قاعدة البيانات أولاً.")
        user_id = int(user["id"])
        conn.execute(
            "UPDATE users SET password_hash=?, failed_login_attempts=0, locked_until=NULL, "
            "password_changed_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (password_hash, user_id),
        )
        # Force a fresh login on every device after credential reset.
        conn.execute(
            "UPDATE user_sessions SET is_active=0, logout_time=CURRENT_TIMESTAMP "
            "WHERE user_id=? AND is_active=1",
            (user_id,),
        )
    print("تم ضبط بيانات الدخول: username=admin / password=admin")
    print("تحذير: غيّر كلمة المرور فور تسجيل الدخول، ولا تستخدم هذه البيانات على نظام منشور.")


if __name__ == "__main__":
    main()
