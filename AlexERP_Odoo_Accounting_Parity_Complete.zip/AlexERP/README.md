# Alex ERP

نظام إدارة أعمال مبني على Python، بواجهة سطح مكتب باستخدام CustomTkinter، وقاعدة بيانات SQLite مع دعم PostgreSQL، بالإضافة إلى واجهة ويب/موبايل.

## التشغيل

من المجلد الرئيسي للمشروع `AlexERP`:

```bash
python -m pip install -r requirements.txt
python -m alexerp.main
```

لتشغيل خادم الويب/الموبايل:

```bash
python mobile_web/mobile_server.py
```

## تنظيم المشروع

- `alexerp/core/`: الثوابت والسياق والتحقق والأدوات المشتركة.
- `alexerp/database/`: الاتصال والمعاملات والترحيلات والنسخ الاحتياطي ومخططات الجداول.
- `alexerp/repositories/`: استعلامات الوصول للبيانات.
- `alexerp/services/`: قواعد العمل ودورات المستندات.
- `alexerp/ui/`: شاشات سطح المكتب ومكوناتها.
- `alexerp/exports/`: تصدير التقارير.
- `alexerp/ai/`: تكاملات المساعد الذكي.
- `alexerp/tests/`: اختبارات الانحدار.
- `mobile_web/`: خادم واجهة الويب والموبايل.
- `docs/reports/`: تقارير وملاحظات مراحل التطوير السابقة.

## ملاحظات أمان وتشغيل

- لا تضع ملف `.env` أو مفاتيح API أو كلمات مرور داخل ملفات التوزيع.
- مجلد `alexerp/data/` و`alexerp/backups/` يحتويان بيانات تشغيل ونسخًا احتياطية. يجب حمايتهما وعدم رفعهما إلى مستودع عام.
- شهادة TLS ومفتاحها المحليان داخل `alexerp/data/tls/` مخصصان للتشغيل المحلي. لا تعِد استخدام المفتاح الخاص في بيئة إنتاج مشتركة.
- خذ نسخة احتياطية قابلة للاستعادة قبل أي ترحيل أو تحديث على قاعدة بيانات العمل.

## سجل التطبيقات (Module Registry)

تعريفات وحدات الأعمال موجودة في `alexerp/modules/manifests/`، ويحتوي كل ملف JSON على هوية الوحدة ووصفها وصلاحياتها واعتمادياتها. يتم التحقق منها عبر `alexerp.core.module_registry.ModuleRegistry`.

السجل حاليًا وصفي وتدقيقي فقط؛ لا يقوم بتثبيت التطبيقات أو تحميلها ديناميكيًا، ولا يحل محل فحوص الصلاحيات الحالية.

## Module catalog and manifest validation

Application metadata is stored under `alexerp/modules/manifests/` and validated by `alexerp/core/module_registry.py`. The registry is currently read-only: it audits module metadata and does not install, upgrade, or dynamically activate modules. See `docs/reports/PHASE5_MODULE_CATALOG_HARDENING_AR.md` for the latest validation scope and test results.
